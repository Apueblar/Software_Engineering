

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.Cecy-ZUo.js","_app/immutable/chunks/oc7Qw1OF.js","_app/immutable/chunks/DnLu3DwL.js","_app/immutable/chunks/6FvQZ0GU.js","_app/immutable/chunks/CFpd1QAU.js","_app/immutable/chunks/CP6Jtm_6.js","_app/immutable/chunks/D-bbJ390.js"];
export const stylesheets = [];
export const fonts = [];
