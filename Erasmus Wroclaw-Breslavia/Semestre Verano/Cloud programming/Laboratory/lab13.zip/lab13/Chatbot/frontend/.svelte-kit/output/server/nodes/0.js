

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.M6oZVpNm.js","_app/immutable/chunks/oc7Qw1OF.js","_app/immutable/chunks/DnLu3DwL.js"];
export const stylesheets = ["_app/immutable/assets/0.BRrtow_v.css"];
export const fonts = [];
