export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.C4GWS3ZL.js",app:"_app/immutable/entry/app.C4nPFsN9.js",imports:["_app/immutable/entry/start.C4GWS3ZL.js","_app/immutable/chunks/CP6Jtm_6.js","_app/immutable/chunks/DnLu3DwL.js","_app/immutable/chunks/D-bbJ390.js","_app/immutable/entry/app.C4nPFsN9.js","_app/immutable/chunks/DnLu3DwL.js","_app/immutable/chunks/CFpd1QAU.js","_app/immutable/chunks/oc7Qw1OF.js","_app/immutable/chunks/CkgipOMe.js","_app/immutable/chunks/D-bbJ390.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:true},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
