

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.KU999LTw.js","_app/immutable/chunks/oc7Qw1OF.js","_app/immutable/chunks/DnLu3DwL.js","_app/immutable/chunks/6FvQZ0GU.js","_app/immutable/chunks/CFpd1QAU.js","_app/immutable/chunks/CkgipOMe.js","_app/immutable/chunks/D-bbJ390.js"];
export const stylesheets = [];
export const fonts = [];
