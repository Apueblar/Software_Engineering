import{l as o,a as r}from"../chunks/CP6Jtm_6.js";export{o as load_css,r as start};
