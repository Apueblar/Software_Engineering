import { e as ensure_array_like, c as pop, p as push } from "../../chunks/index.js";
import axios from "axios";
import { p as public_env } from "../../chunks/shared-server.js";
import { e as escape_html } from "../../chunks/escaping.js";
import "clsx";
const replacements = {
  translate: /* @__PURE__ */ new Map([
    [true, "yes"],
    [false, "no"]
  ])
};
function attr(name, value, is_boolean = false) {
  if (value == null || !value && is_boolean) return "";
  const normalized = name in replacements && replacements[name].get(value) || value;
  const assignment = is_boolean ? "" : `="${escape_html(normalized, true)}"`;
  return ` ${name}${assignment}`;
}
axios.create({
  baseURL: public_env.PUBLIC_API_BASE_URL
});
function _page($$payload, $$props) {
  push();
  let username = "User" + Math.floor(Math.random() * 1e3);
  let newMessage = "";
  let messages = [];
  const each_array = ensure_array_like(messages);
  $$payload.out += `<div class="max-w-2xl mx-auto p-4"><div class="mb-4 flex items-center"><label for="username" class="font-semibold mr-2">Nickname:</label> <input id="username" type="text" autocomplete="off"${attr("value", username)} class="border border-gray-300 rounded px-3 py-2" placeholder="Enter your nickname"></div> <h1 class="text-2xl font-bold mb-4">Chat Room</h1> <div class="border border-gray-300 rounded p-4 mb-4 h-80 overflow-y-auto"><!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let msg = each_array[$$index];
    $$payload.out += `<div class="mb-2"><span class="font-semibold">${escape_html(msg.username)}</span> <span class="text-sm text-gray-500 ml-2">${escape_html(new Date(msg.timestamp).toLocaleTimeString())}</span> <p>${escape_html(msg.message)}</p></div>`;
  }
  $$payload.out += `<!--]--></div> <div class="flex space-x-2"><input type="text"${attr("value", newMessage)} class="flex-grow border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring" placeholder="Type your message..."> <button class="cursor-pointer bg-blue-500 hover:bg-blue-600 text-white font-semibold px-4 py-2 rounded">Send</button> <button class="cursor-pointer bg-red-500 hover:bg-red-600 text-white font-semibold px-4 py-2 rounded">Clear Chat</button></div></div>`;
  pop();
}
export {
  _page as default
};
