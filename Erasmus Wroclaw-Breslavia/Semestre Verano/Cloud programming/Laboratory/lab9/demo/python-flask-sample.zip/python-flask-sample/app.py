import os 
from flask import Flask, render_template
from dotenv import load_dotenv

load_dotenv()
username = os.getenv("USER_NAME", "Guest")

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("home.html", username=username)

@app.route("/about")
def about():
    return render_template("about.html")
