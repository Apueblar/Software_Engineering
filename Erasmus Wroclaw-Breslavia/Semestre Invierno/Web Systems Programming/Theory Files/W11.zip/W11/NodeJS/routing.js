const http = require('http');
// file: routing.js
// source: https://www.scholarhat.com/tutorial/nodejs/nodejs-and-expressjs
const server = http.createServer((req, res) => {
  if (req.url === '/') {
    res.statusCode = 200;
    res.end('Home Page');
  } else if (req.url === '/about') {
    res.statusCode = 200;
    res.end('About Page');
  } else {
    res.statusCode = 404;
    res.end('Page Not Found');  
  }
});

server.listen(3000, () => {
  console.log('Server running at http://localhost:3000/');
});