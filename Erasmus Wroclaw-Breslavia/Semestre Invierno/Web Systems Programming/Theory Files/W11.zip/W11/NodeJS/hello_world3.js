var http = require('http');
var fs = require('fs');
// file: hello_world3.js
var text_html="";
  fs.readFile('first.html', 'utf8', (err, first) => {
    if (err) {
      console.error('Error reading file:', err);
      return;
    }
    text_html=text_html+first;
    return ;
  });
    text_html=text_html+'<H1>Hello World!</H1>';
    text_html=text_html+'<p>** 2025/2026 **</p>';
    text_html=text_html+'<p>Asynchronously reads the entire contents of files.</p>';

  fs.readFile('last.html', 'utf8', (err, last) => {
    if (err) {
      console.error('Error reading file:', err);
      return;
    }
    text_html=text_html+last;
    return ;
  });
http.createServer(function (req, res) {
  //Open a file on the server and return its content:
  //console.log('File content all:', text_html);
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write(text_html);
  res.end()
}).listen(8080);