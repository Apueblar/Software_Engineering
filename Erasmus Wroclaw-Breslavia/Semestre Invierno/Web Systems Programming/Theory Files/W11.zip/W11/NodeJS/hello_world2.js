var http = require('http');
var fs = require('fs');
// file: hello_world2.js
var text_html="";
try {
  // Read file synchronously
  const first = fs.readFileSync('first.html', 'utf8');
    text_html=text_html+first;
} catch (err) {
  console.error('Error reading file:', err);
}
  text_html=text_html+'<H1>Hello World!</H1>';
  text_html=text_html+'<p>** 2025 **</p>';
  text_html=text_html+'<p>Synchronously reads the entire contents of files.</p>';
try {
  // Read file synchronously
  const last = fs.readFileSync('last.html', 'utf8');
    text_html=text_html+last;
} catch (err) {
  console.error('Error reading file:', err);
}

http.createServer(function (req, res) {
  //Open a file on the server and return its content:
//  console.log('File content all:', text_html);
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write(text_html);
  res.end()
}).listen(8080);
