var http = require('http');
var fs = require('fs');
// file: demo_file.js
// source: https://www.w3schools.com/nodejs/
http.createServer(function (req, res) {
  //Open a file on the server and return its content:
  fs.readFile('demo_file.html', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      return;
    }
    console.log('File content:', data);
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    return res.end();
  });
}).listen(8080);