var http = require('http');
// file: year_month.js
http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});

  // In the new standard, the URL requires the full address (including the host)
  // req.url is just a path (e.g., /?year=2026), so we add the database
  const baseURL = 'http://' + req.headers.host;
  const myUrl = new URL(req.url, baseURL);

  // We get query parameters
  const q = myUrl.searchParams;
  const year = q.get('year') || "";
  const month = q.get('month') || "";
  const day = q.get('day') || "";

  // We are building an answer
  let txt = `${year} ${month} ${day}<br>`;
  
  // We get the properties from the myUrl object, not from req
  txt += myUrl.host + " " + myUrl.pathname + " " + myUrl.search;

  res.end(txt);
}).listen(8080);

console.log('Serwer działa na http://localhost:8080');
