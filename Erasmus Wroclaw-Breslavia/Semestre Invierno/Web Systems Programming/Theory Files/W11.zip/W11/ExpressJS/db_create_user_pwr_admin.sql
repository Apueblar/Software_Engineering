-- 1. Create a new user with a specific password
CREATE USER 'pwr_admin'@'localhost' IDENTIFIED BY 'admin12345';

-- 2. Grant all privileges on the 'pwr' database only
-- This is more secure than giving access to everything
GRANT ALL PRIVILEGES ON pwr.* TO 'pwr_admin'@'localhost';

-- 3. Apply the changes immediately
FLUSH PRIVILEGES;
