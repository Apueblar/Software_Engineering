const express = require('express');
const app = express();
// file: ex_routing.js
// source: https://www.scholarhat.com/tutorial/nodejs/nodejs-and-expressjs

app.get('/', (req, res) => {
  res.send('Home Page');
});

app.get('/about', (req, res) => {
  res.send('About Page');
});

app.use((req, res) => {
  res.status(404).send('Page Not Found');
});

app.listen(3000, () => {
  console.log('Server running at http://localhost:3000/');
});