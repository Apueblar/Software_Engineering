const express = require('express'); 
const fs = require('fs');
const app = express();              
const port = 3000;                  
// file: form_ex.js

// Form parser (Content-Type: application/x-www-form-urlencoded)
app.use(express.urlencoded({ extended: true }));

// Everything from the public folder will be available 
// immediately in this css/style.css
app.use(express.static('public'));

app.get('/form.html', (req, res) => {
  res.send(fs.readFileSync('form_ex.html', 'utf8'));
});

let generateTableBody=function(req){
  let data=req.body; // data from body of request
//  let data=req.query; // data from query string of request
  let text=`<tr><td>First name</td><td>${data.fname}</td></tr>`;
  text+=`<tr><td>Last name</td><td>${data.lname}</td></tr>`;
  text+=`<tr><td>Index number</td><td>${data.index_no}</td></tr>`;
  text+=`<tr><td>Is active</td><td>${data.is_active}</td></tr>`;
  return text;
}

app.post('/show.html', (req, res) => {
//app.get('/show.html', (req, res) => {
  let text=fs.readFileSync('form_table.html', 'utf8')
  let asTable=generateTableBody(req);
  text=text.replace("{mydata}",asTable);
  res.send(text);
});

app.use((req, res) => {
  res.status(404).send('Page Not Found');
});

app.listen(port, () => {
  console.log('Server running at http://localhost:3000/');
});
