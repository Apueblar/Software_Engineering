-- ==========================================================
-- DATABASE INITIALIZATION SCRIPT - PWR STUDENTS SYSTEM
-- ==========================================================

-- Create the database if it doesn't already exist
CREATE DATABASE IF NOT EXISTS pwr;
USE pwr;

-- Table structure for 'students'
-- Note: MySQL uses TINYINT(1) to represent Boolean values (0 = false, 1 = true)
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    n_index INT NOT NULL,              -- Student ID number (numeric)
    is_active TINYINT(1) DEFAULT 1     -- Boolean flag for active status
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/* ALTERNATIVE VERSION (Fresh Start):
   DROP TABLE IF EXISTS students;
   -- followed by the CREATE TABLE block above
*/

-- Insert international test data
INSERT INTO students (first_name, last_name, n_index, is_active) VALUES 
('John', 'Doe', 112233, 1),        -- Active student (USA)
('Sato', 'Yuki', 223344, 1),       -- Active student (Japan)
('Maria', 'Garcia', 334455, 0),    -- Inactive student (Spain)
('Hans', 'Müller', 445566, 1),     -- Active student (Germany)
('Elena', 'Popova', 556677, 0);    -- Inactive student (Bulgaria)

-- Verify the data was inserted correctly
SELECT * FROM students;