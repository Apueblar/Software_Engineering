// --- SECTION 1: Configuration & Imports ---
// file: db_ex.js

const express = require('express');
const fs = require('fs'); 	// for fs.ReadFile()
const path = require('path');   // path.join()
const mysql = require('mysql2');
const app = express();              // Tworzymy instancję aplikacji
const port = 3000;                  // Ustalamy numer portu

var db = mysql.createConnection({
    host: "localhost", 
    user: "pwr_admin",
    port: 3306,
    password: "admin12345", 
    database: "pwr",
    });

// Parser for forms (Content-Type: application/x-www-form-urlencoded)
app.use(express.urlencoded({ extended: true }));
// Everything in the 'public' folder will be available immediately
app.use(express.static('public'));

// --- SECTION 2: Routes Definition (The "Instructions") ---

let generateStudentsRows=function(db_result){

}

app.get('/students', (req, res) => {
    fs.readFile(path.join(__dirname, 'student_index.html'), 'utf-8', (err, htmlTemplate) => {       
        db.query("SELECT * FROM students", (err, result) => {
            
// Map SQL results to HTML table rows
const tableRows = result.map(student => {
    // 1. Determine status label and CSS classes based on 'is_active' (0 or 1)
    const statusLabel = student.is_active ? 'Active' : 'Inactive';
    
    // Class for the status badge (green or red)
    const badgeClass = student.is_active ? 'badge-active' : 'badge-inactive';
    
    // Class for the entire row (e.g., to make inactive students look "faded")
    const rowClass = student.is_active ? 'row-active' : 'row-dimmed';

    return `
        <tr class="${rowClass}">
            <td>${student.first_name}</td>
            <td>${student.last_name}</td>
            <td>${student.n_index}</td>
            <td>
                <span class="status-badge ${badgeClass}">${statusLabel}</span>
            </td>
            <td>
                <a href="/students/view/${student.id}" class="view-btn">View Details</a>
            </td>
        </tr>
    `;
}).join('');

// Now replace the placeholder in your template
const finalPage = htmlTemplate.replace("{allStudentsView}", tableRows);
res.send(finalPage);
        });
    });
});

app.get('/students/add', (req, res) => {
  res.send(fs.readFileSync('student_add.html', 'utf8'));
});

// Remember to have app.use(express.urlencoded({ extended: true })); at the top!
app.post('/students/add', (req, res) => {
    const firstNameFromForm = req.body.fname; // names from form
    const lastNameFromForm = req.body.lname;
    const indexNumberFromForm = req.body.index_no;
    
    // Radio buttons send the 'value' as a string ("1" or "0")
    const isActiveStatus = parseInt(req.body.is_active); 

    // 2. Prepare SQL with DATABASE column names
    const sql = "INSERT INTO students (first_name, last_name, n_index, is_active) VALUES (?, ?, ?, ?)";
    
    // 3. Map form variables to SQL placeholders
    const values = [
        firstNameFromForm, 
        lastNameFromForm, 
        indexNumberFromForm, 
        isActiveStatus
    ];

    db.query(sql, values, (err, result) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).send("Could not add student to database.");
        }

        console.log(`Success! New student added with DB ID: ${result.insertId}`);
        
        // 4. Redirect back to the main list
        res.redirect('/students');
    });
});

app.get('/students/view/:id', (req, res) => {
    const studentId = req.params.id;

    // 1. Read the template file
    fs.readFile('./student_view.html', 'utf8', (err, htmlTemplate) => {
        if (err) {
            return res.status(500).send("Template file missing.");
        }

        // 2. Fetch the specific student from the database
        const sql = "SELECT * FROM students WHERE id = ?";
        db.query(sql, [studentId], (err, result) => {
            if (err) return res.status(500).send("Database error.");
            
            if (result.length === 0) {
                return res.status(404).send("Student not found.");
            }

            const student = result[0];

            // 3. Prepare the HTML snippet for the placeholder
            const statusLabel = student.is_active ? "Active" : "Inactive";
            const badgeClass = student.is_active ? "badge-active" : "badge-inactive";

            const detailHtml = `
                <div class="profile-card">
                    <h2>${student.first_name} ${student.last_name}</h2>
                    <p><strong>Database ID:</strong> ${student.id}</p>
                    <p><strong>Index Number:</strong> ${student.n_index}</p>
                    <p><strong>Status:</strong> 
                        <span class="status-badge ${badgeClass}">${statusLabel}</span>
                    </p>
                </div>
            `;

            // 4. Replace placeholder and send response
            const finalPage = htmlTemplate.replace("{oneStudentView}", detailHtml);
            res.send(finalPage);
        });
    });
});



app.use((req, res) => {
  res.status(404).send('Page Not Found');
});


// --- SECTION 3: Startup (The "Engine Launch") ---
db.connect((err) => {
    if (err) {
        console.error("Could not connect to DB!");
        process.exit(1);
    }
    console.log("MySQL connected...");

    // The server starts ONLY when the database confirms the connection
    app.listen(3000, () => {
        console.log("Server is running on port 3000");
    });
});

// --- SECTION 4: Shutdown (The "Cleanup") ---
process.on('SIGINT', () => {
    db.end(() => {
        console.log("DB closed. Exiting...");
        process.exit(0);
    });
});
