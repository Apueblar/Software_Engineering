//File: person.js
export const firstName = "Anna";
export const lastName = "Jasna";
export const age = 30;
export function withStars(line) {
    return `*** ${line}! ***`;
  }