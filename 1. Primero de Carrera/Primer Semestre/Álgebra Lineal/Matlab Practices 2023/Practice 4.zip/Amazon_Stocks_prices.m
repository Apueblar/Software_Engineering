% Prises of Amazon
% https://www.macrotrends.net/stocks/charts/AMZN/amazon/stock-splits
%% Data:
years=[2010:2020];
% Stock prices before the split:
stocks=[136.25 181.36 175.88 256.07 398.79 312.57 656.28 757.92 1172 1465.2 1875 3206 2991.47];