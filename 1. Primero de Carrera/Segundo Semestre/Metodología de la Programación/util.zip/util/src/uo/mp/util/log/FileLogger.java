package uo.mp.util.log;

import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import uo.mp.util.console.Console;

/**
 * A very basic implementation of a logger utility.
 * For this the date are sent to the System.err standard output.
 * The format of every lines is: <timestamp> <message>
 */
public class FileLogger {

	private String outFileName = "log.txt";
	private final static boolean APPEND = true;
	private static boolean AUTOFLUSH = true;
	
	public FileLogger(String outFileName) {
		this.outFileName = outFileName;
	}

	/**
	 * Sends the full stack trace of the exception received to the log
	 * prefixing it with a timestamp 
	 * @param t, the exception to be logged
	 */
	public void log(Throwable exception) {		
		try(PrintWriter out = new PrintWriter(new FileWriter(outFileName, APPEND), AUTOFLUSH)) {
			out.print( new Date()  + " ");
			exception.printStackTrace( out );
		} catch (IOException e) {
			Console.printError("UNABLE TO WRITE IN THE LOG FILE");
			Console.printError(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/*
	 * Sends the string recived as a message to the log, prefixing it with a timestamp
	 * @param message
	 */
	public void log(String message) {
		try(PrintWriter out = new PrintWriter(new FileWriter(outFileName, APPEND), AUTOFLUSH)) {
				out.print( new Date()  + " ");
				out.println( message );
		} catch (IOException e) {
			Console.printError("UNABLE TO WRITE IN THE LOG FILE");
			Console.printError(e.getMessage());
			e.printStackTrace();
		}
	}
}
