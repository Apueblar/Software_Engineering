package uo.mp.util.io;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * A utility class to read/write text lines 
 * from/to a compressed text file (.gz) 
 */
public class ZipFileUtil extends AbstractFileUtil{

	@Override
	Reader getReader(String pathToTheFile) throws FileNotFoundException, IOException {
		return new InputStreamReader(new GZIPInputStream(new FileInputStream(pathToTheFile)));
	}

	@Override
	Writer getWriter(String outFileName) throws IOException {
		return new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(outFileName)));
	}

}
