package uo.mp.util.io;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

/**
 * A utility class to read/write text lines from/to a text file (.txt)
 */
public class FileUtil extends AbstractFileUtil{

	@Override
	Reader getReader(String pathToTheFile) throws FileNotFoundException {
		return new FileReader(pathToTheFile);
	}

	@Override
	Writer getWriter(String outFileName) throws IOException {
		return new FileWriter(outFileName);
	}

}
