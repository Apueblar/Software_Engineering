package uo.mp.util.exception.parserException;

public class InvalidLineFormatException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidLineFormatException(String message) {
		super(message);
	}
}
