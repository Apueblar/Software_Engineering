package uo.mp.first.midterm2324.model.vehicle;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/*
 * Scenarios:
 * Illegal dni, 
 * illegal plate, 
 * illegal year,
 * illegal axle, 
 * illegal tonnage, 
 * valid data
 */
class TruckConstructorTest {

	private String plate = "plate";
	private String dni = "dni"; 
	private int year = 2000;	
	private int axle = 4;
	private int tonnage = 5;
	
	/**
	 * GIVEN: null dni, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void nullDni() {
		dni = null;
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {	
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: empty dni, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void emptyDni() {
		dni = "";
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: blank dni, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void blankDni() {
		dni = "  ";
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: null plate number, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void nullPlateNumber() {
		plate = null;
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: empty plate number, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void emptyPlateNumber() {
		plate = "";
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: blank plate number, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void blankPlateNumber() {
		plate = "  ";
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: year 0, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void zeroYear() {
		year = 0;
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}


	
	/**
	 * GIVEN: year under 0, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void yearUnder0() {
		year = -10;
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());	
		}
	}
	
		
	/**
	 * GIVEN: tonnage under 0, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void tonnUnder0() {
		tonnage = -10;
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: tonnage is 0, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void tonn0() {
		tonnage = 0;
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}

	/**
	 * GIVEN: number of axles under zero, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void axleUnderZero() {
		axle = -1;
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: number of axles is zero, all other values are legal 
	 * WHEN: create a new Truck
	 * THEN: IAE
	 */
	@Test
	void axleIsZero() {
		axle = 0;
		try {
			new Truck (dni, plate, year, axle, tonnage);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}	
	}
	

	/**
	 * GIVEN: values are legal 
	 * WHEN: create a new Truck
	 * THEN: a car is created
	 */
	@Test
	void validData() {
		Truck t = new Truck (dni, plate, year, axle, tonnage);
		assertEquals(t.getOwnerDNI(), dni);
		assertEquals(t.getPlateNumber(), plate);
		assertEquals(t.getRegistrationYear(), year);
		assertEquals(t.getAxle(), axle);
		assertEquals(t.getTonnage(), tonnage);	
	}
	
}
