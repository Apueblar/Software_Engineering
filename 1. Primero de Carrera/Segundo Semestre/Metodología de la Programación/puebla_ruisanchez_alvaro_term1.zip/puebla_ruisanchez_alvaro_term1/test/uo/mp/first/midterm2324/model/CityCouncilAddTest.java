package uo.mp.first.midterm2324.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.jupiter.api.Test;

import uo.mp.first.midterm2324.model.vehicle.Car;
import uo.mp.first.midterm2324.model.vehicle.Motorbike;
import uo.mp.first.midterm2324.model.vehicle.Truck;

/*
 * CityCouncil::add
 * Scenarios:
 * - add null
 * - car
 * - motorbike
 * - truck
 * -add 1 of each
 */
class CityCouncilAddTest {
	
	/**
	 * GIVEN: new city council , null vehicle
	 * WHEN: add(null)
	 * THEN: IAE
	 */
	@Test
	void nullVehicleTest() {
		CityCouncil cC = new CityCouncil();
		try {
			cC.add(null);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {	
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());
			assertTrue("The vehicles should be 0", cC.forTestingVehicles().size() == 0);
			assertTrue("The city vehicles should be 0", cC.forTestingCityVehicles().size() == 0);
		}
	}
	
	/**
	 * GIVEN: new city council, Car vehicle
	 * WHEN: add(car)
	 * THEN: vehicles increases, and cityVehicles increases
	 */
	@Test
	void carVehicleTest() {
		CityCouncil cC = new CityCouncil();
		cC.add(new Car ("dni", "plate", 2002, 10, 5));
		assertTrue("The vehicles should be 1", cC.forTestingVehicles().size() == 1);
		assertTrue("The city vehicles should be 1", cC.forTestingCityVehicles().size() == 1);
		assertTrue(cC.forTestingVehicles().contains(new Car ("dni", "plate", 2002, 10, 5)));
	}
	
	/**
	 * GIVEN: new city council, MotorBike vehicle
	 * WHEN: add(motorBike)
	 * THEN: vehicles increases, and cityVehicles increases
	 */
	@Test
	void motorBikeVehicleTest() {
		CityCouncil cC = new CityCouncil();
		cC.add(new Motorbike ("dni", "plate", 2024, 150));
		assertTrue("The vehicles should be 1", cC.forTestingVehicles().size() == 1);
		assertTrue("The city vehicles should be 1", cC.forTestingCityVehicles().size() == 1);
		assertTrue(cC.forTestingVehicles().contains(new Motorbike ("dni", "plate", 2024, 150)));
	}
	
	/**
	 * GIVEN: new city council, Truck vehicle
	 * WHEN: add(truck)
	 * THEN: vehicles increases, and cityVehicles increases
	 */
	@Test
	void truckVehicleTest() {
		CityCouncil cC = new CityCouncil();
		cC.add(new Truck ("dni", "plate", 2000, 4, 5));
		assertTrue("The vehicles should be 1", cC.forTestingVehicles().size() == 1);
		assertTrue("The city vehicles should be 0", cC.forTestingCityVehicles().size() == 0);
		assertTrue(cC.forTestingVehicles().contains(new Truck ("dni", "plate", 2000, 4, 5)));
	}
	
	/**
	 * GIVEN: new city council, Car, Moto, Truck vehicle
	 * WHEN: add(car), add(moto), add(truck)
	 * THEN: vehicles 3, and cityVehicles 2
	 */
	@Test
	void oneOfEachVehicleTest() {
		CityCouncil cC = new CityCouncil();
		cC.add(new Car ("dni", "plate", 2002, 10, 5));
		cC.add(new Motorbike ("dni", "plate", 2024, 150));
		cC.add(new Truck ("dni", "plate", 2000, 4, 5));
		assertTrue("The vehicles should be 3", cC.forTestingVehicles().size() == 3);
		assertTrue("The city vehicles should be 2", cC.forTestingCityVehicles().size() == 2);
		assertTrue(cC.forTestingVehicles().contains(new Car ("dni", "plate", 2002, 10, 5)));
		assertTrue(cC.forTestingVehicles().contains(new Motorbike ("dni", "plate", 2024, 150)));
		assertTrue(cC.forTestingVehicles().contains(new Truck ("dni", "plate", 2000, 4, 5)));
	}
}



































