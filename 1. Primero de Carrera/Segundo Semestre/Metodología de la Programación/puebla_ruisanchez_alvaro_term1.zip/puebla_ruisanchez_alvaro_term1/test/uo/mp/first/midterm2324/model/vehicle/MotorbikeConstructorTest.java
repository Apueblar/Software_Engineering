package uo.mp.first.midterm2324.model.vehicle;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/*
 * Scenarios:
 * Illegal dni, illegal plate, illegal year, illegal capacity, valid data
 */
class MotorbikeConstructorTest {

	private String plate = "plate";
	private String dni = "dni"; 
	private	int year = 2024;
	private int capacity = 150;
	
	/**
	 * GIVEN: null dni, all other values are legal 
	 * WHEN: create a new Motorbike
	 * THEN: IAE
	 */
	@Test
	void nullDni() {
		dni = null;
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: empty dni, all other values are legal 
	 * WHEN: create a new Motorbike
	 * THEN: IAE
	 */
	@Test
	void emptyDni() {
		dni = "";
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: blank dni, all other values are legal 
	 * WHEN: create a new Motorbike
	 * THEN: IAE
	 */
	@Test
	void blankDni() {
		dni = "  ";
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: null plate number, all other values are legal 
	 * WHEN: create a new Motorbike
	 * THEN: IAE
	 */
	@Test
	void nullPlateNumber() {
		plate = null;
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: empty plate number, all other values are legal 
	 * WHEN: create a new Motorbike
	 * THEN: IAE
	 */
	@Test
	void emptyPlateNumber() {
		plate = "";
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: blank plate number, all other values are legal 
	 * WHEN: create a new Motorbike
	 * THEN: IAE
	 */
	@Test
	void blankPlateNumber() {
		plate = "  ";
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}

	/**
	 * GIVEN: year 0, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void zeroYear() {
		year = 0;
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	
	/**
	 * GIVEN: year under 0, all other values are legal 
	 * WHEN: create a new Moto
	 * THEN: IAE
	 */
	@Test
	void yearUnder0() {
		year = -10;
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
		

	/**
	 * GIVEN: capacity under 0, all other values are legal 
	 * WHEN: create a new Motorbike
	 * THEN: IAE
	 */
	@Test
	void capacityUnder0() {
		capacity = -10;
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: capacity is 0, all other values are legal 
	 * WHEN: create a new Motorbike
	 * THEN: IAE
	 */
	@Test
	void capacity0() {
		capacity = 0;
		try {
			new Motorbike (dni, plate, year, capacity);
			fail("should have failed");
		}catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}

	 }
	
	
	/**
	 * GIVEN: all legal values, all other values are legal 
	 * WHEN: create a new Motorbike
	 * THEN: new Motorbike is created
	 */
	@Test
	void legalValues() {
		
		Motorbike c = new Motorbike (dni, plate, year, capacity);
		assertEquals(c.getOwnerDNI(), dni);
		assertEquals(c.getPlateNumber(), plate);
		assertEquals(c.getRegistrationYear(), year);
		assertEquals(c.getCubicCapacity(), capacity);
	}
	
	
}
