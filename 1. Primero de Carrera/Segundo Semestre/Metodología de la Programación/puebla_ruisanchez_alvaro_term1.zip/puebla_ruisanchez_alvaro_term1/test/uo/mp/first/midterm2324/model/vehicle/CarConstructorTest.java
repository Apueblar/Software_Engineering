package uo.mp.first.midterm2324.model.vehicle;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;


import org.junit.jupiter.api.Test;

/*
 * Scenarios:
 * Illegal dni, illegal plate, illegal power, illegal passengers, valid data
 */
class CarConstructorTest {
	private String dni = "dni1"; 
	private String plate = "plate";	
	private int year = 2002;
	private int power = 10;
	private int passengers = 5;
	
	/**
	 * GIVEN: null owner, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void nullDNI() {
		dni = null;
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {	
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	

	/**
	 * GIVEN: empty owner, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void emptyDni() {
		dni = "";		
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: blank dni, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void blankDni() {
		dni = "  ";
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: null plate, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void nullPlateNumber() {
		plate = null;
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: empty plate, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void emptyPlateNumber() {
		plate = "";
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: blank plate, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void blankPlateNumber() {
		plate = "  ";
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e ) {			
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: year 0, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void zeroYear() {
		year = 0;
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	
	/**
	 * GIVEN: year under 0, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void yearUnder0() {
		year = -10;
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	
	/**
	 * GIVEN: power under 0, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void powerUnder0() {
		power = -10;
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: power is 0, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void power0() {
		power = 0;
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}

	/**
	 * GIVEN: number of passengers under lower limit, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void passengerUnderLowerLimit() {
		passengers = 2;
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: number of passengers over higher limit, all other values are legal 
	 * WHEN: create a new Car
	 * THEN: IAE
	 */
	@Test
	void passengerOverHigherLimit() {
		passengers = 10;
		try {
			new Car (dni, plate, year, power, passengers);
			fail("should have failed");
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
			assertFalse(e.getMessage().isBlank());		
		}
	}
	
	/**
	 * GIVEN: number of passengers is lower limit, all other values are also legal 
	 * WHEN: create a new Car
	 * THEN: new car is created with the expected values
	 */
	@Test
	void passengerIsLowerLimit() {
		passengers = 4;
		Car c = new Car (dni, plate, year, power, passengers);
		assertEquals(c.getOwnerDNI(), dni);
		assertEquals(c.getPlateNumber(), plate);
		assertEquals(c.getRegistrationYear(), year);
		assertEquals(c.getPower(), power);
		assertEquals(c.getPassengers(), passengers);
	}
	
	/**
	 * GIVEN: number of passengers is higher limit, all other values are also legal 
	 * WHEN: create a new Car
	 * THEN: new car is created with the expected values
	 */
	@Test
	void passengerIsHigherLimit() {
		passengers = 7;
		Car c = new Car (dni, plate, year, power, passengers);
		assertEquals(c.getOwnerDNI(), dni);
		assertEquals(c.getPlateNumber(), plate);
		assertEquals(c.getRegistrationYear(), year);
		assertEquals(c.getPower(), power);
		assertEquals(c.getPassengers(), passengers);

	}
	
	/**
	 * GIVEN: number of passengers is a value in the middle of the valid range, all other values are also legal 
	 * WHEN: create a new Car
	 * THEN: new car is created with the expected values
	 */
	@Test
	void passengerIsInMiddleRange() {
		passengers = 5;
		Car c = new Car (dni, plate, year, power, passengers);
		assertEquals(c.getOwnerDNI(), dni);
		assertEquals(c.getPlateNumber(), plate);
		assertEquals(c.getRegistrationYear(), year);
		assertEquals(c.getPower(), power);
		assertEquals(c.getPassengers(), passengers);

	}
		
	
}
