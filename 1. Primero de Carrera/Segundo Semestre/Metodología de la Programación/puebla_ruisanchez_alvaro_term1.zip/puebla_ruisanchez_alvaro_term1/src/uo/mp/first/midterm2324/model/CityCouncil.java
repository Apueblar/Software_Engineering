package uo.mp.first.midterm2324.model;

import java.util.ArrayList;
import java.util.List;

import uo.mp.first.midterm2324.model.vehicle.CityVehicle;
import uo.mp.first.midterm2324.model.vehicle.Vehicle;
import uo.mp.util.check.ArgumentChecks;

public class CityCouncil {
	
	List<Vehicle> vehicles = new ArrayList<Vehicle>();
	List<CityVehicle> cityVehicles = new ArrayList<CityVehicle>();
	
	public void add(Vehicle vehicle) {
		ArgumentChecks.isNotNull(vehicle, "The vehicle must not be null");
		if (vehicle instanceof CityVehicle) {cityVehicles.add((CityVehicle) vehicle);}
		vehicles.add(vehicle);
	}
	
	public Vehicle search(Vehicle searchedVehicle) {
		ArgumentChecks.isNotNull(searchedVehicle, "The vehicle must not be null");
		for ( Vehicle vehicle : vehicles) {
			if(vehicle.equals(searchedVehicle)) {return vehicle;}
		}
		return null;
	}
	
	public int totalRevenue() {
		int taxes = 0;
		for (Vehicle vehicle : vehicles) {
			taxes += vehicle.getTax();
		}
		for (CityVehicle vehicle : cityVehicles) {
			taxes += vehicle.getCityTax();
		}
		return taxes;
	}
	
	List<Vehicle> forTestingVehicles() {return vehicles;}
	
	List<CityVehicle> forTestingCityVehicles() {return cityVehicles;}
}
