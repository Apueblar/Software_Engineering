package uo.mp.first.midterm2324.model.vehicle;

public interface CityVehicle {

	int getCityTax();

}
