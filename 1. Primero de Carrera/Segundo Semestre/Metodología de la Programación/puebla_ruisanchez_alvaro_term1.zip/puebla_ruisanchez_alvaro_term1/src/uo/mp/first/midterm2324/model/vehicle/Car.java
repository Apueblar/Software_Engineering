package uo.mp.first.midterm2324.model.vehicle;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public class Car extends AbstractVehicle implements CityVehicle {

	private int power;
	private int passenger;
	public final static int MIN_PASSENGERS = 4;
	public final static int MAX_PASSENGERS = 7;
	private final static int CIRCULATING_TAX = 112;//€
	private final static int CITY_TAX = 30;// + power * passenger
	
	public Car(String ownerDNI, String plateNumber, int registrationYear, int power, int passenger) {
		super(ownerDNI, plateNumber, registrationYear);
		
		setPower(power);
		setPassenger(passenger);
	}
	
	public int getPower() {
		return power;
	}

	private void setPower(int power) {
		ArgumentChecks.isTrue(power > 0, "The power must be grater than 0");
		this.power = power;
	}

	public int getPassengers() {
		return passenger;
	}

	private void setPassenger(int passenger) {
		ArgumentChecks.isTrue(MIN_PASSENGERS <= passenger && passenger <= MAX_PASSENGERS, getOwnerDNI());
		this.passenger = passenger;
	}

	@Override
	public int getTax() {
		return CIRCULATING_TAX;
	}

	@Override
	public int getCityTax() {
		return CITY_TAX + power * passenger;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(passenger, power);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		return passenger == other.passenger && power == other.power;
	}
	
	@Override
	String getName() {
		return "Car";
	}

	@Override
	String getSpecificInfo() {
		return String.format(", power = %d, passengers = %d", getPower(), getPassengers());
	}

	

}
