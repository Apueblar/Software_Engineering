package uo.mp.first.midterm2324.model.vehicle;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public class Truck extends AbstractVehicle {

	private int axle;
	private int tonnage;
	private final static int CIRCULATING_TAX_LOW = 43;// * tonnage
	private final static int TONNAGE_REF = 2;
private final static int CIRCULATING_TAX_HIGH = 148;//€
	
	public Truck(String ownerDNI, String plateNumber, int registrationYear, int axle, int tonnage) {
		super(ownerDNI, plateNumber, registrationYear);
		
		setAxle(axle);
		setTonnage(tonnage);
	}

	public int getAxle() {
		return axle;
	}

	private void setAxle(int axle) {
		ArgumentChecks.isTrue(axle > 0, "The axles must be greater than 0");
		this.axle = axle;
	}

	public int getTonnage() {
		return tonnage;
	}

	private void setTonnage(int tonnage) {
		ArgumentChecks.isTrue(tonnage > 0, "The tonnage must be greater than 0");
		this.tonnage = tonnage;
	}

	@Override
	public int getTax() {
		if (tonnage < TONNAGE_REF) {return axle * CIRCULATING_TAX_LOW;}
		return CIRCULATING_TAX_HIGH;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(axle, tonnage);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Truck other = (Truck) obj;
		return axle == other.axle && tonnage == other.tonnage;
	}

	@Override
	String getName() {
		return "Truck";
	}

	@Override
	String getSpecificInfo() {
		return String.format(", axles = %d, tonnage = %d", getAxle(), getTonnage());
	}

}
