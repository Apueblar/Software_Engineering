package uo.mp.first.midterm2324;

import uo.mp.first.midterm2324.interaction.SimulateOperation;

public class LaunchApp {

	public static void main(String[] args) {
		new SimulateOperation().run();
	}

}
