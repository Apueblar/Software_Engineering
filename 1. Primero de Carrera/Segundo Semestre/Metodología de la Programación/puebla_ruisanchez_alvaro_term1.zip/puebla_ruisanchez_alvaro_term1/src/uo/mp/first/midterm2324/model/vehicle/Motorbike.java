package uo.mp.first.midterm2324.model.vehicle;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public class Motorbike extends AbstractVehicle implements CityVehicle{

	private int cubicCapacity;
	private final static int LOW_RANGE_TAX = 250;
	private final static int LOW_PRICE_TAX = 4;
	private final static int MIDDLE_RANGE_TAX = 1000;
	private final static int MIDDLE_PRICE_TAX = 30;
	private final static int HIGH_PRICE_TAX = 60;
	private final static int CITY_TAX = 10;// * cc

	public Motorbike(String ownerDNI, String plateNumber, int registrationYear, int capacity) {
		super(ownerDNI, plateNumber, registrationYear);
		
		setCubicCapacity(capacity);
	}

	public int getCubicCapacity() {
		return cubicCapacity;
	}

	private void setCubicCapacity(int cubicCapacity) {
		ArgumentChecks.isTrue(cubicCapacity > 0, "The cubic capacity must be greater than 0");
		this.cubicCapacity = cubicCapacity;
	}

	@Override
	public int getTax() {
		if (cubicCapacity < LOW_RANGE_TAX) {return LOW_PRICE_TAX;}
		if (cubicCapacity <= MIDDLE_RANGE_TAX) {return MIDDLE_PRICE_TAX;}
		return HIGH_PRICE_TAX;
	}

	@Override
	public int getCityTax() {
		return CITY_TAX * cubicCapacity;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(cubicCapacity);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Motorbike other = (Motorbike) obj;
		return cubicCapacity == other.cubicCapacity;
	}

	@Override
	String getName() {
		return "Motorbike";
	}

	@Override
	String getSpecificInfo() {
		return String.format(", cubic Capacity = %d", getCubicCapacity());
	}

}
