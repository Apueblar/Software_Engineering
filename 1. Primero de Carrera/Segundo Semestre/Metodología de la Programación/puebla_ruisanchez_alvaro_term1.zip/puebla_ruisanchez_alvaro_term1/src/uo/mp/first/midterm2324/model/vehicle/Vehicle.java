package uo.mp.first.midterm2324.model.vehicle;

public interface Vehicle {
	
	public String getOwnerDNI();

	public String getPlateNumber();
	
	public int getRegistrationYear();
	
	int getTax();
}
