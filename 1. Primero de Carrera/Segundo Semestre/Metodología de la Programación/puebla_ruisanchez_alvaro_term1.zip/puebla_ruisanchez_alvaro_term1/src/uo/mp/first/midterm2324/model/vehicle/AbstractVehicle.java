package uo.mp.first.midterm2324.model.vehicle;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public abstract class AbstractVehicle implements Vehicle{

	private String ownerDNI;
	private String plateNumber;
	private int registrationYear;
	
	public AbstractVehicle(String ownerDNI, String plateNumber, int registrationYear) {
		setOwnerDNI(ownerDNI);
		setPlateNumber(plateNumber);
		setRegistrationYear(registrationYear);
	}

	public String getOwnerDNI() {
		return ownerDNI;
	}

	private void setOwnerDNI(String ownerDNI) {
		ArgumentChecks.isNotNull(ownerDNI, "The dni must not be null");
		ArgumentChecks.isNotBlank(ownerDNI, "The dni must not be blank/empty");
		this.ownerDNI = ownerDNI;
	}

	public String getPlateNumber() {
		return plateNumber;
	}

	private void setPlateNumber(String plateNumber) {
		ArgumentChecks.isNotNull(plateNumber, "The plate must not be null");
		ArgumentChecks.isNotBlank(plateNumber, "The plate must not be blank/empty");
		this.plateNumber = plateNumber;
	}

	public int getRegistrationYear() {
		return registrationYear;
	}

	private void setRegistrationYear(int registrationYear) {
		ArgumentChecks.isTrue(registrationYear > 0, "The registration year must be greater than 0");
		this.registrationYear = registrationYear;
	}

	@Override
	public int hashCode() {
		return Objects.hash(ownerDNI, plateNumber, registrationYear);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractVehicle other = (AbstractVehicle) obj;
		return Objects.equals(ownerDNI, other.ownerDNI) && Objects.equals(plateNumber, other.plateNumber)
				&& registrationYear == other.registrationYear;
	}

	@Override
	public String toString() {
		return String.format("%s ( Plate number = %s, owner = %s, registration year = %d%s)", getName(), getPlateNumber(), getOwnerDNI(), getRegistrationYear(), getSpecificInfo());
	}
	
	abstract String getName();
	
	abstract String getSpecificInfo();
}
