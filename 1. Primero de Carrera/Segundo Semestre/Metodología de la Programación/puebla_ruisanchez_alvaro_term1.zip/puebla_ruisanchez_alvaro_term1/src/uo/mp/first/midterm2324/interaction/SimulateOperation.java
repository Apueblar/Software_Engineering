package uo.mp.first.midterm2324.interaction;

import uo.mp.first.midterm2324.model.CityCouncil;
import uo.mp.first.midterm2324.model.vehicle.Car;
import uo.mp.first.midterm2324.model.vehicle.Motorbike;
import uo.mp.first.midterm2324.model.vehicle.Truck;
import uo.mp.first.midterm2324.model.vehicle.Vehicle;

public class SimulateOperation {

	public void run() {
		Car c = new Car (/*dni*/ "owner", 
				/*plate number*/ "car", 
				/*registration year*/ 2022, 
				/*power*/ 50, 
				/*number of passengers*/ 5);
		Truck t = new Truck (/*dni*/ "owner", 
				/*plate number*/ "truck", 
				/*registration year*/ 2023,
				/*axles*/ 3, 
				/*tonnage*/ 150);
		Motorbike m = new Motorbike (/*dni*/ "owner", 
				/*plate number*/ "moto", 
				/*registration year*/ 2022,
				/* cubic capacity */ 150);

		CityCouncil cc = new CityCouncil();
		cc.add(c);
		cc.add(m);
		cc.add(t);
		
		Vehicle found = cc.search(c);
		displayVehicle(found);
		found = cc.search(new Truck (/*dni*/ "owner", 
				/*plate number*/ "truck", 
				/*registration year*/ 2023,
				/*axles*/ 3, 
				/*tonnage*/ 150)
				);
		displayVehicle(found);
		found = cc.search(new Motorbike (/*dni*/ "owner", 
				/*plate number*/ "otom", 
				/*registration year*/ 2022,
				/* cubic capacity */ 150)
				);
		displayVehicle(found);

		System.out.println("Total revenue = " + cc.totalRevenue());
		
	}

	private void displayVehicle(Vehicle v) {
		if (v!=null)
			System.out.println(v.toString());
		else
			System.out.println("null vehicle");
	}
}
