package uo.mp.newsstand.service.parsers;

import java.util.ArrayList;
import java.util.List;

import uo.mp.newsstand.domain.Magazine;
import uo.mp.newsstand.domain.Magazine.Frequency;
import uo.mp.newsstand.domain.Newspaper;
import uo.mp.newsstand.domain.Publication;
import uo.mp.util.check.ArgumentChecks;

public class PublicationParser {

	/**
	 * Transforms a list of Strings in a list of instances of Publication.
	 * Any of the following are invalid lines in the input file: 
	 * 		- incorrect type of publication, 
	 * 		- wrong number of fields in a line, and 
	 * 		- incorrect data format in numeric fields.
	 * Invalid lines will not produce a Publication instance but will throw an InvalidLineFormatException instead.
	 * As a result of processing this exception, a message will be written to a log (use Log) 
	 * @param lines non-null list of strings, probably empty
	 * 		One by each publication
	 * 				type_of_publication \t name_of_publication \t sales \t stock \t frequency
	 * 
	 * @return a list of publications
	 */
	public List<Publication> parse(List<String> lines) {
		ArgumentChecks.isNotNull(lines, "Invalid list of publications.");
		List<Publication> result = new ArrayList<>();
		for (String line : lines) {
			if(!line.isBlank()) {
				Publication pub = parseLine(line);
				result.add(pub);
			}
		}
		
		return result;
	}

	private Publication parseLine(String line) {
		final String SEPARATOR = "\t", newspaper = "newspaper";
		final int KEYWORD = 0;
		
		String[] splittedLine = line.split(SEPARATOR);
		if(splittedLine[KEYWORD].contentEquals(newspaper)) {
			return parseNewspaper(splittedLine);
		}else {
			return parseMagazine(splittedLine);
		}
	}

	private final static int NAME = 1, SALES = 2, STOCK = 3;
	private Newspaper parseNewspaper(String[] splittedLine) {
		String name = splittedLine[NAME];
		int sales = Integer.parseInt(splittedLine[SALES]), stock = Integer.parseInt(splittedLine[STOCK]);
		return new Newspaper(name, sales, stock);
	}
	
	private Magazine parseMagazine(String[] splittedLine) {
		final int FREQUENCY = 4;
		String name = splittedLine[NAME];
		int sales = Integer.parseInt(splittedLine[SALES]), stock = Integer.parseInt(splittedLine[STOCK]);
		Frequency frequency = Frequency.valueOf(splittedLine[FREQUENCY].toUpperCase());
		
		return new Magazine(name, sales, stock, frequency);
	}
}
