package uo.mp.newsstand.exception;

public class NotYetImplementedException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	private String methodName;
	
	public NotYetImplementedException(String message, String methodName) {
		super(message);
		this.methodName = methodName;
	}

	public NotYetImplementedException(String methodName) {
		super("The method %s is not implemented yet.".formatted(methodName));
		this.methodName = methodName;
	}
	
	public String getMethodName() {
		return methodName;
	}
}
