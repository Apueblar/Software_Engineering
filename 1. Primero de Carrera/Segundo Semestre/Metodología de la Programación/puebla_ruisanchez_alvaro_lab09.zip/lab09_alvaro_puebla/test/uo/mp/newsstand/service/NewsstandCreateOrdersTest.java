package uo.mp.newsstand.service;

import static org.junit.Assert.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.newsstand.domain.Magazine;
import uo.mp.newsstand.domain.Magazine.Frequency;
import uo.mp.newsstand.domain.Newspaper;
import uo.mp.newsstand.domain.Publication;
import uo.mp.newsstand.exception.NewsstandException;

public class NewsstandCreateOrdersTest {

	Newsstand ns;
	Newspaper np;
	Magazine mg;
	String name;
	int sufficientSales;
	int sufficientStock;
	
	@BeforeEach
	public void setUp() {
		ns = new Newsstand();
		name = "Las 4 adivinanzas";
		sufficientSales = 25;
		sufficientStock = Publication.LOW_STOCK + 10;
	}
	
	/**
	 * GIVEN: A newspaper with enough copies in stock 
	 * WHEN: create orders
	 * THEN: no new order is generated 
	 */
	@Test
	public void enoughCopiesNewspaperNoOrderTest() throws NewsstandException {
		np = new Newspaper(name, sufficientSales, sufficientStock);
		ns.addPublication(np);
		ns.createOrders();
		assertTrue(ns.getOrders().size() == 0);
	}

	/**
	 * GIVEN: A newspaper with copies in stock in the limit 
	 * WHEN: generate orders
	 * THEN: no new order is generated
	 */
	@Test
	public void copiesintheLimitNewspaperNoOrderTest() throws NewsstandException {
		sufficientStock = Publication.LOW_STOCK;
		np = new Newspaper(name, sufficientSales, sufficientStock);
		ns.addPublication(np);
		ns.createOrders();
		assertTrue(ns.getOrders().size() == 0);
	}
	
	/**
	 * GIVEN: A newspaper with no enough copies in stock 
	 * WHEN: generate orders
	 * THEN: new order is generated with name and getSales() + (getStock() * 2)
	 */
	@Test
	public void noEnoughCopiesNewspaperNoOrderTest() throws NewsstandException {
		int insufficientStock = Publication.LOW_STOCK-1;
		np = new Newspaper(name, sufficientSales, insufficientStock);
		ns.addPublication(np);
		ns.createOrders();
		assertTrue("" + ns.getOrders(), ns.getOrders().size() == 1);
		assertTrue("" + ns.getOrders(), ns.getOrders().get(0).getName().equals(name));
	}

	/**
	 * GIVEN: A weekly magazine with enough copies in stock 
	 * WHEN: generate orders
	 * THEN: no new order is generated
	 */
	@Test
	public void enoughCopiesWeeklyMagazineNoOrderTest() throws NewsstandException {
		mg = new Magazine(name, sufficientSales, sufficientStock, Frequency.WEEKLY);
		ns.addPublication(mg);
		ns.createOrders();
		assertTrue("" + ns.getOrders().size(), ns.getOrders().size() == 0);
	}
	
	/**
	 * GIVEN: A weekly magazine with copies in stock in the limit 
	 * WHEN: generate orders
	 * THEN: no new order is generated
	 */
	@Test
	public void limitCopiesWeeklyMagazineNoOrderTest() throws NewsstandException {
		sufficientStock = Publication.LOW_STOCK;
		mg = new Magazine(name, sufficientSales, sufficientStock, Frequency.WEEKLY);
		ns.addPublication(mg);
		ns.createOrders();
		assertTrue("" + ns.getOrders().size(), ns.getOrders().size() == 0);
	}
	
	/**
	 * GIVEN: A weekly magazine with copies in stock under 5 
	 * WHEN: generate orders
	 * THEN: order is generated
	 */
	@Test
	public void weeklyMagazineCopiesUnder5Order20() throws NewsstandException {
		int insufficientStock = 1;
		mg = new Magazine(name, sufficientSales, insufficientStock, Frequency.WEEKLY);
		ns.addPublication(mg);
		ns.createOrders();
		assertTrue("" + ns.getOrders(), ns.getOrders().size() == 1);
		assertTrue("" + ns.getOrders(), ns.getOrders().get(0).getName().equals(name));
	}
	
	/**
	 * GIVEN: A weekly magazine with copies in stock equals 5
	 * WHEN: generate orders
	 * THEN: order is generated to order number of copies sold
	 */
	@Test
	public void weeklyMagazine5CopiesOrderSold() throws NewsstandException {
		int insufficientStock = 5;
		mg = new Magazine(name, sufficientSales, insufficientStock, Frequency.WEEKLY);
		ns.addPublication(mg);
		ns.createOrders();
		assertTrue("" + ns.getOrders(), ns.getOrders().size() == 1);
		assertTrue("" + ns.getOrders(), ns.getOrders().get(0).getName().equals(name));
		assertTrue("" + ns.getOrders().get(0).getQuantity(), ns.getOrders().get(0).getQuantity() == sufficientSales);
	}
	
	
	
	/**
	 * GIVEN: A monthly magazine with enough copies in stock 
	 * WHEN: generate orders
	 * THEN: no new order is generated
	 */
	@Test
	public void enoughCopiesMonthlyMagazineNoOrderTest() throws NewsstandException {
		mg = new Magazine(name, sufficientSales, sufficientStock, Frequency.MONTHLY);
		ns.addPublication(mg);
		ns.createOrders();
		assertTrue("" + ns.getOrders().size(), ns.getOrders().size() == 0);
	}
	
	/**
	 * GIVEN: A monthly magazine with copies in stock in the limit (10)
	 * WHEN: generate orders
	 * THEN: no new order is generated
	 */
	@Test
	public void limitCopiesMonthlyMagazineNoOrderTest() throws NewsstandException {
		sufficientStock = Publication.LOW_STOCK;
		mg = new Magazine(name, sufficientSales, sufficientStock, Frequency.MONTHLY);
		ns.addPublication(mg);
		ns.createOrders();
		assertTrue("" + ns.getOrders().size(), ns.getOrders().size() == 0);
	}
	
	/**
	 * GIVEN: A monthly magazine with copies in stock under 5 
	 * WHEN: generate orders
	 * THEN: order is generated 
	 */
	@Test
	public void monthlyMagazineCopiesUnder5Order20() throws NewsstandException {
		int insufficientStock = 1;
		mg = new Magazine(name, sufficientSales, insufficientStock, Frequency.MONTHLY);
		ns.addPublication(mg);
		ns.createOrders();
		assertTrue("" + ns.getOrders(), ns.getOrders().size() == 1);
		assertTrue("" + ns.getOrders(), ns.getOrders().get(0).getName().equals(name));
	}
	
	/**
	 * GIVEN: A monthly magazine with copies in stock equals 5
	 * WHEN: generate orders
	 * THEN: order is generated to order number of copies sold +
	 * 									  number of copies in stock
	 */
	@Test
	public void monthlyMagazine5CopiesOrderSoldPlusStock() throws NewsstandException {
		int insufficientStock = 5;
		mg = new Magazine(name, sufficientSales, insufficientStock, Frequency.MONTHLY);
		ns.addPublication(mg);
		ns.createOrders();
		assertTrue("" + ns.getOrders(), ns.getOrders().size() == 1);
		assertTrue("" + ns.getOrders(), ns.getOrders().get(0).getName().equals(name));
		assertTrue(sufficientSales + " " + insufficientStock + ":" + ns.getOrders().get(0).getQuantity(), ns.getOrders().get(0).getQuantity() == sufficientSales + insufficientStock);
	}
	
}
