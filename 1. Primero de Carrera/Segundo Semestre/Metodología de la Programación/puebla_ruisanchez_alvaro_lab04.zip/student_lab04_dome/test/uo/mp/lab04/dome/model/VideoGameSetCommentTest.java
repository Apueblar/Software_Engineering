package uo.mp.lab04.dome.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * VideoGame::setComment(arg)
 * 
 * - Right comment
 * - null argument
 * - empty string
 * - argument does not contain meaningful chars
 */
public class VideoGameSetCommentTest {

    private VideoGame aVideoGame;
    private String theTitle;
    private String theAuthor;
    private int numberOfPlayers;
    private Platform platform;
    private double price;

    @BeforeEach
    public void setUp() {
	theTitle = "Star Wars";
	theAuthor = "George Lucas";
	numberOfPlayers = 4;
	platform = Platform.PlayStation;
	price = 10;
	aVideoGame = new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price);
    }

    /**
     * GIVEN VideoGame with "No comment" comment
     * WHEN call setComment with other comment full of meaningful chars
     * THEN comment is changed to new string
     */
    @Test
    public void validComment() {
	aVideoGame.setComment("Excellent");

	assertEquals("Excellent", aVideoGame.getComment());
    }

    /**
     * GIVEN VideoGame with a comment
     * WHEN call setComment with null
     * THEN comment unchanged
     */
    @Test
    public void nullComment() {
	aVideoGame.setComment("Excellent");
	aVideoGame.setComment(null);

	assertEquals("Excellent", aVideoGame.getComment());
    }

    /**
     * GIVEN VideoGame with a comment
     * WHEN call setComment with ""
     * THEN comment unchanged
     */
    @Test
    public void emptyComment() {
	aVideoGame.setComment("Excellent");
	aVideoGame.setComment("");

	assertEquals("Excellent", aVideoGame.getComment());
    }

    /**
     * GIVEN VideoGame with a comment
     * WHEN call setComment with " "
     * THEN comment unchanged
     */
    @Test
    public void blankComment() {
	aVideoGame.setComment("Excellent");
	aVideoGame.setComment("      ");

	assertEquals("Excellent", aVideoGame.getComment());
    }
}