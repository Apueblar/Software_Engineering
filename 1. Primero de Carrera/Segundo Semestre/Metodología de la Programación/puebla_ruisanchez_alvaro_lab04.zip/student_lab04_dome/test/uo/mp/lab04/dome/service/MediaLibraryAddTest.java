package uo.mp.lab04.dome.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import uo.mp.lab04.dome.model.CD;
import uo.mp.lab04.dome.model.DVD;
import uo.mp.lab04.dome.model.Platform;
import uo.mp.lab04.dome.model.VideoGame;

/**
 * MediaLibrary::add(item)
 * 
 * - Add valid CD
 * - Add valid DVD
 * - Add valid VideoGame
 * - Add null (invalid)
 * - Add 1 of each
 */
public class MediaLibraryAddTest {

    @Test
    void addValidCDToEmptyCatalog() {
	MediaLibrary media = new MediaLibrary();
	CD myCD = new CD("The End", "The Doors", 10, 100, 12);
	media.add(myCD);
	;

	assertEquals(1, media.getCatalog()
	    .size());

	assertEquals(myCD, media.getCatalog()
	    .get(0));

	assertTrue(media.getCatalog()
	    .contains(myCD));
    }

    @Test
    void addValidDVDToEmptyCatalog() {
	MediaLibrary media = new MediaLibrary();
	DVD myDVD = new DVD("The End", "Paco Rueda", 10, 13);
	media.add(myDVD);
	;

	assertEquals(1, media.getCatalog()
	    .size());

	assertEquals(myDVD, media.getCatalog()
	    .get(0));

	assertTrue(media.getCatalog()
	    .contains(myDVD));
    }

    @Test
    void addValidVideoGameToEmptyCatalog() {
	MediaLibrary media = new MediaLibrary();
	VideoGame myVideoGame = new VideoGame("The End", "Paco Rueda", 5, Platform.XBox, 50);
	media.add(myVideoGame);
	;

	assertEquals(1, media.getCatalog()
	    .size());

	assertEquals(myVideoGame, media.getCatalog()
	    .get(0));

	assertTrue(media.getCatalog()
	    .contains(myVideoGame));
    }

    @Test
    public void addNullToEmptyCatalog() {
	MediaLibrary media = new MediaLibrary();

	IllegalArgumentException e = assertThrows(IllegalArgumentException.class, () -> media.add(null),
		"Exception expected");
	assertEquals("The item is null", e.getMessage());
    }

    @Test
    public void add1OfEachTest() {
	MediaLibrary media = new MediaLibrary();

	CD myCD = new CD("The End", "The Doors", 10, 100, 9);
	media.add(myCD);
	DVD myDVD = new DVD("The End", "Paco Rueda", 10, 8.5);
	media.add(myDVD);
	VideoGame myVideoGame = new VideoGame("The End", "Paco Rueda", 5, Platform.XBox, 102);
	media.add(myVideoGame);

	assertEquals(3, media.getCatalog()
	    .size());
	assertEquals(myCD, media.getCatalog()
	    .get(0));
	assertTrue(media.getCatalog()
	    .contains(myCD));

	assertEquals(myDVD, media.getCatalog()
	    .get(1));
	assertTrue(media.getCatalog()
	    .contains(myDVD));

	assertEquals(myVideoGame, media.getCatalog()
	    .get(2));
	assertTrue(media.getCatalog()
	    .contains(myVideoGame));
    }
}
