package uo.mp.lab04.dome.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import uo.mp.lab04.dome.model.CD;
import uo.mp.lab04.dome.model.DVD;
import uo.mp.lab04.dome.model.Platform;
import uo.mp.lab04.dome.model.VideoGame;

/**
 * MediaLibrary::getTotalPrice()
 * 
 * - Get the price of some items
 */
public class MediaLibraryTotalPriceTest {

    @Test
    public void add1OfEachTest() {
	MediaLibrary media = new MediaLibrary();

	assertTrue(0 == media.getTotalPrice(), "The total price must be 0, it is empty");

	CD myCD = new CD("The End", "The Doors", 10, 100, 9);
	media.add(myCD);

	assertTrue(9 + 2 == media.getTotalPrice(), "The total price must be 11 + TAX");

	DVD myDVD = new DVD("The End", "Paco Rueda", 10, 8.5);
	media.add(myDVD);

	assertTrue((9 + 2 + 8.5) == media.getTotalPrice(), "The total price must be 19.5");

	VideoGame myVideoGame = new VideoGame("The End", "Paco Rueda", 5, Platform.XBox, 102);
	media.add(myVideoGame);

	assertTrue((9 + 2 + 8.5 + 102 * 1.1) == media.getTotalPrice(), "The total price must be 131.7");
    }
}
