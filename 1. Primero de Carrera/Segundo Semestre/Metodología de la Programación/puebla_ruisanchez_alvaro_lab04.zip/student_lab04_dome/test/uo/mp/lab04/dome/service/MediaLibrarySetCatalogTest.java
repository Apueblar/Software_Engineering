package uo.mp.lab04.dome.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import uo.mp.lab04.dome.model.CD;
import uo.mp.lab04.dome.model.DVD;
import uo.mp.lab04.dome.model.Item;
import uo.mp.lab04.dome.model.Platform;
import uo.mp.lab04.dome.model.VideoGame;

public class MediaLibrarySetCatalogTest {

    @Test
    void setCatalogTest() {
	MediaLibrary media = new MediaLibrary();
	media.setCatalog(null);
	assertTrue(media.getCatalog() == null);

	CD myCD = new CD("The End", "The Doors", 10, 100, 10);
	DVD myDVD = new DVD("The End", "Paco Rueda", 10, 20);
	VideoGame myVideoGame = new VideoGame("The End", "Paco Rueda", 5, Platform.XBox, 89.9);
	List<Item> list = new ArrayList<Item>(Arrays.asList(myCD, myDVD, myVideoGame));
	media.setCatalog(list);
	assertEquals(media.getCatalog(), list);
    }

}
