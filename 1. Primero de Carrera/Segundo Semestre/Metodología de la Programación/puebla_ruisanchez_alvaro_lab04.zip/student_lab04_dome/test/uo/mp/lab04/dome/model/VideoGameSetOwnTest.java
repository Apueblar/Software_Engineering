package uo.mp.lab04.dome.model;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * VideoGame::setOwn(boolean)
 *
 * - being own to own
 * - being own to not own
 * - being not own to not own
 * - being not own to own
 */
public class VideoGameSetOwnTest {

    private VideoGame aVideoGame;
    private String theTitle;
    private String theAuthor;
    private int numberOfPlayers;
    private Platform platform;
    private double price;

    @BeforeEach
    public void setUp() {
	theTitle = "Star Wars";
	theAuthor = "George Lucas";
	numberOfPlayers = 4;
	platform = Platform.PlayStation;
	price = 10;
	aVideoGame = new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price);
    }

    /**
     * GIVEN VideoGame owned
     * WHEN call setOwn ( true )
     * THEN VideoGame not changed
     * 
     */
    @Test
    public void trueToTrue() {
	aVideoGame.setOwn(true);
	aVideoGame.setOwn(true);
	assertTrue(aVideoGame.getOwn());
    }

    /**
     * GIVEN VideoGame owned
     * WHEN call setOwn ( false )
     * THEN VideoGame not owned
     * 
     */
    @Test
    public void trueToFalse() {
	aVideoGame.setOwn(true);
	aVideoGame.setOwn(false);
	assertFalse(aVideoGame.getOwn());
    }

    /**
     * GIVEN VideoGame not owned
     * WHEN call setOwn ( false )
     * THEN VideoGame not changed
     * 
     */
    @Test
    public void falseToFalse() {
	aVideoGame.setOwn(false);
	aVideoGame.setOwn(false);
	assertFalse(aVideoGame.getOwn());
    }

    /**
     * GIVEN VideoGame not owned
     * WHEN call setOwn ( true )
     * THEN VideoGame owned
     * 
     */
    @Test
    public void falseToTrue() {
	aVideoGame.setOwn(false);
	aVideoGame.setOwn(true);
	assertTrue(aVideoGame.getOwn());
    }

}