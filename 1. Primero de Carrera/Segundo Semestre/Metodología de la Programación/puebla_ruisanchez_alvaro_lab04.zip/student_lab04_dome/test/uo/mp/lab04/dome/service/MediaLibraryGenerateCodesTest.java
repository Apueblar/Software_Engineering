package uo.mp.lab04.dome.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import uo.mp.lab04.dome.model.CD;
import uo.mp.lab04.dome.model.DVD;
import uo.mp.lab04.dome.model.Platform;
import uo.mp.lab04.dome.model.VideoGame;

/**
 * MediaLibrary::generateCodes()
 * 
 * - Add various items
 */
public class MediaLibraryGenerateCodesTest {

    @Test
    void GenerateCodesTest() {
	MediaLibrary media = new MediaLibrary();

	assertEquals("", media.generateCodes());

	CD myCD = new CD("Ender", "The Doors", 10, 100, 9);
	media.add(myCD);

	assertEquals("End0", media.generateCodes());

	DVD myDVD = new DVD("Begin", "Paco Rueda", 10, 8.5);
	media.add(myDVD);

	assertEquals("End0-Beg1", media.generateCodes());

	VideoGame myVideoGame = new VideoGame("GT", "Paco Rueda", 5, Platform.XBox, 102);
	media.add(myVideoGame);

	assertEquals("End0-Beg1-GT2", media.generateCodes());

	VideoGame myVideoGame2 = new VideoGame("GT", "Paco Rueda", 5, Platform.XBox, 102);
	media.add(myVideoGame2);

	assertEquals("End0-Beg1-GT2-GT3", media.generateCodes());
    }
}
