package uo.mp.lab04.dome.service;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;

import uo.mp.lab04.dome.model.CD;

/**
 * MediaLibrary::searchItem(item)
 * 
 * - matchDifferentReferenceTest
 */
public class MediaLibrarySearchItemTest {

    @Test
    void matchDifferentReferenceTest() {
	MediaLibrary media = new MediaLibrary();
	CD myCD = new CD("The End", "The Doors", 10, 100, 12);
	media.add(myCD);

	assertNotNull(media.searchItem(new CD("The End", "The Doors", 10, 100, 12)));
    }

}
