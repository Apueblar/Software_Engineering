package uo.mp.lab04.dome.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Constructor with parameters
 * Scenarios
 * 
 * - Valid arguments
 * - Invalid title, null
 * - Invalid title, blanks
 * - Invalid author, null
 * - Invalid author, blanks
 * - Invalid numberOfPlayers, 0
 * - Invalid numberOfPlayers, -1
 * - Invalid plataform, "Wikipedia"
 */
public class VideoGameConstructorTest {

    private VideoGame aVideoGame;
    private String theTitle;
    private String theAuthor;
    private int numberOfPlayers;
    private Platform platform;
    private double price;

    @BeforeEach
    public void setUp() {
	theTitle = "Star Wars";
	theAuthor = "George Lucas";
	numberOfPlayers = 4;
	platform = Platform.PlayStation;
	price = 10;
    }

    /**
     * GIVEN valid arguments
     * WHEN new VideoGame(arguments)
     * THEN a new VideoGame is created with that attributes
     */
    @Test
    public void validParams() {
	aVideoGame = new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price);

	assertEquals(theTitle, aVideoGame.getTitle());
	assertEquals(theAuthor, aVideoGame.getAuthor());
	assertFalse(aVideoGame.getOwn());
	assertEquals("No comment", aVideoGame.getComment());
    }

    /**
     * GIVEN valid arguments, except title = null
     * WHEN new VideoGame(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void nullTitle() {
	theTitle = null;
	try {
	    new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price);
	    fail("Exception expected");
	} catch (IllegalArgumentException e) {
	    assertEquals("Invalid title (cannot be null)", e.getMessage());
	}
    }

    /**
     * GIVEN valid arguments, except title = " "
     * WHEN new Cd(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void blankTitle() {
	theTitle = "    ";
	try {
	    new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price);
	    fail("Exception expected");
	} catch (IllegalArgumentException e) {
	    assertEquals("Invalid title (cannot be blank)", e.getMessage());
	}
    }

    /**
     * GIVEN valid arguments, except title = ""
     * WHEN new Cd(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void emptyTitle() {
	theTitle = "";
	try {
	    new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price);
	    fail("Exception expected");
	} catch (IllegalArgumentException e) {
	    assertEquals("Invalid title (cannot be blank)", e.getMessage());
	}
    }

    /**
     * GIVEN valid arguments, except author = null
     * WHEN new VideoGame(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void nullauthor() {
	theAuthor = null;
	try {
	    new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price);
	    fail("Exception expected");
	} catch (IllegalArgumentException e) {
	    assertEquals("Invalid author (cannot be null)", e.getMessage());
	}
    }

    /**
     * GIVEN valid arguments, except author = " "
     * WHEN new VideoGame(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void blankauthor() {
	theAuthor = "   ";
	try {
	    new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price);
	    fail("Exception expected");
	} catch (IllegalArgumentException e) {
	    assertEquals("Invalid author (cannot be blank)", e.getMessage());
	}
    }

    /**
     * GIVEN valid arguments, except author = ""
     * WHEN new VideoGame(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test

    public void emptyauthor() {
	theAuthor = "";
	try {
	    new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price);
	    fail("Exception expected");
	} catch (IllegalArgumentException e) {
	    assertEquals("Invalid author (cannot be blank)", e.getMessage());
	}
    }

    /**
     * GIVEN valid arguments, except NumberOfPlayers = 0
     * WHEN new VideoGame(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void zeroNumberOfPlayers() {
	numberOfPlayers = 0;

	IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
		() -> new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price), "Exception expected");
	assertEquals("The number of players must be greater than 0", e.getMessage());
    }

    /**
     * GIVEN valid arguments, except NumberOfPlayers < 0
     * WHEN new VideoGame(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void negativeNumberOfPlayers() {
	numberOfPlayers = -1;

	IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
		() -> new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price), "Exception expected");
	assertEquals("The number of players must be greater than 0", e.getMessage());
    }

    /**
     * GIVEN valid arguments, except platform = "null"
     * WHEN new VideoGame(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void differentPlatformTest() {
	platform = null;

	IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
		() -> new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price), "Exception expected");
	assertEquals("The platform must be XBox, PlayStation or Nintendo", e.getMessage());
    }

    /**
     * GIVEN valid arguments, except price negative
     * WHEN new VideoGame(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void negativePriceTest() {
	price = -1;

	IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
		() -> new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price), "Exception expected");
	assertEquals("The price must be between the limits [0.0 and 1000.0]", e.getMessage());
    }

    /**
     * GIVEN valid arguments, except price too high
     * WHEN new VideoGame(arguments)
     * THEN throws IllegalArgumentException
     */
    @Test
    public void overPriceTest() {
	price = 1000000;

	IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
		() -> new VideoGame(theTitle, theAuthor, numberOfPlayers, platform, price), "Exception expected");
	assertEquals("The price must be between the limits [0.0 and 1000.0]", e.getMessage());
    }

}
