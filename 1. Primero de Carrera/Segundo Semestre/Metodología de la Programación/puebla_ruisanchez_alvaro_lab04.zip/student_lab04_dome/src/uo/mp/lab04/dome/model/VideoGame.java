package uo.mp.lab04.dome.model;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public class VideoGame extends Item {

    private String author;
    private int numberOfPlayers;
    private Platform platform;
    private final static double TAX = 1.1;

    /**
     * Creates a new VideoGame with default values for gotIt and comment
     * 
     * @param theTitle        String for title
     * @param theAuthor       String for author
     * @param numberOfPlayers integer for numberOfPlayers
     * @param platform        String for platform
     */
    public VideoGame(String theTitle, String theAuthor, int numberOfPlayers, Platform platform, double price) {
	super(theTitle, price);
	setAuthor(theAuthor);
	setNumberOfPlayers(numberOfPlayers);
	setPlatform(platform);
    }

    /**
     * Sets the author
     * 
     * @param arg String with the new author name
     * @throws IllegalArgumentException if the argument is null, 0-length or does not contain meaningful characters
     */
    private void setAuthor(String arg) {
	ArgumentChecks.isNotNull(arg, "Invalid author (cannot be null)");
	ArgumentChecks.isNotBlank(arg, "Invalid author (cannot be blank)");

	this.author = arg;
    }

    /**
     * @return author's name
     */
    public String getAuthor() {
	return this.author;
    }

    /*
     * Checks the numberOfPlayers and assigns it to the variable numberOfPlayers.
     * 
     * @param numberOfPlayers The maximun number of players for each video game.
     * 
     * @throws IllegalArgumentException if the numberOfPlayers is not greater than 0
     */
    public void setNumberOfPlayers(int numberOfPlayers) {
	ArgumentChecks.isTrue(numberOfPlayers > 0, "The number of players must be greater than 0");
	this.numberOfPlayers = numberOfPlayers;
    }

    /*
     * @return The number of players that can play at the same time
     */
    public int getNumberOfPlayers() {
	return numberOfPlayers;
    }

    /*
     * Checks the platform and assigns it to the variable platform.
     * 
     * @param platform The platform of the video game
     * 
     * @throws IllegalArgumentException if the platform is not XBox, PlayStation or Nintendo
     */
    public void setPlatform(Platform platform) {
	ArgumentChecks.isNotNull(platform, "The platform must be XBox, PlayStation or Nintendo");
	this.platform = platform;
    }

    /*
     * @return The platform of the video game (XBox, PlayStation or Nintendo)
     */
    public Platform getPlatform() {
	return platform;
    }

    /**
     * @return The info of this object
     */
    @Override
    public String toString() {
	String info = "";
	info += ("Video Game: " + getTitle() + " (" + getPlatform() + ")\n");
	info += ("Number Of Players: " + getNumberOfPlayers() + "\n");
	info += ("Author: " + getAuthor() + "\n");
	if (getOwn()) {
	    info += ("You own it\n");
	} else {
	    info += ("You do not own it\n");
	}
	info += ("Comment: " + getComment() + "\n");
	return info;
    }

    /*
     * @return the responsible of this VideoGame (the author)
     */
    @Override
    public String getResponsible() {
	return getAuthor();
    }

    @Override
    public int hashCode() {
	final int prime = 31;
	int result = super.hashCode();
	result = prime * result + Objects.hash(author, platform);
	return result;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (!super.equals(obj))
	    return false;
	if (!(obj instanceof VideoGame))
	    return false;
	VideoGame other = (VideoGame) obj;
	return Objects.equals(author, other.author) && platform == other.platform;
    }

    @Override
    public double getPrice() {
	return super.getPrice() * TAX;
    }

}
