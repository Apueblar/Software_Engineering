package uo.mp.lab04.dome.model;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public class DVD extends ItemWithPlayingTime {

    private String director;

    /**
     * Creates a new Dvd with default values for gotIt and comment
     * 
     * @param theTitle    String for title
     * @param theDirector String for director
     * @param time        integer for time
     */
    public DVD(String theTitle, String theDirector, int time, double price) {
	super(theTitle, time, price);
	setDirector(theDirector);
    }

    /**
     * 
     * @param arg String with the new director
     * @throws IllegalArgumentException if the argument is null, 0-length or does not contain meaningful characters
     */
    private void setDirector(String arg) {
	ArgumentChecks.isNotNull(arg, "Invalid director (cannot be null)");
	ArgumentChecks.isNotBlank(arg, "Invalid director (cannot be blank)");
	this.director = arg;
    }

    /**
     * @return the director of the dvd
     */
    public String getDirector() {
	return this.director;
    }

    /**
     * @return The info of this object
     */
    @Override
    public String toString() {
	String info = "";
	info += ("DVD: " + getTitle() + " (" + getPlayingTime() + " mins)\n");
	info += ("Director: " + getDirector() + "\n");
	if (getOwn()) {
	    info += ("You own it\n");
	} else {
	    info += ("You do not own it\n");
	}
	info += ("Comment: " + getComment() + "\n");
	return info;
    }

    /*
     * @return the responsible of this DVD (the director)
     */
    @Override
    public String getResponsible() {
	return getDirector();
    }

    @Override
    public int hashCode() {
	final int prime = 31;
	int result = super.hashCode();
	result = prime * result + Objects.hash(director);
	return result;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (!super.equals(obj))
	    return false;
	if (!(obj instanceof DVD))
	    return false;
	DVD other = (DVD) obj;
	return Objects.equals(director, other.director);
    }

}
