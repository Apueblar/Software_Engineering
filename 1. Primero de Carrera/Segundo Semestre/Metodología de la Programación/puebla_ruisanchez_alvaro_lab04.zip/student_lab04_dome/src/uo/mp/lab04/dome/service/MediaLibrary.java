package uo.mp.lab04.dome.service;

import java.util.ArrayList;
import java.util.List;

import uo.mp.lab04.dome.model.Item;
import uo.mp.util.check.ArgumentChecks;

public class MediaLibrary {

    private List<Item> catalog = new ArrayList<Item>();

    /*
     * Used to add CDs or DVDs to the catalog
     * 
     * @param item the new item
     */
    public void add(Item item) {
	ArgumentChecks.isNotNull(item, "The item is null");
	catalog.add(item);
    }

    /*
     * Used to assign a catalog
     * 
     * @param catalog The new catalog
     */
    void setCatalog(List<Item> catalog) {
	this.catalog = catalog;
    }

    /*
     * Counts the number of owned CDs and DVDs.
     * 
     * @return the number of owned items.
     */
    public int numberOfItemOwned() {
	int haveIt = 0;
	for (Item item : catalog) {
	    if (item.getOwn()) {
		++haveIt;
	    }
	}
	return haveIt;
    }

    /*
     * Searches in the catalog for the item
     * 
     * @param item The item to search for similarities
     * 
     * @return null if not found, otherwise the object
     */
    Item searchItem(Item item) {
	for (Item object : catalog) {
	    if (object.equals(item)) {
		return object;
	    }
	}
	return null;
    }

    /*
     * For testing
     */
    List<Item> getCatalog() {
	return catalog;
    }

    /*
     * Used to print all the CDs and DVDs in out
     */
    public String list() {
	String res = "";
	for (Item item : catalog) {
	    res += item.toString() + "\n";
	}
	return res;
    }

    /*
     * @return An array of strings of all the responsibles of each item in the catalog
     */
    public List<String> getResponsibles() {
	List<String> responsibles = new ArrayList<String>();
	for (Item item : catalog) {
	    responsibles.add(item.getResponsible());
	}
	return responsibles;
    }

    /*
     * @return An array of all the items in the catalog
     */
    List<Item> getItems() {
	List<Item> items = new ArrayList<Item>();
	for (Item item : catalog) {
	    items.add(item);
	}
	return items;
    }

    /*
     * @return The total price of all the items of the catalog
     */
    public double getTotalPrice() {
	double money = 0.0;
	for (Item item : catalog) {
	    money += item.getPrice();
	}
	return money;
    }

    /**
     * @return This method returns a string as the result of concatenating
     *         item’s code, joined by a dash (-).
     *         If there is no item, returns an empty string.
     **/
    public String generateCodes() {
	String codes = "";
	if (catalog.size() == 0) {
	    return codes;
	}
	for (int i = 0; i < catalog.size() - 1; i++) {
	    try {
		codes += catalog.get(i)
		    .getTitle()
		    .substring(0, 3);
	    } catch (Exception e) {
		codes += catalog.get(i)
		    .getTitle();
	    }
	    codes += String.format("%d-", i);
	}
	try {
	    codes += catalog.get(catalog.size() - 1)
		.getTitle()
		.substring(0, 3);
	} catch (Exception e) {
	    codes += catalog.get(catalog.size() - 1)
		.getTitle();
	}
	codes += String.format("%d", catalog.size() - 1);
	return codes;
    }

}
