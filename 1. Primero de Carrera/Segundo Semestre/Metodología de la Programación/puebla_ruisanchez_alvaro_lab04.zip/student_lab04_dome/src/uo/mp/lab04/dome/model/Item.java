package uo.mp.lab04.dome.model;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public abstract class Item {

    private String title;
    private boolean gotIt; // I have my own copy of the Cd
    private String comment;
    private double price;
    private final static double MIN_PRICE = 0.0;
    private final static double MAX_PRICE = 1000.0;

    Item(String theTitle, double price) {
	setTitle(theTitle);
	setOwn(false);
	setComment("No comment");
	setPrice(price);
    }

    /**
     * @return the price of the item
     */
    public double getPrice() {
	return price;
    }

    /*
     * @param price The price of the item
     * 
     * @throws IllegalArgumentException if the price is not between the limits [0.0 , 1000.0]
     */
    public void setPrice(double price) {
	ArgumentChecks.isTrue(MIN_PRICE <= price && price <= MAX_PRICE,
		"The price must be between the limits [0.0 and 1000.0]");
	this.price = price;
    }

    public abstract String getResponsible();

    /**
     * 
     * @param arg String with the new title
     * @throws IllegalArgumentException if the argument is null, 0-length or does not contain meaningful characters
     */
    private void setTitle(String arg) {
	ArgumentChecks.isNotNull(arg, "Invalid title (cannot be null)");
	ArgumentChecks.isNotBlank(arg, "Invalid title (cannot be blank)");

	this.title = arg;
    }

    /**
     * 
     * @param boolean true means we own a copy; otherwise, false
     */
    public void setOwn(boolean ownIt) {
	gotIt = ownIt;
    }

    /**
     * 
     * @param arg String with a new comment to the element
     * @implNote If the argument is null or does not contain meaningful characters (other than blanks, new lines, etc)
     *           previous comment stays as it is
     */
    public void setComment(String arg) {
	if (arg != null && !arg.isBlank()) {
	    this.comment = arg;
	}
    }

    /**
     * @return the comment (if any) or default
     */
    public String getComment() {
	return comment;
    }

    /**
     * @return true if we own a copy; false otherwise
     */
    public boolean getOwn() {
	return gotIt;
    }

    /**
     * @return title
     */
    public String getTitle() {
	return this.title;
    }

    @Override
    public int hashCode() {
	return Objects.hash(title);
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (!(obj instanceof Item))
	    return false;
	Item other = (Item) obj;
	return Objects.equals(title, other.title);
    }

}
