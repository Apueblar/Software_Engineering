package uo.mp.lab04.dome.model;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public class CD extends ItemWithPlayingTime {

    private String artist;
    private int numberOfTracks;
    private final static double TAX = 2.0;

    /**
     * Creates a new Cd with default values for gotIt and comment
     * 
     * @param theTitle  String for title
     * @param theArtist String for artist
     * @param tracks    integer for tracks
     * @param time      integer for time
     */
    public CD(String theTitle, String theArtist, int tracks, int time, double price) {
	super(theTitle, time, price);
	setArtist(theArtist);
	setNumberOfTracks(tracks);
    }

    /**
     * 
     * @param arg String with the new artist name
     * @throws IllegalArgumentException if the argument is null, 0-length or does not contain meaningful characters
     */
    private void setArtist(String arg) {
	ArgumentChecks.isNotNull(arg, "Invalid artist (cannot be null)");
	ArgumentChecks.isNotBlank(arg, "Invalid artist (cannot be blank)");

	this.artist = arg;
    }

    /**
     * 
     * @param arg integer with the number of tracks in the CD
     * @throws IllegalArgumentException if the argument is is lower or equal zero
     */
    private void setNumberOfTracks(int arg) {
	ArgumentChecks.isTrue(arg > 0, "Invalid number of tracks %d (must be a positive integer)".formatted(arg));
	this.numberOfTracks = arg;
    }

    /**
     * @return artist's name
     */
    public String getArtist() {
	return this.artist;
    }

    /**
     * @return number of tracks
     */
    public int getNumberOfTracks() {
	return this.numberOfTracks;
    }

    /**
     * @return The info of this object
     */
    @Override
    public String toString() {
	String info = "";
	info += ("CD: " + getTitle() + " (" + getPlayingTime() + " mins)\n");
	info += ("Artist: " + getArtist() + "\\n");
	info += ("Tracks: " + getNumberOfTracks() + "\n");
	if (getOwn()) {
	    info += ("You own it\n");
	} else {
	    info += ("You do not own it\n");
	}
	info += ("Comment: " + getComment() + "\n");
	return info;
    }

    /*
     * @return the responsible of this CD (the artist)
     */
    @Override
    public String getResponsible() {
	return getArtist();
    }

    @Override
    public int hashCode() {
	final int prime = 31;
	int result = super.hashCode();
	result = prime * result + Objects.hash(artist);
	return result;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (!super.equals(obj))
	    return false;
	if (!(obj instanceof CD))
	    return false;
	CD other = (CD) obj;
	return Objects.equals(artist, other.artist);
    }

    @Override
    public double getPrice() {
	return super.getPrice() + TAX;
    }

}