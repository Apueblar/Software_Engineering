package uo.mp.lab04.dome.model;

import uo.mp.util.check.ArgumentChecks;

public abstract class ItemWithPlayingTime extends Item {

    private int playingTime;

    ItemWithPlayingTime(String theTitle, int time, double price) {
	super(theTitle, price);
	setPlayingTime(time);
    }

    /**
     * 
     * @param arg integer with the playing time in the CD
     * @throws IllegalArgumentException if the argument is is lower or equal zero
     */
    private void setPlayingTime(int arg) {
	ArgumentChecks.isTrue(arg > 0, "Invalid playing time %d (must be a positive integer)".formatted(arg));
	this.playingTime = arg;
    }

    /**
     * @return playing time
     */
    public int getPlayingTime() {
	return this.playingTime;
    }
}
