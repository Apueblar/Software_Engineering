package uo.mp.lab04.dome.ui;

import java.util.List;

import uo.mp.lab04.dome.model.CD;
import uo.mp.lab04.dome.model.DVD;
import uo.mp.lab04.dome.model.Platform;
import uo.mp.lab04.dome.model.VideoGame;
import uo.mp.lab04.dome.service.MediaLibrary;

public class MediaPlayer {

    public void run() {
	MediaLibrary media = new MediaLibrary();

	CD myCD = new CD("The End", "The Doors", 10, 100, 10);
	media.add(myCD);
	DVD myDVD = new DVD("The Begining", "Paco Rueda", 10, 15);
	media.add(myDVD);
	VideoGame myVideoGame = new VideoGame("GTAVI", "Rockstar", 1, Platform.PlayStation, 85);
	myVideoGame.setOwn(true);
	myVideoGame.setComment("The game is incredible as like the cryptocurrencies.");
	media.add(myVideoGame);

	System.out.println("Items owned: " + media.numberOfItemOwned());
	System.out.println("");

	System.out.println(media.list());

	this.printReponsibles(media.getResponsibles());
    }

    /*
     * Prints the list of responsibles of each item in the catalog
     */
    public void printReponsibles(List<String> l) {
	if (l.size() == 0) {
	    System.out.println(" ");
	}
	for (int i = 0; i < l.size() - 1; i++) {
	    System.out.print(l.get(i) + ", ");
	}
	System.out.println(l.get(l.size() - 1));
    }
}
