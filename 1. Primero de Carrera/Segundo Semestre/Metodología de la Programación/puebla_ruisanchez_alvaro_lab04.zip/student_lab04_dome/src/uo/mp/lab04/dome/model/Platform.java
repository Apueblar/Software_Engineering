package uo.mp.lab04.dome.model;

public enum Platform {

    XBox, PlayStation, Nintendo; // Todas las posible variables

    private int year; // Podemos crear atributes to the platform

    Platform() {
	// Constructor the cada plataform
    }

    Platform(int year) {
	setYear(year);
    }

    public void setYear(int year) {
	this.year = year;
    }

    public int getYear() {
	return year;
    }

}
