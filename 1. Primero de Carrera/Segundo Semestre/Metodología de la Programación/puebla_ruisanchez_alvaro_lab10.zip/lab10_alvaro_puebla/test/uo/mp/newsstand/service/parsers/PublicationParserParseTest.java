package uo.mp.newsstand.service.parsers;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PublicationParserParseTest {

	PublicationParser pp;
	
	@BeforeEach
	public void setUp() {
		pp = new PublicationParser();
	}
	
	/**
	 * GIVEN: A null list
	 * WHEN: parse
	 * THEN: IAE
	 */
	@Test
	public void nullListOfLinesTest() {
		try {
			pp.parse(null);
			fail();
		} catch (IllegalArgumentException e) {
			assertTrue(e.getMessage().length() != 0);
		}
	}
	
	
}
