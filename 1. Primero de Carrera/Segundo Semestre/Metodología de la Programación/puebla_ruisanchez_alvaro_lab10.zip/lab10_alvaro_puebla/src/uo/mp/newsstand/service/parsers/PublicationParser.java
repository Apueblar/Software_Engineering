package uo.mp.newsstand.service.parsers;

import java.util.ArrayList;
import java.util.List;

import uo.mp.newsstand.domain.Magazine;
import uo.mp.newsstand.domain.Magazine.Frequency;
import uo.mp.newsstand.domain.Newspaper;
import uo.mp.newsstand.domain.Publication;
import uo.mp.newsstand.exception.InvalidLineFormatException;
import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.log.Logger;

public class PublicationParser {

	/**
	 * Transforms a list of Strings in a list of instances of Publication.
	 * Any of the following are invalid lines in the input file: 
	 * 		- incorrect type of publication, 
	 * 		- wrong number of fields in a line, and 
	 * 		- incorrect data format in numeric fields.
	 * Invalid lines will not produce a Publication instance but will throw an InvalidLineFormatException instead.
	 * As a result of processing this exception, a message will be written to a log (use Log) 
	 * @param lines non-null list of strings, probably empty
	 * 		One by each publication
	 * 				type_of_publication \t name_of_publication \t sales \t stock \t frequency
	 * 
	 * @return a list of publications
	 */
	public List<Publication> parse(List<String> lines) {
		ArgumentChecks.isNotNull(lines, "Invalid list of publications.");
		List<Publication> result = new ArrayList<>();
		for (int lineNumber = 0; lineNumber < lines.size(); lineNumber++) {
			String line = lines.get(lineNumber);
			if(!line.isBlank()) {
				Publication pub;
				try {
					pub = parseLine(line, lineNumber);
					result.add(pub);
				} catch (InvalidLineFormatException e) {
					Logger.log(e.getMessage());
				}
			}
		}
		
		return result;
	}

	private Publication parseLine(String line, int lineNumber) throws InvalidLineFormatException {
		final String SEPARATOR = "\t", newspaper = "newspaper", magazine = "magazine";
		final int KEYWORD = 0;
		
		String[] splittedLine = line.split(SEPARATOR);
		if (line.length() < 1) {throw new InvalidLineFormatException("INVALID LINE %d : INVALID NUMBER OF FIELDS".formatted(lineNumber + 1));}
		if(splittedLine[KEYWORD].contentEquals(newspaper)) {
			if (splittedLine.length != 4) {throw new InvalidLineFormatException("INVALID LINE %d : INVALID NUMBER OF FIELDS newspaper".formatted(lineNumber + 1));}
			return parseNewspaper(splittedLine, lineNumber + 1);
		}if(splittedLine[KEYWORD].contentEquals(magazine)) {
			if (splittedLine.length != 5) {throw new InvalidLineFormatException("INVALID LINE %d : INVALID NUMBER OF FIELDS magacine".formatted(lineNumber + 1));}
			return parseMagazine(splittedLine, lineNumber + 1);
		}
		throw new InvalidLineFormatException("INVALID LINE %d : INVALID KEYWORD".formatted(lineNumber + 1));
	}

	private final static int NAME = 1, SALES = 2, STOCK = 3;
	private Newspaper parseNewspaper(String[] splittedLine, int lineNumber) throws InvalidLineFormatException {
		String name = splittedLine[NAME];
		int sales, stock;
		try {
			sales = Integer.parseInt(splittedLine[SALES]);
			stock = Integer.parseInt(splittedLine[STOCK]);
		} catch (NumberFormatException e) {
			throw new InvalidLineFormatException("INVALID LINE %d : INVALID NUMBER".formatted(lineNumber + 1));
		}
		return new Newspaper(name, sales, stock);
	}
	
	private Magazine parseMagazine(String[] splittedLine, int lineNumber) throws InvalidLineFormatException {
		final int FREQUENCY = 4;
		String name = splittedLine[NAME];
		int sales, stock;
		try {
			sales = Integer.parseInt(splittedLine[SALES]);
			stock = Integer.parseInt(splittedLine[STOCK]);
		} catch (NumberFormatException e) {
			throw new InvalidLineFormatException("INVALID LINE %d : INVALID NUMBER".formatted(lineNumber + 1));
		}
		Frequency frequency = Frequency.valueOf(splittedLine[FREQUENCY].toUpperCase());
		
		return new Magazine(name, sales, stock, frequency);
	}
}
