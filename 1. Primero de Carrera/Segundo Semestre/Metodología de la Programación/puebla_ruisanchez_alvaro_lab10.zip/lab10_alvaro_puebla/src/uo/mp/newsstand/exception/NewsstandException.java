package uo.mp.newsstand.exception;

public class NewsstandException extends Exception{
	private static final long serialVersionUID = 1L;

private String publicationName;
	
	public NewsstandException(String message, String publicationName) {
		super(message);
		this.publicationName = publicationName;
	}
	
	public NewsstandException(String message) {
		super(message);
	}

	public String getPublicationName() {
		return publicationName;
	}
}
