package uo.mp.util.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.LinkedList;
import java.util.List;

/**
 * A utility class to read/write text lines from/to a text file
 */
public abstract class AbstractFileUtil {

	abstract Reader getReader(String pathToTheFile) throws FileNotFoundException, IOException;
	
	/**
	 * Fake method to read lines from a file
	 * 
	 * Read all lines from a file. A line is considered to be terminated by a line feed ('\n'). 
	 * Each item in the list (line) will contain the contents of a line, not including any line-termination characters.
	 * @param pathToTheFile path to a plain text file
	 * @return the lines from the file as a List
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public List<String> readLines(String pathToTheFile) throws FileNotFoundException, IOException {
		List<String> res = new LinkedList<>();
		
		try(BufferedReader br = new BufferedReader(getReader(pathToTheFile))) {
			while (br.ready() /*ready es true si tiene siguiente línea*/) {res.add(br.readLine());}
		}
		return res;
	}
	
	abstract Writer getWriter(String outFileName) throws IOException;

	/**
	 * Fake method to write lines to a file
	 * 
	 * Write to a plain text file all strings in the list. Lines will be separated by a line feed ('\n'). 
	 * Each item in the list (line) contains the contents for one line, not including any
	 * line-termination characters.
	 * 
	 * @param pathToTheFile path to a plain text file
	 * @param lines         the List of Strings to be writen to the file
	 * @throws IOException
	 */
	public void writeLines(String outFileName, List<String> lines) throws IOException {
		try(BufferedWriter bw = new BufferedWriter(getWriter(outFileName))) {
			for(String line : lines) {
				bw.write(line);
				bw.newLine();
			}
		}
	}

}
