package uo.mp.newsstand.exception;

public class InvalidLineFormatException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidLineFormatException(String message) {
		super(message);
	}
}
