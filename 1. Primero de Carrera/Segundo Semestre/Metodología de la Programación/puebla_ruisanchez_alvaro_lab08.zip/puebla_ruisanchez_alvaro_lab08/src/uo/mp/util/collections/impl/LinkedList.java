package uo.mp.util.collections.impl;

import java.util.Iterator;
import java.util.NoSuchElementException;
import uo.mp.util.check.ArgumentChecks;

public class LinkedList<T> extends AbstractList<T> {

	private Node head;
	
	private class Node {
		
		T value;
		Node next;
		
		Node(T value, Node next) {
			this.value = value;
			this.next = next;
		}
	}
	
	private Node getNode(int index) {
		ArgumentChecks.isTrue(index >= 0 && index < super.size(), "The index must be between 0 and the size");
		int position = 0;
		Node node = this.head;
		while (position < index) {
			node = node.next;
			position++; 
		}
		return node;
	}

	public void addFirst(T value) {
		ArgumentChecks.isNotNull(value, "The element you want to set is null");
		this.head = new Node(value, this.head);
		super.incNumberOfElements();
	}



	@Override
	public void clear() {
		head = null;
		super.setNumberOfElements(0);
	}

	@Override
	public T get(int index) {
		return getNode(index).value;
	}

	@Override
	public T set(int index, T value) {
		ArgumentChecks.isTrue(index >= 0 && index < super.size(), "The index (" + index + ") must be between 0 and the size");
		ArgumentChecks.isNotNull(value, "The element you want to set is null");
		Node node = getNode(index);
		T nodeValue = node.value;
		node.value = value;
		return nodeValue;
	}

	@Override
	public void add(int index, T value) {
		ArgumentChecks.isTrue(index >= 0 && index <= super.size(), "The index (" + index + ") must be between 0 and the size");
		ArgumentChecks.isNotNull(value, "The element you want to set is null");
		if (index==0) {addFirst(value);}
		else {
			Node previous = getNode(index-1);
			previous.next = new Node(value, previous.next);
			super.incNumberOfElements();
		}
	}

	@Override
	public T remove(int index) {
		if (this.isEmpty()) {return null;}
		T value;
		if (index == 0) { 
			value = this.head.value;
			this.head = this.head.next;
		} else {
			Node previous = getNode(index - 1);
			value = previous.next.value;
			previous.next = previous.next.next;
		}
		super.decNumberOfElements();
		return value; 
	}
	
	@Override
	public int indexOf(Object o) {
		if (o == null) {return -1;}
		int position = 0;
		Node node = this.head;
		while(position < super.size()) {
			if(node.value.equals(o)) {return position;}
			node = node.next;
			position++;
		}
		return -1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int hashCode = 1;
		int position = 0;
		Node thisNode = this.head;
		while (position < super.size()) {
			hashCode = prime * hashCode + (thisNode.value == null ? 0 : thisNode.value.hashCode());
			thisNode = thisNode.next;
			position++; 
		}
		return hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {return true;}
		if (obj == null) {return false;}
		if (getClass() != obj.getClass()) {return false;}
		@SuppressWarnings("unchecked")
		LinkedList<T> other = (LinkedList<T>) obj;
		int position = 0;
		Node thisNode = this.head;
		Node otherNode = other.head;
		while (position < super.size()) {
			if (thisNode.value != otherNode.value) {return false;}
			otherNode = otherNode.next;
			thisNode = thisNode.next;
			position++; 
		}
		return true;
	}

	@Override
	public Iterator<T> iterator() {
		return new LinkedListIterator();
	}

	private class LinkedListIterator implements Iterator<T>{

		private Node currentNode = head;
		
		@Override
		public boolean hasNext() {
			return currentNode.next != null;
		}

		@Override
		public T next() {
			if(!hasNext()) {throw new NoSuchElementException("No such element");}
			T ret = currentNode.value;
			currentNode = currentNode.next;
			return ret;
		}
		
	}
}
