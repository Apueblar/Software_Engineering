package uo.mp.util.collections.impl;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

import uo.mp.util.check.ArgumentChecks;

public class ArrayList<T> extends AbstractList<T> {

	private T[] elements;
	private final static int INITIAL_CAPACITY = 20;

	public ArrayList() {
		this(INITIAL_CAPACITY);
	}

	@SuppressWarnings("unchecked")
	public ArrayList(int capacity) {
		this.elements= (T[]) new Object[capacity];
	}
	
	private void moreMemory() {
		@SuppressWarnings("unchecked")
		T[] aux = (T[]) new Object[2 * elements.length];
		System.arraycopy(elements, 0, aux, 0,elements.length);
		elements = aux;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void clear() {
		elements = (T[]) new Object[INITIAL_CAPACITY];
		super.setNumberOfElements(0);
	}

	@Override
	public T get(int index) {
		return elements[index];
	}

	@Override
	public T set(int index, T element) {
		ArgumentChecks.isTrue(index >= 0 && index < super.size(), "The index must be between 0 and the size");
		ArgumentChecks.isNotNull(element, "The element you want to set is null");
		T object = elements[index];
		elements[index] = element;
		return object;
	}

	@Override
	public void add(int index, T element) {
		ArgumentChecks.isNotNull(element, "You cannot add a null element");
		if (super.size() >= this.elements.length) {this.moreMemory();}
		for(int i = index; i < super.size(); i++) {elements[i+1] = elements[i];}
		elements[index] = element;
		super.incNumberOfElements();
	}

	@Override
	public T remove(int index) {
		ArgumentChecks.isTrue(index >= 0 && index < super.size(), "The index must be between 0 and the size");
		T value = elements[index];
		for(int i = index; i < size() - 1; i++) {elements[i] = elements[i+1];}
		super.decNumberOfElements();
		elements[super.size()] = null;
		return value;
	}

	@Override
	public int indexOf(Object o) {
		if (o == null) {return -1;}
		for (int i = 0; i < super.size(); i++) {
			if (elements[i].equals(o)) {return i;}
		}
		return -1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int hash = 1;
		for (int index = 0; index < super.size(); index++) {
			hash = prime * hash + elements[index].hashCode();
		}
		return hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {return true;}
		if (obj == null) {return false;}
		if (getClass() != obj.getClass()) {return false;}
		@SuppressWarnings("unchecked")
		ArrayList<T> other = (ArrayList<T>) obj;
		return Arrays.deepEquals(elements, other.elements);
	}

	@Override
	public Iterator<T> iterator() {
		return new ArrayListIterator();
	}
	
	private class ArrayListIterator implements Iterator<T> {

		private int currentIndex = 0;
		
		@Override
		public boolean hasNext() {
			return currentIndex < size();
		}

		@Override
		public T next() {
			if(!hasNext()) {throw new NoSuchElementException("No such element");}
			return elements[currentIndex++];
		}
		
	}
	
}