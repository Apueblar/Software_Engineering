package uo.mp.util.collections.impl;

import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.collections.List;

public abstract class AbstractList<T> implements List<T> {

	private int numberOfElements = 0;
	
	public AbstractList() {}
	
	public AbstractList(int numberOfElements) {
		this.numberOfElements = numberOfElements;
	}

	@Override
	public int size() {
		return numberOfElements;
	}
	
	@Override
	public boolean isEmpty() {
		return numberOfElements == 0;
	}

	void setNumberOfElements(int numberOfElements) {
		ArgumentChecks.isTrue(numberOfElements >= 0, "The number of elements must be >= 0");
		this.numberOfElements = numberOfElements;
	}
	
	void incNumberOfElements() {++numberOfElements;}
	
	void decNumberOfElements() {--numberOfElements;}
	
	@Override
	public boolean add(T o) {
		add(numberOfElements, o);
		return true;
	}
	
	@Override
	public boolean remove(Object o) {
		int index = indexOf(o);
		if (index == -1) {return false;}
		remove(index);
		return true;
	}
	
	@Override
	public boolean contains(Object o) {
		if(this.indexOf(o) == -1) {return false;}
		return true;
	}
	
	public abstract void add(int numberOfElements, T o);
}
