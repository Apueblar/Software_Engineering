package uo.mp.util.collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;


/*
 * SCENARIOS
 * emptyList 	List is empty, then indexOf any item is -1
 * repeatedItem	In a list with repeated elements the indexOf that element returns the position of the first occurrence
 * notInList	The index of an Item not existing in the list is -1
 * nullElem	The index of null is -1
 * firstInList	The index of the first item is 0
 * lastItem	The index of the last item is size - 1
 * nextItem	The index of the an item b next in the list to another item a, is one more than the index of a
 */
public class IndexOfTests {
	
	public static Stream<Arguments> createLists() {
		  return Stream.of(
		      Arguments.of(new ArrayList<Object>()),
		      Arguments.of(new LinkedList<Object>())
		  );
		}

	/**
	 * GIVEN: any list and a null element
	 * WHEN: trying to find the element in the list 
	 * THEN: returns -1 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void nullElem(List<?> list) {
		assertEquals(-1, list.indexOf(null));
	}
	
	/**
	 * GIVEN: an empty list and a non-null element
	 * WHEN: trying to find the element in the list 
	 * THEN: returns -1 (not found) 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyList(List<?> list) {
		String str = "objeto";
		assertEquals(-1, list.indexOf(str));
	}
	
	/**
	 * GIVEN: a list containing repeated item 
	 * WHEN: index of the element in the list 
	 * THEN: returns the index of the first appearance 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void repeatedItem(List<Object> list) {
		list.add(new Object()); // Non empty
		
		String str = "objeto";
		int size = list.size();
		list.add(str);
		list.add(str);
		assertEquals(size, list.indexOf(str));
	}
	
	/**
	 * GIVEN: a list containing several items 
	 * WHEN: index of an element not in the list 
	 * THEN: returns -1  
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void notInList(List<Object> list) {
		list.add(new Object()); // Non empty
		list.add(new Object()); // Non empty
		list.add(new Object()); // Non empty
		
		String str = "objeto";
		assertEquals(-1, list.indexOf(str));
	}
	
	/**
	 * GIVEN: a non empty list and a non-null element place at the head of the list
	 * WHEN: trying to find the element in the list 
	 * THEN: returns 0
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void firstItemInList(List<Object> list) {
		list.add(new Object()); // Non empty
		
		String str = "objeto";
		list.set(0, str);
		assertEquals(0, list.indexOf(str));
	}

	/**
	 * GIVEN: a non empty list and a non-null element place at the end of the list
	 * WHEN: trying to find the element in the list 
	 * THEN: returns size-1
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void lastItemInList(List<Object> list) {
		list.add(new Object()); // Non empty
		
		String str = "objeto";
		list.add(str);
		assertEquals(list.size()-1, list.indexOf(str));
	}
	
	/**
	 * GIVEN: a non empty list and a non-null element (a) in the list
	 * WHEN: indexof the element next to it in the list (b)
	 * THEN: returns the indexof a + 1
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void nextItemInList(List<Object> list) {
		list.add(new Object()); // Non empty
		
		String a = "objeto1";
		assertTrue(list.add(a));
		String b = "objeto2";
		assertTrue(list.add(b));
		assertEquals(list.indexOf(a) + 1, list.indexOf(b));
	}
}
