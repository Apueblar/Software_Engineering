package uo.mp.util.collections;

import static org.junit.Assert.assertTrue;
import java.util.stream.Stream;

import org.junit.jupiter.api.Named;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;

/*
 * SCENARIOS
 *  emptyList Size of an empty list is 0
 * 	nonEmptyList Size of a list with several(n) elements is n
 */
public class SizeTests {
	public static Stream<Arguments> createLists() {
		  return Stream.of(
		      Arguments.of(Named.of("ArrayList", new ArrayList<Object>())),
		      Arguments.of(Named.of("LinkedList", new LinkedList<Object>()))
		  );
		}
	/**
	 * GIVEN: a new list
	 * WHEN: size()
	 * THEN: return 0
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyList(List<?> list) {
		assertTrue("The new list is not size = 0", list.size() == 0);
	}

	/**
	 * GIVEN: a non empty list
	 * WHEN: size()
	 * THEN: return numberOfElements
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void nonEmptyList(List<Integer> list) {
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		
		assertTrue("The list has a size different from 4", list.size() == 4);
	}

}
