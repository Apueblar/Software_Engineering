package uo.mp.util.collections;

import static org.junit.jupiter.api.Assertions.fail;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;

/*
 * SCENARIOS
 * 	sameTypeEmpty Two empty lists the same type are equals
 *  bothTypesEmtpy Two empty lists, each of them a different type, are equals
 * 	sameTypeSameItems Two lists the same type with the same elements in the same order are equal
 *  sameTypeSameItemsDifferentOrder Two lists same type with the same elements in different positions are different
 *  sameTypeDifferentItems Two lists same type with the different elements are different
 * 	bothTypesSameItems One ArrayList and one LinkedList containing the same elements in the same order are equals
 * 	bothTypesDifferentItems One ArrayList and one LinkedList containing different elements are not equals
 */
public class EqualsTests {
	

	private static Stream<Arguments> create2ListsSameType() {
	    return Stream.of(
	    		Arguments.of(new ArrayList<Object>(), new ArrayList<Object>()),
	    		Arguments.of(new LinkedList<Object>(), new LinkedList<Object>())
	    );
	}
	
	private static Stream<Arguments> create2ListsDifferentType() {
	    return Stream.of(
	    		Arguments.of(new ArrayList<Object>(), new LinkedList<Object>()),
	    		Arguments.of(new LinkedList<Object>(), new ArrayList<Object>())
	    );
	}
	
	@ParameterizedTest@MethodSource("create2ListsSameType")
	/**
	 * GIVEN: 2 list same type
	 * WHEN: they are both empty
	 * THEN: are equal
	 */
	public void sameTypeEmtpy(List<?> list1, List<?> list2) {
		fail();
	}

	
	@ParameterizedTest@MethodSource("create2ListsDifferentType")
	/**
	 * GIVEN: An arrayList and a linkedList
	 * WHEN: they are both empty
	 * THEN: are equal
	 */
	public void bothEmtpy(List<?> list1, List<?> list2) {

		fail();
		
	}

	@ParameterizedTest@MethodSource("create2ListsSameType")
	/**
	 * GIVEN: 2 same type with same items in same order
	 * WHEN: equals?
	 * THEN: true
	 */
	public void sameItemsSameType(List<?> list1, List<?> list2) {
		
		fail();
	}
	
	
	@ParameterizedTest@MethodSource("create2ListsSameType")
	/**
	 * GIVEN: 2 lists same type with same items in different order
	 * WHEN: equals?
	 * THEN: false
	 */
	public void sameTypeSameItemsDifferentOrder(List<?> list1, List<?> list2) {
		
		fail();
	}

	
	@ParameterizedTest@MethodSource("create2ListsSameType")

	/**
	 * GIVEN: 2 arraylist with different items 
	 * WHEN: equals?
	 * THEN: false
	 */
	public void sameTypeDifferentItems(List<?> list1, List<?> list2) {
		fail();
	}


	@ParameterizedTest@MethodSource("create2ListsDifferentType")
	/**
	 * GIVEN: arraylist and linkedlist with same items in same order
	 * WHEN: equals?
	 * THEN: true
	 */
	public void bothTypesSameItems(List<?> list1, List<?> list2) {
		fail();
	}

	@ParameterizedTest@MethodSource("create2ListsDifferentType")

	/**
	 * GIVEN: arraylist and linkedlist with different items or in different order
	 * WHEN: equals?
	 * THEN: false
	 */
	public void bothTypesDifferentItems(List<?> list1, List<?> list2) {
		
		fail();

	}

}
