package uo.mp.util.collections;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.util.stream.Stream;

import org.junit.jupiter.api.Named;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;

/*
 * SCENARIOS
 * 	emptyList A new list is empty
 * 	clearedList A cleared list is empty
 * 	listSizeOne A list with with one element is not empty
 * 	severalItemsList A list with more than one element is not empty
 */
public class IsEmptyTests {
	
	public static Stream<Arguments> createLists() {
		  return Stream.of(
		      Arguments.of(Named.of("ArrayList", new ArrayList<Object>())),
		      Arguments.of(Named.of("LinkedList", new LinkedList<Object>()))
		  );
		}
	
	/**
	 * GIVEN: a new list
	 * WHEN: isEmpty()
	 * THEN: return true
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyList(List<?> list) {
		assertTrue("The new list is not empty", list.isEmpty());
	}

	/**
	 * GIVEN: a cleared list
	 * WHEN: isEmpty()
	 * THEN: return true
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void clearedList(List<Integer> list) {
		list.add(1);
		list.add(2);
		
		list.clear();
		assertTrue("The cleared list is not empty", list.isEmpty());
	}
	
	/**
	 * GIVEN: a list of size 1
	 * WHEN: isEmpty()
	 * THEN: return false
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void listSizeOne(List<Integer> list) {
		list.add(1);

		assertFalse("The cleared list is empty", list.isEmpty());
	}
	
	/**
	 * GIVEN: a list of several elements
	 * WHEN: isEmpty()
	 * THEN: return false
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void severalItemsList(List<Integer> list) {
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		
		assertFalse("The cleared list is empty", list.isEmpty());
	}
}
