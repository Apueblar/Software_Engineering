package uo.mp.util.collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Named;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;

/*
 * SCENARIOS
 * emptyList The hashCode of an empty list is 1
 * nonEmptyList The hashCode of a non empty list is the computed hashCode
 * sameTypeSameItemsLists The hashCode of two equals lists of the same type are the same
 * sameTypeDifferentItemsLists The hashCode of two equals lists of different type are the same
 * sameTypeSameItemsDifferentOrder The hashCode of two lists same type with the same elements in different positions are different
 * differentTypeSameItemsLists The hashCode of two lists different type with the same elements in same positions is the same
 */
public class HashCodeTests {
	
	private static Stream<Arguments> create2ListsSameType() {
	    return Stream.of(
	    		Arguments.of(Named.of("ArrayList", new ArrayList<Object>()), Named.of("ArrayList", new ArrayList<Object>())),
	    		Arguments.of(Named.of("LinkedList", new LinkedList<Object>()), Named.of("LinkedList", new LinkedList<Object>()))
	    );
	}
	
	private static Stream<Arguments> create2ListsDifferentType() {
	    return Stream.of(
	    		Arguments.of(Named.of("ArrayList", new ArrayList<Object>()), Named.of("LinkedList", new LinkedList<Object>())),
	    		Arguments.of(Named.of("LinkedList", new LinkedList<Object>()), Named.of("ArrayList", new ArrayList<Object>()))
	    );
	}
	
	public static Stream<Arguments> createOneList() {
		  return Stream.of(
		      Arguments.of(Named.of("ArrayList", new ArrayList<Object>())),
		      Arguments.of(Named.of("LinkedList", new LinkedList<Object>()))
		  );
		}
	
	private int val;

	@BeforeEach
	public void setUp() throws Exception {
		val = 31;
	}


	/**
	 * GIVEN: an empty list 
	 * THEN: the hashCode is 1
	 */
	@ParameterizedTest@MethodSource("createOneList")
	public void emptyList(List<?> list) {
		assertEquals(list.hashCode(), 1);
	}

	/**
	 * GIVEN: a non empty list 
	 * THEN: the hash code is calculated as in the formula
	 */
	@ParameterizedTest@MethodSource("createOneList")
	public void nonEmptyList(List<String> list) {
		list.add("testing");
		list.add("with");
		list.add("JUnit");
		list.add("framework");	

		int hash = list.hashCode();
		
		int myHash = 1;
		for (int index = 0; index < list.size(); index++) {
			myHash = val * myHash + list.get(index).hashCode();
		}
		assertEquals(hash, myHash);
	}
	
	/**
	 * GIVEN: two non empty lists the same type with same items 
	 * THEN: the hashCode is the same
	 */
	@ParameterizedTest@MethodSource("create2ListsSameType")

	public void sameTypeSameItemsLists(List<String> list1, List<String> list2) {

		list1.add(0, "testing");
		list1.add(1, "with");
		list1.add(2, "JUnit");
		list1.add(3, "framework");
		
		list2.add(0, "testing");
		list2.add(1, "with");
		list2.add(2, "JUnit");
		list2.add(3, "framework");

		assertEquals(list1.hashCode(), list2.hashCode());
	}
	
	/**
	 * GIVEN: two non empty lists the same type with same items in different order
	 * THEN: the hashCode is the same
	 */
	@ParameterizedTest@MethodSource("create2ListsSameType")
	public void sameTypeSameItemsDifferentOrder(List<String> list1, List<String> list2) {

		list1.add( "testing");
		list1.add( "with");
		list1.add( "JUnit");
		list1.add( "framework");
		
		list2.add( "JUnit");
		list2.add( "testing");
		list2.add( "with");
		list2.add( "framework");

		assertNotEquals(list1.hashCode(), list2.hashCode());
	}
		
	/**
	 * GIVEN: two non empty lists the same type with different items 
	 * THEN: the hashCode is different
	 */
	@ParameterizedTest@MethodSource("create2ListsSameType")
	public void sameTypeDifferentItemsLists(List<String> list1, List<String> list2) {

		list1.add(0, "testing");
		list1.add(1, "with");
		list1.add(2, "JUnit");
		
		list2.add("framework");
		
		assertNotEquals(list1.hashCode(), list2.hashCode());
	}
	
	
	/**
	 * GIVEN: two non empty lists different type with same items 
	 * THEN: the hashCode is different
	 */
	@ParameterizedTest@MethodSource("create2ListsDifferentType")
	public void differentTypeSameItemsLists(List<String> list1, List<String> list2 ) {

		list1.add("testing");
		list1.add("with");
		list1.add("JUnit");
		list1.add("framework");

		list2.add("testing");
		list2.add("with");
		list2.add("JUnit");
		list2.add("framework");

		assertEquals(list1.hashCode(), list2.hashCode());
	}
}
