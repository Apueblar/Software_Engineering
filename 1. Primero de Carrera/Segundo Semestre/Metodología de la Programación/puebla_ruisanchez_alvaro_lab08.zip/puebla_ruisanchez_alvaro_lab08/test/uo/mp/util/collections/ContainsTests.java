package uo.mp.util.collections;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.util.stream.Stream;

import org.junit.jupiter.api.Named;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;

/*
 * SCENARIOS
 * 	emptyList An empty list does not contain an arbitrary element
 * 	notInList A list with several elements returns false to contain an element not in the list 
 * 	onlyElementInList A list with one element contains the element
 * 	isInList A list with several elements contains all its elements
 * 	emptyListDoesNotContainNull An empty list does not contains null
 * 	nullNotInList A list with elements does not contains null
 */
public class ContainsTests {
	public static Stream<Arguments> createLists() {
		  return Stream.of(
		      Arguments.of(Named.of("ArrayList", new ArrayList<Integer>())),
		      Arguments.of(Named.of("LinkedList", new LinkedList<Integer>()))
		  );
		}

	/**
	 * GIVEN: an empty list
	 * WHEN:  contains anything
	 * THEN: return false
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyList(List<?> list) {	
		assertFalse("The list contains doesn't work as 1 is not contained in an empty list", list.contains(1));
	}

	/**
	 * GIVEN: a list with several items
	 * WHEN: contains a item not in the list
	 * THEN: return false
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void notInList(List<Integer> list) {
		list.add(1);
		list.add(2);
		list.add(3);
		assertFalse("The list contains doesn't work as 4 is not contained in the list", list.contains(4));
	}
	
	/**
	 * GIVEN: a list with 1 element
	 * WHEN: contains of the element
	 * THEN: return true
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void onlyElementInList(List<Integer> list) {
		list.add(1);
		assertTrue("The list contains doesn't work as 1 is contained in the list", list.contains(1));
	}
	
	/**
	 * GIVEN: a list of several elements
	 * WHEN: contains each element
	 * THEN: return true
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void isInList(List<Integer> list) {
		list.add(1);
		list.add(2);
		list.add(3);
		assertTrue("The list contains doesn't work as 1 is contained in the list", list.contains(1));
		assertTrue("The list contains doesn't work as 1 is contained in the list", list.contains(2));
		assertTrue("The list contains doesn't work as 1 is contained in the list", list.contains(3));
	}

	/**
	 * GIVEN: an empty list
	 * WHEN: contains null
	 * THEN: return false
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyListDoesNotContainNull(List<?> list) {
		assertFalse("The list contains doesn't work as null is not contained in an empty list", list.contains(null));
	}
	
	/**
	 * GIVEN: a list of several elements
	 * WHEN: contains null
	 * THEN: return false
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void nullNotInList(List<Integer> list) {
		list.add(1);
		list.add(2);
		list.add(3);
		assertFalse("The list contains doesn't work as null is not contained in the list", list.contains(null));
	}
}
