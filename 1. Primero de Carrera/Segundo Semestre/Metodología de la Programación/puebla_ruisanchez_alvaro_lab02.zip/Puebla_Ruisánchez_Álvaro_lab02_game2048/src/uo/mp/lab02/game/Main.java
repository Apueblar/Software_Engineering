package uo.mp.lab02.game;

import uo.mp.lab02.game.ui.GameApp;



/**
 * Main class of the 2048 game 2048 is a game created by Gabriele Cirulli. The
 * objective is to combine numbers (powers of 2) to get the number 2048 and then
 * win the play. To move the numbers on the board you choose the movement
 * direction (up, down, left and right) with the keyboard. Then the numbers move
 * in the chosen direction and one of this things may happen: - If the
 * next-in-the-direction-to-move cell's value is free the value changes to that
 * cell - If the current value is equal to the next-in-the-direction-to-move
 * cell's value then both values add up in the next cell - If the current value
 * is different then the movement is blocked Copyright: Copyright (c) 2018
 * School of Computing Science - University of Oviedo
 * 
 * @author MP teachers
 * @version 1.0
 */

public class Main {
	public static void main(String[] args) {
		new GameApp().run();
	}
}
