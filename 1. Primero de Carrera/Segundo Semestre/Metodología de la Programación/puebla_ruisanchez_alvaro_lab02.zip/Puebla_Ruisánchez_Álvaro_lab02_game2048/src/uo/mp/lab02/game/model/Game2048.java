package uo.mp.lab02.game.model;

import java.util.Random;
import uo.mp.util.check.ArgumentChecks;

/**
 * A simulation of the "2048" game, see http://juego2048.es/ Copyright (c) 2023 School of Computer Science - University
 * of Oviedo
 * The Game2048 class deals with the gameboard, setting up an array of elements and putting the array in a string. 
 * Most of the logic is also here, the class providing methods for spawning 2's at random locations, moving up, down, left and right, 
 * and letting players know when the game is over.
 * 
 * @author �lvaro Puebla
 * @version 1.1
 */
public class Game2048 {
	private int[][] board;
	private static final int WIN_VALUE = 2048;
	private static final int MIN_BOARD_SIZE = 3;
	private static final int MAX_BOARD_SIZE = 5;
	private static final int DEFAULT_BOARD_SIZE = 3;
	private static final int FREE_POSITION = 0;
	private static final int NEW_PIECE = 2;
	
    /**
     * Creates a 3x3 board (default board) All cells set to 0
     */
    public Game2048() {
    	this(DEFAULT_BOARD_SIZE);
    }

    /**
     * Creates a squared board with the specified size, zeroes all its positions
     * 
     * @param size the desired size for the board
     * @throws IllegalArgumentException
     */
    public Game2048(int size) {
    	ArgumentChecks.isTrue(size <= MAX_BOARD_SIZE, "The size must be lower or equal than " + MAX_BOARD_SIZE);
    	ArgumentChecks.isTrue(size >= MIN_BOARD_SIZE, "The size must be greater or equal than " + MIN_BOARD_SIZE);
    	this.board = createBoard(size);
    }

    /**
     * Constructor with an initial matrix as parameter Useful for testing purposes
     * 
     * @param board squared matrix, 3x3 to 5x5, containing only power-of-2 values. If size < 3 or size > 5 or some tile
     *              contains a non-power-of-2 value, default board is used instead
     * @throws IllegalArgumentException
     */
    Game2048(int[][] board) {
    	ArgumentChecks.isNotNull(board, "You must add a matrix");
    	if (!isSquare(board) || board.length < MIN_BOARD_SIZE || board.length > MAX_BOARD_SIZE || !isPower(board)) {
    		this.board = createBoard(DEFAULT_BOARD_SIZE);
    	} else {
    		this.board = board;
    	}
    }
    
    /**
     * Creates a default board full of 0
     * 
     * @param size the length of the board
     * 
     * @return the default board
     */
    private int[][] createBoard(int size) {
    	board = new int [size][size];
    	for(int i = 0; i < size; i++) {
    		for(int j = 0; j < size; j++) {
    			board[i][j] = FREE_POSITION;
    		}
    	}
    	return board;
	}
    
    /**
     * Checks if the matrix is squared
     * 
     * @param matrix The matrix
     * 
     * @return if its squared or not
     */
    private boolean isSquare(int[][] matrix) {
    	for(int row = 0; row < matrix.length; row++) {
    		if (matrix.length != matrix[row].length) {return false;}
    	}
    	return true;
    }
    
    /**
     * Checks if all the values in the matrix are powers of 2
     * 
     * @param matrix the matrix
     * @return if all the numbers are powers of 2
     */
    private boolean isPower(int[][] matrix) {
    	for(int i = 0; i < matrix.length; i++) {
    		for(int j = 0; j < matrix[0].length; j++) {
    			if (matrix[i][j] != FREE_POSITION && !powerOfTwoBitwise(matrix[i][j])) {return false;}
    		}
    	}
    	return true;
    }

    /**
     * @param n integer number >= 0
     * 
     * @return true if n is a power-of-2 number; false otherwise
     */
    private boolean powerOfTwoBitwise(int n) {
	return (n & (n - 1)) == 0;
    }

    /**
     * Returns the board. For testing purposes
     * 
     * @param the array
     */
    int[][] getBoard() {
    	return board;
    }

    /**
     * A free position is a cell with a 0 value
     * 
     * @return true if there is no free positions on the board
     */
    public boolean isBoardFull() {
		for(int i = 0; i < board.length; i++) {
			for(int j = 0; j < board[0].length; j++) {
				if (board[i][j] == FREE_POSITION) {return false;}
			}
		}
		return true;
    }
    
    
    
    
    /**
     * Pseudocode: For each row 
     * - slideRight (Moves all non blank tiles to the right) 
     * - mergeRight (Moves through the vector; if two adjacent tiles are equal combines them doubling the value of the right tile and setting a zero on the left one) 
     * - slideRight (again, as mergeRight has introduced new zeroes)
     */    
    public void moveRight() {
    	for (int i = 0; i < board.length; i++) {
    		slideRight(board[i]);
    		mergeRight(board[i]);
    		slideRight(board[i]);
    	}
    }

    /**
     * @param vector to move all the non 0 tiles to the Right
     */
    private void slideRight(int[] vector) {
    	for (int i = 0; i < vector.length - 1; i++) {
			for (int j = 0; j < vector.length - 1; j++) {
				if (vector[j] != 0 && vector[j + 1] == 0) {
					vector[j + 1] = vector[j];
					vector[j] = 0;
				}
			}
    	}
    }

    /**
     * @param vector to merge adding contiguous tiles to the right if contain the same value and replacing tile on the
     *               left with zero
     */
    private void mergeRight(int[] vector) {
    	for (int j = vector.length - 1; 0 < j; j--) {
			if (vector[j] == vector[j - 1]) {
				vector[j - 1] = 0;
				vector[j] *= 2;
			}
		}
    }

    /**
     * Move elements to the left with the same logic as in moveRight() By using the rotateBoard() method it is much
     * easier, it is a combination of rotate, rotate, move right, rotate, rotate
     */
    public void moveLeft() {
		rotateBoard();
		rotateBoard();
		moveRight();
		rotateBoard();
		rotateBoard();
    }

    /**
     * Move elements up with the same logic as in moveRight() By using the rotateBoard() method it is much easier, a
     * combination of rotations and moveRight
     */
    public void moveUp() {
    	rotateBoard();
		rotateBoard();
		rotateBoard();
		moveRight();
		rotateBoard();
    }

    /**
     * Move elements down with the same logic as in moveRight() By using the rotateBoard() method it is much easier, a
     * combination of rotations and moveRight
     */
    public void moveDown() {
    	rotateBoard();
    	moveRight();
		rotateBoard();
		rotateBoard();
		rotateBoard();
    }

    /**
     * Rotates the board to the left (counterclockwise) Hint: create a new array and copy the values in the rotated
     * positions
     */
    private void rotateBoard() {
		int[][] rotated_array = new int[board.length][board[0].length];
		
		for(int i = 0; i < board.length; i++) {
			for(int j = 0; j < board[0].length; j++) {
				rotated_array[board.length - (j + 1)][i] = board[i][j];
			}
		}
		
		this.board = rotated_array;
    }

    /**
     * Writes a 2 value on a random free tile, ensuring there is one.
     * 
     * @return true if there was a free tile; false otherwise.
     */
    public boolean next() {
    	int freePos = 0;
    	for(int i = 0; i < board.length; i++) {
			for(int j = 0; j < board[0].length; j++) {
				if (board[i][j] == FREE_POSITION) {freePos += 1;} // The same as freePos++
			}
		}
		if (freePos == 0) {return false;}
		
		Random random = new Random();
		for (int i = 0; i < board.length; i++) {
			for(int j = 0; j < board[0].length; j++) {
				if (board[i][j] == FREE_POSITION) {
					if (random.nextInt(freePos) == 0) {
						board[i][j] = NEW_PIECE;
						return true;
					}
					freePos--;
				}
			}
		}
		throw new IllegalArgumentException("NEVER REACHED");
    }

    /**
     * @return a String with the content of the board to be printed out. Format each string so there are 5 spaces for
     *         every cell in the same row. Example: 2 2 0 2 0 0 2 0 2 will be
     *         "2....2....0....\n2....0....0....\n2....0....2...."
     */
    public String toString() {
    	String text = "";
    	for (int i = 0; i < board.length; i++) {
    		for (int j = 0; j < board[0].length; j++) {
    			text += String.format("%-5s", Integer.toString(board[i][j]));
    		}
    		text += "\n";
    	}
    	return text;
    }

    /**
     * @return true if the player has won; a tile contains 2048 
     */
    public boolean win() {
    	for(int i = 0; i < board.length; i++) {
			for(int j = 0; j < board[0].length; j++) {
				if (board[i][j] >= WIN_VALUE) {return true;}
			}
		}
		return false;
    }

}
