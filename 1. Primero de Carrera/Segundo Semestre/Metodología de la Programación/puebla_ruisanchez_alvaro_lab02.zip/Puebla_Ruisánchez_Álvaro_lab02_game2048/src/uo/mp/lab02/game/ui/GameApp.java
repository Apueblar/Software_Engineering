package uo.mp.lab02.game.ui;

import uo.mp.lab02.game.model.Game2048;

/**
 * The Game Class houses the run method, most of the GUI methods and the Key
 * interactions. It takes both the Game2048 class, and enables it to work.
 **/

public class GameApp {
	private Game2048 game = new Game2048();

	public void run() {
		do {
			play();
		} while (userWantsAnotherPlay());
	}

	private boolean userWantsAnotherPlay() {
		Output.showNewGamePrompt();
		return Input.readCharacter() == 's';
	}

	private void play() {
		Output.printTitle();

		do {
			game.next();
			Output.showGameStatus(game.toString());
			doMovement();
		} while (!game.win() && !game.isBoardFull());
		Output.showGameOver();
	}

	private void doMovement() {
		Output.showMovements();
		switch (Input.readCharacter()) {
		case 'r':
		case 'R':
			game.moveRight();
			break;
		case 'l':
		case 'L':
			game.moveLeft();
			break;
		case 'u':
		case 'U':
			game.moveUp();
			break;
		case 'd':
		case 'D':
			game.moveDown();
			break;
		}
	}

}
