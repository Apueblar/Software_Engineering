package uo.mp.lab02.game.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Input {

	/**
	 * Reads an character from the standard input (usually the keyboard)
	 * @return 
	 */
	static int readCharacter() {
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		int character = 0;
		try {
			character = br.read();
		} catch (IOException e) {
			System.out.println("An error has happen with the data input!");
			System.exit(0);
		}
		return character;
	}
	
}
