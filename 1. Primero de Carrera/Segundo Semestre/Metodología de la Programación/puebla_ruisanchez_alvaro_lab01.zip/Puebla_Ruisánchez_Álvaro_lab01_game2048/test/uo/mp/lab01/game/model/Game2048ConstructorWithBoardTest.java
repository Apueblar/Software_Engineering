package uo.mp.lab01.game.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.util.ForTesting;

/**
 * Scenarios:
 * - valid boards (lower limit 3, intermediate dimension 4, higher limit 5)
 * - invalid board: not squared
 * - invalid board: dimension under 3
 * - invalid board: dimension over 5
 * - invalid board: content not a multiple of 2
 * - invalid null board
 */
public class Game2048ConstructorWithBoardTest {

    @Test
    /**
     * GIVEN: A valid matrix 3x3
     * WHEN: Create a Game with the board
     * THEN: the board is set to the argument
     */
    @DisplayName("Test with a valid matrix 3x3")
    public void testLowerLimit() {
        Game2048 game = new Game2048(ForTesting.FULL);
        assertArrayEquals(ForTesting.FULL, game.getBoard(), "Full board test failed");
        
        game = new Game2048(ForTesting.EMPTY);
        assertArrayEquals(ForTesting.EMPTY, game.getBoard(), "Empty board test failed");
    }

    @Test
    /**
     * GIVEN: A valid matrix 5x5
     * WHEN: Create a Game with the board
     * THEN: the board is set to the argument
     */
    @DisplayName("Test with a valid matrix 5x5")
    public void testUpperLimit() {
    	Game2048 game = new Game2048(ForTesting.BIG_HALF_FULL);
        assertArrayEquals(ForTesting.BIG_HALF_FULL, game.getBoard(), "Half_Full board test failed");
        
        game = new Game2048(ForTesting.BIG_EMTPY);
        assertArrayEquals(ForTesting.BIG_EMTPY, game.getBoard(), "Empty board test failed");
        
        game = new Game2048(ForTesting.HALF_FULL_2048);
        assertArrayEquals(ForTesting.HALF_FULL_2048, game.getBoard(), "Half_Full_2048 board test failed");
    }

    @Test
    /**
     * GIVEN: A valid matrix 4x4
     * WHEN: Create a Game with the board
     * THEN: the board is set to the argument
     */
    @DisplayName("Test with a valid matrix 4x4")
    public void testIntermediateDimension() {
    	Game2048 game = new Game2048(ForTesting.MEDIUM_HALF_FULL);
        assertArrayEquals(ForTesting.MEDIUM_HALF_FULL, game.getBoard(), "Half_Full board test failed");
        
        game = new Game2048(ForTesting.MEDIUM_EMPTY);
        assertArrayEquals(ForTesting.MEDIUM_EMPTY, game.getBoard(), "Empty board test failed");
    }

    @Test
    /**
     * GIVEN: An invalid matrix 2x2
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    @DisplayName("Test with an invalid matrix 2x2")
    public void testDimensionUnder3() {
       	Game2048 game = new Game2048(ForTesting.TINY_BOARD);
        assertArrayEquals(ForTesting.EMPTY, game.getBoard(), "2x2 board test failed");

    }

    @Test
    /**
     * GIVEN: An invalid matrix 6x6
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    @DisplayName("Test with an invalid matrix 6x6")
    public void testDimensionOver5() {
       	Game2048 game = new Game2048(ForTesting.TOO_BIG_BOARD);
        assertArrayEquals(ForTesting.EMPTY, game.getBoard(), "6x6 board test failed");
    }

    @Test
    /**
     * GIVEN: An invalid matrix 3x4
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    @DisplayName("Test with an invalid non squared matrix 2x3")
    public void testNotSquaredDimension() {
       	Game2048 game = new Game2048(ForTesting.NOT_SQUARED_BOARD);
        assertArrayEquals(ForTesting.EMPTY, game.getBoard(), "2x3 board test failed");
    }

    @Test
    /**
     * GIVEN: An matrix 4x4 containing an invalid value (not power of 2)
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    @DisplayName("Test with an invalid power of 2 matrix")
    public void testInvalidContent() {
       	Game2048 game = new Game2048(ForTesting.CORRUPTED_BOARD);
        assertArrayEquals(ForTesting.EMPTY, game.getBoard(), "Corrupted board test failed");
    }

    @Test
    /**
     * GIVEN: A null matrix
     * WHEN: Create a Game with the board
     * THEN: IllegalArgumentException expected
     */
    @DisplayName("Test with a null matrix")
    public void testNullContent() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		    new Game2048(null);
		}, "IllegalArgumentException was expected");
    }
}
