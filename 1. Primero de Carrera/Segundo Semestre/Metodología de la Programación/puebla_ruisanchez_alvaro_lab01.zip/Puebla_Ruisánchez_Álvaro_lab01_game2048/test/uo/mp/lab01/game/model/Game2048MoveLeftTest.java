package uo.mp.lab01.game.model;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import uo.mp.lab01.game.model.Game2048;

/**
 * Scenarios
 * - no merge is possible
 * - one merge is possible
 * - more than one merge is possible but invalid on a merged tile
 */
public class Game2048MoveLeftTest {

    /**
     * GIVEN: [[0,2,0],[2,0,0],[0,0,2]]
     * WHEN: moveLeft
     * THEN: [[2,0,0],[2,0,0],[2,0,0]]
     */
    @Test
    public void shiftNoMerge() {
		int[][] arr = { { 0, 2, 0 }, { 2, 0, 0 }, { 0, 0, 2 } };
		int[][] result = { { 2, 0, 0 }, { 2, 0, 0 }, { 2, 0, 0 } };
		Game2048 game = new Game2048(arr);
		game.moveLeft();
	
		assertArrayEquals(game.getBoard(), result);

    }

    /**
     * GIVEN: [[0,2,2],[2,0,2],[2,2,0]]
     * WHEN: moveLeft
     * THEN: [[4,0,0],[4,0,0],[4,0,0]]
     */
    @Test
    public void shiftMergeOne() {
		int[][] arr = { { 0, 2, 2 }, { 2, 0, 2 }, { 2, 2, 0 } };
		int[][] result = { { 4, 0, 0 }, { 4, 0, 0 }, { 4, 0, 0 } };
		Game2048 game = new Game2048(arr);
		game.moveLeft();
	
		assertArrayEquals(game.getBoard(), result);

    }

    /**
     * GIVEN: [[2,2,2],[2,2,4],[4,2,2]]
     * WHEN: moveLeft
     * THEN: [[4,2,0],[4,4,0],[4,4,0]]
     */
    @Test
    public void shiftMergeJustOnce() {
		int[][] arr = { { 2, 2, 2 }, { 2, 2, 4 }, { 4, 2, 2 } };
		int[][] result = { { 4, 2, 0 }, { 4, 4, 0 }, { 4, 4, 0 } };
		Game2048 game = new Game2048(arr);
		game.moveLeft();
	
		assertArrayEquals(game.getBoard(), result);

    }

    /**
     * GIVEN: [[2,2,0,2,2],[2,0,2,0,2],[2,2,2,2,0],[2,4,4,0,2],[4,2,4,2,2]]
     * WHEN: moveLeft
     * THEN: [[4,4,0,0,0],[4,2,0,0,0],[4,4,0,0,0],[2,8,2,0,0],[4,2,4,4,0]]
     */
    @Test
    public void shiftMergeOneBigBoard() {
		int[][] arr = { { 2, 2, 0, 2, 2 }, { 2, 0, 2, 0, 2 }, { 2, 2, 2, 2, 0 }, { 2, 4, 4, 0, 2 }, { 4, 2, 4, 2, 2 } };
		int[][] result = { { 4, 4, 0, 0, 0 }, { 4, 2, 0, 0, 0 }, { 4, 4, 0, 0, 0 }, { 2, 8, 2, 0, 0 }, { 4, 2, 4, 4, 0 } };
		Game2048 game = new Game2048(arr);
		game.moveLeft();
	
		assertArrayEquals(game.getBoard(), result);

    }
}
