package uo.mp.lab01.game.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.util.ForTesting;

/**
 * Scenarios:
 * - true empty matrix 
 * - true half full matrix 
 * - false full matrix
 */
public class Game2048NextTest {

	@Test
    /**
     * GIVEN: An empty matrix 3x3
     * WHEN: next
     * THEN: true and a 2 is randomly placed
     */
    @DisplayName("Test with empty matrix")
    public void testEmptyMatrix() {
        Game2048 game = new Game2048(ForTesting.EMPTY);
        assertTrue(game.next());
        assertTrue("Empty next test failed", count2(game.getBoard()) == 1);
        
        assertTrue(game.next());
        assertTrue("Empty next test failed", count2(game.getBoard()) == 2);
        
        assertTrue(game.next());
        assertTrue("Empty next test failed", count2(game.getBoard()) == 3);
        
        assertTrue(game.next());
        assertTrue("Empty next test failed", count2(game.getBoard()) == 4);
        
        assertTrue(game.next());
        assertTrue("Empty next test failed", count2(game.getBoard()) == 5);
        
        assertTrue(game.next());
        assertTrue("Empty next test failed", count2(game.getBoard()) == 6);
        
        assertTrue(game.next());
        assertTrue("Empty next test failed", count2(game.getBoard()) == 7);
    }

    @Test
    /**
     * GIVEN: A half-full matrix 4x4
     * WHEN: next
     * THEN: true and a 2 is randomly placed
     */
    @DisplayName("Test with half-full matrix")
    public void testHalfFullMatrix() {
    	Game2048 game = new Game2048(ForTesting.MEDIUM_HALF_FULL);
    	assertTrue("MEDIUM_HALF_FULL has been changed", count2(game.getBoard()) == 4);
    	
        assertTrue(game.next());
        assertTrue("Half-Full next test failed", count2(game.getBoard()) == 5);
        
        assertTrue(game.next());
        assertTrue("Half-Full next test failed", count2(game.getBoard()) == 6);
        
        assertTrue(game.next());
        assertTrue("Half-Full next test failed", count2(game.getBoard()) == 7);
        
        assertTrue(game.next());
        assertTrue("Half-Full next test failed", count2(game.getBoard()) == 8);
        
        assertTrue(game.next());
        assertTrue("Half-Full next test failed", count2(game.getBoard()) == 9);
        
        assertTrue(game.next());
        assertTrue("Half-Full next test failed", count2(game.getBoard()) == 10);
        
        assertTrue(game.next());
        assertTrue("Half-Full next test failed", count2(game.getBoard()) == 11);
        
        assertTrue(game.next());
        assertTrue("Half-Full next test failed", count2(game.getBoard()) == 12);
    }

    @Test
    /**
     * GIVEN: A full matrix 5x5
     * WHEN: next
     * THEN: false
     */
    public void testFullMatrix() {
    	Game2048 game = new Game2048(ForTesting.FULL_2048);
    	assertFalse("Full next test failed", game.next());
    }

	private int count2(int[][] matrix) {
		int num = 0;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[0].length; j++) {
				if (matrix[i][j] == 2) {num += 1;}
			}
		}
		return num;
	}
}