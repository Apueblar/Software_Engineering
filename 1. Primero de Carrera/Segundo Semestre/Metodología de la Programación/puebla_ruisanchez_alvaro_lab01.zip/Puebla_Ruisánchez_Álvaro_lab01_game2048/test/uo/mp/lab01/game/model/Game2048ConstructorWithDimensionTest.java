package uo.mp.lab01.game.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.fail;
import java.util.Arrays;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.util.ForTesting;

/**
 * Scenarios:
 * - valid boards (size from 3 to 5)
 * - invalid boards: size lower than 3 (2)
 * - invalid boards: size greater than 5 (6)
 * - invalid boards: size 0
 */
public class Game2048ConstructorWithDimensionTest {

    @Test
    /**
     * GIVEN: A valid size of 3
     * WHEN: Create a Game with the size
     * THEN: The board is set to a 3x3 matrix of 0's
     */
    @DisplayName("Test with size = 3")
    public void testSize3Board() {
    	Game2048 game = new Game2048(3);
    	int[][] Matrix1 = { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } };
        assertArrayEquals(Matrix1, game.getBoard(), "Size 3 board test failed");
    }

    @Test
    /**
     * GIVEN: A valid size of 5
     * WHEN: Create a Game with the size
     * THEN: The board is set to a 5x5 matrix of 0's
     */
    @DisplayName("Test with size = 5")
    public void testSize5Board() {
    	Game2048 game = new Game2048(5);
    	int[][] Matrix2 = { { 0, 0, 0, 0, 0}, { 0, 0, 0, 0, 0}, { 0, 0, 0, 0, 0}, { 0, 0, 0, 0, 0}, { 0, 0, 0, 0, 0}};
        assertArrayEquals(Matrix2, game.getBoard(), "Size 3 board test failed");
    }

    @Test
    /**
     * GIVEN: An invalid size of 2
     * WHEN: Create a Game with the size
     * THEN: IllegalArgumentException expected
     */
    @DisplayName("Test with size = 2")
    public void testSize2Board() {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    	    new Game2048(2);
    	}, "IllegalArgumentException was expected");
    }

    @Test
    /**
     * GIVEN: An invalid size of 6
     * WHEN: Create a Game with the size
     * THEN: IllegalArgumentException expected
     */
    @DisplayName("Test with size = 6")
    public void testSize6Board() {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    	    new Game2048(6);
    	}, "IllegalArgumentException was expected");
    }

    @Test
    /**
     * GIVEN: An invalid size of 0
     * WHEN: Create a Game with the size
     * THEN: IllegalArgumentException expected
     */
    @DisplayName("Test with size = 0")
    public void testSize0Board() {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    	    new Game2048(0);
    	}, "IllegalArgumentException was expected");
    }

}
