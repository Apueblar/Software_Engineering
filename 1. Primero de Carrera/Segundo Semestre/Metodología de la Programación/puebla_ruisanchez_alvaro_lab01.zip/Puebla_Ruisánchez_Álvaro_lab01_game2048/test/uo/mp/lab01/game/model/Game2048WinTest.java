package uo.mp.lab01.game.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.Game2048;
import uo.mp.lab01.game.model.util.ForTesting;

/**
 * Scenarios:
 * - false 2048 win (EMPTY)
 * - false 2048 win (FULL)
 * - false 2048 win (HALF_FULL)
 * - false 2048 win (MEDIUM_HALF_FULL)
 * - false 2048 win (MEDIUM_EMPTY)
 * - false 2048 win (BIG_EMTPY)
 * - false 2048 win (BIG_HALF_FULL)
 * - true 2048 win (HALF_FULL_2048)
 * - true 2048 win (FULL_2048)
 */
class Game2048WinTest {

	@Test
	/* GIVEN: an empty board (3x3)
	 * WHEN: win method is run
	 * THEN: false
	 */
	@DisplayName("Empty Win() Test")
	void testEmptyWin() {
		Game2048 game = new Game2048(ForTesting.EMPTY);
		assertFalse(game.win());
	}
	
	@Test
	/* GIVEN: a full board (3x3)
	 * WHEN: win method is run
	 * THEN: false
	 */
	@DisplayName("Full Win() Test")
	void testFullWin() {
		Game2048 game = new Game2048(ForTesting.FULL);
		assertFalse(game.win());
	}
	
	@Test
	/* GIVEN: an half-full board (3x3)
	 * WHEN: win method is run
	 * THEN: false
	 */
	@DisplayName("Half-Full Win() Test")
	void testHalfFullWin() {
		Game2048 game = new Game2048(ForTesting.HALF_FULL);
		assertFalse(game.win());
	}
	
	@Test
	/* GIVEN: a medium-half-full board (4x4)
	 * WHEN: win method is run
	 * THEN: false
	 */
	@DisplayName("Medium-Half-Full Win() Test")
	void testMediumHalfFullWin() {
		Game2048 game = new Game2048(ForTesting.MEDIUM_HALF_FULL);
		assertFalse(game.win());
	}
	
	@Test
	/* GIVEN: a medium-empty board (4x4)
	 * WHEN: win method is run
	 * THEN: false
	 */
	@DisplayName("Medium-Empty Win() Test")
	void testMediumEmptyWin() {
		Game2048 game = new Game2048(ForTesting.MEDIUM_EMPTY);
		assertFalse(game.win());
	}
	
	@Test
	/* GIVEN: a big-empty board (5x5)
	 * WHEN: win method is run
	 * THEN: false
	 */
	@DisplayName("Big-Empty Win() Test")
	void testBigEmptyWin() {
		Game2048 game = new Game2048(ForTesting.BIG_EMTPY);
		assertFalse(game.win());
	}
	
	@Test
	/* GIVEN: a big-half-full board (5x5)
	 * WHEN: win method is run
	 * THEN: false
	 */
	@DisplayName("Big-Half-Full Win() Test")
	void testBigHalfFullWin() {
		Game2048 game = new Game2048(ForTesting.BIG_HALF_FULL);
		assertFalse(game.win());
	}
	
	@Test
	/* GIVEN: an half-full-2048 board (5x5)
	 * WHEN: win method is run
	 * THEN: true
	 */
	@DisplayName("Half-Full-2048 Win() Test")
	void testHalfFull2048Win() {
		Game2048 game = new Game2048(ForTesting.HALF_FULL_2048);
		assertTrue(game.win());
	}

	
	@Test
	/* GIVEN: a full-2048 board (5x5)
	 * WHEN: win method is run
	 * THEN: true
	 */
	@DisplayName("Full-2048 Win() Test")
	void testFull2048Win() {
		Game2048 game = new Game2048(ForTesting.FULL_2048);
		assertTrue(game.win());
	}
	
}
