package uo.mp.lab01.game.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.Game2048;
import uo.mp.lab01.game.model.util.ForTesting;

/**
 * Scenarios: 
 * - Fully filled board 
 * - Partially filled board 
 * - Empty board
 */
public class Game2048IsBoardFullTest {

	@Test
	/**
	 * GIVEN: a full board {{2,2,2},{2,2,2},{2,2,2}} 
	 * WHEN: run is board full 
	 * THEN: true
	 */
	public void testFullBoard() {

		Game2048 game = new Game2048(ForTesting.FULL);
		assertTrue(game.isBoardFull());
	}

	@Test
	/**
	 * GIVEN: a not full board {{2,2,0},{2,2,0},{2,2,0}} 
	 * WHEN: run is board full
	 * THEN: false
	 */
	public void testNotFullBoard() {

		Game2048 game = new Game2048(ForTesting.HALF_FULL);
		assertFalse(game.isBoardFull());
	}

	@Test
	/**
	 * GIVEN: an empty board {{0,0,0},{0,0,0},{0,0,0}} 
	 * WHEN: run is board full 
	 * THEN: false
	 */
	public void testEmptyBoard() {
		Game2048 game = new Game2048(ForTesting.EMPTY);
		assertFalse(game.isBoardFull());
	}
}
