package uo.mp.lab01.game.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.util.ForTesting;

/**
 * Scenarios:
 * - Empty board 3x3
 * - Medium board 4x4
 * - Big board 5x5
 * - HALF_FULL_2048 5x5
 */
public class Game2048ToStringTest {

    @Test
    /**
     * GIVEN: An empty board 3x3
     * WHEN: toString
     * THEN: we get a string of the board
     */
    @DisplayName("Test with a valid matrix 3x3")
    public void testToStringEmpty() {
        Game2048 game = new Game2048(ForTesting.EMPTY);
        String text = game.toString();
        assertEquals("0    0    0    \n0    0    0    \n0    0    0    \n", text);
    }
    
    @Test
    /**
     * GIVEN: A half full board 4x4
     * WHEN: toString
     * THEN: we get a string of the board
     */
    @DisplayName("Test with a valid matrix 4x4")
    public void testToStringMedium() {
        Game2048 game = new Game2048(ForTesting.MEDIUM_HALF_FULL);
        String text = game.toString();
        assertEquals("2    0    0    0    \n2    0    0    0    \n2    0    0    0    \n2    0    0    0    \n", text);
    }
    
    @Test
    /**
     * GIVEN: A half full board 5x5
     * WHEN: toString
     * THEN: we get a string of the board
     */
    @DisplayName("Test with a valid matrix 5x5")
    public void testToStringBig() {
        Game2048 game = new Game2048(ForTesting.BIG_HALF_FULL);
        String text = game.toString();
        assertEquals("2    0    0    0    0    \n2    0    0    0    0    \n2    0    0    0    0    \n2    0    0    0    0    \n2    0    0    0    0    \n", text);
    }
    
    @Test
    /**
     * GIVEN: A half full board 5x5 with 2048
     * WHEN: toString
     * THEN: we get a string of the board
     */
    @DisplayName("Test with a valid matrix 5x5 win_2048")
    public void testToStringHalfFull2048() {
        Game2048 game = new Game2048(ForTesting.HALF_FULL_2048);
        String text = game.toString();
        assertEquals("2    0    0    0    0    \n2    0    0    0    0    \n2    0    2048 0    0    \n2    0    0    0    0    \n2    0    0    0    0    \n", text);
    }
    
    @Test
    /**
     * GIVEN: A half full board 5x5 with 2048
     * WHEN: toString
     * THEN: we get a string of the board
     */
    @DisplayName("Test with a valid matrix 5x5 win_Full_2048")
    public void testToStringFull2048() {
        Game2048 game = new Game2048(ForTesting.FULL_2048);
        String text = game.toString();
        assertEquals("2    2    4    2    8    \n2    8    64   64   32   \n2    2    2048 16   8    \n2    2    8    256  8    \n2    2    16   128  512  \n", text);
    }
    
}
