package uo.mp.lab01.game.ui;

class Output {

    static void printTitle() {
	System.out.print("2048 GAME\n");
    }

    static void showNewGamePrompt() {
	System.out.print("Do you want another try? s/n: ");
    }

    static void showGameOver() {
	System.out.println("GAME OVER");
    }

    static void showMovements() {
	System.out.print("Choose one direction [r R]/[l L]/[u U]/[d D]: ");
    }
    
    static void showGameStatus (String gameStatus) {
    	System.out.print(gameStatus);
    }

}
