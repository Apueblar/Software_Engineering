#include <cstring>
#include <iostream>

// To pass every step you can input these values:
// [PasswordControl_T3] -> "v31cQD4fA", ".....#.#......."
// [MaskAccess_T3] -> 2645449929, 785676330
// [AsmBasedControl_T3] -> 250, 65, 64
// [CheckArray_T3] -> 369, 65535, 65535
// "Access granted"
//
// If not, Invalid License!

using namespace std;

extern "C" bool areEqualAssembly(int a, int b);
extern "C" int IsValidAssembly(int num1, int num2, int num3);

// Write here the UO that you have used as ID:
// UO: 299751

void PasswordControl_T3(void);
void MaskAccess_T3(void);
void AsmBasedControl_T3(void);
void CheckArray_T3(void);

int main() {
    PasswordControl_T3();
    MaskAccess_T3();
    AsmBasedControl_T3();
    CheckArray_T3();
    cout << "Access granted";
    return 0;
}

// PasswordControl_T3() ----- �lvaro
// Valid input: "v31cQD4fA"
// And Valid second part input: ".....#.#......." or more length
// Invalid input: any other string
void PasswordControl_T3(void) {
    int const MAX_PASSWORD = 20;
    char Input[MAX_PASSWORD];

    cout << "[PasswordControl_T3] Enter password: ";
    cin >> Input;
    if (strcmp(Input, "v31cQD4fA") != 0) {
        cout << "You do not have access here" << endl;
        exit(EXIT_FAILURE);
    }
    cout << "[PasswordControl_T3] Enter password again: ";
    cin >> Input;
    if (strlen(Input) < 15 || Input[5] != Input[7]) {
        cout << "There was some failure" << endl;
        exit(EXIT_FAILURE);
    }
}

// MaskAccsess_T3() ----- Sof�a
// Valid inputs:
// num1=2645449929, num2=785676330
// num1=4286578703, num2=8387647
// num1=4286578703, num2=8388159


// #######11..................0....
// .........##############000######

// 11111111100000000000000000001111 (4286578703)
// 00000000011111111111111000111111 (8388159)

// 10011101101011100101110011001001 (2645449929)
// 00101110110101000111100000101010 (785676330)

// Invalid input: 1, 1, 1
void MaskAccess_T3() {
    int ID[] = { 2, 9, 9, 7, 5, 1 };

    unsigned int num1, num2;
    cout << "[MaskAccess_T3] Enter one unsigned 32-bit integer number: ";
    cin >> num1;
    cout << "[MaskAccess_T3] Enter another unsigned 32-bit integer number: ";
    cin >> num2;

    if (((num1 >> (ID[4] - 1)) & 1) != ((num2 >> (ID[3] - 1)) & 1)) {
        cout << "Intruder detected" << endl;
        exit(EXIT_FAILURE);
    }

    unsigned int aux0 = num1 >> (32 - ID[2]);
    unsigned int aux1 = num2 & (32 - ID[2]);
    unsigned int aux2 = (aux0 << (32 - ID[2])) + aux1;
    if (aux2 <= ID[1] * 347) {
        cout << "These are not the droids you're looking for" << endl;
        exit(EXIT_FAILURE);
    }

    int aux3 = (num2 >> (ID[1] - 1)) & (ID[1] - ID[3] - 1);
    if (aux3 != 0) {
        cout << "Halt!" << endl;
        exit(EXIT_FAILURE);
    }
}

//  AsmBasedControl_T3() -----  Marcos
//  Valid input: 250, 65, 64
// Invalid input: 1, 2, 3
void AsmBasedControl_T3() {
    int number1, number2, number3;
    cout << "[AsmBasedControl_T3] Enter a 32-bit integer number: ";
    cin >> number1;
    cout << "[AsmBasedControl_T3] Enter another 32-bit integer number: ";
    cin >> number2;
    cout << "[AsmBasedControl_T3] Enter the last 32-bit integer number: ";
    cin >> number3;

    if (IsValidAssembly(number1, number2, number3) == 0) {
        cout << "Intruder detected" << endl;
        exit(EXIT_FAILURE);
    }
}

// CheckArray_T3() -----  Irene
// Valid input: 369, 65535, 65535
// Invalid input: 1, 1, 1
void CheckArray_T3() {
    int const SIZE_ARRAY = 3;
    int elements[SIZE_ARRAY];

    cout << "[CheckArray_T3] Enter a 16 bits integer: ";
    cin >> elements[0];
    cout << "[CheckArray_T3] Enter another 16 bits integer: ";
    cin >> elements[1];
    cout << "[CheckArray_T3] Enter the last 16 bits integer: ";
    cin >> elements[2];

    // verify that the logical AND bitwise is equal to 369
    short int result = elements[0];
    for (int i = 1; i < SIZE_ARRAY; i++) {
        result &= elements[i];
    }
    if (result != 369) {
        cout << "Stop" << endl;
        exit(EXIT_FAILURE);
    }
}