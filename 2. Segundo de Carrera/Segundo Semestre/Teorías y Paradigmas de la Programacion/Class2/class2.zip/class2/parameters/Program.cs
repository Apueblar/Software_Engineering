﻿using System.Diagnostics;

namespace parameters
{
    internal class Program
    {
        static void Swap(ref int a, ref int b)
        {
            int tmp = a;
            a = b;
            b = tmp;
        }
        static void ReadValues(out string name, out string surname, out string idNumber)
        {
            Console.WriteLine("Please, write your name: ");
            do
            {
                name = Console.ReadLine();
            } while (name != null);
            Debug.Assert(name != null, "Error, name must not be null");

            Console.WriteLine("Please, write your surname: ");
            surname = Console.ReadLine();
            Console.WriteLine("Please, write your idNumber: ");
            idNumber = Console.ReadLine();
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            int a = 10;
            int b = -10;
            Console.WriteLine("{0} {1}", a, b);
            Swap(ref a, ref b);
            Console.WriteLine("{0} {1}", a, b);

            string s1, s2, s3;
            ReadValues(out s1, out s2, out s3);
            Console.WriteLine("Name {0}, Surname {1}, ID {2}", s1, s2, s3);

        }
    }
}
