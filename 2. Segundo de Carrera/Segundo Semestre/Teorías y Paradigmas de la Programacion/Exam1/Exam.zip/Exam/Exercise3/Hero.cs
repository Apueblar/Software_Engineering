﻿using System;
using System.Collections.Generic;

namespace heroes
{

    public class Hero
    {
        string name;
        public string Name { get { return name; } }
        string archetype;
        public string Archetype { get { return archetype; } }

        public Hero(string name, string tipo)
        {
            this.name = name;
            this.archetype = tipo;
        }

        public override string ToString()
        {
            return $"{name} ({archetype})";
        }
    }
    public class Archetype
    {
        public string Name { get; protected set; }
        public IEnumerable<string> Attacks{ get; protected set; }
        
        public Archetype(string nombre, IEnumerable<string> atacks)
        {
            this.Name = nombre;
            this.Attacks = atacks;
        }
        public override string ToString()
        {
            return $"{Name} ({string.Join(", ", Attacks)})";
        }
    }

    public class Clash
    {
        public string Phase { get; protected set; }
        public Hero Hero { get; protected set; }
        public Hero Villain { get; protected set; }
        public Hero Winner { get; protected set; }

        public Clash(string phase, Hero hero, Hero villain, Hero winner)
        {
            this.Phase = phase;
            this.Hero = hero;
            this.Villain = villain;
            this.Winner = winner;
        }
        public override string ToString()
        {
            return $"{Phase}: {Hero} vs {Villain} => Winner: {Winner}";
        }
    }
}
