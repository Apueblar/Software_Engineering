﻿using heroes;

namespace First_exam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Heroes:");
            Console.WriteLine(string.Join("\n", Model.Heroes.Select(g => g.ToString())));

            Console.WriteLine("\nArchetype:");
            Console.WriteLine(string.Join("\n", Model.Archetypes.Select(g => g.ToString())));

            Console.WriteLine("\nClash:");
            Console.WriteLine(string.Join("\n", Model.Clash.Select(g => g.ToString())));

            Query1();
            Query2();
        }

        static void Query1()
        {
            Console.WriteLine("\nQuery 1:");
            var part1 = Model.Archetypes.Where(arch => arch.Attacks.Any(att => att.ToLower().Contains("ray"))).Select(x => x.Name);
            // Here we have the archatypes containing ray
            var result = Model.Clash.Where(clash => part1.Contains(clash.Hero.Archetype) || part1.Contains(clash.Villain.Archetype)).Select(x => x.Phase);
            Console.WriteLine("Clashes in which a ray was used as a weapon:");
            foreach (var clash in result)
            {
                Console.WriteLine(clash);
            }
        }

        static void Query2()
        {
            Console.WriteLine("\nQuery 2:");
            var heroes = Model.Clash.Select(c => c.Hero);
            var villains = Model.Clash.Select(c => c.Villain);
            var heroesTotal = heroes.Concat(villains); // Adds to the Heroes the Villains
            var result = heroesTotal.GroupBy(g => g.Name);
            Console.WriteLine("Names of the heroes who have participated in clashes, Number of clashes:");
            foreach (var element in result)
            {
                Console.WriteLine(String.Format("({0}, {1})", element.Key, element.Count()));
            }
        }
    }
}