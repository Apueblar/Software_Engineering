﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace heroes
{

    public static class Model
    { 

        private static Hero[] heroes = null;
        public static IEnumerable<Hero> Heroes { get { return heroes; } }

        private static Archetype[] archetypes = null;
        public static IEnumerable<Archetype> Archetypes { get { return archetypes; } }

        private static Clash[] clashes = null;
        public static IEnumerable<Clash> Clash { get { return clashes; } }
        public static void InicializeHeroes()
        {
            IList<Hero> list = new List<Hero>();
            list.Add(new Hero("Flare", "Elemental"));
            list.Add(new Hero("Steel Guardian", "Armored"));
            list.Add(new Hero("Quickstrike", "Acrobatic"));
            list.Add(new Hero("Thunderclash", "Elemental"));
            list.Add(new Hero("Stonefist", "Brute Force"));
            list.Add(new Hero("Shadowstep", "Stealthy"));
            list.Add(new Hero("Mindwave", "Psychic"));
            list.Add(new Hero("Blazeheart", "Elemental"));
            list.Add(new Hero("Titanium Defender", "Armored"));
            list.Add(new Hero("Whirlwind", "Acrobatic"));
            list.Add(new Hero("Tempest", "Elemental"));
            list.Add(new Hero("Ironclad", "Armored"));
            list.Add(new Hero("Vortex", "Strategic"));
            list.Add(new Hero("Nightshade", "Stealthy"));
            list.Add(new Hero("Ironfist", "Brute Force"));
            list.Add(new Hero("Specter", "Stealthy"));
            list.Add(new Hero("Gravitas", "Psychic"));
            list.Add(new Hero("Blitz", "Acrobatic"));
            list.Add(new Hero("Razorstorm", "Strategic"));
            list.Add(new Hero("Quakebringer", "Brute Force"));
            heroes = list.ToArray();

        }
        public static void InicializeArchetypes()
        {
            IList<Archetype> list = new List<Archetype>();
            list.Add(new Archetype("Acrobatic", new string[] { "Acrobatic Jump", "Capture Net", "Quick Strike" }));
            list.Add(new Archetype("Armored", new string[] { "Energy Shield", "Armored Punch", "Repulsor Ray" }));
            list.Add(new Archetype("Elemental", new string[] { "Fire Ray", "Electric Storm", "Hailstorm" }));
            list.Add(new Archetype("Brute Force", new string[] { "Earthquake Punch", "Crushing Fist", "Impact Leap" }));
            list.Add(new Archetype("Strategic", new string[] { "Trap Deployment", "Tactical Strike", "Enhanced Reflexes" }));
            list.Add(new Archetype("Stealthy", new string[] { "Invisibility", "Shadow Ray", "Quick Escape" }));
            list.Add(new Archetype("Psychic", new string[] { "Telekinesis", "Mental Ray", "Psychic Projection" }));
            archetypes = list.ToArray();
        }
        public static void InitializeClashes()
        {
            var list = new List<Clash>();
            list.Add(new Clash("City Defense 1", heroes[2], heroes[16], heroes[16]));
            list.Add(new Clash("City Defense 2", heroes[7], heroes[11], heroes[7]));
            list.Add(new Clash("City Defense 3", heroes[4], heroes[19], heroes[4]));
            list.Add(new Clash("Revenge of Evil", heroes[8], heroes[13], heroes[8]));
            list.Add(new Clash("Clash of Titans 1", heroes[16], heroes[0], heroes[0]));
            list.Add(new Clash("Clash of Titans 2", heroes[7], heroes[3], heroes[7]));
            list.Add(new Clash("Clash of Titans 3", heroes[4], heroes[5], heroes[5]));
            list.Add(new Clash("Battle in the Shadows 1", heroes[8], heroes[6], heroes[6]));
            list.Add(new Clash("Battle in the Shadows 2", heroes[7], heroes[5], heroes[7]));
            list.Add(new Clash("Midnight Crisis 1", heroes[0], heroes[6], heroes[0]));
            list.Add(new Clash("Midnight Crisis 2", heroes[7], heroes[0], heroes[0]));
            list.Add(new Clash("Midnight Crisis Final", heroes[0], heroes[10], heroes[10]));
            clashes = list.ToArray();
        }

        static Model()
        {
            InicializeHeroes();
            InicializeArchetypes();
            InitializeClashes();
        }

    }
}