﻿namespace First_exam
{
    public static class DivideAndPrime
    {
		private static IDictionary<uint, uint[]> memo = new Dictionary<uint, uint[]>();

		public static IEnumerable<uint> Divisors(this uint n) // Does not make sense to have negative numbers
		{
			if (n == 0) { throw new ArgumentException("Zero has infinitely many divisors."); } // Handling 0 explicitly
			if (memo.ContainsKey(n)) { return memo[n]; } // Return cached result if exists
			uint[] divs = Enumerable.Range(1, (int)n)
									.Where(div => n % (uint)div == 0)
									.Select(div => (uint)div)
									.ToArray();
			memo[n] = divs; // Store computed divisors
			return divs;
		}

		public static bool IsPrime(this uint n) => n > 1 && (n.Divisors().Count() == 2); // A prime is a value greater than 1 that has as divisors 1 and itself
	}
}
