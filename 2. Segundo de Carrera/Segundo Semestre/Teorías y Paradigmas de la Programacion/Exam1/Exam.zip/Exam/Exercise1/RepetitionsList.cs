﻿using System;
using System.Collections;

namespace First_exam
{
	public class RepetitionsList<T> : IEnumerable<T>
	{
		private readonly LinkedList<T> data;

		public RepetitionsList()
		{
			data = new LinkedList<T>();
		}

		public uint NumberOfElements => data.NumberOfElements;
		
		public void Add(T element, uint reps)
		{
			for (uint i = 0; i < reps; i++) // Adds to the list x repetitions
			{
				data.Add(element);
			}
		}

		public void Add(T element) => Add(element, 1); // Calls the method of repetitions add with 1 repetition

		public T GetElement(uint index) => data.GetElement(index);

		public bool Contains(T value) => data.Contains(value);

		public bool Remove(T value)
		{
			if (data.NumberOfElements == 0) { return false; } // Imposible to return from an empty list

			uint startPos = 0;
			bool notFound = true;

			for (uint position = 0; position < data.NumberOfElements; position++) {
				if (EqualityComparer<T>.Default.Equals(data.GetElement(position), value) && // Exists
					(position == 0 || !EqualityComparer<T>.Default.Equals(data.GetElement(position - 1), value))) // Is the first
				{
                    startPos = position;
					notFound = false;
					break;
				}
			}
			if (notFound) { return false; } // The element with that value does not exist

			uint count = 0;
			for (uint i = startPos; i < data.NumberOfElements; i++) // Count the elements in the sequence
			{
				if (EqualityComparer<T>.Default.Equals(data.GetElement(i), value))
				{
					count++;
				}else {	break; }
			}

			for (uint i = 0; i < count; i++) { data.Remove(value); } // Remove the values

			return true;
		}

		public override string ToString() => data.ToString();

		public IEnumerable<T> ForEach(Action<T> action) => data.ForEach(action);

		public T? Find(Predicate<T> f) => data.Find(f);

		public IEnumerable<T> Filter(Predicate<T> f) => data.Filter(f);

		public TResult Reduce<TResult>(Func<T, TResult, TResult> f, TResult init) => data.Reduce(f, init);

        public IEnumerable<TResult> Map<TResult>(Func<T, TResult> function) => data.Map(function);

        public IEnumerable<T> Invert() => data.Invert();

		public IEnumerator<T> GetEnumerator() => data.GetEnumerator();

		IEnumerator IEnumerable.GetEnumerator() => data.GetEnumerator();
	}
}
