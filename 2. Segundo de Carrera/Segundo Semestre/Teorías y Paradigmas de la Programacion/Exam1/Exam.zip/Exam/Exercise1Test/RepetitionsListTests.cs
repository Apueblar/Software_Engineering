﻿using System;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace First_exam
{
	[TestClass]
	public sealed class RepetitionsListTests
	{
		[TestMethod]
		public void TestAddSingleElement()
		{
			var list = new RepetitionsList<int>();

			list.Add(5);

			Assert.AreEqual(1u, list.NumberOfElements, "List should contain one element.");
			Assert.AreEqual(5, list.GetElement(0));
		}

		[TestMethod]
		public void TestAddMultipleRepetitions()
		{
			var list = new RepetitionsList<string>();

			list.Add("hello", 3);

			Assert.AreEqual(3u, list.NumberOfElements, "List should contain three elements.");
			for (uint i = 0; i < list.NumberOfElements; i++)
			{
				Assert.AreEqual("hello", list.GetElement(i));
			}
		}

		[TestMethod]
		public void TestContains()
		{
			var list = new RepetitionsList<int>();
			list.Add(10);
			list.Add(20);

			Assert.IsTrue(list.Contains(10), "List should contain 10.");
			Assert.IsTrue(list.Contains(20), "List should contain 20.");
			Assert.IsFalse(list.Contains(30), "List should not contain 30.");
		}

		[TestMethod]
		public void TestRemoveGroupOfRepetitions()
		{
			var list = new RepetitionsList<int>();
			// Add a group of repeated values
			list.Add(42, 4);
			// Add other elements before and after the group
			list.Add(1);
			list.Add(42, 2);
			list.Add(2);

			// Pre-removal count (group 1: 4 occurrences, group 2: 2 occurrences, plus 1 and 2)
			uint initialCount = list.NumberOfElements;
			Assert.AreEqual((uint)(4 + 1 + 2 + 1), initialCount, "Initial count is not as expected.");

			// Remove the first contiguous group of 42s.
			bool removed = list.Remove(42);

			Assert.IsTrue(removed, "Removal should return true.");
			// After removal, only the second group of 42 should remain.
			uint expectedCount = initialCount - 4;
			Assert.AreEqual(expectedCount, list.NumberOfElements, "Count after removal is not as expected.");

			// Verify that the first occurrence of 42 is now from the second group (2 occurrences)
			int indexOfFirst42 = -1;
			for (uint i = 0; i < list.NumberOfElements; i++)
			{
				if (list.GetElement(i) == 42)
				{
					indexOfFirst42 = (int)i;
					break;
				}
			}
			Assert.AreNotEqual(-1, indexOfFirst42, "42 should still be in the list after removal.");
			// Remove the second group.
			removed = list.Remove(42);
			Assert.IsTrue(removed, "Second removal should return true.");
			// Now 42 should no longer be in the list.
			Assert.IsFalse(list.Contains(42), "List should not contain 42 after both removals.");
		}

		[TestMethod]
		public void TestGetElementOutOfRangeThrows()
		{
			var list = new RepetitionsList<int>();
			list.Add(100);

			try
			{
				list.GetElement(1); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void TestMapFunction()
		{
			var list = new RepetitionsList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);

			// Map each integer to its string representation.
			IEnumerable<string> mapped = list.Map(x => $"Number: {x}");
			var result = new List<string>(mapped);

			Assert.AreEqual(3, result.Count);
			Assert.AreEqual("Number: 1", result[0]);
			Assert.AreEqual("Number: 2", result[1]);
			Assert.AreEqual("Number: 3", result[2]);
		}

		[TestMethod]
		public void TestForEachFunction()
		{
			var list = new RepetitionsList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);
			int sum = 0;

			// Use ForEach to accumulate a sum.
			list.ForEach(x => sum += x).ToList();

			Assert.AreEqual(60, sum);
		}

		[TestMethod]
		public void TestFindFunction()
		{
			var list = new RepetitionsList<string>();
			list.Add("apple");
			list.Add("banana");
			list.Add("cherry");

			// Find the element that starts with 'b'.
			string? found = list.Find(s => s.StartsWith("b"));

			Assert.AreEqual("banana", found);
		}

		[TestMethod]
		public void TestFilterFunction()
		{
			var list = new RepetitionsList<int>();
			list.Add(2);
			list.Add(3);
			list.Add(4);
			list.Add(5);

			// Filter even numbers.
			IEnumerable<int> evens = list.Filter(x => x % 2 == 0);
			var evenList = new List<int>(evens);

			CollectionAssert.AreEqual(new List<int> { 2, 4 }, evenList);
		}

		[TestMethod]
		public void TestReduceFunction()
		{
			var list = new RepetitionsList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			list.Add(4);

			// Sum all elements.
			int sum = list.Reduce((x, acc) => x + acc, 0);

			Assert.AreEqual(10, sum);
		}

		[TestMethod]
		public void TestInvertFunction()
		{
			var list = new RepetitionsList<char>();
			list.Add('a');
			list.Add('b');
			list.Add('c');

			// Invert the list.
			IEnumerable<char> inverted = list.Invert();
			var result = new List<char>(inverted);

			// Expect reverse order: c, b, a.
			CollectionAssert.AreEqual(new List<char> { 'c', 'b', 'a' }, result);
		}
	}
}

