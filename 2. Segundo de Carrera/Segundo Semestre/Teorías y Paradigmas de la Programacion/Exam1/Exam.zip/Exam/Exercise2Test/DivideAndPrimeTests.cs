﻿using System.Collections.Generic;

namespace First_exam
{
	[TestClass]
	public sealed class DivideAndPrimeTests
	{
		[TestMethod]
		public void TestDivisorsOf6()
		{
			uint number = 6;
			uint[] expected = { 1, 2, 3, 6 };
			CollectionAssert.AreEqual(expected, number.Divisors().ToArray());
		}

		[TestMethod]
		public void TestDivisorsOfPrimeNumber()
		{
			uint number = 7;
			uint[] expected = { 1, 7 };
			CollectionAssert.AreEqual(expected, number.Divisors().ToArray());
		}

		[TestMethod]
		public void TestDivisorsOf1()
		{
			uint number = 1;
			uint[] expected = { 1 };
			CollectionAssert.AreEqual(expected, number.Divisors().ToArray());
		}

		[TestMethod]
		public void TestIsPrimeWithPrimeNumber()
		{
			uint number = 13;
			Assert.IsTrue(number.IsPrime());
		}

		[TestMethod]
		public void TestIsPrimeWithNonPrimeNumber()
		{
			uint number = 10;
			Assert.IsFalse(number.IsPrime());
		}

		[TestMethod]
		public void TestMemoizationWorks()
		{
			uint number = 12;
			var firstCall = number.Divisors().ToArray();
			var secondCall = number.Divisors().ToArray();
			CollectionAssert.AreEqual(firstCall, secondCall);
		}

		[TestMethod]
		public void TestDivisorsOfZero()
		{
			uint number = 0;
			try
			{
				number.Divisors().ToArray(); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void TestIsPrimeWithZero()
		{
			uint number = 0;
			Assert.IsFalse(number.IsPrime()); // 0 is not prime
		}

		[TestMethod]
		public void TestIsPrimeWithTwo()
		{
			uint number = 2;
			Assert.IsTrue(number.IsPrime()); // 2 is the smallest prime number
		}

		[TestMethod]
		public void TestDivisorsOfLargeNumber()
		{
			uint number = 100000;
			var result = number.Divisors().ToArray();
			Assert.IsTrue(result.Length > 2); // Should have multiple divisors
		}

		[TestMethod]
		public void TestIsPrimeWithLargePrime()
		{
			uint number = 97;
			Assert.IsTrue(number.IsPrime()); // 97 is a prime number
		}

		[TestMethod]
		public void TestIsPrimeWithLargeNonPrime()
		{
			uint number = 100;
			Assert.IsFalse(number.IsPrime()); // 100 is not prime
		}

		[TestMethod]
		public void TestDivisorsMemoizationEfficiency()
		{
			uint number = 100000;
			var firstRun = number.Divisors().ToArray();
			var secondRun = number.Divisors().ToArray();
			CollectionAssert.AreEqual(firstRun, secondRun); // Memoization should return the same result
		}
	}
}
