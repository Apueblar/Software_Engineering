﻿namespace Lists
{
	public class Angle
	{
		public double Radians { get; private set; }
		public float Degrees { get { return (float)(this.Radians / Math.PI * 180); } }
		public Angle(double radians) { this.Radians = radians; }
		public Angle(float degrees) { this.Radians = degrees / 180.0 * Math.PI; }
		public double Sine() { return Math.Sin(this.Radians); }
		public double Cosine() { return Math.Cos(this.Radians); }
		public double Tangent() { return Sine() / Cosine(); }
		public int Quadrant
		{
			get
			{
				double degrees = this.Degrees;
				if (degrees > 0 && degrees <= 90) return 1;
				if (degrees > 90 && degrees <= 180) return 2;
				if (degrees > 180 && degrees <= 270) return 3;
				return 4; // 270 < degrees < 360
			}
		}
	}

	public class Person
	{
		public String FirstName { get; private set; }
		public String Surname { get; private set; }
		public string IDNumber { get; private set; }
		public override String ToString() { return String.Format("{0} {1} with {2} ID number", FirstName, Surname, IDNumber); }
		public Person(String firstName, String surname, string idNumber)
		{
			this.FirstName = firstName;
			this.Surname = surname;
			this.IDNumber = idNumber;
		}
		public Person(String firstName, String surname)
		{
			this.FirstName = firstName;
			this.Surname = surname;
			this.IDNumber = "Unknown";
		}
	}


	[TestClass]
	public class LinkedListTests
	{
		[TestMethod]
		public void Add_ThreeElementsInt_CountIsThree()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			Assert.AreEqual((uint)3, list.NumberOfElements);
		}

		[TestMethod]
		public void Add_ThreeElementsString_CountIsThree()
		{
			var list = new LinkedList<string>();
			list.Add("Hello");
			list.Add("World");
			list.Add("Test");
			Assert.AreEqual((uint)3, list.NumberOfElements);
		}

		[TestMethod]
		public void Add_ThreeElementsFloat_CountIsThree()
		{
			var list = new LinkedList<float>();
			list.Add(1.1f);
			list.Add(2.2f);
			list.Add(3.3f);
			Assert.AreEqual((uint)3, list.NumberOfElements);
		}

		[TestMethod]
		public void Add_ThreeElementsObject_CountIsThree()
		{
			var list = new LinkedList<object>();
			list.Add(new object());
			list.Add(new object());
			list.Add(new object());
			Assert.AreEqual((uint)3, list.NumberOfElements);
		}

		[TestMethod]
		public void GetElement_ValidIndex_ReturnsValue()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);
			Assert.AreEqual(10, list.GetElement(0));
			Assert.AreEqual(20, list.GetElement(1));
			Assert.AreEqual(30, list.GetElement(2));
		}

		[TestMethod]
		public void Remove_ExistingElement_DecreasesCount()
		{
			var list = new LinkedList<int>();
			list.Add(100);
			list.Add(200);
			bool result = list.Remove(100);
			Assert.IsTrue(result);
			Assert.AreEqual((uint)1, list.NumberOfElements);
		}

		[TestMethod]
		public void Remove_NonExistingElement_ReturnsFalse()
		{
			var list = new LinkedList<int>();
			list.Add(50);
			bool result = list.Remove(99);
			Assert.IsFalse(result);
		}

		[TestMethod]
		public void RemoveAt_ValidIndex_RemovesElement()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);
			bool removed = list.RemoveAt(1);
			Assert.IsTrue(removed);
			Assert.AreEqual((uint)2, list.NumberOfElements);
			Assert.AreEqual(10, list.GetElement(0));
			Assert.AreEqual(30, list.GetElement(1));
		}

		[TestMethod]
		public void ToString_CheckFormat()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			Assert.AreEqual("[1, 2, 3]", list.ToString());
		}

		[TestMethod]
		public void ToString_EmptyList_ReturnsEmptyBrackets()
		{
			var list = new LinkedList<int>();
			Assert.AreEqual("[]", list.ToString());
		}

		[TestMethod]
		public void Add_ThreePersonElements_CountIsThree()
		{
			var list = new LinkedList<Person>();
			list.Add(new Person("Alice", "Johnson"));
			list.Add(new Person("Bob", "Smith"));
			list.Add(new Person("Charlie", "Brown"));

			Assert.AreEqual((uint)3, list.NumberOfElements);
		}

		[TestMethod]
		public void GetElement_PersonList_ReturnsCorrectPerson()
		{
			var list = new LinkedList<Person>();
			var p1 = new Person("Alice", "Johnson");
			var p2 = new Person("Bob", "Smith");
			var p3 = new Person("Charlie", "Brown");

			list.Add(p1);
			list.Add(p2);
			list.Add(p3);

			Assert.AreEqual(p1, list.GetElement(0));
			Assert.AreEqual(p2, list.GetElement(1));
			Assert.AreEqual(p3, list.GetElement(2));
		}

		[TestMethod]
		public void Remove_PersonObject_RemovesCorrectly()
		{
			var list = new LinkedList<Person>();
			var p1 = new Person("Alice", "Johnson");
			var p2 = new Person("Bob", "Smith");
			var p3 = new Person("Charlie", "Brown");

			list.Add(p1);
			list.Add(p2);
			list.Add(p3);
			bool removed = list.Remove(p2);

			Assert.IsTrue(removed);
			Assert.AreEqual((uint)2, list.NumberOfElements);
			Assert.AreEqual(p1, list.GetElement(0));
			Assert.AreEqual(p3, list.GetElement(1));
		}

		[TestMethod]
		public void Remove_PersonDuplicate_RemovesFirstOccurrence()
		{
			var list = new LinkedList<Person>();
			var p1 = new Person("Alice", "Johnson");
			var p2 = new Person("Bob", "Smith");

			list.Add(p1);
			list.Add(p2);
			list.Add(p1);

			bool removed = list.Remove(p1);

			Assert.IsTrue(removed);
			Assert.AreEqual((uint)2, list.NumberOfElements);
			Assert.AreEqual(p2, list.GetElement(0));
			Assert.AreEqual(p1, list.GetElement(1));
		}

		[TestMethod]
		public void AddFirst_OneElement_CountIsOne()
		{
			var list = new LinkedList<int>();
			list.AddFirst(10);
			Assert.AreEqual((uint)1, list.NumberOfElements);
			Assert.AreEqual(10, list.GetElement(0));
		}

		[TestMethod]
		public void AddFirst_MultipleElements_ElementsAreInOrder()
		{
			var list = new LinkedList<int>();
			list.AddFirst(10);
			list.AddFirst(20);
			list.AddFirst(30);
			Assert.AreEqual((uint)3, list.NumberOfElements);
			// The most recent added element is the first in the list.
			Assert.AreEqual(30, list.GetElement(0));
			Assert.AreEqual(20, list.GetElement(1));
			Assert.AreEqual(10, list.GetElement(2));
		}

		[TestMethod]
		public void LargeList_PerformanceTest()
		{
			var list = new LinkedList<int>();
			const int itemCount = 1000;

			for (int i = 0; i < itemCount; i++)
			{
				list.Add(i);
			}

			Assert.AreEqual((uint)itemCount, list.NumberOfElements);
			Assert.AreEqual(0, list.GetElement(0));
			Assert.AreEqual(itemCount - 1, list.GetElement(itemCount - 1));

			for (int i = 0; i < itemCount / 2; i++)
			{
				list.Remove(i);
			}

			Assert.AreEqual((uint)itemCount / 2, list.NumberOfElements);
		}

		[TestMethod]
		public void RemoveAllElements_CheckEmptyState()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);

			list.Remove(10);
			list.Remove(20);
			list.Remove(30);

			Assert.AreEqual((uint)0, list.NumberOfElements);
			Assert.AreEqual("[]", list.ToString());
		}

		[TestMethod]
		public void Contains_ThreeElementsInt_CheckIsTrue()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);

			Assert.IsTrue(list.Contains(10));
			Assert.IsTrue(list.Contains(20));
			Assert.IsTrue(list.Contains(30));
		}

		[TestMethod]
		public void Contains_NoElemetsInt_CheckIsFalse()
		{
			var list = new LinkedList<int>();

			Assert.IsFalse(list.Contains(10));
			Assert.IsFalse(list.Contains(20));
			Assert.IsFalse(list.Contains(30));
		}

		[TestMethod]
		public void Contains_ThreeElementsString_CheckIsTrue()
		{
			var list = new LinkedList<string>();
			list.Add("Hi");
			list.Add("Lunch");
			list.Add("Potatoe");

			Assert.IsTrue(list.Contains("Hi"));
			Assert.IsTrue(list.Contains("Lunch"));
			Assert.IsTrue(list.Contains("Potatoe"));
		}

		[TestMethod]
		public void Contains_NoElementsString_CheckIsFalse()
		{
			var list = new LinkedList<string>();

			Assert.IsFalse(list.Contains("Hi"));
			Assert.IsFalse(list.Contains("Lunch"));
			Assert.IsFalse(list.Contains("Potatoe"));
		}

		[TestMethod]
		public void Find_ShouldReturnMatchingElement()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			list.Add(4);

			int? result = list.Find(n => n > 2);

			Assert.AreEqual(3, result);
		}

		[TestMethod]
		public void Find_ShouldReturnDefault_WhenNoMatch()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);

			int? result = list.Find(n => n > 10);

			Assert.AreEqual(default(int), result);
		}

		[TestMethod]
		public void Find_ShouldReturnRightAngle()
		{
			var angles = new LinkedList<Angle>();
			angles.Add(new Angle(30));
			angles.Add(new Angle(45));
			angles.Add(new Angle(90));
			angles.Add(new Angle(120));

			var result = angles.Find(a => a.Degrees == 90);

			Assert.IsNotNull(result);
			Assert.AreEqual(90, result.Degrees);
		}

		[TestMethod]
		public void Filter_ShouldReturnMatchingElements()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			list.Add(4);
			list.Add(5);

			var result = list.Filter(n => n % 2 == 0).ToList();

			CollectionAssert.AreEqual(new List<int> { 2, 4 }, result);
		}

		[TestMethod]
		public void Filter_ShouldReturnEmpty_WhenNoMatch()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(3);
			list.Add(5);

			var result = list.Filter(n => n > 10).ToList();

			Assert.AreEqual(0, result.Count);
		}

		[TestMethod]
		public void Filter_ShouldReturnAnglesInQuadrant2()
		{
			var angles = new LinkedList<Angle>();
			angles.Add(new Angle(30));   // Quadrant 1
			angles.Add(new Angle(100));  // Quadrant 2
			angles.Add(new Angle(200));  // Quadrant 3
			angles.Add(new Angle(300));  // Quadrant 4

			var result = angles.Filter(a => a.Quadrant == 2).ToList();

			Assert.AreEqual(1, result.Count);
			Assert.AreEqual(100, result[0].Degrees, 1e-6);
		}

		[TestMethod]
		public void Reduce_ShouldSumNumbers()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			list.Add(4);

			var sum = list.Reduce((value, acc) => acc + value, 0);

			Assert.AreEqual(10, sum);
		}

		[TestMethod]
		public void Reduce_ShouldReturnDefault_WhenEmpty()
		{
			var list = new LinkedList<int>();

			var sum = list.Reduce((value, acc) => acc + value, 0);

			Assert.AreEqual(0, sum);
		}

		[TestMethod]
		public void Reduce_ShouldAccumulateStrings()
		{
			var list = new LinkedList<string>();
			list.Add("Hello");
			list.Add("World");

			var concatenated = list.Reduce((str, acc) => acc + (acc.Length > 0 ? " " : "") + str, "");

			Assert.AreEqual("Hello World", concatenated);
		}

		[TestMethod]
		public void Map_ShouldConvertIntToString()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);

			var result = list.Map(x => $"Number {x}").ToList();

			CollectionAssert.AreEqual(
				new List<string> { "Number 1", "Number 2", "Number 3" },
				result
			);
		}

		[TestMethod]
		public void Map_ShouldHandleEmptyList()
		{
			var list = new LinkedList<int>();

			var result = list.Map(x => $"Number {x}").ToList();

			Assert.AreEqual(0, result.Count);
		}

		[TestMethod]
		public void Map_ShouldTransformPeople()
		{
			var people = new LinkedList<Person>();
			people.Add(new Person("John", "Doe", "12345"));
			people.Add(new Person("Jane", "Smith", "67890"));

			var result = people.Map(p => $"{p.FirstName} {p.Surname}").ToList();

			CollectionAssert.AreEqual(new List<string> { "John Doe", "Jane Smith" }, result);
		}

		[TestMethod]
		public void Invert_ShouldReverseIntegers()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);

			var reversed = list.Invert().ToList();

			CollectionAssert.AreEqual(new List<int> { 3, 2, 1 }, reversed);
		}

		[TestMethod]
		public void Invert_ShouldHandleEmptyList()
		{
			var list = new LinkedList<int>();

			var reversed = list.Invert().ToList();

			Assert.AreEqual(0, reversed.Count);
		}

		[TestMethod]
		public void Invert_ShouldWorkWithAngles()
		{
			var angles = new LinkedList<Angle>();
			angles.Add(new Angle(30));
			angles.Add(new Angle(45));
			angles.Add(new Angle(90));

			var reversed = angles.Invert().ToList();
			
			CollectionAssert.AreEqual(
				new List<float> { 90, 45, 30 },
				reversed.Select(a => a.Degrees).ToList()
			);
		}

		[TestMethod]
		public void ForEach_ShouldReturnAllElementsInOrder()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);

			var allElements = list.ForEach(_ => { }).ToList();

			CollectionAssert.AreEqual(new List<int> { 10, 20, 30 }, allElements);
		}

		//[TestMethod]
		//public void InvertAndReduce_IntList_ProducesExpectedConcatenation()
		//{
		//	var list = new LinkedList<int>();
		//	list.Add(1);
		//	list.Add(2);
		//	list.Add(3);
		//	// Original order: 1, 2, 3

		//	var inverted = list.Invert(); // Expected order: 3, 2, 1
		//	string result = inverted.Reduce((item, acc) => acc + item.ToString() + ",", "");

		//	Assert.AreEqual("3,2,1,", result);
		//}

		//[TestMethod]
		//public void InvertAndReduce_PersonList_ProducesExpectedConcatenation()
		//{
		//	var list = new LinkedList<Person>();
		//	list.Add(new Person("Alice", "Johnson"));
		//	list.Add(new Person("Bob", "Smith"));
		//	list.Add(new Person("Charlie", "Brown"));
		//	// Original order: Alice Johnson, Bob Smith, Charlie Brown

		//	var inverted = list.Invert(); // Expected order: Charlie Brown, Bob Smith, Alice Johnson
		//	string result = inverted.Reduce((person, acc) => acc + person.FirstName + " " + person.Surname + ", ", "");

		//	Assert.AreEqual("Charlie Brown, Bob Smith, Alice Johnson, ", result);
		//}

		//[TestMethod]
		//public void InvertAndReduce_AngleList_ProducesExpectedConcatenation()
		//{
		//	var list = new LinkedList<Angle>();
		//	list.Add(new Angle(30f)); // 30 degrees
		//	list.Add(new Angle(60f)); // 60 d
		//	list.Add(new Angle(90f)); // 90 d
		//							  // Original order: 30, 60, 90 degrees

		//	var inverted = list.Invert(); // Expected order: 90, 60, 30, 
		//	string result = inverted.Reduce((angle, acc) => acc + ((int)angle.Degrees).ToString() + ", ", "");

		//	Assert.AreEqual("90, 60, 30, ", result);
		//}
	}

	[TestClass]
	public class LinkedListNegativeTests
	{
		[TestMethod]
		public void Add_NullValue_ThrowsArgumentException()
		{
			var list = new LinkedList<string>();

			try
			{
				list.Add(null); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void AddFirst_NullValue_ThrowsArgumentException()
		{
			var list = new LinkedList<string>();

			try
			{
				list.AddFirst(null); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void GetElement_IndexOutOfBounds_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);

			try
			{
				var _ = list.GetElement(5); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void GetElement_EmptyList_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();
			try
			{
				var _ = list.GetElement(0); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void RemoveAt_IndexOutOfBounds_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			try
			{
				var _ = list.RemoveAt(2); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void RemoveAt_EmptyList_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();
			try
			{
				var _ = list.RemoveAt(0); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

	}
	[TestClass]
	public class LinkedListEnumeratorTests
	{
		[TestMethod]
		public void Enumerate_EmptyList_ShouldReturnNoElements()
		{
			var list = new LinkedList<int>();
			var enumerator = list.GetEnumerator();

			Assert.IsFalse(enumerator.MoveNext());
		}

		[TestMethod]
		public void Enumerate_SingleElementList_ShouldReturnSingleElement()
		{
			var list = new LinkedList<int>();
			list.Add(10);

			var result = new List<int>();
			foreach (var item in list)
			{
				result.Add(item);
			}

			Assert.AreEqual(1, result.Count);
			CollectionAssert.Contains(result, 10);
		}

		[TestMethod]
		public void Enumerate_MultipleElementList_ShouldReturnAllElementsInOrder()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);

			var result = new List<int>();
			foreach (var item in list)
			{
				result.Add(item);
			}

			CollectionAssert.AreEqual(new List<int> { 1, 2, 3 }, result);
		}

		[TestMethod]
		public void Enumerate_PersonList_ShouldReturnAllPersons()
		{
			var list = new LinkedList<Person>();
			var person1 = new Person("John", "Doe");
			var person2 = new Person("Jane", "Smith");
			var person3 = new Person("Alice", "Johnson");

			list.Add(person1);
			list.Add(person2);
			list.Add(person3);

			var result = new List<Person>();
			foreach (var person in list)
			{
				result.Add(person);
			}

			CollectionAssert.AreEqual(new List<Person> { person1, person2, person3 }, result);
		}

		[TestMethod]
		public void Enumerate_ListAfterRemovingElement_ShouldNotContainRemovedElement()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			list.Remove(2);

			var result = new List<int>();
			foreach (var item in list)
			{
				result.Add(item);
			}

			CollectionAssert.AreEqual(new List<int> { 1, 3 }, result);
		}
	}
}
