﻿namespace Sets
{
	/// <summary>
	/// Represents a mathematical set implementation using a linked list as the underlying data structure.
	/// Provides operations for adding, removing, and checking elements, along with set operations.
	/// </summary>
	public class Set<T>
    {
		/// <summary>
		/// Internal storage for set elements using a linked list.
		/// Ensures unique elements and maintains order.
		/// </summary>
		private Lists.LinkedList<T> data;

		/// <summary>
		/// Gets the number of elements in the set.
		/// </summary>
		public uint NumberOfElements => data.NumberOfElements; // Read-Only variable

		/// <summary>
		/// Initializes an empty set.
		/// </summary>
		public Set()
        {
            data = new Lists.LinkedList<T>();
        }

		/// <summary>
		/// Copy constructor that creates a new set from an existing one.
		/// Ensures deep copying of elements.
		/// </summary>
		/// <param name="other">The set to copy.</param>
		private Set(Set<T> other)
        {
            data = new Lists.LinkedList<T>();
			foreach (T element in other.data)
			{
				data.Add(element);
			}
		}

		/// <summary>
		/// Adds an element to the set if it is not already present.
		/// </summary>
		/// <param name="element">The element to add.</param>
		public void Add(T element)
        {
            if (!Contains(element)) { data.Add(element); }
        }

		/// <summary>
		/// Removes an element from the set if it exists.
		/// </summary>
		/// <param name="element">The element to remove.</param>
		/// <returns>True if the element was removed, otherwise false.</returns>
		public bool Remove(T element)
        {
            return data.Remove(element);
        }

		/// <summary>
		/// Checks whether the set contains a specified element.
		/// </summary>
		/// <param name="element">The element to search for.</param>
		/// <returns>True if the element is in the set, otherwise false.</returns>
		public bool Contains(T element)
        {
            return data.Contains(element);
        }

		/// <summary>
		/// Gets the element at a specified index in the set.
		/// Throws an exception if the index is out of bounds.
		/// </summary>
		/// <param name="index">The index of the element.</param>
		/// <returns>The element at the specified index.</returns>
		public T this[uint index]
        {
            get
            {
                if (index < 0 || index >= data.NumberOfElements)
                {
                    throw new ArgumentOutOfRangeException(nameof(index), "Index is out of range.");
                }
                return data.GetElement(index);
            }
        }

		/// <summary>
		/// Returns a string representation of the set.
		/// </summary>
		/// <returns>A string containing all elements of the set.</returns>
		public override string ToString()
        {
            return data.ToString();
        }

		// operator overloads

		/// <summary>
		/// Overloads the + operator to return a new set with the added element.
		/// </summary>
		public static Set<T> operator +(Set<T> set, T element)
        {
            Set<T> result = new Set<T>(set);
            result.Add(element);
            return result;
        }

		/// <summary>
		/// Overloads the - operator to return a new set with the specified element removed.
		/// </summary>
		public static Set<T> operator -(Set<T> set, T element)
        {
            Set<T> result = new Set<T>(set);
            result.Remove(element);
            return result;
        }

		/// <summary>
		/// Overloads the | operator to perform the union of two sets.
		/// </summary>
		public static Set<T> operator |(Set<T> set1, Set<T> set2)
        {
            Set<T> result = new Set<T>(set1);
			foreach (T elem in set2.data)
			{
				result.Add(elem);
			}
			return result;
        }

		/// <summary>
		/// Overloads the & operator to perform the intersection of two sets.
		/// </summary>
		public static Set<T> operator &(Set<T> set1, Set<T> set2)
        {
            Set<T> result = new Set<T>();
			foreach (T elem in set1.data)
			{
				if (set2.Contains(elem))
				{
					result.Add(elem);
				}
			}
			return result;
        }

		/// <summary>
		/// Overloads the - operator to perform the difference of two sets.
		/// </summary>
		public static Set<T> operator -(Set<T> set1, Set<T> set2)
        {
            Set<T> result = new Set<T>();
			foreach (T elem in set1.data)
			{
				if (!set2.Contains(elem))
				{
					result.Add(elem);
				}
			}
			return result;
        }

		/// <summary>
		/// Overloads the ^ operator to check if an element exists in the set.
		/// </summary>
		public static bool operator ^(Set<T> set, T element)
        {
            return set.Contains(element);
        }
    }
}
