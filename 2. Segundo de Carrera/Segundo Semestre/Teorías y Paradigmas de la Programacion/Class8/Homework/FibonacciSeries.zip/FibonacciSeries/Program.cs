﻿using FibonacciSeries;
using System.Diagnostics;

namespace FibonacciSeries
{
    internal class Program
    {
        static void Main(string[] args)
        {
			int n = 100000000;
			var chrono = new Stopwatch();

			Console.WriteLine("\nCreation of the series:");

			// Lazy Fibonacci Creation
			chrono.Start();
			var LazyResult = FibonacciClass.LazyFibonacci(n);
			chrono.Stop();
			long LazyCreationTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Lazy Creation time is {0} milliseconds.", LazyCreationTime);

			// Eager Fibonacci Creation
			chrono.Restart();
			var EagerResult = FibonacciClass.FibonacciEager(n);
			chrono.Stop();
			long EagerCreationTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Eager Creation time is {0} milliseconds.", EagerCreationTime);

			// Restart the variables (unnecessary)
			LazyResult = FibonacciClass.LazyFibonacci(n);
			EagerResult = FibonacciClass.FibonacciEager(n);

			// Get First Element
			Console.WriteLine("\nGet the first:");
			chrono.Restart();
			int LazyFirst = LazyResult.First();
			chrono.Stop();
			long LazyFirstTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Lazy First time is {0} milliseconds.", LazyFirstTime);

			chrono.Restart();
			int EagerFirst = EagerResult.First();
			chrono.Stop();
			long EagerFirstTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Eager First time is {0} milliseconds.", EagerFirstTime);

			// Restart the variables
			LazyResult = FibonacciClass.LazyFibonacci(n);
			EagerResult = FibonacciClass.FibonacciEager(n);

			// Skip 10,000 elements and get the 10,001st
			Console.WriteLine("\nCheck if skip is lazy:");
			chrono.Restart();
			var LazySkip10000 = LazyResult.Skip(10000);
			chrono.Stop();
			long LazySkipTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Lazy Skip 10000 time is {0} milliseconds.", LazySkipTime);

			chrono.Restart();
			var EagerSkip10000 = EagerResult.Skip(10000);
			chrono.Stop();
			long EagerSkipTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Eager Skip 10000 time is {0} milliseconds.", EagerSkipTime);


			// Restart the variables
			LazyResult = FibonacciClass.LazyFibonacci(n);
			EagerResult = FibonacciClass.FibonacciEager(n);

			// Skip 10,000 elements and get the 10,001st
			Console.WriteLine("\nGet the 10,001st of the series:");
			chrono.Restart();
			var LazySkip10001 = LazyResult.Skip(10000);
			var lastSkip10001 = LazySkip10001.First();
			chrono.Stop();
			long LazySkipTime10001 = chrono.ElapsedMilliseconds;
			Console.WriteLine("Lazy Skip 10000 time is {0} milliseconds.", LazySkipTime10001);

			chrono.Restart();
			int EagerSkip10001 = EagerResult.Skip(100000).First();
			chrono.Stop();
			long EagerSkipTime10001 = chrono.ElapsedMilliseconds;
			Console.WriteLine("Eager Skip 10000 time is {0} milliseconds.", EagerSkipTime10001);

			// Restart the variables
			LazyResult = FibonacciClass.LazyFibonacci(n);
			EagerResult = FibonacciClass.FibonacciEager(n);

			// Get the last element
			Console.WriteLine("\nGet the last of the series:");

			chrono.Restart();
			int LazyLast = LazyResult.Last();  // Lazy evaluation requires .Take(n)
			chrono.Stop();
			long LazyLastTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Lazy Last time is {0} milliseconds.", LazyLastTime);

			chrono.Restart();
			int EagerLast = EagerResult.Last();
			chrono.Stop();
			long EagerLastTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Eager Last time is {0} milliseconds.", EagerLastTime);

			// Creation + Get the last element
			Console.WriteLine("\nCreation + Last of the series:");

			chrono.Restart();
			int LazyCreateLast = FibonacciClass.LazyFibonacci(n).Last();  // Lazy evaluation requires .Take(n)
			chrono.Stop();
			long LazyCreateLastTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Lazy Create + Last time is {0} milliseconds.", LazyCreateLastTime);

			chrono.Restart();
			int EagerCreateLast = FibonacciClass.FibonacciEager(n).Last(); // Eager evaluation requires .Take(n)
			chrono.Stop();
			long EagerCreateLastTime = chrono.ElapsedMilliseconds;
			Console.WriteLine("Eager Create + Last time is {0} milliseconds.", EagerCreateLastTime);
		}
	}
}
