﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace TPP.Laboratory.Functional.Lab08 {

    class Query {

        private Model model = new Model();

        private static void Show<T>(IEnumerable<T> collection) {
            foreach (var item in collection) {
                Console.WriteLine(item);
            }
            Console.WriteLine("Number of items in the collection: {0}.", collection.Count());
        }

        static void Main(string[] args) {
            Query query = new Query();
            query.Query1();
            query.Query2();
            query.Query3();
            query.Query4();
            query.Query5();
            query.Query6();

            query.Homework1();
            query.Homework2();
            query.Homework3();
            query.Homework4();
            query.Homework5();
        }

        private void Query1() {
            Console.WriteLine("Query 1:");
            // Modify this query to show the names of the employees older than 50 years
            var employees = model.Employees.Where(x => x.Age>50).Select(x => x.Name);
            Console.WriteLine("Employees:");
            Show(employees);
            // Where == Filter
            // Select == Map
        }

        private void Query2() {
            Console.WriteLine("Query 2:");
            // Show the name and email of the employees who work in Asturias
            var employees = model.Employees.Where(x => x.Province.ToLower().Equals("asturias"));
            IEnumerable<(string,string)> nameEmployeesInAsturias = employees.Select(x => (x.Name, x.Email)); // Option 1
            var result = employees.Select(emp => new { Nombre=emp.Name, CorreoElectronico = emp.Email}); // Option 2

            Console.WriteLine("Employees:");
            Show(nameEmployeesInAsturias);

            Console.WriteLine("Employees:");
            foreach (var element in result)
            {
                Console.WriteLine(String.Format("{0} {1}", element.Nombre, element.CorreoElectronico));
            }
        }

        // Notice: from now on, check out http://msdn.microsoft.com/en-us/library/9eekhta0.aspx

        private void Query3() {
            Console.WriteLine("Query 3:");
            // Show the names of the departments with more than one employee 18 years old and beyond; 
            var departmentsWithMoreThan1adult = model.Departments.Where(dep => dep.Employees.Count(emp => emp.Age > 18) > 1);
            // the department should also have any office number starting with "2.1"
            var allconditionsdepratments = departmentsWithMoreThan1adult.Where(dep => dep.Employees.Any(emp => emp.Office.Number.StartsWith("2.1")));
            Console.WriteLine("Departments:");
            Show(allconditionsdepratments.Select(d => d.Name));
        }

        private void Query4() {
            Console.WriteLine("Query 4:");
            // Show the phone calls of each employee.
            var phoneCalls = model.Employees.Join(model.PhoneCalls,
                    emp => emp.TelephoneNumber,
                    call => call.SourceNumber,
                    (emp, call) =>
                        new { EmployeeName = emp.Name, CallDuration = call.Seconds });
            // Each line should show the name of the employee and the phone call duration in seconds.
            Console.WriteLine("PhoneCalls:");
            Show(phoneCalls);
        }

        private void Query5() {
            Console.WriteLine("Query 5:");
            // Show, grouped by each province, the name of the employees
            var groupedByProvinceEmployees = model.Employees.GroupBy(emp => emp.Province);
            // (both province and employees must be lexicographically ordered)
            var orderedEmpByProvince = groupedByProvinceEmployees.OrderBy(g => g.Key);
            Console.WriteLine("GroupBY:");
            foreach (var group in orderedEmpByProvince)
            {
                Console.WriteLine(String.Format("{0} {1}", group.Key, group.Count()));
                foreach (var emp in group.OrderByDescending(g => g.Name))
                {
                    Console.WriteLine(String.Format("\t{0} {1}", emp.Name, emp.Province));
                }
            }
        }

        private void Query6() {
            Console.WriteLine("Query 6:");
            // Rank the calls by duration. Show rank position and duration
            var orderedCalls = model.PhoneCalls.OrderByDescending(call => call.Seconds);

            var ranking = orderedCalls.Zip(Enumerable.Range(1, orderedCalls.Count()));
            Console.WriteLine("Order Phone Calls By Duration:");
            foreach (var r in ranking)
            {
                Console.WriteLine(String.Format("{0} {1}", r.Second, r.First.Seconds));
            }

        }


        /************ Homework **********************************/

        private void Homework1() {
            Console.WriteLine("Homework 1:");
			// Show, ordered by age, the names of the employees in the Computer Science department,
			var employeesInComputerScienceDep = model.Employees.Where(emp => emp.Department.Name.ToLower().Equals("computer science")).OrderBy(emp => emp.Age);
			// who have an office in the Faculty of Science (Building),
			var empInCSDepWithOfficeInFofS = employeesInComputerScienceDep.Where(emp => emp.Office.Building.ToLower().Equals("faculty of science"));
			// and who have done phone calls longer than one minute
			var empICSDepWOInFoSWithCallsLonger1min = empInCSDepWithOfficeInFofS.Where(emp => model.PhoneCalls.Any(call => call.SourceNumber.Equals(emp.TelephoneNumber) && call.Seconds > 60)).Select(emp => emp.Name);
            Console.WriteLine("Employees that fulfill the conditions:");
            Show(empICSDepWOInFoSWithCallsLonger1min);
        }

        private void Homework2() {
            Console.WriteLine("Homework 2:");
            // Show the summation, in seconds, of the phone calls done by the employees of the Computer Science department
            var employeesInComputerScienceDep = model.Employees.Where(emp => emp.Department.Name.ToLower().Equals("computer science"));
            var phoneCallsDurationDoneByEmployeesOfTheCSDep = employeesInComputerScienceDep.Join(model.PhoneCalls,
                    emp => emp.TelephoneNumber,
                    call => call.SourceNumber,
                    (emp, call) => call.Seconds);
            Console.WriteLine("Summation of calls done by employees of CS Dep: {0}", phoneCallsDurationDoneByEmployeesOfTheCSDep.Aggregate(0, (prev,newnum) => prev+newnum));
        }

        private void Homework3() {
            Console.WriteLine("Homework 3:");
            // Show the phone calls done by each department, ordered by department names.
            var callsGroupedByDepartment = model.Employees.Join(model.PhoneCalls,
                emp => emp.TelephoneNumber,
                call => call.SourceNumber,
                (emp, call) => new { Emp = emp, Call = call }
                ).GroupBy(Anony => Anony.Emp.Department).OrderBy(group => group.Key.Name);

			// Each line must show “Department = <Name>, Duration = <Seconds>”
			foreach (var calls in callsGroupedByDepartment)
            {
				foreach (var call in calls)
				{
					Console.WriteLine(String.Format("Department = {0}, Duration = {1}", calls.Key.Name, call.Call.Seconds));
				}
			}
		}

        private void Homework4() {
            Console.WriteLine("Homework 4:");
            // Show the departments with the youngest employee,
            var departmentsAndEmp = model.Employees.GroupBy(emp => emp.Department);
			// together with the name of the youngest employee and his/her age 
			var depandYoungestEmp = departmentsAndEmp.Select(group => {
				var minAge = group.Min(emp => emp.Age);
				return new { Dep = group.Key, MinAge = minAge, Youngest = group.Where(emp => emp.Age.Equals(minAge)) };
            }
            );
			// (more than one youngest employee may exist)
			foreach (var group in depandYoungestEmp)
			{
				foreach (var emp in group.Youngest)
				{
					Console.WriteLine(String.Format("Department = {0}, Employee = {1}", group.Dep.Name, emp.Name));
				}
			}
		}

        private void Homework5() {
            Console.WriteLine("Homework 5:");
            // Show the greatest summation of phone call durations, in seconds,
            // of the employees in the same department, together with the name of the department 
            // (it can be assumed that there is only one department fulfilling that condition)

            var greatestSumDurationOfCallsByDep = model.Employees
                .Join(model.PhoneCalls,
                emp => emp.TelephoneNumber,
                call => call.SourceNumber,
                (emp, call) => new { Emp = emp, Call = call }
                )
                .GroupBy(Anony => Anony.Emp.Department)
                .Select(group => new { Dep = group.Key, SummationDuration = group.Aggregate(0, (prev, a) => prev + a.Call.Seconds) })
                .OrderByDescending(group => group.SummationDuration)
                .First(); // To select the maximum

		    Console.WriteLine(String.Format("Department = {0}, Summation Duration = {1}", greatestSumDurationOfCallsByDep.Dep.Name, greatestSumDurationOfCallsByDep.SummationDuration));
		}
    }
}
