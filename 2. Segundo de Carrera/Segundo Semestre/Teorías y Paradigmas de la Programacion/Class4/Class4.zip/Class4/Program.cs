﻿namespace Lab4
{
    internal class Program
    {
        //Exercise 1: Create swap method to swap any type
        //Exercise 2: Create Max method to get the max of 2 numbers, obj or T
        //Exercise 3: Change list implementation to allow T
        //Exercise 4: Iterator
        //Exercise 5: Homework
        static void Main(string[] args)
        {
            int a = 10;
            int b = 20;
            Swap(ref a, ref b);
            Console.WriteLine("a={0},b={1}",a,b);
            a = 10;
            b = 20;
            Console.WriteLine("max={0}", Max(a,b));
            Iterate();
        }

        //EX1
        static void Swap<T>(ref T? a, ref T? b)
        {
            T? tmp = a;
            a = b;
            b = tmp;
        }

        //EX2
        static T Max<T>(T a, T b) where T : IComparable<T>
        {
            return a.CompareTo(b) > 0 ? a : b;
        }

        //EX3 DONE

        //EX4
        static void Iterate<LinkedList,T>(LinkedList list) where LinkedList : IEnumerable<T> 
        {
            IEnumerator<T> iterator = list.GetEnumerator();
            while (iterator.MoveNext()) {
                Console.WriteLine(iterator.Current);
            }
        }

        // We need to implement IEnumerable in linkedlist
        // Create a LinkedListEnumerator that implements Enumerator
    }
}
