﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Dictionary.Test
{
	[TestClass]
	public class IDictionaryTests
	{
		[TestMethod]
		public void Add_Elements_IncreasesCount() // Count is the number of pairs in the dectionary
		{
			IDictionary<int, string> dictionary = new Dictionary<int, string>();
			dictionary.Add(1, "One");
			dictionary.Add(2, "Two");
			dictionary.Add(3, "Three");

			Assert.AreEqual(3, dictionary.Count, "Adding elements should increase count.");
		}

		[TestMethod]
		public void Add_DuplicateKey_ThrowsException() // In every dictionary you can't repeat the same key
		{
			IDictionary<int, string> dictionary = new Dictionary<int, string>
			{
				{ 1, "One" }
			};
			try
			{
				dictionary.Add(1, "Duplicate"); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void Get_ValueByKey_ReturnsCorrectValue()
		{
			IDictionary<string, int> dictionary = new Dictionary<string, int>
			{
				{ "A", 10 },
				{ "B", 20 }
			};

			Assert.AreEqual(10, dictionary["A"], "Value for key 'A' should be 10.");
			Assert.AreEqual(20, dictionary["B"], "Value for key 'B' should be 20.");
		}

		[TestMethod]
		public void Set_ValueByKey_UpdatesValue()
		{
			IDictionary<string, string> dictionary = new Dictionary<string, string>
			{
				{ "Key1", "Value1" }
			};

			dictionary["Key1"] = "UpdatedValue";

			Assert.AreEqual("UpdatedValue", dictionary["Key1"], "Value should be updated.");
		}

		[TestMethod]
		public void ContainsKey_ExistingKey_ReturnsTrue()
		{
			IDictionary<int, string> dictionary = new Dictionary<int, string>
			{
				{ 100, "Hundred" }
			};

			Assert.IsTrue(dictionary.ContainsKey(100), "Dictionary should contain key 100.");
			Assert.IsFalse(dictionary.ContainsKey(200), "Dictionary should not contain key 200.");
		}

		[TestMethod]
		public void Remove_ExistingKey_RemovesEntry()
		{
			IDictionary<string, int> dictionary = new Dictionary<string, int>
			{
				{ "X", 50 },
				{ "Y", 100 }
			};

			bool removed = dictionary.Remove("X");

			Assert.IsTrue(removed, "Removing existing key should return true.");
			Assert.IsFalse(dictionary.ContainsKey("X"), "Key 'X' should no longer exist.");
			Assert.AreEqual(1, dictionary.Count, "Dictionary count should decrease.");
		}

		[TestMethod]
		public void Remove_NonExistingKey_ReturnsFalse()
		{
			IDictionary<string, int> dictionary = new Dictionary<string, int>
			{
				{ "A", 10 }
			};

			bool removed = dictionary.Remove("B");

			Assert.IsFalse(removed, "Removing non-existing key should return false.");
			Assert.AreEqual(1, dictionary.Count, "Count should remain unchanged.");
		}

		[TestMethod]
		public void TryGetValue_ExistingKey_ReturnsValue()
		{
			IDictionary<int, string> dictionary = new Dictionary<int, string>
			{
				{ 1, "One" },
				{ 2, "Two" }
			};

			bool found = dictionary.TryGetValue(2, out string? value);

			Assert.IsTrue(found, "TryGetValue should return true for existing key.");
			Assert.AreEqual("Two", value, "Value for key 2 should be 'Two'.");
		}

		[TestMethod]
		public void TryGetValue_NonExistingKey_ReturnsFalse()
		{
			IDictionary<int, string> dictionary = new Dictionary<int, string>();

			bool found = dictionary.TryGetValue(99, out string? value);

			Assert.IsFalse(found, "TryGetValue should return false for non-existing key.");
			Assert.IsNull(value, "Value should be null when key is not found.");
		}

		[TestMethod]
		public void Iterate_WithForEach_ReturnsAllPairs()
		{
			IDictionary<string, int> dictionary = new Dictionary<string, int>
			{
				{ "One", 1 },
				{ "Two", 2 },
				{ "Three", 3 }
			};

			var keys = new List<string>();
			var values = new List<int>();

			foreach (var pair in dictionary)
			{
				keys.Add(pair.Key);
				values.Add(pair.Value);
			}

			CollectionAssert.AreEquivalent(new List<string> { "One", "Two", "Three" }, keys, "Keys should match.");
			CollectionAssert.AreEquivalent(new List<int> { 1, 2, 3 }, values, "Values should match.");
		}

		[TestMethod]
		public void Clear_DictionaryBecomesEmpty()
		{
			IDictionary<int, string> dictionary = new Dictionary<int, string>
			{
				{ 1, "One" },
				{ 2, "Two" }
			};

			dictionary.Clear();

			Assert.AreEqual(0, dictionary.Count, "Cleared dictionary should have 0 elements.");
		}

		[TestMethod]
		public void Keys_Collection_ReturnsAllKeys()
		{
			IDictionary<int, string> dictionary = new Dictionary<int, string>
			{
				{ 1, "A" },
				{ 2, "B" }
			};

			CollectionAssert.AreEquivalent(new List<int> { 1, 2 }, dictionary.Keys.ToList(), "Keys should match.");
		}

		[TestMethod]
		public void Values_Collection_ReturnsAllValues()
		{
			IDictionary<int, string> dictionary = new Dictionary<int, string>
			{
				{ 1, "Alpha" },
				{ 2, "Beta" }
			};

			CollectionAssert.AreEquivalent(new List<string> { "Alpha", "Beta" }, dictionary.Values.ToList(), "Values should match.");
		}

		[TestMethod]
		public void Access_NonExistingKey_ThrowsException()
		{
			IDictionary<int, string> dictionary = new Dictionary<int, string>();
			try
			{
				string _ = dictionary[100]; // Should throw exception
				Assert.Fail("Expected an KeyNotFoundException to be thrown.");
			}
			catch (KeyNotFoundException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}
	}
}
