﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;

namespace Vector.Test
{
	[TestClass]
	public class IListTests
	{
		[TestMethod]
		public void Add_Elements_IncreasesCount()
		{
			IList<int>? list = new List<int>();
			Assert.IsNotNull(list);

			list.Add(10);
			list.Add(20);
			list.Add(30);

			Assert.AreEqual(3, list.Count, "Adding elements should increase count.");
		}

		[TestMethod]
		public void Get_ElementByIndex_ReturnsCorrectValue()
		{
			IList<string>? list = new List<string> { "Apple", "Banana", "Cherry" };
			Assert.IsNotNull(list);

			Assert.AreEqual("Apple", list[0], "First element should be 'Apple'.");
			Assert.AreEqual("Banana", list[1], "Second element should be 'Banana'.");
			Assert.AreEqual("Cherry", list[2], "Third element should be 'Cherry'.");
		}

		[TestMethod]
		public void Set_ElementByIndex_ChangesValue()
		{
			IList<int>? list = new List<int> { 1, 2, 3 };
			Assert.IsNotNull(list);

			list[1] = 99;  // Modify second element
			Assert.AreEqual(99, list[1], "Element at index 1 should be updated.");
		}

		[TestMethod]
		public void Contains_ElementExists_ReturnsTrue()
		{
			IList<double>? list = new List<double> { 1.1, 2.2, 3.3 };
			Assert.IsNotNull(list);

			Assert.IsTrue(list.Contains(2.2), "List should contain 2.2.");
			Assert.IsFalse(list.Contains(4.4), "List should not contain 4.4.");
		}

		[TestMethod]
		public void IndexOf_FirstOccurrence_ReturnsCorrectIndex()
		{
			IList<char>? list = new List<char> { 'a', 'b', 'c', 'b' };
			Assert.IsNotNull(list);

			Assert.AreEqual(1, list.IndexOf('b'), "Index of first 'b' should be 1.");
			Assert.AreEqual(-1, list.IndexOf('z'), "Index of non-existing element should be -1.");
		}

		[TestMethod]
		public void Remove_ExistingElement_DecreasesCount()
		{
			IList<int>? list = new List<int> { 100, 200, 300 };
			Assert.IsNotNull(list);

			bool removed = list.Remove(200);

			Assert.IsTrue(removed, "Remove should return true for existing elements.");
			Assert.AreEqual(2, list.Count, "Count should decrease after removal.");
			Assert.IsFalse(list.Contains(200), "Removed element should not exist in the list.");
		}

		[TestMethod]
		public void Remove_NonExistingElement_ReturnsFalse()
		{
			IList<int>? list = new List<int> { 1, 2, 3 };
			Assert.IsNotNull(list);

			bool removed = list.Remove(99);
			Assert.IsFalse(removed, "Remove should return false for non-existing elements.");
			Assert.AreEqual(3, list.Count, "Count should remain unchanged.");
		}

		[TestMethod]
		public void Iterate_WithForEach_ReturnsAllElements()
		{
			IList<string>? list = new List<string> { "X", "Y", "Z" };
			Assert.IsNotNull(list);

			List<string>? result = new List<string>();
			Assert.IsNotNull(result);

			foreach (var item in list)
			{
				result.Add(item);
			}

			CollectionAssert.AreEqual(new List<string> { "X", "Y", "Z" }, result, "Iteration should return all elements in correct order.");
		}

		[TestMethod]
		public void Add_DuplicateElements_AllowsDuplicates()
		{
			IList<int>? list = new List<int> { 5, 10, 5, 15 };
			Assert.IsNotNull(list);

			Assert.AreEqual(4, list.Count, "List should allow duplicate values.");
			Assert.AreEqual(0, list.IndexOf(5), "First occurrence of 5 should be at index 0.");
		}

		[TestMethod]
		public void Clear_ListBecomesEmpty()
		{
			IList<int>? list = new List<int> { 1, 2, 3 };
			Assert.IsNotNull(list);

			list.Clear();
			Assert.AreEqual(0, list.Count, "Cleared list should have 0 elements.");
			Assert.IsFalse(list.Contains(1), "List should not contain removed elements.");
		}

		[TestMethod]
		public void Insert_ElementAtIndex_ShiftsElements()
		{
			IList<int>? list = new List<int> { 1, 3, 4 };
			Assert.IsNotNull(list);

			list.Insert(1, 2); // Insert at index 1

			CollectionAssert.AreEqual(new List<int> { 1, 2, 3, 4 }, list.ToList(), "Elements should shift when inserting.");
		}

		[TestMethod]
		public void RemoveAt_Index_RemovesElement()
		{
			IList<string>? list = new List<string> { "First", "Second", "Third" };
			Assert.IsNotNull(list);

			list.RemoveAt(1); // Remove "Second"
			CollectionAssert.AreEqual(new List<string> { "First", "Third" }, list.ToList(), "Element at index should be removed.");
		}

		[TestMethod]
		public void Access_InvalidIndex_ThrowsException()
		{
			IList<int>? list = new List<int> { 1, 2, 3 };
			Assert.IsNotNull(list);
			try
			{
				var _ = list[5]; // Should throw exception
				Assert.Fail("Expected an ArgumentOutOfRangeException to be thrown.");
			}
			catch (ArgumentOutOfRangeException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void RemoveAt_InvalidIndex_ThrowsException()
		{
			IList<int>? list = new List<int> { 1, 2, 3 };
			Assert.IsNotNull(list);
			try
			{
				list.RemoveAt(5); // Should throw exception
				Assert.Fail("Expected an ArgumentOutOfRangeException to be thrown.");
			}
			catch (ArgumentOutOfRangeException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}
	}
}
