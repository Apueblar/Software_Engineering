﻿using System.Diagnostics.Metrics;
using System.Numerics;

namespace Lab09
{
	[TestClass]
	public sealed class Test1
	{
		[TestMethod]
		public void OverSequentialConcurrentTest()
		{
			BitcoinValueData[] vector = Utils.GetBitcoinData();

			Master master = new Master(vector, 1);
			

			DateTime before = DateTime.Now;
			double result = master.ComputeOver(7_000);
			DateTime after = DateTime.Now;
			Console.WriteLine("Result with one thread: {0:N2}.", result);
			Console.WriteLine("Elapsed time: {0:N0} ticks.",
			(after - before).Ticks);

			master = new Master(vector, 4);
			before = DateTime.Now;
			result = master.ComputeOver(7_000);
			after = DateTime.Now;
			Console.WriteLine("Result with 4 threads: {0:N2}.", result);
			Console.WriteLine("Elapsed time: {0:N0} ticks.",
				(after - before).Ticks);
		}
	}
}
