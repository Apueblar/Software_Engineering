﻿
namespace Lab09 {

    internal class Worker {

        private BitcoinValueData[] vector;

        private int fromIndex, toIndex;

        private long result;

        internal long Result {
            get { return this.result; }
        }

        internal Worker(BitcoinValueData[] vector, int fromIndex, int toIndex) {
            this.vector = vector;
            this.fromIndex = fromIndex;
            this.toIndex = toIndex;
        }

        internal void ComputeOver(object numberOBJ)
        {
            int? number = numberOBJ as int?;
            this.result = 0;
            for (int i = this.fromIndex; i <= this.toIndex; i++)
                if (this.vector[i].Value > number) { this.result++; }
        }

    }

}
