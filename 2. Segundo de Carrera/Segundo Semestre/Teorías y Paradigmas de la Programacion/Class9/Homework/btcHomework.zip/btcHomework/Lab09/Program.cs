﻿using System;
using static System.Net.Mime.MediaTypeNames;


namespace Lab09
{

    class Program
    {
        /*
         * This program processes Bitcoin value information obtained from the
         * url https://api.kraken.com/0/public/OHLC?pair=xbteur&interval=5.
         */
        static void Main(string[] args)
        {
            var data = Utils.GetBitcoinData();
            foreach (var d in data)
                Console.WriteLine(d);

            BitcoinValueData[] vector = Utils.GetBitcoinData();

			Console.WriteLine("Concurrency or Sequential:");
			//Implement an application that concurrently computes the number of occurrences of a
			//bitcoin value higher than a fixed value. Checks concurrency and sequential
			Master master = new Master(vector, 1);
			DateTime before = DateTime.Now;
			double result = master.ComputeOver(7_000);
			DateTime after = DateTime.Now;
			Console.WriteLine("Result with one thread: {0:N2}.", result);
			Console.WriteLine("Elapsed time: {0:N0} nanoseconds.",
			(after - before).Nanoseconds);

			master = new Master(vector, 4);
			before = DateTime.Now;
			result = master.ComputeOver(7_000);
			after = DateTime.Now;
			Console.WriteLine("Result with 4 threads: {0:N2}.", result);
			Console.WriteLine("Elapsed time: {0:N0} nanoseconds.",
				(after - before).Nanoseconds);

			// The results may say that the sequential is faster as the creation of the workers may take more than actually computing the whole vector

			// In my computer the sequential approach is the fastest, only with 9.4mS, the more threads you have in "small" problems the more time it takes

			for (int threads = 1; threads <= 10; threads++)
			{
				master = new Master(vector, threads);
				GC.Collect();
				GC.WaitForFullGCComplete();

				before = DateTime.Now;
				result = master.ComputeOver(7000);
				after = DateTime.Now;

				Console.WriteLine("Threads: {0} | Over 7000: {1} | Time: {2} nanoseconds", threads, result, (after - before).TotalNanoseconds);
			}

			for (int threads = 1; threads <= 100; threads++)
			{
				master = new Master(vector, threads);
				GC.Collect();
				GC.WaitForFullGCComplete();

				before = DateTime.Now;
				result = master.ComputeOver(7000);
				after = DateTime.Now;

				Console.WriteLine("{0}|{1}", threads, (after - before).TotalNanoseconds);
			}

			// After doing the excel, the best result is the sequential one with 10475300 nanoSeconds
		}
	}
}
