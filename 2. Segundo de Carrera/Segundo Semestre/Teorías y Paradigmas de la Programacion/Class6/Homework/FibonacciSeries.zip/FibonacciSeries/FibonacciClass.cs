﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FibonacciSeries
{
	public static class FibonacciClass
	{
		public static IEnumerable<int> LazyFibonacci(int n)
		{
			if (n <= 0) yield break; // Handle edge case

			int first = 1, second = 1;

			for (int i = 0; i < n; i++)
			{
				yield return first;
				int addition = first + second;
				first = second;
				second = addition;
			}
		}


		/// <summary>
		/// Non memoized recursive Fibonacci function
		/// </summary>
		public static List<int> FibonacciEager(int n)
		{
			if (n <= 0) return new List<int>(); // Handle edge case

			List<int> results = new List<int>();
			int first = 1, second = 1;

			for (int i = 0; i < n; i++)
			{
				results.Add(first);
				int addition = first + second;
				first = second;
				second = addition;
			}
			return results;
		}

	}
}
