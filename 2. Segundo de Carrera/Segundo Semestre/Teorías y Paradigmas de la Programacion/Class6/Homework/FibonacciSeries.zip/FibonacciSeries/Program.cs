﻿using FibonacciSeries;
using System.Diagnostics;

namespace FibonacciSeries
{
    internal class Program
    {
        static void Main(string[] args)
        {
			int n = 10000000;
			var chrono = new Stopwatch();

			Console.WriteLine("\nCreation of the series:");

			// Lazy Fibonacci Creation
			chrono.Start();
			var LazyResult = FibonacciClass.LazyFibonacci(n);
			chrono.Stop();
			long LazyCreationTime = chrono.ElapsedTicks;
			Console.WriteLine("Lazy Creation time is {0:N} ticks.", LazyCreationTime);

			// Eager Fibonacci Creation
			chrono.Restart();
			var EagerResult = FibonacciClass.FibonacciEager(n);
			chrono.Stop();
			long EagerCreationTime = chrono.ElapsedTicks;
			Console.WriteLine("Eager Creation time is {0:N} ticks.", EagerCreationTime);

			// Restart the variables (unnecessary)
			LazyResult = FibonacciClass.LazyFibonacci(n);
			EagerResult = FibonacciClass.FibonacciEager(n);

			// Get First Element
			Console.WriteLine("\nCreation of the series:");
			chrono.Restart();
			int LazyFirst = LazyResult.First();
			chrono.Stop();
			long LazyFirstTime = chrono.ElapsedTicks;
			Console.WriteLine("Lazy First time is {0:N} ticks.", LazyFirstTime);

			chrono.Restart();
			int EagerFirst = EagerResult.First();
			chrono.Stop();
			long EagerFirstTime = chrono.ElapsedTicks;
			Console.WriteLine("Eager First time is {0:N} ticks.", EagerFirstTime);

			// Restart the variables
			LazyResult = FibonacciClass.LazyFibonacci(n);
			EagerResult = FibonacciClass.FibonacciEager(n);

			// Skip 10,000 elements and get the 10,001st
			Console.WriteLine("\nGet the 10,001st of the series:");
			chrono.Restart();
			int LazySkip10001 = LazyResult.Skip(10000).First();
			chrono.Stop();
			long LazySkipTime = chrono.ElapsedTicks;
			Console.WriteLine("Lazy Skip 10000 time is {0:N} ticks.", LazySkipTime);

			chrono.Restart();
			int EagerSkip10001 = EagerResult.Skip(10000).First();
			chrono.Stop();
			long EagerSkipTime = chrono.ElapsedTicks;
			Console.WriteLine("Eager Skip 10000 time is {0:N} ticks.", EagerSkipTime);

			// Restart the variables
			LazyResult = FibonacciClass.LazyFibonacci(n);
			EagerResult = FibonacciClass.FibonacciEager(n);

			// Get the last element
			Console.WriteLine("\nGet the last of the series:");

			chrono.Restart();
			int LazyLast = LazyResult.Take(n).Last();  // Lazy evaluation requires .Take(n)
			chrono.Stop();
			long LazyLastTime = chrono.ElapsedTicks;
			Console.WriteLine("Lazy Last time is {0:N} ticks.", LazyLastTime);

			chrono.Restart();
			int EagerLast = EagerResult.Last();
			chrono.Stop();
			long EagerLastTime = chrono.ElapsedTicks;
			Console.WriteLine("Eager Last time is {0:N} ticks.", EagerLastTime);

			// Creation + Get the last element
			Console.WriteLine("\nCreation + Last of the series:");

			chrono.Restart();
			int LazyCreateLast = FibonacciClass.LazyFibonacci(n).Take(n).Last();  // Lazy evaluation requires .Take(n)
			chrono.Stop();
			long LazyCreateLastTime = chrono.ElapsedTicks;
			Console.WriteLine("Lazy Create + Last time is {0:N} ticks.", LazyCreateLastTime);

			chrono.Restart();
			int EagerCreateLast = FibonacciClass.FibonacciEager(n).Last(); // Eager evaluation requires .Take(n)
			chrono.Stop();
			long EagerCreateLastTime = chrono.ElapsedTicks;
			Console.WriteLine("Eager Create + Last time is {0:N} ticks.", EagerCreateLastTime);
		}
	}
}
