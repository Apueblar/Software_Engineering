﻿using System;

namespace TPP.Laboratory.Functional.Lab06 {

    class Program {

        static int Addition(int a, int b) {
            return a + b;
        }

        static Func<int, int> CurryedAdd(int a)
        {
            return b => b + a;
        }

        static int Multiplication(int a, int b, int c)
        {
            return a * b * c;
        }

        static Func<int,int> Multiplication(int a, int b)
        {
            return c => Multiplication(a, b, c);
        }

        static Func<int, Func<int, int>> Multiplication(int a)
        {
            return b => c => Multiplication(a, b, c);
        }

        static int Squared(int a)
        {
            return Multiplication(1)(a)(a);
        }

        static void Main() {
            Console.WriteLine(Addition(1, 2));
            var add = CurryedAdd(2);
            Console.WriteLine(add(1));

            Console.WriteLine(Multiplication(2, 3, 4));
            var mul = Multiplication(2, 3);
            Console.WriteLine(mul(4));

            var curryMult = Multiplication(2);
            var near = curryMult(3);
            Console.WriteLine(near(4));

            Console.WriteLine(Squared(4));
        }

    }
}
