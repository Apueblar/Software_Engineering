﻿using System;
using System.Diagnostics.Metrics;

namespace TPP.Laboratory.Functional.Lab06 {

    /// <summary>
    /// Try to guess the behavior of this program without running it
    /// </summary>
    class Closures {

        /* Form 1
        /// <summary>
        /// Version with a single method
        /// </summary>
        static (Func<int> Increment, Func<int> Decrement, Func<int, int> Assign) Counter() {    // Similar to an object constructor
            int counter = 0;            // Like an object attributes
            //return () => ++counter;     // Like object method
            return (() => ++counter, () => --counter, value => counter = value);
        }
        */

        struct Wrapper
        {
            public Func<int> add;
            public Func<int> dec;
            public Func<int, int> change;
        }

        /// <summary>
        /// Version with a single method
        /// </summary>
        static Wrapper Counter()
        {    // Similar to an object constructor
            int counter = 0;            // Like an object attributes
            Wrapper count = new Wrapper
            {
                add = () => ++counter,       // Increment the counter
                dec = () => --counter,       // Decrement the counter
                change = value => counter = value  // Set counter to a specific value
            };
            return count;

            //return () => ++counter;     // Like object method
            //return (() => ++counter, () => --counter, value => counter = value);
        }

        static void Main() {
            /*
            var counterDelegate = Counter();
            Console.WriteLine(counterDelegate.Increment());
            Console.WriteLine(counterDelegate.Increment());

            var anotherCounterDelegate = Counter();
            Console.WriteLine(anotherCounterDelegate.Increment());
            Console.WriteLine(anotherCounterDelegate.Increment());

            Console.WriteLine(counterDelegate.Increment());
            Console.WriteLine(counterDelegate.Decrement());
            Console.WriteLine(counterDelegate.Assign(11));
            Console.WriteLine(counterDelegate.Decrement());
            */

            Wrapper counterDelegate = Counter();
            Console.WriteLine(counterDelegate.add());
            Console.WriteLine(counterDelegate.add());

            Wrapper anotherCounterDelegate = Counter();
            Console.WriteLine(anotherCounterDelegate.add());
            Console.WriteLine(anotherCounterDelegate.add());

            Console.WriteLine(counterDelegate.add());
            Console.WriteLine(counterDelegate.dec());
            Console.WriteLine(counterDelegate.change(11));
            Console.WriteLine(counterDelegate.dec());
        }
    }

}
