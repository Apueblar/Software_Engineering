﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace ConcurrencyHomework
{
	/// <summary>
	/// Splits the words array into N segments, spawns N threads to count each segment,
	/// then merges the partial counts into a single dictionary.
	/// </summary>
	public class Master
	{
		private readonly string[] words;
		private readonly int numberOfThreads;

		public Master(string[] words, int numberOfThreads)
		{
			if (numberOfThreads < 1 || numberOfThreads > words.Length)
				throw new ArgumentException("The number of threads must be between 1 and the length of the words array.");
			this.words = words;
			this.numberOfThreads = numberOfThreads;
		}

		public IDictionary<string, uint> CountWords()
		{
			// 1) Create workers
			Worker[] workers = new Worker[numberOfThreads];
			int itemsPerThread = words.Length / numberOfThreads;

			for (int i = 0; i < numberOfThreads; i++)
			{
				int start = i * itemsPerThread;
				int end = (i < numberOfThreads - 1)
					? (start + itemsPerThread - 1)
					: (words.Length - 1);  // last thread takes remainder

				workers[i] = new Worker(words, start, end);
			}

			// 2) Spawn threads
			Thread[] threads = new Thread[numberOfThreads];
			for (int i = 0; i < numberOfThreads; i++)
			{
				threads[i] = new Thread(workers[i].Compute)
				{
					Name = $"Worker {i + 1}",
					Priority = ThreadPriority.BelowNormal
				};
				threads[i].Start();
			}

			// 3) Wait to finish
			foreach (var t in threads)
				t.Join();

			// 4) Merge results
			var finalCount = new Dictionary<string, uint>(StringComparer.OrdinalIgnoreCase);
			foreach (var w in workers)
			{
				foreach (var kv in w.Result)
				{
					if (finalCount.ContainsKey(kv.Key))
						finalCount[kv.Key] += kv.Value;
					else
						finalCount[kv.Key] = kv.Value;
				}
			}

			return finalCount;
		}
	}
}
