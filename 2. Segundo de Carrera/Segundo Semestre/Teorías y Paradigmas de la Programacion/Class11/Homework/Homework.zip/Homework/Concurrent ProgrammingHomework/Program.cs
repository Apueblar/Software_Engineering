﻿using System;
using System.IO;
using System.Threading;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Threading.Tasks;


namespace ConcurrencyHomework {

    class Program {

        static void Main(string[] args) {
			// Read and split text
			string text = Processing.ReadTextFile(@"..\..\..\..\clarin.txt");
			string[] wordsFromText = Processing.DivideIntoWords(text);

			IDictionary<string, uint> wordsCountSeq;
			IDictionary<string, uint> wordsCountMasterAndWorkers;
			IDictionary<string, uint> wordsCountPLINQ;

			// SEQUENTIAL COUNT
			Stopwatch crono = Stopwatch.StartNew();
			Processing.CountWordsSequential(wordsFromText, out wordsCountSeq);
			crono.Stop();
			Console.WriteLine("Sequential results:");
			ShowResults(wordsCountSeq);
			Console.WriteLine("Elapsed time sequential: {0:N0} ms.\n", crono.ElapsedMilliseconds);

			crono = Stopwatch.StartNew();
			Processing.CountWordsWithMasterAndWorkers(wordsFromText, out wordsCountMasterAndWorkers);
			crono.Stop();
			Console.WriteLine("Master And Workers results:");
			ShowResults(wordsCountMasterAndWorkers);
			Console.WriteLine("Elapsed time Master And Workers: {0:N0} ms.\n", crono.ElapsedMilliseconds);


			// PLINQ COUNT
			crono = Stopwatch.StartNew();
			Processing.CountWordsPLINQ(wordsFromText, out wordsCountPLINQ);
			crono.Stop();
			Console.WriteLine("PLINQ results:");
			ShowResults(wordsCountPLINQ);
			Console.WriteLine("Elapsed time PLINQ: {0:N0} ms.", crono.ElapsedMilliseconds);

			// Benefit low: thread/task startup, memory‐bound ToLower+dictionary ops and merge overhead outweigh small workload.
			// Boost speed by using larger text, thread‐local dictionaries and batching updates instead of per‐word locks.
			// TPL: use Parallel.ForEach with a local Dictionary per partition and one final merge into a ConcurrentDictionary.
			// PLINQ: use AsParallel().Aggregate to accumulate per‐thread maps and merge once, avoiding heavy GroupBy.  
		}

		public static void ShowResults(IDictionary<string, uint> wordsCount)
		{
			const int maxToShow = 20;
			Console.WriteLine($"> There were {wordsCount.Count} distinct words.");
			Console.WriteLine("> Sample counts (up to {0} entries):", maxToShow);
			Show(wordsCount, Console.Out, maxToShow);
		}

		private static void Show<K, V>(IDictionary<K, V> collection, TextWriter stream, int maxNumberOfElements)
		{
			int i = 0;
			foreach (var kv in collection.Take(maxNumberOfElements))
			{
				stream.WriteLine($"\t{kv.Key}: {kv.Value}");
				i++;
			}
		}

	}

}
