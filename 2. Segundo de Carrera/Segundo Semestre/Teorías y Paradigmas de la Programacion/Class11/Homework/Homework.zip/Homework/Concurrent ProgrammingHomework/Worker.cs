﻿
using System.Collections.Generic;
using System;

namespace ConcurrencyHomework
{

	/// <summary>
	/// Counts word occurrences in a slice of the array [fromIndex..toIndex].
	/// </summary>
	internal class Worker
	{
		private readonly string[] words;
		private readonly int fromIndex, toIndex;
		private Dictionary<string, uint> localCount;

		public IDictionary<string, uint> Result => localCount;

		public Worker(string[] words, int fromIndex, int toIndex)
		{
			this.words = words;
			this.fromIndex = fromIndex;
			this.toIndex = toIndex;
		}

		/// <summary>
		/// Thread entry point. Builds a local frequency dictionary.
		/// </summary>
		public void Compute()
		{
			localCount = new Dictionary<string, uint>(StringComparer.OrdinalIgnoreCase);
			for (int i = fromIndex; i <= toIndex; i++)
			{
				// normalize to lower‐case
				var w = words[i].ToLowerInvariant();
				if (localCount.ContainsKey(w))
					localCount[w]++;
				else
					localCount[w] = 1;
			}
		}
	}

}
