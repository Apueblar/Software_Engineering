﻿using System;
using System.IO;
using System.Threading;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ConcurrencyHomework
{

    public static class Processing {

        public static String ReadTextFile(string fileName) {
            using (StreamReader stream = File.OpenText(fileName)) {
                StringBuilder text = new StringBuilder();
                string line;
                while ((line = stream.ReadLine()) != null) {
                    text.AppendLine(line);
                }
                return text.ToString();
            }
        }

        public static string[] DivideIntoWords(String text) {
            return text.Split(new char[] { ' ', '\r', '\n', ',', '.', ';', ':', '-', '!', '¡', '¿', '?', '/', '«', 
                                            '»', '_', '(', ')', '\"', '*', '\'', 'º', '[', ']', '#' },
                StringSplitOptions.RemoveEmptyEntries);
        }

		public static void CountWordsSequential(string[] words, out IDictionary<string, uint> wordsCount)
		{
			// Sequential
			wordsCount = new Dictionary<string, uint>(StringComparer.OrdinalIgnoreCase);
			foreach (var w in words)
			{
				string key = w.ToLowerInvariant();
				if (wordsCount.ContainsKey(key)) {
					wordsCount[key]++;
				}
				else {
					wordsCount[key] = 1;
				}
			}
		}

		public static void CountWordsWithMasterAndWorkers(string[] words, out IDictionary<string, uint> wordsCount)
		{
			// Master And Workers
			int n = Environment.ProcessorCount;
			int size = words.Length / n;
			var tasks = new Task<Dictionary<string, uint>>[n];

			for (int i = 0; i < n; i++)
			{
				int start = i * size;
				int end = (i == n - 1) ? words.Length : start + size;
				tasks[i] = Task.Run(() =>
				{
					var local = new Dictionary<string, uint>(StringComparer.OrdinalIgnoreCase);
					for (int j = start; j < end; j++)
					{
						var w = words[j].ToLowerInvariant();
						if (local.ContainsKey(w)) local[w]++;
						else local[w] = 1;
					}
					return local;
				});
			}

			Task.WaitAll(tasks);

			// Merge
			wordsCount = new Dictionary<string, uint>(StringComparer.OrdinalIgnoreCase);
			foreach (var task in tasks)
			{
				foreach (var word in task.Result)
				{
					if (wordsCount.ContainsKey(word.Key)) { wordsCount[word.Key] += word.Value; }
					else { wordsCount[word.Key] = word.Value; }
				}
			}
		}


		public static void CountWordsPLINQ(string[] words, out IDictionary<string, uint> wordsCount)
		{
			// PLINQ
			var query = words.AsParallel()
							 .Select(w => w.ToLowerInvariant())
							 .GroupBy(w => w)
							 .Select(g => new { Word = g.Key, Count = (uint) g.Count() });
			wordsCount = query.ToDictionary(x => x.Word, x => x.Count, StringComparer.OrdinalIgnoreCase);
		}

	}

}
