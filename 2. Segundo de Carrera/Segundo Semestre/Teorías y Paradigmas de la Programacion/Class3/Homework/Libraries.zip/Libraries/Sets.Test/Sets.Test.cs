﻿namespace Sets
{
	class Person
	{
		public string FirstName { get; set; }
		public string Surname { get; set; }
		public override string ToString()
		{
			return "[Name=" + FirstName + ", Surname=" + Surname + "]";
		}
		public Person(string FirstName, string Surname)
		{
			this.FirstName = FirstName;
			this.Surname = Surname;
		}
		public override bool Equals(object? obj)
		{
			if (obj == null || obj.GetType() != typeof(Person))
			{
				return false;
			}

			Person other = (Person)obj;
			return FirstName == other.FirstName && Surname == other.Surname;
		}
		public override int GetHashCode()
		{
			return HashCode.Combine(FirstName, Surname);
		}
	}

	[TestClass]
	public sealed class SetsTest
	{
		[TestMethod]
		public void Test_Add_And_Remove_Person()
		{
			Set<Person> peopleSet = new Set<Person>();
			Person p1 = new Person("John", "Doe");
			Person p2 = new Person("Jane", "Doe");

			peopleSet += p1;
			peopleSet += p2;
			Assert.AreEqual(2, peopleSet.NumberOfElements);

			peopleSet -= p1;
			Assert.AreEqual(1, peopleSet.NumberOfElements);
		}

		[TestMethod]
		public void Test_Union_Intersection_Difference_Person()
		{
			Set<Person> set1 = new Set<Person>();
			Set<Person> set2 = new Set<Person>();

			Person p1 = new Person("Alice", "Smith");
			Person p2 = new Person("Bob", "Jones");
			Person p3 = new Person("Charlie", "Brown");

			set1 += p1;
			set1 += p2;
			set2 += p2;
			set2 += p3;

			Set<Person> unionSet = set1 | set2;
			Assert.AreEqual(3, unionSet.NumberOfElements);

			Set<Person> intersectionSet = set1 & set2;
			Assert.AreEqual(1, intersectionSet.NumberOfElements);
			Assert.IsTrue(intersectionSet ^ p2);

			Set<Person> differenceSet = set1 - set2;
			Assert.AreEqual(1, differenceSet.NumberOfElements);
			Assert.IsTrue(differenceSet ^ p1);
		}

		[TestMethod]
		public void Test_Add_And_Remove_String()
		{
			Set<string> stringSet = new Set<string>();
			stringSet += "Hello";
			stringSet += "World";
			Assert.AreEqual(2, stringSet.NumberOfElements);

			stringSet -= "Hello";
			Assert.AreEqual(1, stringSet.NumberOfElements);
		}

		[TestMethod]
		public void Test_Add_And_Remove_Float()
		{
			Set<float> floatSet = new Set<float>();
			floatSet += 1.1f;
			floatSet += 2.2f;
			Assert.AreEqual(2, floatSet.NumberOfElements);

			floatSet -= 1.1f;
			Assert.AreEqual(1, floatSet.NumberOfElements);
		}

		[TestMethod]
		public void Test_Add_And_Remove_Int()
		{
			Set<int> intSet = new Set<int>();
			intSet += 10;
			intSet += 20;
			Assert.AreEqual(2, intSet.NumberOfElements);

			intSet -= 10;
			Assert.AreEqual(1, intSet.NumberOfElements);
		}

		[TestMethod]
		public void Test_Contains_Operator()
		{
			Set<int> intSet = new Set<int>();
			intSet += 5;
			Assert.IsTrue(intSet ^ 5);
			Assert.IsFalse(intSet ^ 10);
		}

		[TestMethod]
		public void Test_Indexer()
		{
			Set<string> stringSet = new Set<string>();
			stringSet += "One";
			stringSet += "Two";
			stringSet += "Three";

			Assert.AreEqual("One", stringSet[0]);
			Assert.AreEqual("Two", stringSet[1]);
			Assert.AreEqual("Three", stringSet[2]);
		}

		[TestMethod]
		public void Add_DuplicateElement_ShouldNotAddTwice()
		{
			var set = new Set<int>();
			set.Add(5);
			set.Add(5);
			Assert.AreEqual(1, set.NumberOfElements, "Duplicate elements should not be added.");
		}

		[TestMethod]
		public void Remove_NonExistingElement_ShouldReturnFalse()
		{
			var set = new Set<int>();
			bool result = set.Remove(10);
			Assert.IsFalse(result, "Removing a non-existing element should return false.");
		}

		[TestMethod]
		[ExpectedException(typeof(ArgumentOutOfRangeException))]
		public void GetElement_OutOfBounds_ShouldThrowException()
		{
			var set = new Set<int>();
			var element = set[0];
		}

		[TestMethod]
		public void AddRemove_PersonObjects_ShouldWorkCorrectly()
		{
			var set = new Set<Person>();
			var person1 = new Person("John", "Doe");
			var person2 = new Person("Jane", "Doe");
			set.Add(person1);
			set.Add(person2);
			Assert.AreEqual(2, set.NumberOfElements);

			set.Remove(person1);
			Assert.AreEqual(1, set.NumberOfElements);
		}

		[TestMethod]
		public void Union_Operation_ShouldCombineUniqueElements()
		{
			var set1 = new Set<int>();
			set1 += 1; set1 += 2; set1 += 3;
			var set2 = new Set<int>();
			set2 += 3; set2 += 4; set2 += 5;

			var result = set1 | set2;
			Assert.AreEqual(5, result.NumberOfElements);
		}

		[TestMethod]
		public void Intersection_Operation_ShouldReturnCommonElements()
		{
			var set1 = new Set<int>();
			set1 += 1; set1 += 2; set1 += 3; set1 += 4;
			var set2 = new Set<int>();
			set2 += 3; set2 += 4; set2 += 5; set2 += 6;

			var result = set1 & set2;
			Assert.AreEqual(2, result.NumberOfElements);
			Assert.IsTrue(result.Contains(3));
			Assert.IsTrue(result.Contains(4));
		}

		[TestMethod]
		public void Difference_Operation_ShouldReturnUniqueElements()
		{
			var set1 = new Set<int>();
			set1 += 1; set1 += 2; set1 += 3; set1 += 4;
			var set2 = new Set<int>();
			set2 += 3; set2 += 4; set2 += 5; set2 += 6;

			var result = set1 - set2;
			Assert.AreEqual(2, result.NumberOfElements);
			Assert.IsTrue(result.Contains(1));
			Assert.IsTrue(result.Contains(2));
		}

		[TestMethod]
		public void Contains_Operator_ShouldReturnCorrectBoolean()
		{
			var set = new Set<int>();
			set += 1; set += 2; set += 3;

			Assert.IsTrue(set ^ 2);
			Assert.IsFalse(set ^ 5);
		}
	}
}
