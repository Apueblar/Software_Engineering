﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Stacks
{
	[TestClass]
	public sealed class StackTests
	{
		[TestMethod]
		public void Stack_ShouldBeEmptyOnInitialization()
		{
			var stack = new Stack<int>(5);
			Assert.IsTrue(stack.IsEmpty);
			Assert.IsFalse(stack.IsFull);
		}

		[TestMethod]
		public void PushAndPop_Integer_ShouldWorkCorrectly()
		{
			var stack = new Stack<int>(3);
			stack.Push(42);
			Assert.AreEqual(42, stack.Pop());
			Assert.IsTrue(stack.IsEmpty);
		}

		[TestMethod]
		public void PushAndPop_String_ShouldWorkCorrectly()
		{
			var stack = new Stack<string>(3);
			stack.Push("Hello");
			Assert.AreEqual("Hello", stack.Pop());
			Assert.IsTrue(stack.IsEmpty);
		}

		[TestMethod]
		public void PushAndPop_Float_ShouldWorkCorrectly()
		{
			var stack = new Stack<float>(2);
			stack.Push(3.14f);
			Assert.AreEqual(3.14f, stack.Pop());
		}

		[TestMethod]
		public void PushAndPop_Double_ShouldWorkCorrectly()
		{
			var stack = new Stack<double>(2);
			stack.Push(99.99);
			Assert.AreEqual(99.99, stack.Pop());
		}

		[TestMethod]
		public void PushAndPop_Char_ShouldWorkCorrectly()
		{
			var stack = new Stack<char>(2);
			stack.Push('A');
			Assert.AreEqual('A', stack.Pop());
		}

		[TestMethod]
		public void PushAndPop_Boolean_ShouldWorkCorrectly()
		{
			var stack = new Stack<bool>(2);
			stack.Push(true);
			Assert.AreEqual(true, stack.Pop());
		}

		[TestMethod]
		public void PushAndPop_Object_ShouldWorkCorrectly()
		{
			var obj = new { Name = "TestObject", Value = 100 };
			var stack = new Stack<object>(2);
			stack.Push(obj);
			Assert.AreEqual(obj, stack.Pop());
		}

		[TestMethod]
		public void PushAndPop_EmptyString_ShouldWorkCorrectly()
		{
			var stack = new Stack<string>(3);
			stack.Push("");
			Assert.AreEqual("", stack.Pop());
		}

		[TestMethod]
		public void PushAndPop_NegativeNumbers_ShouldWorkCorrectly()
		{
			var stack = new Stack<int>(3);
			stack.Push(-50);
			Assert.AreEqual(-50, stack.Pop());
		}

		[TestMethod]
		public void Push_MultipleElements_ShouldMaintainLIFO()
		{
			var stack = new Stack<int>(3);
			stack.Push(1);
			stack.Push(2);
			stack.Push(3);

			Assert.AreEqual(3, stack.Pop());
			Assert.AreEqual(2, stack.Pop());
			Assert.AreEqual(1, stack.Pop());
			Assert.IsTrue(stack.IsEmpty);
		}

		[TestMethod]
		public void Pop_EmptyStack_ShouldThrowException()
		{
			var stack = new Stack<int>(3);
			var exception = Assert.ThrowsException<InvalidOperationException>(() => stack.Pop());

			Assert.AreEqual("Cannot pop from an empty stack", exception.Message);
		}

		[TestMethod]
		public void Push_BeyondCapacity_ShouldThrowException()
		{
			var stack = new Stack<int>(2);
			stack.Push(1);
			stack.Push(2);
			var exception = Assert.ThrowsException<InvalidOperationException>(() => stack.Push(3));

			Assert.AreEqual("The stack reached the maximum capacity", exception.Message);
		}

		[TestMethod]
		public void Stack_IsEmptyAndIsFull_ShouldBeConsistent()
		{
			var stack = new Stack<int>(2);
			Assert.IsTrue(stack.IsEmpty);
			Assert.IsFalse(stack.IsFull);

			stack.Push(1);
			stack.Push(2);
			Assert.IsFalse(stack.IsEmpty);
			Assert.IsTrue(stack.IsFull);

			stack.Pop();
			Assert.IsFalse(stack.IsFull);

			stack.Pop();
			Assert.IsTrue(stack.IsEmpty);
		}

		[TestMethod]
		public void Stack_CapacityOne_ShouldWorkCorrectly()
		{
			var stack = new Stack<int>(1);
			stack.Push(99);
			Assert.IsTrue(stack.IsFull);
			Assert.AreEqual(99, stack.Pop());
			Assert.IsTrue(stack.IsEmpty);
		}
	}
}
