﻿using System.Diagnostics;

namespace Stacks
{
	/// <summary>
	/// A generic stack (LIFO - Last In, First Out) implementation that uses a linked list as its underlying data structure.
	/// This class follows the Design by Contract methodology, ensuring class invariants, preconditions, and postconditions.
	/// </summary>
	/// <typeparam name="T">The type of elements stored in the stack.</typeparam>
	public class Stack<T>
	{
		/// <summary>
		/// Internal linked list used to store stack elements.
		/// </summary>
		private Lists.LinkedList<T> list;

		/// <summary>
		/// The maximum number of elements allowed in the stack.
		/// </summary>
		private uint maxNumberOfElements;

		/// <summary>
		/// Indicates whether the stack is empty.
		/// </summary>
		public bool IsEmpty { get; private set; }

		/// <summary>
		/// Indicates whether the stack is full.
		/// </summary>
		public bool IsFull { get; private set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="Stack{T}"/> class with a specified capacity.
		/// </summary>
		/// <param name="maxNumberOfElements">The maximum number of elements the stack can hold.</param>
		/// <exception cref="ArgumentException">Thrown when the maximum number of elements is set to zero.</exception>
		public Stack(uint maxNumberOfElements)
		{
			if (maxNumberOfElements == 0)
			{
				throw new ArgumentException("Stack size must be greater than 0", nameof(maxNumberOfElements));
			}

			list = new Lists.LinkedList<T>();
			this.maxNumberOfElements = maxNumberOfElements;
			IsEmpty = true;
			IsFull = false;

			// Class invariant: Stack should start empty
			Debug.Assert(IsEmpty == (list.NumberOfElements == 0), "IsEmpty should be true when list is empty");
		}

		/// <summary>
		/// Removes and returns the top element of the stack.
		/// </summary>
		/// <returns>The last element that was added to the stack.</returns>
		/// <exception cref="InvalidOperationException">Thrown when attempting to pop from an empty stack.</exception>
		public T Pop()
		{
			// Preconditions
			if (IsEmpty)
			{
				throw new InvalidOperationException("Cannot pop from an empty stack");
			}

			// Remove last element (LIFO behavior)
			T topElement = list.GetElement(list.NumberOfElements - 1);
			list.RemoveAt(list.NumberOfElements - 1);

			// Postconditions
			IsEmpty = list.NumberOfElements == 0;
			IsFull = false;

			// Class invariant: If the list is empty, IsEmpty should be true.
			Debug.Assert(IsEmpty == (list.NumberOfElements == 0), "IsEmpty should be true if list is empty");
			
			return topElement;
		}

		/// <summary>
		/// Adds an element to the top of the stack.
		/// </summary>
		/// <param name="obj">The object to push onto the stack.</param>
		/// <exception cref="ArgumentNullException">Thrown when attempting to push a null value.</exception>
		/// <exception cref="InvalidOperationException">Thrown when attempting to push onto a full stack.</exception>
		public void Push(T obj)
		{
			// Preconditions
			if (obj == null) {
				throw new ArgumentNullException(nameof(obj), "The object you try to push is null");
			}
			if (IsFull)
			{
				throw new InvalidOperationException("The stack reached the maximum capacity");
			}

			// Add the object
			list.Add(obj);

			// Postconditions
			IsEmpty = false;
			IsFull = list.NumberOfElements == maxNumberOfElements;

			// Class invariant: IsFull should be true only when the stack is at max capacity.
			Debug.Assert(IsFull == (list.NumberOfElements == maxNumberOfElements), "IsFull should be true when list reaches max capacity");
		}
	}
}
