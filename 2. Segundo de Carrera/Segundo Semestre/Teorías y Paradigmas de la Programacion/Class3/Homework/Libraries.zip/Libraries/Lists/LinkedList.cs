﻿using System.Diagnostics;

namespace Lists
{
	/// <summary>
	/// Implementation of a generic singly linked list.
	/// Supports adding, removing, checking for existence, and retrieving elements by index.
	/// </summary>
	public class LinkedList<T>
	{
		/// <summary>
		/// Internal class representing a node in the linked list.
		/// Each node contains a value and a reference to the next node.
		/// </summary>
		private class LLNode
		{
			/// <summary>
			/// Value stored in the node.
			/// </summary>
			public T Value { get; set; }

			/// <summary>
			/// Reference to the next node in the list. Null if it's the last node.
			/// </summary>
			public LLNode? Next { get; set; }

			/// <summary>
			/// Initializes a new node with the given value.
			/// </summary>
			/// <param name="value">The value assigned to the node.</param>
			public LLNode(T value)
			{
				Value = value;
				Next = null;
			}
		}

		/// <summary>
		/// Reference to the first node (head) of the list. Null if the list is empty.
		/// </summary>
		private LLNode? head;

		/// <summary>
		/// Number of elements currently stored in the list.
		/// </summary>
		public int NumberOfElements { get; private set; }

		/// <summary>
		/// Class Invariant: Ensures `NumberOfElements` is always correct.
		/// </summary>
		[Conditional("DEBUG")]
		private void ValidateClassInvariant()
		{
			int count = 0;
			LLNode? current = head;
			while (current != null)
			{
				count++;
				current = current.Next;
			}
			Debug.Assert(count == NumberOfElements, "Invariant violated: NumberOfElements must match actual node count.");
		}

		/// <summary>
		/// Initializes an empty linked list.
		/// </summary>
		public LinkedList()
		{
			head = null;
			NumberOfElements = 0;
			ValidateClassInvariant();
		}

		/// <summary>
		/// Retrieves the node at the specified index.
		/// </summary>
		/// <param name="index">Zero-based index of the node.</param>
		/// <returns>The node at the given index.</returns>
		/// <exception cref="ArgumentException">Thrown when index is out of bounds.</exception>
		private LLNode GetIndex(int index)
		{
			if (index < 0 || index >= NumberOfElements)
			{
				throw new ArgumentException("The index must be in the range of 0, to NumberOfElements.");
			}
			Debug.Assert(head != null, "Head should never be null when index is valid.");

			LLNode current = head;
			for (int i = 0; i < index; i++)
			{
				Debug.Assert(current.Next != null, "Next node should never be null within bounds.");
				current = current.Next;
			}
			return current;
		}

		/// <summary>
		/// Adds a new element to the end of the linked list.
		/// </summary>
		/// <param name="value">The value to be added.</param>
		/// <exception cref="ArgumentException">Thrown when value is null.</exception>
		public void Add(T value)
		{
			if (value == null)
			{
				throw new ArgumentException("Value cannot be null.");
			}

			LLNode newNode = new LLNode(value);
			if (head == null)
			{
				head = newNode;
			} else
			{
				LLNode last = GetIndex(NumberOfElements - 1);
				last.Next = newNode;
			}
			NumberOfElements++;
			Debug.Assert(NumberOfElements > 0, "Postcondition violated: NumberOfElements must increase after addition.");
			ValidateClassInvariant();
		}

		/// <summary>
		/// Removes the first occurrence of a value from the linked list.
		/// </summary>
		/// <param name="value">The value to be removed.</param>
		/// <returns>True if the value was found and removed; otherwise, false.</returns>
		public bool Remove(T value)
		{
			if (head == null) { return false; } // Empty list

			if (EqualityComparer<T>.Default.Equals(head.Value, value))
			{
				head = head.Next;
				NumberOfElements--;
				Debug.Assert(NumberOfElements >= 0, "Postcondition violated: NumberOfElements cannot be negative.");
				ValidateClassInvariant();
				return true;
			}

			LLNode current = head;
			while (current.Next != null && !EqualityComparer<T>.Default.Equals(current.Next.Value, value))
			{
				current = current.Next;
			}

			if (current.Next == null) { return false; }

			current.Next = current.Next.Next;
			NumberOfElements--;
			Debug.Assert(NumberOfElements >= 0, "Postcondition violated: NumberOfElements cannot be negative.");
			ValidateClassInvariant();
			return true;
		}

		/// <summary>
		/// Removes the element at the specified index from the linked list.
		/// Throws an exception if the index is out of bounds.
		/// </summary>
		/// <param name="index">The zero-based index of the element to remove.</param>
		/// <returns>True if the element was successfully removed; otherwise, false.</returns>
		/// <exception cref="ArgumentException">Thrown when the index is out of range.</exception>
		public bool RemoveAt(int index)
		{
			if (index < 0 || index >= NumberOfElements) { throw new ArgumentException("The index must be in the range of 0, to NumberOfElements."); }

			if (index == 0) // If remove head
			{
				head = head!.Next;
				NumberOfElements--;
				Debug.Assert(NumberOfElements >= 0, "Postcondition violated: NumberOfElements cannot be negative.");
				ValidateClassInvariant();
				return true;
			}

			LLNode prevNode = GetIndex(index - 1);
			if (prevNode.Next == null) { return false; }

			prevNode.Next = prevNode.Next.Next;
			NumberOfElements--;
			Debug.Assert(NumberOfElements >= 0, "Postcondition violated: NumberOfElements cannot be negative.");
			ValidateClassInvariant();
			return true;
		}

		/// <summary>
		/// Retrieves the value at a specified index.
		/// </summary>
		/// <param name="index">The zero-based index.</param>
		/// <returns>The value at the index or null if out of bounds.</returns>
		public T GetElement(int index)
		{
			return GetIndex(index).Value;
		}


		/// <summary>
		/// Converts the linked list to a string representation.
		/// </summary>
		/// <returns>A string representing the linked list.</returns>
		public override string ToString()
		{
			if (NumberOfElements == 0)
			{
				return "[]"; // The list is empty
			}
			Debug.Assert(head != null, "The head is null, it should have been checked before");

			string tostring = string.Format("[{0}", head.Value);
			LLNode? currentNode = head.Next;

			while (currentNode != null)
			{
				tostring += string.Format(", {0}", currentNode.Value);
				currentNode = currentNode.Next;
			}
			return tostring + "]";
		}

		/// <summary>
		/// Checks if the list contains a specified value.
		/// </summary>
		/// <param name="value">The value to search for.</param>
		/// <returns>True if the value exists in the list; otherwise, false.</returns>
		public bool Contains(T value)
		{
			LLNode? currentNode = head;
			while (currentNode != null)
			{
				if (EqualityComparer<T>.Default.Equals(currentNode.Value, value))
				{
					return true;
				}
				currentNode = currentNode.Next;
			}
			return false;
		}
	}
}
