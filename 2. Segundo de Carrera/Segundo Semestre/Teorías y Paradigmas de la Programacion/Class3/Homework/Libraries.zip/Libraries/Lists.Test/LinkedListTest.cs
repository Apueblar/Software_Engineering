﻿namespace Lists
{
	class Person
	{
		public string FirstName { get; set; }
		public string Surname { get; set; }
		public override string ToString()
		{
			return "[Name=" + FirstName + ", Surname=" + Surname + "]";
		}
		public Person(string FirstName, string Surname) {
			this.FirstName = FirstName;
			this.Surname = Surname;
		}
		public override bool Equals(object? obj)
		{
			if (obj == null || obj.GetType() != typeof(Person))
			{
				return false;
			}

			Person other = (Person) obj;
			return FirstName == other.FirstName && Surname == other.Surname;
		}
		public override int GetHashCode()
		{
			return HashCode.Combine(FirstName, Surname);
		}
	}

	[TestClass]
	public class LinkedListTests
	{
		[TestMethod]
		public void Add_ThreeElementsInt_CountIsThree()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			Assert.AreEqual(3, list.NumberOfElements);
		}

		[TestMethod]
		public void Add_ThreeElementsString_CountIsThree()
		{
			var list = new LinkedList<string>();
			list.Add("Hello");
			list.Add("World");
			list.Add("Test");
			Assert.AreEqual(3, list.NumberOfElements);
		}

		[TestMethod]
		public void Add_ThreeElementsFloat_CountIsThree()
		{
			var list = new LinkedList<float>();
			list.Add(1.1f);
			list.Add(2.2f);
			list.Add(3.3f);
			Assert.AreEqual(3, list.NumberOfElements);
		}

		[TestMethod]
		public void Add_ThreeElementsObject_CountIsThree()
		{
			var list = new LinkedList<object>();
			list.Add(new object());
			list.Add(new object());
			list.Add(new object());
			Assert.AreEqual(3, list.NumberOfElements);
		}

		[TestMethod]
		public void GetElement_ValidIndex_ReturnsValue()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);
			Assert.AreEqual(10, list.GetElement(0));
			Assert.AreEqual(20, list.GetElement(1));
			Assert.AreEqual(30, list.GetElement(2));
		}

		[TestMethod]
		public void Remove_ExistingElement_DecreasesCount()
		{
			var list = new LinkedList<int>();
			list.Add(100);
			list.Add(200);
			bool result = list.Remove(100);
			Assert.IsTrue(result);
			Assert.AreEqual(1, list.NumberOfElements);
		}

		[TestMethod]
		public void Remove_NonExistingElement_ReturnsFalse()
		{
			var list = new LinkedList<int>();
			list.Add(50);
			bool result = list.Remove(99);
			Assert.IsFalse(result);
		}

		[TestMethod]
		public void RemoveAt_ValidIndex_RemovesElement()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);
			bool removed = list.RemoveAt(1);
			Assert.IsTrue(removed);
			Assert.AreEqual(2, list.NumberOfElements);
			Assert.AreEqual(10, list.GetElement(0));
			Assert.AreEqual(30, list.GetElement(1));
		}

		[TestMethod]
		public void ToString_CheckFormat()
		{
			var list = new LinkedList<int>();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			Assert.AreEqual("[1, 2, 3]", list.ToString());
		}

		[TestMethod]
		public void ToString_EmptyList_ReturnsEmptyBrackets()
		{
			var list = new LinkedList<int>();
			Assert.AreEqual("[]", list.ToString());
		}

		[TestMethod]
		public void Add_ThreePersonElements_CountIsThree()
		{
			var list = new LinkedList<Person>();
			list.Add(new Person("Alice", "Johnson"));
			list.Add(new Person("Bob", "Smith"));
			list.Add(new Person("Charlie", "Brown"));

			Assert.AreEqual(3, list.NumberOfElements);
		}

		[TestMethod]
		public void GetElement_PersonList_ReturnsCorrectPerson()
		{
			var list = new LinkedList<Person>();
			var p1 = new Person("Alice", "Johnson");
			var p2 = new Person("Bob", "Smith");
			var p3 = new Person("Charlie", "Brown");

			list.Add(p1);
			list.Add(p2);
			list.Add(p3);

			Assert.AreEqual(p1, list.GetElement(0));
			Assert.AreEqual(p2, list.GetElement(1));
			Assert.AreEqual(p3, list.GetElement(2));
		}

		[TestMethod]
		public void Remove_PersonObject_RemovesCorrectly()
		{
			var list = new LinkedList<Person>();
			var p1 = new Person("Alice", "Johnson");
			var p2 = new Person("Bob", "Smith");
			var p3 = new Person("Charlie", "Brown");

			list.Add(p1);
			list.Add(p2);
			list.Add(p3);
			bool removed = list.Remove(p2);

			Assert.IsTrue(removed);
			Assert.AreEqual(2, list.NumberOfElements);
			Assert.AreEqual(p1, list.GetElement(0));
			Assert.AreEqual(p3, list.GetElement(1));
		}

		[TestMethod]
		public void Remove_PersonDuplicate_RemovesFirstOccurrence()
		{
			var list = new LinkedList<Person>();
			var p1 = new Person("Alice", "Johnson");
			var p2 = new Person("Bob", "Smith");

			list.Add(p1);
			list.Add(p2);
			list.Add(p1);

			bool removed = list.Remove(p1);

			Assert.IsTrue(removed);
			Assert.AreEqual(2, list.NumberOfElements);
			Assert.AreEqual(p2, list.GetElement(0));
			Assert.AreEqual(p1, list.GetElement(1));
		}

		[TestMethod]
		public void LargeList_PerformanceTest()
		{
			var list = new LinkedList<int>();
			const int itemCount = 1000;

			for (int i = 0; i < itemCount; i++)
			{
				list.Add(i);
			}

			Assert.AreEqual(itemCount, list.NumberOfElements);
			Assert.AreEqual(0, list.GetElement(0));
			Assert.AreEqual(itemCount - 1, list.GetElement(itemCount - 1));

			for (int i = 0; i < itemCount / 2; i++)
			{
				list.Remove(i);
			}

			Assert.AreEqual(itemCount / 2, list.NumberOfElements);
		}

		[TestMethod]
		public void RemoveAllElements_CheckEmptyState()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);

			list.Remove(10);
			list.Remove(20);
			list.Remove(30);

			Assert.AreEqual(0, list.NumberOfElements);
			Assert.AreEqual("[]", list.ToString());
		}

		[TestMethod]
		public void Contains_ThreeElementsInt_CheckIsTrue()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);
			list.Add(30);

			Assert.IsTrue(list.Contains(10));
			Assert.IsTrue(list.Contains(20));
			Assert.IsTrue(list.Contains(30));
		}

		[TestMethod]
		public void Contains_NoElemetsInt_CheckIsFalse()
		{
			var list = new LinkedList<int>();

			Assert.IsFalse(list.Contains(10));
			Assert.IsFalse(list.Contains(20));
			Assert.IsFalse(list.Contains(30));
		}

		[TestMethod]
		public void Contains_ThreeElementsString_CheckIsTrue()
		{
			var list = new LinkedList<string>();
			list.Add("Hi");
			list.Add("Lunch");
			list.Add("Potatoe");

			Assert.IsTrue(list.Contains("Hi"));
			Assert.IsTrue(list.Contains("Lunch"));
			Assert.IsTrue(list.Contains("Potatoe"));
		}

		[TestMethod]
		public void Contains_NoElementsString_CheckIsFalse()
		{
			var list = new LinkedList<string>();

			Assert.IsFalse(list.Contains("Hi"));
			Assert.IsFalse(list.Contains("Lunch"));
			Assert.IsFalse(list.Contains("Potatoe"));
		}
	}

	[TestClass]
	public class LinkedListNegativeTests
	{
		[TestMethod]
		public void Add_NullValue_ThrowsArgumentException()
		{
			var list = new LinkedList<string>();

			var exception = Assert.ThrowsException<ArgumentException>(() => list.Add(null));

			Assert.AreEqual("Value cannot be null.", exception.Message);
		}

		[TestMethod]
		public void GetElement_NegativeIndex_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();

			var exception = Assert.ThrowsException<ArgumentException>(() => list.GetElement(-1));

			Assert.AreEqual("The index must be in the range of 0, to NumberOfElements.", exception.Message);
		}

		[TestMethod]
		public void GetElement_IndexOutOfBounds_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();
			list.Add(10);
			list.Add(20);

			var exception = Assert.ThrowsException<ArgumentException>(() => list.GetElement(5));

			Assert.AreEqual("The index must be in the range of 0, to NumberOfElements.", exception.Message);
		}

		[TestMethod]
		public void GetElement_EmptyList_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();

			var exception = Assert.ThrowsException<ArgumentException>(() => list.GetElement(0));

			Assert.AreEqual("The index must be in the range of 0, to NumberOfElements.", exception.Message);
		}

		[TestMethod]
		public void RemoveAt_NegativeIndex_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();

			var exception = Assert.ThrowsException<ArgumentException>(() => list.RemoveAt(-1));

			Assert.AreEqual("The index must be in the range of 0, to NumberOfElements.", exception.Message);
		}

		[TestMethod]
		public void RemoveAt_IndexOutOfBounds_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();
			list.Add(1);

			var exception = Assert.ThrowsException<ArgumentException>(() => list.RemoveAt(2));

			Assert.AreEqual("The index must be in the range of 0, to NumberOfElements.", exception.Message);
		}

		[TestMethod]
		public void RemoveAt_EmptyList_ThrowsArgumentException()
		{
			var list = new LinkedList<int>();

			var exception = Assert.ThrowsException<ArgumentException>(() => list.RemoveAt(0));

			Assert.AreEqual("The index must be in the range of 0, to NumberOfElements.", exception.Message);
		}
	}
}
