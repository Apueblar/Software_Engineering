﻿using System;

namespace TPP.Laboratory.ObjectOrientation.Lab03 {

    interface EqualatorPredicate
    {
        bool Compare(object? a, object? b);
    }

    public class ComparePersonUsingNameLength : EqualatorPredicate
    {
        public bool Compare(object a, object b)
        {
            Person p1 = a as Person;
            Person p2 = b as Person;
            if (p1 == null || p2 == null)
            {
                return false;
            }
            return p1.FirstName.Length == p2.FirstName.Length;
        }
    }

    public class CompareAngleIfTheyAreInTheSameQuadrant : EqualatorPredicate
    {
        public bool Compare(object a, object b)
        {
            Angle p1 = a as Angle;
            Angle p2 = b as Angle;
            if (p1 == null || p2 == null)
            {
                return false; // At least one is not an angle
            }
            return SameQuadrant(p1, p2);
        }
        private bool SameQuadrant(Angle a, Angle b)
        {
            // Normalize the angles to the range [0, 2π)
            double radianA = a.Radians % (2 * Math.PI);
            double radianB = b.Radians % (2 * Math.PI);

            // To ensure they are in the range [0, 2π)
            if (radianA < 0) radianA += 2 * Math.PI;
            if (radianB < 0) radianB += 2 * Math.PI;

            // Determine the quadrants
            int quadrantA = (radianA < Math.PI / 2) ? 1 :
                            (radianA < Math.PI) ? 2 :
                            (radianA < 3 * Math.PI / 2) ? 3 : 4;

            int quadrantB = (radianB < Math.PI / 2) ? 1 :
                            (radianB < Math.PI) ? 2 :
                            (radianB < 3 * Math.PI / 2) ? 3 : 4;

            return quadrantA == quadrantB;
        }

    }

    public static class AlgoExte
        {

            // Exercise: Implement an IndexOf method that finds the first position (index) 
            // of an object in an array of objects. It should be valid for Person, Angle and future classes.
            public static uint? IndexOfv0(this object[] collection, object findObj)
            {
                for (uint i = 0; i < collection.Length; i++)
                {
                    if (Object.Equals(collection[i], findObj))
                    {
                        return i;
                    }
                }
                return null;
            }

            public static uint? IndexOf(this object[] collection, object findObj, EqualatorPredicate predicate)
            {
                for (uint i = 0; i < collection.Length; i++)
                {
                    if (predicate.Compare(collection[i], findObj))
                    {
                        return i;
                    }
                }
                return null;
            }


    }

    class Algorithms {

        


        static Person[] CreatePeople() {
            string[] firstnames = { "María", "Juan", "Pepe", "Luis", "Carlos", "Miguel", "Cristina" };
            string[] surnames = { "Díaz", "Pérez", "Hevia", "García", "Rodríguez", "Pérez", "Sánchez" };
            int numberOfPeople = 100;

            Person[] printOut = new Person[numberOfPeople];
            Random random = new Random();
            for (int i = 0; i < numberOfPeople; i++)
                printOut[i] = new Person(
                    firstnames[random.Next(0, firstnames.Length)],
                    surnames[random.Next(0, surnames.Length)],
                    random.Next(9000000, 90000000) + "-" + (char)random.Next('A', 'Z')
                    );
            return printOut;
        }

        static Angle[] CreateAngles() {
            Angle[] angles = new Angle[(int)(Math.PI * 2 * 10)];
            int i = 0;
            while (i < angles.Length) {
                angles[i] = new Angle(i / 10.0);
                i++;
            }
            return angles;
        }

        static void Main() {
            uint? i = AlgoExte.IndexOf(CreateAngles(), new Angle(5 / 10.0));
            Console.WriteLine(String.Format("{0}", i));
            Console.WriteLine("Hola";
        }

    }

}
