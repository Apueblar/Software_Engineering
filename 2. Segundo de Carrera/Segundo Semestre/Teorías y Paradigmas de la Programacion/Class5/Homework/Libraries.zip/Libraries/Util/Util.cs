﻿namespace Util
{
    public static class ExtensionMethods
    {
        public static T? Find<T> (this IEnumerable<T> collection, Predicate<T> f)
        {
            foreach(var element in collection)
            {
                if (f(element))
                {
                    return element;
                }
            }
            return default(T);
        }
        public static IEnumerable<T> Filter<T>(this IEnumerable<T> collection, Predicate<T> f)
        {
            IList<T> filt = new List<T>();
            foreach (var element in collection)
            {
                if (f(element))
                {
                    filt.Add( element );
                }
            }
            return filt;
        }

        public static TResult Reduce<T, TResult>(this IEnumerable<T> collection,TResult defaultResult, Func<T, TResult, TResult> f)
        {
            TResult? result = defaultResult;
			foreach (var item in collection)
			{
				result = f(item, result);
			}
			return result;
		}
    }
}
