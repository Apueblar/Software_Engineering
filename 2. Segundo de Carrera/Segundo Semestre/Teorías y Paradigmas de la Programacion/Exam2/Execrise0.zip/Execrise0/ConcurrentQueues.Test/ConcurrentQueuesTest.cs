﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ConcurrentQueues
{
	[TestClass]
	public sealed class ConcurrentQueuesTest
	{
		[TestMethod]
		public void Enqueue_AddsElementToQueue()
		{
			var queue = new ConcurrentQueue<int>();
			queue.Enqueue(42);

			Assert.AreEqual(1u, queue.NumberOfElements);
			Assert.IsFalse(queue.IsEmpty);
			Assert.AreEqual(42, queue.Peek());
		}

		[TestMethod]
		public void Dequeue_RemovesAndReturnsElement()
		{
			var queue = new ConcurrentQueue<string>();
			queue.Enqueue("first");
			queue.Enqueue("second");

			var item = queue.Dequeue();

			Assert.AreEqual("first", item);
			Assert.AreEqual(1u, queue.NumberOfElements);
			Assert.AreEqual("second", queue.Peek());
		}

		[TestMethod]
		public void Dequeue_ThrowsException_WhenQueueIsEmpty()
		{
			var queue = new ConcurrentQueue<double>();
			try
			{
				var _ = queue.Dequeue(); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
			
		}

		[TestMethod]
		public void Peek_ThrowsException_WhenQueueIsEmpty()
		{
			var queue = new ConcurrentQueue<object>();
			try
			{
				var _ = queue.Peek(); // Should throw exception
				Assert.Fail("Expected an ArgumentException to be thrown.");
			}
			catch (ArgumentException ex)
			{
				Assert.IsFalse(ex.Message.Length == 0);
			}
		}

		[TestMethod]
		public void Peek_ReturnsElementWithoutRemoving()
		{
			var queue = new ConcurrentQueue<int>();
			queue.Enqueue(99);

			var peeked = queue.Peek();
			Assert.AreEqual(99, peeked);
			Assert.AreEqual(1u, queue.NumberOfElements);
		}

		[TestMethod]
		public void IsEmpty_ReturnsTrue_WhenQueueIsEmpty()
		{
			var queue = new ConcurrentQueue<int>();
			Assert.IsTrue(queue.IsEmpty);
		}

		[TestMethod]
		public void IsEmpty_ReturnsFalse_WhenQueueHasElements()
		{
			var queue = new ConcurrentQueue<int>();
			queue.Enqueue(1);
			Assert.IsFalse(queue.IsEmpty);
		}

		[TestMethod]
		public void ConcurrentAccess_EnqueueAndDequeueFromMultipleThreads()
		{
			var queue = new ConcurrentQueue<int>();
			int numberOfThreads = 10;
			int itemsPerThread = 1000;

			Parallel.For(0, numberOfThreads, i =>
			{
				for (int j = 0; j < itemsPerThread; j++)
				{
					queue.Enqueue(i * itemsPerThread + j);
				}
			});

			int totalItems = numberOfThreads * itemsPerThread;
			Assert.AreEqual((uint)totalItems, queue.NumberOfElements);

			int count = 0;
			while (!queue.IsEmpty)
			{
				queue.Dequeue();
				count++;
			}

			Assert.AreEqual(totalItems, count);
			Assert.IsTrue(queue.IsEmpty);
		}
	}
}
