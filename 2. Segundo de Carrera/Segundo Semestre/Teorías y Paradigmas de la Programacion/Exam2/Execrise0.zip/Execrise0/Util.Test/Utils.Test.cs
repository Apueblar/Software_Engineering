﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Util
{
	public class Angle
	{
		public double Radians { get; private set; }
		public float Degrees { get { return (float)(this.Radians / Math.PI * 180); } }
		public Angle(double radians) { this.Radians = radians; }
		public Angle(float degrees) {this.Radians = degrees / 180.0 * Math.PI;}
		public double Sine() {return Math.Sin(this.Radians);}
		public double Cosine() {return Math.Cos(this.Radians);}
		public double Tangent() {return Sine() / Cosine();}
		public int Quadrant {
			get
			{
				double degrees = this.Degrees;
				if (degrees > 0 && degrees <= 90) return 1;
				if (degrees > 90 && degrees <= 180) return 2;
				if (degrees > 180 && degrees <= 270) return 3;
				return 4; // 270 < degrees < 360
			}
		}
	}

	public class Person
	{
		public String FirstName { get; private set; }
		public String Surname { get; private set; }
		public string IDNumber { get; private set; }
		public override String ToString() { return String.Format("{0} {1} with {2} ID number", FirstName, Surname, IDNumber); }
		public Person(String firstName, String surname, string idNumber)
		{
			this.FirstName = firstName;
			this.Surname = surname;
			this.IDNumber = idNumber;
		}
	}

	[TestClass]
	public sealed class ExtensionMethodsTest
	{
		[TestMethod]
		public void TestFind_ShouldReturnMatchingElement()
		{
			List<int> numbers = new() { 1, 2, 3, 4, 5 };
			int? result = numbers.Find(n => n > 3);
			Assert.AreEqual(4, result);
		}

		[TestMethod]
		public void TestFind_ShouldReturnDefault_WhenNoMatch()
		{
			List<int> numbers = new() { 1, 2, 3 };
			int? result = numbers.Find(n => n > 5);
			Assert.AreEqual(default(int), result);
		}

		[TestMethod]
		public void TestFilter_ShouldReturnMatchingElements()
		{
			List<int> numbers = new() { 1, 2, 3, 4, 5 };
			IEnumerable<int> result = numbers.Filter(n => n % 2 == 0);
			CollectionAssert.AreEqual(new List<int> { 2, 4 }, new List<int>(result));
		}

		[TestMethod]
		public void TestFilter_ShouldReturnEmpty_WhenNoMatch()
		{
			List<int> numbers = new() { 1, 3, 5 };
			IEnumerable<int> result = numbers.Filter(n => n % 2 == 0);
			CollectionAssert.AreEqual(new List<int>(), new List<int>(result));
		}

		[TestMethod]
		public void TestReduce_ShouldSumNumbers()
		{
			List<int> numbers = new() { 1, 2, 3, 4, 5 };
			int? sum = numbers.Reduce(0, (int n,int accumulator) => accumulator + n);
			Assert.AreEqual(15, sum);
		}

		[TestMethod]
		public void TestReduce_ShouldReturnDefault_WhenEmpty()
		{
			List<int> numbers = new();
			int? sum = numbers.Reduce(0, (int n, int accumulator) => accumulator + n);
			Assert.AreEqual(default(int), sum);
		}

		[TestMethod]
		public void TestFind_ShouldReturnRightAngle()
		{
			List<Angle> angles = new() { new Angle(30), new Angle(45), new Angle(90), new Angle(120) };
			Angle? result = angles.Find(a => a.Degrees == 90);
			Assert.IsNotNull(result);
			Assert.AreEqual(90, result.Degrees);
		}

		[TestMethod]
		public void TestFilter_ShouldReturnAnglesInQuadrant()
		{
			List<Angle> angles = new() { new Angle(30), new Angle(100), new Angle(200), new Angle(300) };
			IEnumerable<Angle> result = angles.Filter(a => a.Quadrant == 2);
			Assert.AreEqual(1, result.Count());
			Assert.AreEqual(100, result.First().Degrees, 1e-6);
		}

		[TestMethod]
		public void TestPersonExtensions()
		{
			List<Person> people = new()
			{
				new Person("John", "Doe", "12345"),
				new Person("Jane", "Smith", "67890"),
				new Person("Alice", "Johnson", "54321"),
				new Person("Bob", "Brown", "98765")
			};

			Person? foundPerson = people.Find(p => p.IDNumber == "67890");
			Assert.IsNotNull(foundPerson);
			Assert.AreEqual("Jane", foundPerson?.FirstName);

			IEnumerable<Person> filteredPeople = people.Filter(p => p.Surname.StartsWith("J"));
			List<Person> filteredList = new List<Person>(filteredPeople);
			Assert.AreEqual(1, filteredList.Count);
			Assert.AreEqual("Alice", filteredList[0].FirstName);

			string allNames = people.Reduce("" , (Person p,string acc) => String.Format("{0}{1}{2} {3}", acc, acc.Length > 0 ? ", " : "", p.FirstName, p.Surname));
			Assert.AreEqual("John Doe, Jane Smith, Alice Johnson, Bob Brown", allNames);
		}

        [TestMethod]
        public void Map_BasicTransformation_ReturnsMappedValues()
        {
            var collection = new List<int> { 1, 2, 3, 4, 5 };
            Func<int, string> function = x => $"Number {x}";

            var result = collection.Map(function).ToList();

            Assert.AreEqual(5, result.Count);
            Assert.AreEqual("Number 1", result[0]);
            Assert.AreEqual("Number 2", result[1]);
            Assert.AreEqual("Number 3", result[2]);
            Assert.AreEqual("Number 4", result[3]);
            Assert.AreEqual("Number 5", result[4]);
        }

        [TestMethod]
        public void Map_EmptyCollection_ReturnsEmptyCollection()
        {
            var collection = new List<int>();
            Func<int, string> function = x => $"Number {x}";

            var result = collection.Map(function).ToList();

            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void Map_SameTypeTransformation_ReturnsSameValues()
        {
            var collection = new List<int> { 1, 2, 3 };
            Func<int, int> function = x => x;

            var result = collection.Map(function).ToList();

            Assert.AreEqual(3, result.Count);
            Assert.AreEqual(1, result[0]);
            Assert.AreEqual(2, result[1]);
            Assert.AreEqual(3, result[2]);
        }

        [TestMethod]
        public void Map_ComplexTransformation_ReturnsCorrectValues()
        {
            var collection = new List<int> { 1, 2, 3 };
            Func<int, string> function = x => x % 2 == 0 ? "Even" : "Odd";

            var result = collection.Map(function).ToList();

            Assert.AreEqual(3, result.Count);
            Assert.AreEqual("Odd", result[0]);
            Assert.AreEqual("Even", result[1]);
            Assert.AreEqual("Odd", result[2]);
        }

        [TestMethod]
        public void Map_ComplexObject_ReturnsMappedObject()
        {
            var collection = new List<Person>
			{
                new Person("John", "Doe", "30"),
                new Person("Jane", "Smith", "25"),
            };
            Func<Person, string> function = p => $"{p.FirstName} has {p.IDNumber} as IDNUMBER";

            var result = collection.Map(function).ToList();

            Assert.AreEqual(2, result.Count);
            Assert.AreEqual("John has 30 as IDNUMBER", result[0]);
            Assert.AreEqual("Jane has 25 as IDNUMBER", result[1]);
        }

        [TestMethod]
        public void Map_CollectionWithNulls_HandlesNullsCorrectly()
        {
            var collection = new List<string> { "Hello", null, "World" };
            Func<string, string> function = x => x?.ToUpper() ?? "NULL";

            var result = collection.Map(function).ToList();

            Assert.AreEqual(3, result.Count);
            Assert.AreEqual("HELLO", result[0]);
            Assert.AreEqual("NULL", result[1]);
            Assert.AreEqual("WORLD", result[2]);
        }

		[TestMethod]
		public void TestInvert_ShouldReturnReversedCollection()
		{
			List<int> numbers = new() { 1, 2, 3, 4, 5 };
			IEnumerable<int> result = numbers.Invert();
			CollectionAssert.AreEqual(new List<int> { 5, 4, 3, 2, 1 }, result.ToList());
		}

		[TestMethod]
		public void TestInvert_ShouldReturnEmpty_WhenCollectionIsEmpty()
		{
			List<int> numbers = new();
			IEnumerable<int> result = numbers.Invert();
			Assert.AreEqual(0, result.Count());
		}

		[TestMethod]
		public void TestInvert_ShouldWorkWithSingleElement()
		{
			List<int> numbers = new() { 42 };
			IEnumerable<int> result = numbers.Invert();
			CollectionAssert.AreEqual(new List<int> { 42 }, result.ToList());
		}

		[TestMethod]
		public void TestInvert_ShouldWorkWithAngles()
		{
			List<Angle> angles = new() { new Angle(30), new Angle(45), new Angle(90) };
			IEnumerable<Angle> result = angles.Invert();
			CollectionAssert.AreEqual(new List<float> { 90, 45, 30 }, result.Select(a => a.Degrees).ToList());
		}

		[TestMethod]
		public void TestInvert_ShouldWorkWithPeople()
		{
			List<Person> people = new()
			{
				new Person("John", "Doe", "12345"),
				new Person("Jane", "Smith", "67890"),
				new Person("Alice", "Johnson", "54321")
			};

			IEnumerable<Person> result = people.Invert();
			CollectionAssert.AreEqual(new List<string> { "Alice", "Jane", "John" }, result.Select(p => p.FirstName).ToList());
		}
	}
}
