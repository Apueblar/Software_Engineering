﻿namespace Util
{
    public static class ExtensionMethods
    {
        public static T? Find<T> (this IEnumerable<T> collection, Predicate<T> f)
        {
            foreach(var element in collection)
            {
                if (f(element))
                {
                    return element;
                }
            }
            return default;
        }

        public static IEnumerable<T> Filter<T>(this IEnumerable<T> collection, Predicate<T> f)
        {
            foreach (var element in collection)
            {
                if (f(element))
                {
                    yield return element;
                }
            }
        }

        public static TResult Reduce<T, TResult>(this IEnumerable<T> collection,TResult defaultResult, Func<T, TResult, TResult> f)
        {
            TResult? result = defaultResult;
			foreach (var item in collection)
			{
				result = f(item, result);
			}
			return result;
		}

        public static IEnumerable<TResult> Map<TElement, TResult>
            (this IEnumerable<TElement> collection, Func<TElement, TResult> function)
        {
            if (collection == null)
            {
                throw new ArgumentException("collection cannot be null.");
            }
            foreach (TElement element in collection)
            {
                yield return function(element);
            }
        }

		public static IEnumerable<T> Invert<T>(this IEnumerable<T> collection)
		{
			var stack = new Stack<T>();
			foreach (var element in collection)
			{
				stack.Push(element); // Store
			}

			foreach (var element in stack)
			{
				yield return element; // Yield 1 by 1
			}
		}
	}
}
