﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EX2
{

    class Producer {

        private readonly Queue<Stocks> queue;
		private readonly Random random = new Random();

        public void Run() {
            foreach (var stock in Stocks.ReadFromFile("../../../brent.csv")) {
                Console.WriteLine("[Producer] Enqueuing: {0}", stock);
                lock (queue)
                {
                    queue.Enqueue(stock);
                }
                Console.WriteLine("[Producer] {0} enqueued.", stock);
				Thread.Sleep(random.Next(150, 201));
			}

			Console.WriteLine("[Producer] -- No more data --");
            bool notFinish = true;
            while (notFinish)
            {
                lock (queue)
                {
                    if (queue.Count() == 0)
                    {
                        notFinish = false;
                    }
                }
                Thread.Sleep(1000);
            }
            System.Environment.Exit(0);
        }

		public Producer(Queue<Stocks> queue) {
            this.queue = queue;
        }
    }
}
