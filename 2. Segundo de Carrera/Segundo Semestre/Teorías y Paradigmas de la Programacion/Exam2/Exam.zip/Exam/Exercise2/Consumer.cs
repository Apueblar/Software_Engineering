﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EX2
{
    class Consumer {

        private Queue<Stocks> queue;
		private readonly Random random = new Random();
		private readonly int id;

		public Consumer(Queue<Stocks> queue, int id) {
            this.queue = queue;
            this.id = id;
        }

        public void Run() {
            while (true) {
                Console.WriteLine("[Consumer #{0}] Dequeuing a stock...", id);
				Stocks? stock = null;
                while (HasToSleep())
                {
                    Thread.Sleep(100);
                }
                lock (queue) {
                    if (queue.Count() != 0)
                    {
						stock = queue.Dequeue();
                    }
                }
                if (stock != null)
                {
					var range = stock.High - stock.Low;
					var upper = stock.High + 1.5 * range;
					var lower = stock.Low - 1.5 * range;

					Console.WriteLine("[Consumer #{0}] Got {1}\n             => Outlier Pair = (Upper: {2:F2}, Lower: {3:F2})", id, stock, upper, lower); 
                    Thread.Sleep(random.Next(400, 501));
                }
            }
        }

        private bool HasToSleep()
        {
            bool result;
            lock (queue)
            {
                result = queue.Count == 0;
            }
            return result;
        }
    }
}
