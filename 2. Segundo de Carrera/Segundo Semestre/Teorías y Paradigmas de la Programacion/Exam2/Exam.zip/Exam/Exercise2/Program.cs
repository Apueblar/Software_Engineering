﻿using System.Collections.Concurrent;

namespace EX2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<Stocks> queue = new Queue<Stocks>();
            Producer producer = new Producer(queue);
            Consumer consumer0 = new Consumer(queue, 0);
            Consumer consumer1 = new Consumer(queue, 1);
            Consumer consumer2 = new Consumer(queue, 2);
            new Thread(producer.Run).Start();
            Thread.Sleep(2000);
            new Thread(consumer0.Run).Start();
            Thread.Sleep(1000);
            new Thread(consumer1.Run).Start();
            Thread.Sleep(1000);
            new Thread(consumer2.Run).Start();

            //(high + (1.5 * (high-low)), low - (1.5 * (high-low)))
        }
    }
}
