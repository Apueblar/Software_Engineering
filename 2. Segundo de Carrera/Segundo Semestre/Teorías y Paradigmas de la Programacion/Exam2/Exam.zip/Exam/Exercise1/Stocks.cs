﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX1
{
    internal class Stocks
    {
        public double Open { get; private set; }
        public double High { get; private set; }
        public double Low { get; private set; }
        public double Close { get; private set; }
        public int Volume { get; private set; }
        public Stocks() { }

        public static IEnumerable<Stocks> ReadFromFile(string fileName)
        {
            using (StreamReader stream = File.OpenText(fileName))
            {
                //Skip first line: This contains the file header
                stream.ReadLine();
                //Read remainder lines
                string line;
                while ((line = stream.ReadLine()) != null)
                {
                    var elements = line.Split(new char[] { ',' });
                    yield return new Stocks()
                    {
                        Open = Double.Parse(elements[0], CultureInfo.InvariantCulture),
                        High = Double.Parse(elements[1], CultureInfo.InvariantCulture),
                        Low = Double.Parse(elements[2], CultureInfo.InvariantCulture),
                        Close = Double.Parse(elements[3], CultureInfo.InvariantCulture),
                        Volume = Int32.Parse(elements[4])
                    };
                }
                yield break;
            }
        }
    }


}
