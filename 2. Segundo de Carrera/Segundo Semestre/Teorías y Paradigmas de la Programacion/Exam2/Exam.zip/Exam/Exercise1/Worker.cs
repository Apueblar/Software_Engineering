﻿using System.Collections.Generic;
using System;

namespace EX1
{

	/// <summary>
	/// Counts word occurrences in a slice of the array [fromIndex..toIndex].
	/// </summary>
	internal class Worker
	{
		private readonly IList<Stocks> stocks;
		private readonly int fromIndex, toIndex;

		public double MaxRangeResult { get; private set; } = double.MinValue;
		public double MinRangeResult { get; private set; } = double.MaxValue;

		public double SumFluct { get; private set; } = 0.0;
		public uint Count { get; private set; } = 0;

		public Worker(IList<Stocks> stocks, int fromIndex, int toIndex)
		{
			this.stocks = stocks;
			this.fromIndex = fromIndex;
			this.toIndex = toIndex;
		}

		public void Process()
		{
			// Iterates through the range of asigned indices
			for (int i = fromIndex; i <= toIndex; i++)
			{
				double range = stocks[i].Open - stocks[i].Close;
				if (range > MaxRangeResult) { MaxRangeResult = range; }
				if (range < MinRangeResult) { MinRangeResult = range; }

				SumFluct += stocks[i].High - stocks[i].Low;
				Count++;
			}
		}
	}
}
