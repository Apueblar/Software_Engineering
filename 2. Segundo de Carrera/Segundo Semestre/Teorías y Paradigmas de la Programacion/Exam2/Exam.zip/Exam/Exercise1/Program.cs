﻿using System.Collections.Generic;
using System.Diagnostics;

namespace EX1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<Stocks> stocks = Stocks.ReadFromFile("../../../bbva.csv");

            int threadsToTest = 4;
            var master = new Master(stocks, threadsToTest);

            Console.WriteLine("4 workers:");
            Stopwatch crono = Stopwatch.StartNew();
            var (maxRange, minRange, avgFluct) = master.ComputeStatistics();
            crono.Stop();
            Console.WriteLine("Elapsed time: {0:N0} ms.\n", crono.ElapsedMilliseconds);

            Console.WriteLine("Maximum (Open-Close) range: {0}", maxRange);
            Console.WriteLine("Minimum (Open-Close) range: {0}", minRange);
            Console.WriteLine("Average (High-Low) fluctuation: {0}", avgFluct);
            Console.WriteLine(new string('-', 50));


            threadsToTest = 8;
            master = new Master(stocks, threadsToTest);

            Console.WriteLine("\n8 workers:");
            crono = Stopwatch.StartNew();
            (maxRange, minRange, avgFluct) = master.ComputeStatistics();
            crono.Stop();
            Console.WriteLine("Elapsed time: {0:N0} ms.\n", crono.ElapsedMilliseconds);

            Console.WriteLine("Maximum (Open-Close) range: {0}", maxRange);
            Console.WriteLine("Minimum (Open-Close) range: {0}", minRange);
            Console.WriteLine("Average (High-Low) fluctuation: {0}", avgFluct);
            Console.WriteLine(new string('-', 50));


            threadsToTest = 1;
            master = new Master(stocks, threadsToTest);

            Console.WriteLine("\n1 worker:");
            crono = Stopwatch.StartNew();
            (maxRange, minRange, avgFluct) = master.ComputeStatistics();
            crono.Stop();
            Console.WriteLine("Elapsed time: {0:N0} ms.\n", crono.ElapsedMilliseconds);

            Console.WriteLine("Maximum (Open-Close) range: {0}", maxRange);
            Console.WriteLine("Minimum (Open-Close) range: {0}", minRange);
            Console.WriteLine("Average (High-Low) fluctuation: {0}", avgFluct);
            Console.WriteLine(new string('-', 50));
        }
    }
}