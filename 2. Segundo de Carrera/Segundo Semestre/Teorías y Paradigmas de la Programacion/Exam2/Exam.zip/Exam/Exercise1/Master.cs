﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace EX1
{
	/// <summary>
	/// Splits the words array into N segments, spawns N threads to count each segment,
	/// then merges the partial counts into a single dictionary.
	/// </summary>
	internal class Master
	{
		private readonly IList<Stocks> stocks;
		private readonly int numberOfThreads;

		public Master(IEnumerable<Stocks> stocksEnumerable, int numberOfThreads)
		{
			if (stocksEnumerable is IList<Stocks> existingList) { this.stocks = existingList; }
			else { this.stocks = stocksEnumerable.ToList(); }

			if (numberOfThreads < 1 || numberOfThreads > this.stocks.Count) { throw new ArgumentException("The number of threads must be between 1 and the length of the stocks enumerable."); }
			this.numberOfThreads = numberOfThreads;
		}

		public (double maxRange, double minRange, double avgFluct) ComputeStatistics()
		{
			// 1) Create workers
			Worker[] workers = new Worker[numberOfThreads];
			int itemsPerThread = stocks.Count() / numberOfThreads;

			for (int i = 0; i < numberOfThreads; i++)
			{
				int start = i * itemsPerThread;
				int end = (i < numberOfThreads - 1)
					? (start + itemsPerThread - 1)
					: (stocks.Count() - 1);  // last thread takes remainder

				workers[i] = new Worker(stocks, start, end);
			}

			// 2) Spawn threads
			Thread[] threads = new Thread[numberOfThreads];
			for (int i = 0; i < numberOfThreads; i++)
			{
				threads[i] = new Thread(workers[i].Process)
				{
					Name = $"Worker {i + 1}",
					Priority = ThreadPriority.BelowNormal
				};
				threads[i].Start();
			}

			// 3) Wait to finish
			foreach (var t in threads) { t.Join(); }

			// 4) Merge results
			double globalMax = double.MinValue;
			double globalMin = double.MaxValue;
			double totalSum = 0.0;
			uint totalCount = 0;
			foreach (var worker in workers)
			{
				double wMax = worker.MaxRangeResult;
				double wMin = worker.MinRangeResult;
				totalSum += worker.SumFluct;
				totalCount += worker.Count;

				if (wMax > globalMax) { globalMax = wMax; }
				if (wMin < globalMin) { globalMin = wMin; }
			}
			double avgFluct = (totalCount > 0) ? (totalSum / totalCount) : 0.0;

			return (globalMax, globalMin, avgFluct);
		}
	}
}
