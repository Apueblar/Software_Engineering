﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace EX3
{
    internal class Program
    {
        private const int MAX = 1_000_000;
        private const int NTHREADS = 4;
        // Lock object for synchronizing access to the numbers queue
        private static readonly object numbersLock = new object();
        // Lock object for synchronizing access to the primes list
        private static readonly object primesLock = new object();
        // Lock object for synchronizing console output
        private static readonly object consoleMonitor = new object();

        static void Main(string[] args)
        {
            var numbers = new Queue<uint>();
            for (uint i = 0; i < MAX; i++)
            {
                numbers.Enqueue(i);
            }
            var primes = new List<uint>();
            var threads = new List<Thread>();

            for (int i = 0; i < NTHREADS; i++)
            {
                var thread = new Thread(() =>
                {
                    //var monitor = new object(); // This is wrong
                    while (true)
                    {
                        uint number = 0;
                        lock (numbersLock) // Change the locks
                        {
                            if (numbers.Count == 0)
                            {
                                lock (consoleMonitor) // Well done
                                {
                                    Console.WriteLine($"  Worker {Thread.CurrentThread.ManagedThreadId} finished");
                                }
                                break;
                            }
                            number = numbers.Dequeue();
                        }

                        if (IsPrime(number))
                        {
                            lock (primesLock) // Change the locks
                            {
                                primes.Add(number);
                            }
                        }
                    }
                });
                threads.Add(thread);
                thread.Start();
                lock (consoleMonitor) // Well done
                {
                    Console.WriteLine($"Worker {thread.ManagedThreadId} started");
                }
            }

            while (true)
            {
                int remaining;

                lock (numbersLock) // Read count under numbersLock to avoid race condition
                {
                    remaining = numbers.Count;
                }
                if (remaining == 0)
                {
                    break;
                }

                lock (consoleMonitor) // Avoid permanent lock of the monitor
                {
                    Console.WriteLine($"Numbers left: {remaining}");
                }
                Thread.Sleep(1000);
            }

            // Wait for all threads to finish processing
            foreach (var thread in threads)
            {
                thread.Join();
            }

            Console.WriteLine($"Primes found: {primes.Count}");
        }

        private static bool IsPrime(uint number)
        {
            if (number < 2) return false;
            uint limit = (uint)Math.Sqrt(number);
            for (uint i = 2; i <= limit; i++)
            {
                if (number % i == 0) return false;
            }
            return true;
        }
    }
}