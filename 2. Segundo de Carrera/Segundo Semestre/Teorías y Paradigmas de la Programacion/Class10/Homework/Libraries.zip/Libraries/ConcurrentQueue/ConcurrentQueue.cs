﻿using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;

namespace ConcurrentQueues
{
	/// <summary>
	/// A thread-safe, generic First-In-First-Out (FIFO) queue implementation.
	/// Uses a linked list as internal storage and ensures safe concurrent access
	/// using a locking mechanism.
	/// </summary>
	/// <typeparam name="T">The type of elements stored in the queue.</typeparam>
	public class ConcurrentQueue<T>
    {
        /// <summary>
		/// Internal storage for queue elements using a linked list.
		/// </summary>
		private Lists.LinkedList<T> data;

		/// <summary>
		/// Lock object used to synchronize access to the queue.
		/// </summary>
		private object locker = new();

		/// <summary>
		/// Initializes a new instance of the ConcurrentQueue class.
		/// </summary>
		public ConcurrentQueue()
		{
			data = new Lists.LinkedList<T>();
		}

		/// <summary>
		/// Gets the number of elements currently in the queue.
		/// Thread-safe read-only property.
		/// </summary>
		public uint NumberOfElements { get { lock (locker) { return data.NumberOfElements; } } } // Read-Only variable

		/// <summary>
		/// Indicates whether the queue is currently empty.
		/// Thread-safe property.
		/// </summary>
		public bool IsEmpty { get { lock (locker) { return data.NumberOfElements == 0; } } }

		/// <summary>
		/// Adds a new element to the end of the queue.
		/// Thread-safe operation.
		/// </summary>
		/// <param name="value">The value to enqueue.</param>
		public void Enqueue(T value)
        {
			lock (locker) { 
                data.Add(value); // Adds to the end of the linkedList
            }
		}

		/// <summary>
		/// Removes and returns the element at the front of the queue.
		/// Thread-safe operation.
		/// </summary>
		/// <returns>The element at the front of the queue.</returns>
		/// <exception cref="ArgumentException">Thrown when the queue is empty.</exception>
		public T Dequeue()
		{
			lock (locker)
			{
				if (data.NumberOfElements == 0)
				{
					throw new ArgumentException("The queue is empty.");
				}
				T result = data.GetElement(0);
				data.RemoveAt(0); // Removes from the start of the linkedList
				return result;
			}
		}

		/// <summary>
		/// Returns the element at the front of the queue without removing it.
		/// Thread-safe operation.
		/// </summary>
		/// <returns>The element at the front of the queue.</returns>
		/// <exception cref="ArgumentException">Thrown when the queue is empty.</exception>
		public T Peek()
		{
			lock (locker)
			{
				if (data.NumberOfElements == 0)
				{
					throw new ArgumentException("The queue is empty.");
				}
				return data.GetElement(0);
			}
		}

	}
}

