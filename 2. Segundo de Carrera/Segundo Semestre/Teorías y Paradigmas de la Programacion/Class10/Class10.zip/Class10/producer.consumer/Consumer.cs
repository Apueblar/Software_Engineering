﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TPP.Laboratory.Concurrency.Lab10
{

    class Consumer {

        private Queue<Product> queue;

        public Consumer(Queue<Product> queue) {
            this.queue = queue;
        }

        public void Run() {
            Random random = new Random();
            while (true) {
                Console.WriteLine("- Dequeuing a product...");
                Product product = null;
                while (HasToSleep())
                {
                    Thread.Sleep(100);
                }
                lock (queue) {
                    if (queue.Count() != 0)
                    {
                        product = queue.Dequeue();
                    }
                }
                if (product != null)
                {
                    Console.WriteLine("- Dequeued {0}.", product);
                    Thread.Sleep(random.Next(300, 700));
                }
            }
        }

        private bool HasToSleep()
        {
            bool result;
            lock (queue)
            {
                result = queue.Count == 0;
            }
            return result;
        }
    }
}
