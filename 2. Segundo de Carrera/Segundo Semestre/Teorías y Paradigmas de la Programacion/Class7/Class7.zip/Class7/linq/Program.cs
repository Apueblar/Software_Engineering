﻿using System.Collections.Generic;
using System;
using System.Linq;

namespace TPP.Laboratory.Functional.Lab07 {

    class Program {

        static void Main() {
            IEnumerable<int> integers = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            var collection = integers.Map(x => x * x).Map(n => { Console.WriteLine(n); return n; });
            collection.Last();

            foreach(var element in integers.Map(x => x * x))
            {
                Console.WriteLine(element);
            }

            Console.WriteLine("New");

            Console.WriteLine("After First");
            var collection2 = collection.Skip(5);
            Console.WriteLine("Is Skip lazy?");
            //Console.WriteLine(collection2.First());
            Console.WriteLine(collection2.ToArray());
            Console.WriteLine(collection2.ToString());
            Console.WriteLine(collection2.ToList());
        }
    }
}
