﻿using System.Linq;
using System.Collections.Generic;
using System;

namespace TPP.Laboratory.Functional.Lab07 {

    static public class Functions {
        /*
        public static IEnumerable<TResult> Map<TElement, TResult>
            (this IEnumerable<TElement> collection, Func<TElement, TResult> function)
        {
            List<TResult> localList = new List<TResult>();
            foreach(var element in collection)
            {
                localList.Add(function(element));
            }
            return localList;
        }*/

        public static IEnumerable<TResult> Map<TElement, TResult>
            (this IEnumerable<TElement> collection, Func<TElement, TResult> function)
        {
            foreach (var element in collection)
            {
                yield return function(element);
            }
        }

    }
}
