using System;
using angle;

namespace TPP.Laboratory.ObjectOrientation.Lab01 {

    /// <summary>
    /// Class that computes the power of a number
    /// </summary>
    class Power {

        static void Main() {
            uint theBase = 2;
            uint exponent = 32;

            ulong result = 1;

            if (theBase == 0) {
                Console.WriteLine("Power: 0.");
                return;
            }

            while (exponent > 0) {
                result *= theBase;
                exponent--;
            }

            Console.WriteLine("Power: {0}.", result);

            Angle a = new Angle(Math.PI);
            Console.WriteLine("My angle instance has {0} as radians", a.Radians);
            Console.WriteLine("My angle instance has {0} as degrees", a.Degrees);

            PersonTO jose = new PersonTO();
            jose.FirstName = "Jose";
            jose.Surname = "Ramirez";

            PersonTO paco = new PersonTO() { FirstName = "Paco", IDNumber = "123456789" ,Surname = "Hoyos" };
            Console.WriteLine(paco);
        }
    }

}

