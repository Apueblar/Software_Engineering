﻿namespace hello.world
{
    /// <summary>
    /// This is my first class in TPP
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// The main method is the entry point of my application
        /// </summary>
        /// <param name="args">This is the array of strings after you invoke the .exe</param>
        static void MainFoo(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Console.WriteLine(args[0]); // Prints the arg 0, the one you specify when running the .exe
            // Comentarios to guapos
            /*Hola Caracola :)*/
        }
    }
}
