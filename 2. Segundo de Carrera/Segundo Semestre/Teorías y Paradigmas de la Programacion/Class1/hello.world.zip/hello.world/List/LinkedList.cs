﻿using System.Diagnostics;

namespace Lists {
	/// <summary>
	/// Implementation of a simple linked list.
	/// Allows adding, removing, and retrieving elements by index.
	/// </summary>
	public class LinkedList {
		/// <summary>
		/// Auxiliary class representing the nodes of the linked list.
		/// Each node contains an integer value and a reference to the next node in the list.
		/// </summary>
		private class LLNode {
			/// <summary>
			/// Value stored in the node.
			/// </summary>
			public int Value { get; set; }

			/// <summary>
			/// Reference to the next node in the list. It can be null if this is the last node.
			/// </summary>
			public LLNode? Next { get; set; }

			/// <summary>
			/// Constructor that initializes the node with a specific value.
			/// </summary>
			/// <param name="value">Integer value assigned to the node.</param>
			public LLNode(int value) {
				Value = value;
				Next = null;
			}
		}

		/// <summary>
		/// Reference to the first node (head) of the list.
		/// If null, the list is empty.
		/// </summary>
		private LLNode? head;

		/// <summary>
		/// Number of elements currently in the list.
		/// </summary>
		public int NumberOfElements { get; private set; }

		/// <summary>
		/// Constructor that initializes an empty linked list.
		/// </summary>
		public LinkedList()	{
			head = null;
			NumberOfElements = 0;
		}

		/// <summary>
		/// Retrieves the LLNode at a specified index.
		/// </summary>
		/// <param name="index">The zero-based index of the element.</param>
		/// <returns>The LLNode at the given index, or null if the index is out of bounds.</returns>
		private LLNode? GetIndex(int index)
		{
			if (index < 0 || index >= NumberOfElements) { return null; }
			Debug.Assert(head != null, "Head should never be null here because index is valid.");

			LLNode current = head;
			for (int i = 0; i < index; i++) {
				Debug.Assert(current.Next != null, "Current.Next should never be null here because index is valid.");
				current = current.Next;
			}
			return current;
		}

		/// <summary>
		/// Adds a new element to the end of the linked list.
		/// </summary>
		/// <param name="value">The integer value to be added.</param>
		public void Add(int value) {
			LLNode newNode = new LLNode(value);
			if (head == null) {
				head = newNode;
			} else {
				LLNode? last = GetIndex(NumberOfElements - 1);
				Debug.Assert(last != null, "The LAST Node must always be != null if the head is not null");
				last.Next = newNode;
			}
			NumberOfElements++;
		}

		/// <summary>
		/// Removes the first occurrence of a value from the linked list.
		/// </summary>
		/// <param name="value">The value to remove.</param>
		/// <returns>True if the value was found and removed, otherwise false.</returns>
		public bool Remove(int value) {
			if (head == null) { return false; }

			if (head.Value == value) {
				head = head.Next;
				NumberOfElements--;
				return true;
			}

			LLNode current = head;
			while (current.Next != null && current.Next.Value != value) {
				current = current.Next;
			}

			if (current.Next == null) { return false; }

			current.Next = current.Next.Next;
			NumberOfElements--;
			return true;
		}

		/// <summary>
		/// Retrieves the value of the node at a specified index.
		/// </summary>
		/// <param name="index">The zero-based index of the element.</param>
		/// <returns>The value at the given index, or null if the index is out of bounds.</returns>
		public int? GetElement(int index) {
			if (index < 0 || index >= NumberOfElements) { return null; }
			Debug.Assert(head != null, "Head should never be null here because index is valid.");

			LLNode current = head;
			for (int i = 0; i < index; i++) {
				Debug.Assert(current.Next != null, "Current.Next should never be null here because index is valid.");
				current = current.Next;
			}
			return current!.Value;
		}
	}
}
