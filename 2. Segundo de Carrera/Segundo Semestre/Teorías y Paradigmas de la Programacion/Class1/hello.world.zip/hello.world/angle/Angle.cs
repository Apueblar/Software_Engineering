﻿namespace angle
{
    public class Angle
    {
        public double Radians {
            get
            {
                return this.value;
            }
            set
            {
                this.value = value;
            }
        }
        public double Degrees
        {
            get
            {
                return this.value/Math.PI * 180;
            }
        }

        private double value;

        public Angle(double v)
        {
            this.value = v;
        }
    }
}
