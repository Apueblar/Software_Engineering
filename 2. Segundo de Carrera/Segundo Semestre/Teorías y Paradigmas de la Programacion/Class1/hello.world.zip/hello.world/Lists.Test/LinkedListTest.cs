﻿namespace Lists.Test
{
	[TestClass]
	public class LinkedListTests
	{
		[TestMethod]
		public void Add_ThreeElements_CountIsThree()
		{
			var list = new LinkedList();
			Assert.AreEqual(0, list.NumberOfElements);
			list.Add(1);
			Assert.AreEqual(1, list.NumberOfElements);
			list.Add(2);
			Assert.AreEqual(2, list.NumberOfElements);
			list.Add(3);
			Assert.AreEqual(3, list.NumberOfElements);
		}

		[TestMethod]
		public void GetElement_ValidIndex_ReturnsValue()
		{
			var list = new LinkedList();
			list.Add(10);
			list.Add(20);
			list.Add(30);
			Assert.AreEqual(10, list.GetElement(0));
			Assert.AreEqual(20, list.GetElement(1));
			Assert.AreEqual(30, list.GetElement(2));
		}
		
		[TestMethod]
		public void GetElement_InvalidIndex_ReturnsNull()
		{
			var list = new LinkedList();
			list.Add(5);
			Assert.IsNull(list.GetElement(-1));
			Assert.IsNull(list.GetElement(1));
		}
		
		[TestMethod]
		public void Remove_ExistingElement_ReturnsTrueAndDecreasesCount()
		{
			var list = new LinkedList();
			list.Add(100);
			list.Add(200);
			bool result = list.Remove(100);
			Assert.IsTrue(result);
			Assert.AreEqual(1, list.NumberOfElements);
			Assert.AreEqual(200, list.GetElement(0));
		}
		
		[TestMethod]
		public void Remove_NonExistingElement_ReturnsFalse()
		{
			var list = new LinkedList();
			list.Add(50);
			bool result = list.Remove(99);
			Assert.IsFalse(result);
			Assert.AreEqual(1, list.NumberOfElements);
		}
		
		[TestMethod]
		public void Remove_FromEmptyList_ReturnsFalse()
		{
			var list = new LinkedList();
			bool result = list.Remove(10);
			Assert.IsFalse(result);
		}
		
		[TestMethod]
		public void Remove_LastElement_ListIsEmpty()
		{
			var list = new LinkedList();
			list.Add(5);
			bool removed = list.Remove(5);
			Assert.IsTrue(removed);
			Assert.AreEqual(0, list.NumberOfElements);
			Assert.IsNull(list.GetElement(0));
		}
		
		[TestMethod]
		public void AddAndRemove_MultipleOperations_CheckConsistency()
		{
			var list = new LinkedList();
			list.Add(1);
			list.Add(2);
			list.Remove(1);
			list.Add(3);
			Assert.AreEqual(2, list.NumberOfElements);
			Assert.AreEqual(2, list.GetElement(0));
			Assert.AreEqual(3, list.GetElement(1));
		}

		[TestMethod]
		public void Remove_MiddleElement_UpdatesListCorrectly()
		{
			var list = new LinkedList();
			list.Add(10);
			list.Add(20);
			list.Add(30);

			bool removed = list.Remove(20);

			Assert.IsTrue(removed);
			Assert.AreEqual(2, list.NumberOfElements);
			Assert.AreEqual(10, list.GetElement(0));
			Assert.AreEqual(30, list.GetElement(1));
		}

		[TestMethod]
		public void Remove_DuplicateValues_RemovesFirstOccurrence()
		{
			var list = new LinkedList();
			list.Add(5);
			list.Add(5);
			list.Add(5);

			bool removed = list.Remove(5);

			Assert.IsTrue(removed);
			Assert.AreEqual(2, list.NumberOfElements);
			Assert.AreEqual(5, list.GetElement(0));
			Assert.AreEqual(5, list.GetElement(1));
		}

		[TestMethod]
		public void MultipleAddRemoveOperations_KeepConsistentState()
		{
			var list = new LinkedList();
			list.Add(1);
			list.Add(2);
			list.Remove(1);
			list.Add(3);
			list.Add(4);
			list.Remove(3);
			list.Add(5);
			Assert.AreEqual(3, list.NumberOfElements);
			Assert.AreEqual(2, list.GetElement(0));
			Assert.AreEqual(4, list.GetElement(1));
			Assert.AreEqual(5, list.GetElement(2));
		}

		[TestMethod]
		public void LargeNumberOfElements_HandlesCorrectly()
		{
			var list = new LinkedList();
			const int count = 1000;

			for (int i = 0; i < count; i++) {
				list.Add(i);
			}
			Assert.AreEqual(count, list.NumberOfElements);

			for (int i = 0; i < count; i += 2) {
				list.Remove(i);
			}
			Assert.AreEqual(count / 2, list.NumberOfElements);

			Assert.AreEqual(1, list.GetElement(0));
			Assert.AreEqual(999, list.GetElement(list.NumberOfElements - 1));
		}

		[TestMethod]
		public void Remove_AllElements_LeavesEmptyList()
		{
			var list = new LinkedList();
			list.Add(1);
			list.Add(2);
			list.Add(3);

			list.Remove(1);
			list.Remove(2);
			list.Remove(3);

			Assert.AreEqual(0, list.NumberOfElements);
			Assert.IsNull(list.GetElement(0));
		}

		[TestMethod]
		public void GetElement_AfterMultipleRemovals_ReturnsCorrectValues()
		{
			var list = new LinkedList();
			list.Add(1);
			list.Add(2);
			list.Add(3);
			list.Add(4);
			list.Add(5);

			list.Remove(2);
			list.Remove(4);

			Assert.AreEqual(3, list.NumberOfElements);
			Assert.AreEqual(1, list.GetElement(0));
			Assert.AreEqual(3, list.GetElement(1));
			Assert.AreEqual(5, list.GetElement(2));
		}

		[TestMethod]
		public void Remove_ConsecutiveElements_UpdatesLinksCorrectly()
		{
			var list = new LinkedList();
			list.Add(1);
			list.Add(2);
			list.Add(3);

			list.Remove(1);
			list.Remove(2);

			Assert.AreEqual(1, list.NumberOfElements);
			Assert.AreEqual(3, list.GetElement(0));
		}

		[TestMethod]
		public void Add_AfterFullRemoval_WorksProperly()
		{
			var list = new LinkedList();
			list.Add(5);
			list.Remove(5);
			list.Add(10);
			list.Add(20);

			Assert.AreEqual(2, list.NumberOfElements);
			Assert.AreEqual(10, list.GetElement(0));
			Assert.AreEqual(20, list.GetElement(1));
		}
	}
}