package db.jdbc1;
import java.sql.*;
import java.util.Scanner;

public class Program {
	
	private static String USERNAME = "uo299874";
	private static String PASSWORD = /*Mi Contraseña :) ---------------------------------------------------------------------------------------------------------------------------------------------------------------------*/"";
	private static String CONNECTION_STRING = "jdbc:oracle:thin:@156.35.94.98:1521:desa19"; // "Protocol:Vendor:Driver:Server:Port:DB name"
	
	private static Connection con;

	private static Connection getConnection() throws SQLException{
		if(DriverManager.getDriver(CONNECTION_STRING) == null)
				DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		return  DriverManager.getConnection(CONNECTION_STRING,USERNAME,PASSWORD);
	}
	
	
	public static void main(String[] args) {
		/*
		//Examples to read by keyboard
		System.out.println("Read an integer by keyboard");	
		int integ = ReadInt();
		System.out.println("Read a string by keyboard");	
		String str = ReadString();
		*/
		try {
			con = getConnection();
			/*
			exercise1_1();
			exercise1_2();
		
			exercise2();
		
			exercise3();
			
			exercise4();
			
			exercise5_1();
			exercise5_2();
			exercise5_3();
			
			exercise6_1();
			exercise6_2();
			
			exercise7_1();
			exercise7_2();
			
			exercise8();
			*/
			exam();
		
			con.close();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

    /*
        1. Develop a Java method that shows the results of queries 19 and 31 from lab session SQL2.
        1.1. (19) Name and surname of customers that have bought a car in a 'madrid' dealer that has 'gti' cars.
    */
	public static void exercise1_1() throws SQLException {
		System.out.println("############# Exercise 1_1: #############");
		/* --19. Name and surname of customers that have bought a car in a 'madrid' dealer that has 'gti' cars.
			SELECT name, surname
			FROM customers
			WHERE dni IN (SELECT DISTINCT S.dni
			    FROM sales S, cars C, dealers DE, distribution DI
			    WHERE S.cifd=DE.cifd AND DE.cityd='madrid' AND DE.cifd=DI.cifd
			            AND DI.codecar=C.codecar AND C.model='gti');
			
			SELECT name, surname
			FROM customers
			WHERE dni IN (SELECT DISTINCT S.dni
			    FROM sales S INNER JOIN dealers DE ON S.cifd=DE.cifd
			        INNER JOIN distribution DI ON DE.cifd=DI.cifd
			        INNER JOIN cars C ON C.codecar=DI.codecar
			    WHERE DE.cityd='madrid' AND C.model='gti');
		 */
		String sentence = "SELECT name, surname\r\n"
				+ "			FROM customers\r\n"
				+ "			WHERE dni IN (SELECT DISTINCT S.dni\r\n"
				+ "			    FROM sales S INNER JOIN dealers DE ON S.cifd=DE.cifd\r\n"
				+ "			        INNER JOIN distribution DI ON DE.cifd=DI.cifd\r\n"
				+ "			        INNER JOIN cars C ON C.codecar=DI.codecar\r\n"
				+ "			    WHERE DE.cityd='madrid' AND C.model='gti')";
		
		Statement st = con.createStatement();
		
		ResultSet rs = st.executeQuery(sentence);
		while (rs.next()){
			
			String name = rs.getString("name");
			String surname = rs.getString("surname");
			
			System.out.println(String.format("Name: %s, Surname: %s",name, surname));
		}
		
		st.close();
	}
	
    /*
        1.2. (31) Dealers having an average stockage greater than the average stockage of all dealers together.
    */
	public static void exercise1_2() throws SQLException {
		System.out.println("############# Exercise 1_2: #############");
		/* --31. Dealer having the best average stockage of all dealers; that is, dealer having an average stockage greater than the average stockage of each one of the remaining dealers.
			SELECT de.cifd, named, cityd
			FROM dealers de, distribution di
			WHERE de.cifd=di.cifd
			GROUP BY de.cifd, named, cityd
			HAVING AVG(stockage)>= ALL(SELECT AVG(stockage) FROM distribution GROUP BY cifd);
			
			SELECT de.cifd, named, cityd
			FROM dealers de INNER JOIN distribution di ON de.cifd=di.cifd
			GROUP BY de.cifd, named, cityd
			HAVING AVG(stockage) >= ALL (SELECT AVG(stockage) FROM distribution GROUP BY cifd);
			
			SELECT de.cifd, named, cityd
			FROM dealers de, distribution di
			WHERE de.cifd=di.cifd
			GROUP BY de.cifd, named, cityd
			HAVING AVG(stockage)>= (SELECT MAX(media) FROM (SELECT AVG(stockage) media FROM distribution GROUP BY cifd))
			
			SELECT de.cifd, named, cityd
			FROM dealers de, distribution di
			WHERE de.cifd=di.cifd
			GROUP BY de.cifd, named, cityd
			ORDER BY AVG(stockage) DESC
			FETCH FIRST 1 ROW ONLY
		 */
		
		String sentence = "SELECT de.cifd, named, cityd\r\n"
				+ "			FROM dealers de, distribution di\r\n"
				+ "			WHERE de.cifd=di.cifd\r\n"
				+ "			GROUP BY de.cifd, named, cityd\r\n"
				+ "			ORDER BY AVG(stockage) DESC\r\n"
				+ "			FETCH FIRST 1 ROW ONLY";
		
		Statement st = con.createStatement();
		
		ResultSet rs = st.executeQuery(sentence);
		while (rs.next()){
			
			int cifd = rs.getInt("cifd");
			String named = rs.getString("named");
			String cityd = rs.getString("cityd");
			
			System.out.println(String.format("Cifd: %d, Named: %s, Cityd: %s",cifd, named, cityd));
		}
		
		st.close();
	}
	
    /*
        2. Develop a Java method that shows the results of query 6 from lab session SQL2, so that the search color is inputted by the user.
            (6) Names of car makers that have sold cars with a color that is inputted by the user.
    */
	public static void exercise2() throws SQLException {
		System.out.println("############# Exercise 2: #############");
		/* --6. Names of car makers that have sold red cars.
		 	SELECT DISTINCT M.namecm
			FROM carmakers M, cmcars CM, sales S
			WHERE M.cifcm=CM.cifcm AND CM.codecar=S.codecar AND S.color='red';
		*/
		String sentence = "SELECT DISTINCT M.namecm\r\n"
				+ "			FROM carmakers M, cmcars CM, sales S\r\n"
				+ "			WHERE M.cifcm=CM.cifcm AND CM.codecar=S.codecar AND S.color= ?";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a color: ");
		String color = ReadString();
		
		psQuery.setString(1,color);
		
		ResultSet rs = psQuery.executeQuery();
		while (rs.next()){
			
			String namecm = rs.getString("namecm");
			
			System.out.println(String.format("Namecm: %s", namecm));
		}
		
		psQuery.close();
	}
	
    /*
        3. Develop a Java method to run query 25 from lab session SQL2, so that the limits for the number of cars are inputted by the user.
            (25) CIFD of dealers with a stock between two values inputted by the user inclusive.
    */
	public static void exercise3() throws SQLException {
		System.out.println("############# Exercise 3: #############");
		/* --25. CIFD of dealers with a stock between 10 and 18 units inclusive.
			SELECT cifd, sum(stockage) AS total_stockage
				FROM distribution
				GROUP BY cifd
				HAVING sum(stockage)>=10 AND sum(stockage)<=18;
				
				SELECT cifd, sum(stockage) AS total_stockage
				FROM distribution
				GROUP BY cifd
				HAVING sum(stockage) BETWEEN 10 AND 18;
		*/
		String sentence = "SELECT cifd, sum(stockage) AS total_stockage"
				+ "			FROM distribution"
				+ "			GROUP BY cifd"
				+ "			HAVING sum(stockage)>=? AND sum(stockage)<=?";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a quantity (low): ");
		int number = ReadInt();
		
		psQuery.setInt(1,number);
		
		System.out.print("Please, enter a quantity (high): ");
		number = ReadInt();
		
		psQuery.setInt(2,number);
		
		ResultSet rs = psQuery.executeQuery();
		while (rs.next()){
			
			String CIFD = rs.getString("cifd");
			
			System.out.println(String.format("Cifd: %s", CIFD));
		}
		
		psQuery.close();
	}
	
    /*
        4. Develop a Java method to run query 22 from lab session SQL2, so that the city of the dealer and the color are inputted by the user.
            (22) Names of the customers that have NOT bought cars with a user-defined color at dealers located in a user-defined city.
    */
	public static void exercise4() throws SQLException {
		System.out.println("############# Exercise 4: #############");
		/* --22. Names of the customers that have NOT bought 'red' cars at 'madrid' dealers.
			SELECT DISTINCT C.name
				FROM customers C INNER JOIN sales S ON S.dni=C.dni
				WHERE C.dni NOT IN (SELECT S.dni
				    FROM dealers D INNER JOIN sales S ON D.cifd=S.cifd
				    WHERE D.cityd='madrid' AND S.color='red');
		*/
		String sentence = "SELECT DISTINCT C.name"
				+ "			FROM customers C INNER JOIN sales S ON S.dni=C.dni"
				+ "			WHERE C.dni NOT IN (SELECT S.dni"
				+ "			    FROM dealers D INNER JOIN sales S ON D.cifd=S.cifd"
				+ "			    WHERE D.cityd=? AND S.color=?)";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a city: ");
		String city = ReadString();
		
		psQuery.setString(1,city);
		
		System.out.print("Please, enter a color: ");
		String color = ReadString();
		
		psQuery.setString(2,color);
		
		ResultSet rs = psQuery.executeQuery();
		while (rs.next()){
			
			String name = rs.getString("name");
			
			System.out.println(String.format("name: %s", name));
		}
		
		psQuery.close();
	}
	
    /*
        5. Develop a Java method that, using the suitable SQL sentence:
        5.1 Creates cars into the CARS table, taking the data from the user.
    */
	public static void exercise5_1() throws SQLException {
		System.out.println("############# Exercise 5_1: #############");
		/*-- 5.1 Creates cars into the CARS table, taking the data from the user.
			INSERT INTO cars (namec, model, codecar) VALUES (?, ?, ?);
		 */
		String sentence = "INSERT INTO cars (namec, model, codecar) VALUES (?, ?, ?)";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a namec: ");
		String namec = ReadString();
		
		psQuery.setString(1,namec);
		
		System.out.print("Please, enter a model: ");
		String model = ReadString();
		
		psQuery.setString(2,model);
		
		System.out.print("Please, enter a codecar: ");
		int codecar = ReadInt();
		
		psQuery.setInt(3,codecar);
		
		if (psQuery.executeUpdate() == 1) {
			System.out.println(String.format("Data succesfully introduced"));
		} else {
			System.out.println(String.format("Some error has ocurred"));
		}
		
		psQuery.close();
	}
	
    /*
        5.2. Deletes a specific car. The code for the car to delete is defined by the user.
    */
	public static void exercise5_2() throws SQLException {
		System.out.println("############# Exercise 5_2: #############");
		/*-- 5.2. Deletes a specific car. The code for the car to delete is defined by the user.
			DELETE FROM cars WHERE codecar = ?;
		 */
		String sentence = "DELETE FROM cars WHERE codecar = ?";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a codecar: ");
		int codecar = ReadInt();
		
		psQuery.setInt(1,codecar);
		
		if (psQuery.executeUpdate() == 1) {
			System.out.println(String.format("Data succesfully deleted"));
		} else {
			System.out.println(String.format("Some error has ocurred"));
		}
		
		psQuery.close();
	}
	
    /*
        5.3. Updates the name and model for a specific car. The code for the car to update is defined by the user
    */
	public static void exercise5_3() throws SQLException {		
		System.out.println("############# Exercise 5_3: #############");
		/*-- 5.3. Updates the name and model for a specific car. The code for the car to update is defined by the user
			UPDATE cars
				SET model = ?, namec = ?
				WHERE codecar = ?;
		 */
		
		String sentence = "UPDATE cars"
				+ "				SET model = ?, namec = ?"
				+ "				WHERE codecar = ?";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter the new model: ");
		String model = ReadString();
		
		psQuery.setString(1,model);
		
		System.out.print("Please, enter the new namec: ");
		String namec = ReadString();
		
		psQuery.setString(2,namec);
		
		System.out.print("Please, enter the updating codecar: ");
		int codecar = ReadInt();
		
		psQuery.setInt(3,codecar);
		
		if (psQuery.executeUpdate() == 1) {
			System.out.println(String.format("Data succesfully updated"));
		} else {
			System.out.println(String.format("Some error has ocurred"));
		}
		
		psQuery.close();
	}
	
    /*
        6. Invoke the exercise 10 function and procedure from lab session PL1 from a Java application.
            (10) Develop a procedure and a function that take a dealer id and return the number of sales that were made in that dealer.
        6.1. Function
    */
	public static void exercise6_1() throws SQLException {		
		System.out.println("############# Exercise 6_1: #############");
		
		CallableStatement cs = con.prepareCall ("{? = call FUNCTION10 (?)}");
		
		cs.registerOutParameter(1,java.sql.Types.INTEGER);
		
		System.out.print("Please, enter a dealerID: ");
		int dealerID = ReadInt();
		
		cs.setInt(2,dealerID);
		
		cs.execute();
		
		int sales = cs.getInt(1);
		System.out.println("Sales made: " + sales);
		
		cs.close();
	}
	
    /*
        6.2. Procedure
    */
	public static void exercise6_2() throws SQLException {		
		System.out.println("############# Exercise 6_2: #############");
		
		CallableStatement cs = con.prepareCall ("{call PROCEDURE10 (?, ?)}");
		
		cs.registerOutParameter(2,java.sql.Types.INTEGER);
		
		System.out.print("Please, enter a dealerID: ");
		int dealerID = ReadInt();
		
		cs.setInt(1,dealerID);
		
		cs.execute();
		
		int sales = cs.getInt(2);
		System.out.println("Sales made: " + sales);
		
		cs.close();
	}
	
    /*
        7. Invoke the exercise 11 function and procedure from lab session PL1 from a Java application.
            (11) Develop a PL/SQL function and a procedure that take a dni that is passed as a parameter and returns 2 values: 
                a) the  number of cars that customer has purchased and b) the number of dealers in which he has purchased them.
        7.1. Function
    */
	public static void exercise7_1() throws SQLException {		
		System.out.println("############# Exercise 7_1: #############");
        
		StringBuilder query = new StringBuilder();
		query.append("{? = call FUNCTION11(?,?)}");

        System.out.println("Please, enter dni: ");
        String dni = ReadString();
        
		CallableStatement cst = con.prepareCall(query.toString());
		cst.registerOutParameter(1,Types.INTEGER);
		cst.registerOutParameter(3,Types.INTEGER);
		cst.setString(2, dni);
        
		cst.executeQuery();
		System.out.println("Customer: " +dni+ " number of cars: "+cst.getInt(1)+" number of dealers: "+cst.getInt(3) );
		cst.close();
	}	
	
    /*
        7.2. Procedure
    */
	public static void exercise7_2() throws SQLException {		
		System.out.println("############# Exercise 7_2: #############");
		StringBuilder query = new StringBuilder();
		query.append("{call PROCEDURE11(?,?,?)}");

        System.out.println("Please, enter dni: ");
        String dni = ReadString();
        
		CallableStatement cst = con.prepareCall(query.toString());
		cst.setString(1, dni);
		cst.registerOutParameter(2,Types.INTEGER);
		cst.registerOutParameter(3,Types.INTEGER);
        
		
		cst.execute();		
		System.out.println("Customer: " +dni+ " number of cars: "+cst.getInt(2)+" number of dealers: "+cst.getInt(3) );
		
        cst.close();
	}
	
    /*
        8. Develop a Java method that displays the cars that have been bought by each customer. Besides, it must display the number of cars that each customer has bought and the number of dealers where each customer has bought. Customers that have bought no cars should not be shown in the report.
    */
	public static void exercise8() throws SQLException {
		System.out.println("############# Exercise 8: #############");
		/*create or replace PROCEDURE procedure12_ListCarsByCustomer AS
		CURSOR customers IS
		    SELECT DISTINCT dni, name, surname
		        FROM sales s INNER JOIN customers cu USING (dni)
		        ORDER BY name;
		v_ncars NUMBER;
		v_ndealers NUMBER;
		CURSOR cars_by_customer(p_dni IN sales.dni%TYPE) IS
		    SELECT codecar, namec, model, color
		        FROM sales s INNER JOIN cars c USING (codecar)
		        WHERE s.dni = p_dni
		        ORDER BY codecar;
		BEGIN
		    FOR current_customer IN customers LOOP
		        SELECT count(*) ncars, count(distinct cifd) ndealers INTO v_ncars,v_ndealers
		            FROM sales
		            WHERE dni = current_customer.dni;
		        DBMS_OUTPUT.PUT_LINE('- Customer: '||current_customer.name||' '||current_customer.surname||' '||v_ncars||' ' || v_ndealers);
		
		        FOR car IN cars_by_customer(current_customer.dni) LOOP
		            DBMS_OUTPUT.PUT_LINE('---> Car: '||car.codecar ||' '||car.namec||' '||car.model||' ' || car.color);
		        END LOOP;
		
		    END LOOP;
		END procedure12_ListCarsByCustomer;
		 */
		
		String cursor1String = "SELECT DISTINCT dni, name, surname"
				+ "		        FROM sales s INNER JOIN customers cu USING (dni)"
				+ "		        ORDER BY name";
		
		PreparedStatement cursor1= con.prepareStatement(cursor1String);
		
		String cursor2String = "SELECT codecar, namec, model, color"
				+ "		        FROM sales s INNER JOIN cars c USING (codecar)"
				+ "		        WHERE s.dni = ?"
				+ "		        ORDER BY codecar";
		
		PreparedStatement cursor2= con.prepareStatement(cursor2String);
		
		String query3String = "SELECT count(*) ncars, count(distinct cifd) ndealers"
				+ "        FROM sales"
				+ "        WHERE dni = ?";
		
		PreparedStatement preparedStatement3= con.prepareStatement(query3String);
		
		
		ResultSet cursor1RS = cursor1.executeQuery();
		while (cursor1RS.next()){
			String name = cursor1RS.getString("name");
			String surname = cursor1RS.getString("surname");
			
			preparedStatement3.setString(1,cursor1RS.getString("dni"));
			ResultSet ResultSet3 = preparedStatement3.executeQuery();
			
			ResultSet3.next(); // To reach the first
			int v_ncars = ResultSet3.getInt("ncars");
			int v_ndealers = ResultSet3.getInt("ndealers");
			System.out.println("- Customer: " + name + " " + surname + " " + v_ncars + " " + v_ndealers);
			
			cursor2.setString(1,cursor1RS.getString("dni"));
			ResultSet cursor2RS = cursor2.executeQuery();
			while (cursor2RS.next()){
				int codecar = cursor2RS.getInt("codecar");
				String namec = cursor2RS.getString("namec");
				String model = cursor2RS.getString("model");
				String color = cursor2RS.getString("color");
				System.out.println("---> Car: " + codecar + " " + namec + " " + model + " " + color);
			}
		}
	}
		
	/*
    Create a procedure that shows, for those instructors participating (participates) in projects: their
	instructor_id, instructor_name, number of projects they participate in (num_projects) and the total amount of money
	they receive for their participation (total_extra_payment). Consider only those projects with a duration
	(pr_duration) higher than 1 year and instructors not supervising (advises) students. Results must be
	printed in descending order, first, by instructor name (instructor_name) and, second, by number of projects.
	In addition, for each of those instructors, the sections (course_id, sec_id, semester, year) they teach (teaches) must be
	shown. The listing will only include sections belonging to courses that are prerequisite of other courses.
	The course title (title) and the name (dept_name) and building (dept_building) of the department responsible for that
	course will be shown as well. Results must be printed in descending order by course_id. The preceding information
	will be arranged this way:
	INSTRUCTOR: instructor_id / instructor_name / num_projects / total_extra_payment
	--SECTION: dept_name – dept_building - course_id - title – sec_id – semester - year
	--SECTION: dept_name – dept_building - course_id - title – sec_id – semester - year
	………
	INSTRUCTOR: instructor_id / instructor_name / num_projects / total_extra_payment
	--SECTION: dept_name – dept_building - course_id - title – sec_id – semester - year
	--SECTION: dept_name – dept_building - course_id - title – sec_id – semester - year    
    */
	public static void exam() throws SQLException {
		System.out.println("############# EXAM: #############");
		/*
		CURSOR1 =
			SELECT instructor_id, instructor_name, COUNT(*) num_projects, SUM(participates.extra_payment) total_extra_payment
			    FROM participates 
			    	INNER JOIN project USING (project_id)
			        INNER JOIN instructor USING (instructor_id)
			    WHERE 1=1
			        AND pr_duration > 1
			        AND instructor_id NOT IN (SELECT instructor_id FROM student)
			    GROUP BY instructor_id, instructor_name
			    ORDER BY instructor_name DESC, num_projects DESC;
		CURSOR2 =
		SELECT d.dept_name, d.dept_building, t.course_id, c.title, t.sec_id, t.semester, t.year
            FROM TEACHES t 
                INNER JOIN COURSE c ON c.COURSE_ID = t.COURSE_ID
                INNER JOIN DEPARTMENT d ON c.DEPT_NAME = d.DEPT_NAME
            WHERE t.INSTRUCTOR_ID = ? (INSTRUCTOR_ID)
                AND c.course_id IN (SELECT PREREQ_ID FROM is_prerequisite)
            ORDER BY c.course_id DESC;
        
        
        FOR i IN c1 LOOP
	        DBMS_OUTPUT.PUT_LINE('INSTRUCTOR: ' || i.instructor_id || ' / ' || i.instructor_name || ' / ' || i.num_projects || ' / ' || i.total_extra_payment);
	        FOR j IN c2 (i.instructor_id) LOOP
	            DBMS_OUTPUT.PUT_LINE('--SECTION: ' || j.dept_name || ' - ' || j.dept_building || ' - ' || j.course_id || ' - ' || j.title || ' - ' || j.sec_id || ' - ' || j.semester|| ' - ' || j.year);
	        END LOOP; 
	    END LOOP;
		 */
		
		String cursor1String = "SELECT instructor_id, instructor_name, COUNT(*) num_projects, SUM(participates.extra_payment) total_extra_payment"
				+ "			    FROM participates"
				+ "			    	INNER JOIN project USING (project_id)"
				+ "			        INNER JOIN instructor USING (instructor_id)"
				+ "			    WHERE 1=1"
				+ "			        AND pr_duration > 1"
				+ "			        AND instructor_id NOT IN (SELECT instructor_id FROM student)"
				+ "			    GROUP BY instructor_id, instructor_name"
				+ "			    ORDER BY instructor_name DESC, num_projects DESC";
		
		PreparedStatement cursor1= con.prepareStatement(cursor1String);
		
		String cursor2String = "SELECT d.dept_name, d.dept_building, t.course_id, c.title, t.sec_id, t.semester, t.year"
				+ "            FROM TEACHES t"
				+ "                INNER JOIN COURSE c ON c.COURSE_ID = t.COURSE_ID"
				+ "                INNER JOIN DEPARTMENT d ON c.DEPT_NAME = d.DEPT_NAME"
				+ "            WHERE 1=1"
				+ "				   AND t.INSTRUCTOR_ID = ?"
				+ "                AND c.course_id IN (SELECT PREREQ_ID FROM is_prerequisite)"
				+ "            ORDER BY c.course_id DESC";
		
		PreparedStatement cursor2= con.prepareStatement(cursor2String);
		
		
		ResultSet cursor1RS = cursor1.executeQuery();
		while (cursor1RS.next()){
			System.out.println("INSTRUCTOR: " + cursor1RS.getInt("instructor_id") + " / " + cursor1RS.getString("instructor_name") + " / " + cursor1RS.getInt("num_projects") + " / " + cursor1RS.getInt("total_extra_payment"));
			
			cursor2.setInt(1,cursor1RS.getInt("instructor_id"));
			ResultSet cursor2RS = cursor2.executeQuery();
			while (cursor2RS.next()){
				System.out.println("--SECTION: " + cursor2RS.getString("dept_name") + " - " + cursor2RS.getString("dept_building") + " - " + cursor2RS.getInt("course_id") + " - " + cursor2RS.getString("title") + " - " + cursor2RS.getInt("sec_id") + " - " + cursor2RS.getString("semester") + " - " + cursor2RS.getInt("year"));
			}
		}
	}
		
	@SuppressWarnings("resource")
	private static String ReadString(){
		return new Scanner(System.in).nextLine();		
	}
	
	@SuppressWarnings("resource")
	private static int ReadInt(){
		return new Scanner(System.in).nextInt();			
	}	
}




















