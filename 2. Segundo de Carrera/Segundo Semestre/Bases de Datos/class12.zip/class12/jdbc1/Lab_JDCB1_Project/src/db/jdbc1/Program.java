package db.jdbc1;
import java.sql.*;
import java.util.Scanner;

public class Program {
	
	private static String USERNAME = "uo299874";
	private static String PASSWORD = /*Mi Contraseña :) ---------------------------------------------------------------------------------------------------------------------------------------------------------------------*/"";
	private static String CONNECTION_STRING = "jdbc:oracle:thin:@156.35.94.98:1521:desa19"; // "Protocol:Vendor:Driver:Server:Port:DB name"
	
	private static Connection con;

	private static Connection getConnection() throws SQLException{
		if(DriverManager.getDriver(CONNECTION_STRING) == null)
				DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		return  DriverManager.getConnection(CONNECTION_STRING,USERNAME,PASSWORD);
	}
	
	
	public static void main(String[] args) {
		/*
		//Examples to read by keyboard
		System.out.println("Read an integer by keyboard");	
		int integ = ReadInt();
		System.out.println("Read a string by keyboard");	
		String str = ReadString();
		*/
		try {
			con = getConnection();
			/*
			exercise1_1();
			exercise1_2();
		
			exercise2();
		
			exercise3();
			
			exercise4();
			
			exercise5_1();
			exercise5_2();
			exercise5_3();
			*/
			exercise6_1();
			exercise6_2();
			
			exercise7_1();
			exercise7_2();
		
			exercise8();
		
			con.close();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

    /*
        1. Develop a Java method that shows the results of queries 19 and 31 from lab session SQL2.
        1.1. (19) Name and surname of customers that have bought a car in a 'madrid' dealer that has 'gti' cars.
    */
	public static void exercise1_1() throws SQLException {
		System.out.println("############# Exercise 1_1: #############");
		/* --19. Name and surname of customers that have bought a car in a 'madrid' dealer that has 'gti' cars.
			SELECT name, surname
			FROM customers
			WHERE dni IN (SELECT DISTINCT S.dni
			    FROM sales S, cars C, dealers DE, distribution DI
			    WHERE S.cifd=DE.cifd AND DE.cityd='madrid' AND DE.cifd=DI.cifd
			            AND DI.codecar=C.codecar AND C.model='gti');
			
			SELECT name, surname
			FROM customers
			WHERE dni IN (SELECT DISTINCT S.dni
			    FROM sales S INNER JOIN dealers DE ON S.cifd=DE.cifd
			        INNER JOIN distribution DI ON DE.cifd=DI.cifd
			        INNER JOIN cars C ON C.codecar=DI.codecar
			    WHERE DE.cityd='madrid' AND C.model='gti');
		 */
		String sentence = "SELECT name, surname\r\n"
				+ "			FROM customers\r\n"
				+ "			WHERE dni IN (SELECT DISTINCT S.dni\r\n"
				+ "			    FROM sales S INNER JOIN dealers DE ON S.cifd=DE.cifd\r\n"
				+ "			        INNER JOIN distribution DI ON DE.cifd=DI.cifd\r\n"
				+ "			        INNER JOIN cars C ON C.codecar=DI.codecar\r\n"
				+ "			    WHERE DE.cityd='madrid' AND C.model='gti')";
		
		Statement st = con.createStatement();
		
		ResultSet rs = st.executeQuery(sentence);
		while (rs.next()){
			
			String name = rs.getString("name");
			String surname = rs.getString("surname");
			
			System.out.println(String.format("Name: %s, Surname: %s",name, surname));
		}
		
		st.close();
	}
	
    /*
        1.2. (31) Dealers having an average stockage greater than the average stockage of all dealers together.
    */
	public static void exercise1_2() throws SQLException {
		System.out.println("############# Exercise 1_2: #############");
		/* --31. Dealer having the best average stockage of all dealers; that is, dealer having an average stockage greater than the average stockage of each one of the remaining dealers.
			SELECT de.cifd, named, cityd
			FROM dealers de, distribution di
			WHERE de.cifd=di.cifd
			GROUP BY de.cifd, named, cityd
			HAVING AVG(stockage)>= ALL(SELECT AVG(stockage) FROM distribution GROUP BY cifd);
			
			SELECT de.cifd, named, cityd
			FROM dealers de INNER JOIN distribution di ON de.cifd=di.cifd
			GROUP BY de.cifd, named, cityd
			HAVING AVG(stockage) >= ALL (SELECT AVG(stockage) FROM distribution GROUP BY cifd);
			
			SELECT de.cifd, named, cityd
			FROM dealers de, distribution di
			WHERE de.cifd=di.cifd
			GROUP BY de.cifd, named, cityd
			HAVING AVG(stockage)>= (SELECT MAX(media) FROM (SELECT AVG(stockage) media FROM distribution GROUP BY cifd))
			
			SELECT de.cifd, named, cityd
			FROM dealers de, distribution di
			WHERE de.cifd=di.cifd
			GROUP BY de.cifd, named, cityd
			ORDER BY AVG(stockage) DESC
			FETCH FIRST 1 ROW ONLY
		 */
		
		String sentence = "SELECT de.cifd, named, cityd\r\n"
				+ "			FROM dealers de, distribution di\r\n"
				+ "			WHERE de.cifd=di.cifd\r\n"
				+ "			GROUP BY de.cifd, named, cityd\r\n"
				+ "			ORDER BY AVG(stockage) DESC\r\n"
				+ "			FETCH FIRST 1 ROW ONLY";
		
		Statement st = con.createStatement();
		
		ResultSet rs = st.executeQuery(sentence);
		while (rs.next()){
			
			int cifd = rs.getInt("cifd");
			String named = rs.getString("named");
			String cityd = rs.getString("cityd");
			
			System.out.println(String.format("Cifd: %d, Named: %s, Cityd: %s",cifd, named, cityd));
		}
		
		st.close();
	}
	
    /*
        2. Develop a Java method that shows the results of query 6 from lab session SQL2, so that the search color is inputted by the user.
            (6) Names of car makers that have sold cars with a color that is inputted by the user.
    */
	public static void exercise2() throws SQLException {
		System.out.println("############# Exercise 2: #############");
		/* --6. Names of car makers that have sold red cars.
		 	SELECT DISTINCT M.namecm
			FROM carmakers M, cmcars CM, sales S
			WHERE M.cifcm=CM.cifcm AND CM.codecar=S.codecar AND S.color='red';
		*/
		String sentence = "SELECT DISTINCT M.namecm\r\n"
				+ "			FROM carmakers M, cmcars CM, sales S\r\n"
				+ "			WHERE M.cifcm=CM.cifcm AND CM.codecar=S.codecar AND S.color= ?";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a color: ");
		String color = ReadString();
		
		psQuery.setString(1,color);
		
		ResultSet rs = psQuery.executeQuery();
		while (rs.next()){
			
			String namecm = rs.getString("namecm");
			
			System.out.println(String.format("Namecm: %s", namecm));
		}
		
		psQuery.close();
	}
	
    /*
        3. Develop a Java method to run query 25 from lab session SQL2, so that the limits for the number of cars are inputted by the user.
            (25) CIFD of dealers with a stock between two values inputted by the user inclusive.
    */
	public static void exercise3() throws SQLException {
		System.out.println("############# Exercise 3: #############");
		/* --25. CIFD of dealers with a stock between 10 and 18 units inclusive.
			SELECT cifd, sum(stockage) AS total_stockage
				FROM distribution
				GROUP BY cifd
				HAVING sum(stockage)>=10 AND sum(stockage)<=18;
				
				SELECT cifd, sum(stockage) AS total_stockage
				FROM distribution
				GROUP BY cifd
				HAVING sum(stockage) BETWEEN 10 AND 18;
		*/
		String sentence = "SELECT cifd, sum(stockage) AS total_stockage"
				+ "			FROM distribution"
				+ "			GROUP BY cifd"
				+ "			HAVING sum(stockage)>=? AND sum(stockage)<=?";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a quantity (low): ");
		int number = ReadInt();
		
		psQuery.setInt(1,number);
		
		System.out.print("Please, enter a quantity (high): ");
		number = ReadInt();
		
		psQuery.setInt(2,number);
		
		ResultSet rs = psQuery.executeQuery();
		while (rs.next()){
			
			String CIFD = rs.getString("cifd");
			
			System.out.println(String.format("Cifd: %s", CIFD));
		}
		
		psQuery.close();
	}
	
    /*
        4. Develop a Java method to run query 22 from lab session SQL2, so that the city of the dealer and the color are inputted by the user.
            (22) Names of the customers that have NOT bought cars with a user-defined color at dealers located in a user-defined city.
    */
	public static void exercise4() throws SQLException {
		System.out.println("############# Exercise 4: #############");
		/* --22. Names of the customers that have NOT bought 'red' cars at 'madrid' dealers.
			SELECT DISTINCT C.name
				FROM customers C INNER JOIN sales S ON S.dni=C.dni
				WHERE C.dni NOT IN (SELECT S.dni
				    FROM dealers D INNER JOIN sales S ON D.cifd=S.cifd
				    WHERE D.cityd='madrid' AND S.color='red');
		*/
		String sentence = "SELECT DISTINCT C.name"
				+ "			FROM customers C INNER JOIN sales S ON S.dni=C.dni"
				+ "			WHERE C.dni NOT IN (SELECT S.dni"
				+ "			    FROM dealers D INNER JOIN sales S ON D.cifd=S.cifd"
				+ "			    WHERE D.cityd=? AND S.color=?)";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a city: ");
		String city = ReadString();
		
		psQuery.setString(1,city);
		
		System.out.print("Please, enter a color: ");
		String color = ReadString();
		
		psQuery.setString(2,color);
		
		ResultSet rs = psQuery.executeQuery();
		while (rs.next()){
			
			String name = rs.getString("name");
			
			System.out.println(String.format("name: %s", name));
		}
		
		psQuery.close();
	}
	
    /*
        5. Develop a Java method that, using the suitable SQL sentence:
        5.1 Creates cars into the CARS table, taking the data from the user.
    */
	public static void exercise5_1() throws SQLException {
		System.out.println("############# Exercise 5_1: #############");
		/*-- 5.1 Creates cars into the CARS table, taking the data from the user.
			INSERT INTO cars (namec, model, codecar) VALUES (?, ?, ?);
		 */
		String sentence = "INSERT INTO cars (namec, model, codecar) VALUES (?, ?, ?)";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a namec: ");
		String namec = ReadString();
		
		psQuery.setString(1,namec);
		
		System.out.print("Please, enter a model: ");
		String model = ReadString();
		
		psQuery.setString(2,model);
		
		System.out.print("Please, enter a codecar: ");
		int codecar = ReadInt();
		
		psQuery.setInt(3,codecar);
		
		if (psQuery.executeUpdate() == 1) {
			System.out.println(String.format("Data succesfully introduced"));
		} else {
			System.out.println(String.format("Some error has ocurred"));
		}
		
		psQuery.close();
	}
	
    /*
        5.2. Deletes a specific car. The code for the car to delete is defined by the user.
    */
	public static void exercise5_2() throws SQLException {
		System.out.println("############# Exercise 5_2: #############");
		/*-- 5.2. Deletes a specific car. The code for the car to delete is defined by the user.
			DELETE FROM cars WHERE codecar = ?;
		 */
		String sentence = "DELETE FROM cars WHERE codecar = ?";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter a codecar: ");
		int codecar = ReadInt();
		
		psQuery.setInt(1,codecar);
		
		if (psQuery.executeUpdate() == 1) {
			System.out.println(String.format("Data succesfully deleted"));
		} else {
			System.out.println(String.format("Some error has ocurred"));
		}
		
		psQuery.close();
	}
	
    /*
        5.3. Updates the name and model for a specific car. The code for the car to update is defined by the user
    */
	public static void exercise5_3() throws SQLException {		
		System.out.println("############# Exercise 5_3: #############");
		/*-- 5.3. Updates the name and model for a specific car. The code for the car to update is defined by the user
			UPDATE cars
				SET model = ?, namec = ?
				WHERE codecar = ?;
		 */
		
		String sentence = "UPDATE cars"
				+ "				SET model = ?, namec = ?"
				+ "				WHERE codecar = ?";
		
		PreparedStatement psQuery= con.prepareStatement(sentence);
		
		System.out.print("Please, enter the new model: ");
		String model = ReadString();
		
		psQuery.setString(1,model);
		
		System.out.print("Please, enter the new namec: ");
		String namec = ReadString();
		
		psQuery.setString(2,namec);
		
		System.out.print("Please, enter the updating codecar: ");
		int codecar = ReadInt();
		
		psQuery.setInt(3,codecar);
		
		if (psQuery.executeUpdate() == 1) {
			System.out.println(String.format("Data succesfully updated"));
		} else {
			System.out.println(String.format("Some error has ocurred"));
		}
		
		psQuery.close();
	}
	
    /*
        6. Invoke the exercise 10 function and procedure from lab session PL1 from a Java application.
            (10) Develop a procedure and a function that take a dealer id and return the number of sales that were made in that dealer.
        6.1. Function
    */
	public static void exercise6_1() throws SQLException {		
		System.out.println("############# Exercise 6_1: #############");
		
		CallableStatement cs = con.prepareCall ("{? = call FUNCTION10 (?)}");
		
		cs.registerOutParameter(1,java.sql.Types.INTEGER);
		
		System.out.print("Please, enter a dealerID: ");
		int dealerID = ReadInt();
		
		cs.setInt(2,dealerID);
		
		cs.execute();
		
		int sales = cs.getInt(1);
		System.out.println("Sales made: " + sales);
		
		cs.close();
	}
	
    /*
        6.2. Procedure
    */
	public static void exercise6_2() throws SQLException {		
		System.out.println("############# Exercise 6_2: #############");
		
		CallableStatement cs = con.prepareCall ("{call PROCEDURE10 (?, ?)}");
		
		cs.registerOutParameter(2,java.sql.Types.INTEGER);
		
		System.out.print("Please, enter a dealerID: ");
		int dealerID = ReadInt();
		
		cs.setInt(1,dealerID);
		
		cs.execute();
		
		int sales = cs.getInt(2);
		System.out.println("Sales made: " + sales);
		
		cs.close();
	}
	
    /*
        7. Invoke the exercise 11 function and procedure from lab session PL1 from a Java application.
            (11) Develop a PL/SQL function and a procedure that take a dni that is passed as a parameter and returns 2 values: 
                a) the  number of cars that customer has purchased and b) the number of dealers in which he has purchased them.
        7.1. Function
    */
	public static void exercise7_1() throws SQLException {		
		System.out.println("############# Exercise 7_1: #############");
		
	}	
	
    /*
        7.2. Procedure
    */
	public static void exercise7_2() throws SQLException {		
		System.out.println("############# Exercise 7_2: #############");
		
	}
	
    /*
        8. Develop a Java method that displays the cars that have been bought by each customer. Besides, it must display the number of cars that each customer has bought and the number of dealers where each customer has bought. Customers that have bought no cars should not be shown in the report.
    */
	public static void exercise8() throws SQLException {		
		System.out.println("############# Exercise 8: #############");
	}
		
	@SuppressWarnings("resource")
	private static String ReadString(){
		return new Scanner(System.in).nextLine();		
	}
	
	@SuppressWarnings("resource")
	private static int ReadInt(){
		return new Scanner(System.in).nextInt();			
	}	
}
