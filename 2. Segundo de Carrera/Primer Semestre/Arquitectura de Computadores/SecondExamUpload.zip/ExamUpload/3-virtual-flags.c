#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include "program.h"

int main(void) {
	float *x = malloc(32 * 1024);

	printf("\nProcess Identifier (PID): %d\n", getpid());

	print_virtual_physical_pte(x, "Heap Memory Allocation Information");

	printf("\nPress [ENTER] to continue\n");
	getchar();

	free(x);
	return 0;
}
