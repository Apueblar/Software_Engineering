package test.set;
import static org.junit.Assert.*;

import org.junit.Test;

import main.set.HashTableExam2425_E1;

/**
 * Test class for the HashTable implementation.
 * Uses JUnit to verify the correctness of the HashTable methods.
 */
public class TestHashTableExam2425_E1 {

	@Test
	public void testRemove() {
		
		HashTableExam2425_E1<Integer> a = new HashTableExam2425_E1<Integer>(5, HashTableExam2425_E1.LINEAR_PROBING, 0.9);
		a.add(0);
		assertEquals (0.0, a.getDeletedRate(), 0.01);
		a.add(5);
		assertEquals (0.0, a.getDeletedRate(), 0.01);
		a.add(10);
		assertEquals (0.0, a.getDeletedRate(), 0.01);
		a.add(15);
		assertEquals (0.0, a.getDeletedRate(), 0.01);
		
		assertEquals("[0] (1) = 0 - [1] (1) = 5 - [2] (1) = 10 - [3] (1) = 15 - [4] (0) = null - ", a.toString());
		
		a.remove(15);
		assertEquals (0.2, a.getDeletedRate(), 0.01);
		a.remove(5);
		assertEquals (0.0, a.getDeletedRate(), 0.01);
		a.remove(0);
		assertEquals (0.2, a.getDeletedRate(), 0.01);
		a.remove(10);
		assertEquals (0.0, a.getDeletedRate(), 0.01);
		
		assertEquals("[0] (0) = null - [1] (0) = null - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.add(5);
		assertEquals (0.0, a.getDeletedRate(), 0.01);
		
		assertEquals("[0] (1) = 5 - [1] (0) = null - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.add(6);
		assertEquals (0.0, a.getDeletedRate(), 0.01);
		
		assertEquals("[0] (1) = 5 - [1] (1) = 6 - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.remove(6);
		assertEquals (0.2, a.getDeletedRate(), 0.01);
		assertEquals("[0] (1) = 5 - [1] (2) = 6 - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.add(11);
		assertEquals (0.0, a.getDeletedRate(), 0.01);
		assertEquals("[0] (1) = 5 - [1] (1) = 11 - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.remove(5);
		assertEquals (0.2, a.getDeletedRate(), 0.01);
		a.add(10);
		assertEquals("[0] (1) = 10 - [1] (1) = 11 - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		assertEquals (0.0, a.getDeletedRate(), 0.01);
	}
}
