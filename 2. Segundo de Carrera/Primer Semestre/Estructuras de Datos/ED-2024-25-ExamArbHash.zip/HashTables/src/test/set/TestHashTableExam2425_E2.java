package test.set;
import static org.junit.Assert.*;

import org.junit.Test;

import main.set.HashTableExam2425_E2;

/**
 * Test class for the HashTable implementation.
 * Uses JUnit to verify the correctness of the HashTable methods.
 */
public class TestHashTableExam2425_E2 {
	
	@Test
	public void testGetCollisionRate() {
		HashTableExam2425_E2<Integer> a = new HashTableExam2425_E2<Integer>(5, HashTableExam2425_E2.LINEAR_PROBING, 1.0, 100);
		
		try {
			a.getCollisionRate();
		} catch (IllegalStateException ISE) {
			assertFalse(ISE.getMessage().isBlank());
		}
		
		a.add(0);
		assertEquals (0.0, a.getCollisionRate(), 0.01);
		assertEquals("[0] (1) = 0 - [1] (0) = null - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.add(5); // 1 collision
		assertEquals (0.5, a.getCollisionRate(), 0.01);
		assertEquals("[0] (1) = 0 - [1] (1) = 5 - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.add(1);
		assertEquals (0.66, a.getCollisionRate(), 0.01);
		assertEquals("[0] (1) = 0 - [1] (1) = 5 - [2] (1) = 1 - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.add(6);
		assertEquals (1, a.getCollisionRate(), 0.01);
		assertEquals("[0] (1) = 0 - [1] (1) = 5 - [2] (1) = 1 - [3] (1) = 6 - [4] (0) = null - ", a.toString());
		
		// 4 operations, 4 collisions
		
		a.remove(0);
		assertEquals("[0] (2) = 0 - [1] (1) = 5 - [2] (1) = 1 - [3] (1) = 6 - [4] (0) = null - ", a.toString());
		assertEquals (0.8, a.getCollisionRate(), 0.01);
		
		a.remove(5);
		assertEquals("[0] (2) = 0 - [1] (2) = 5 - [2] (1) = 1 - [3] (1) = 6 - [4] (0) = null - ", a.toString());
		assertEquals (0.83, a.getCollisionRate(), 0.01);
		
		a.remove(1);
		assertEquals("[0] (2) = 0 - [1] (2) = 5 - [2] (2) = 1 - [3] (1) = 6 - [4] (0) = null - ", a.toString());
		assertEquals (0.86, a.getCollisionRate(), 0.01);
		
		a.remove(6);
		assertEquals("[0] (2) = 0 - [1] (2) = 5 - [2] (2) = 1 - [3] (2) = 6 - [4] (0) = null - ", a.toString());
		assertEquals (1, a.getCollisionRate(), 0.01);
		
		
		a = new HashTableExam2425_E2<Integer>(5, HashTableExam2425_E2.LINEAR_PROBING, 1.0, 100.0f);
		
		a.add(0); // 0 collision
		a.add(5); // 1 collision
		a.remove(0); // 0 collision
		a.search(5); // 1 collision
		assertEquals (0.5, a.getCollisionRate(), 0.01);
	}
	
	@Test
	public void testFinalCollisionRate() {
		HashTableExam2425_E2<Integer> a = new HashTableExam2425_E2<Integer>(5, HashTableExam2425_E2.LINEAR_PROBING, 1.0, 0.50f);
		
		try {
			a.getCollisionRate();
		} catch (IllegalStateException ISE) {
			assertFalse(ISE.getMessage().isBlank());
		}
		
		a.add(0);
		assertEquals (0.0, a.getCollisionRate(), 0.01);
		assertEquals("[0] (1) = 0 - [1] (0) = null - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.add(5); // 1 collision
		assertEquals (0.5, a.getCollisionRate(), 0.01);
		assertEquals("[0] (1) = 0 - [1] (1) = 5 - [2] (0) = null - [3] (0) = null - [4] (0) = null - ", a.toString());
		
		a.add(1);
		assertEquals (0.0, a.getCollisionRate(), 0.01); // Resized
		assertEquals("[0] (1) = 0 - [1] (1) = 1 - [2] (0) = null - [3] (0) = null - [4] (0) = null - [5] (1) = 5 - [6] (0) = null - [7] (0) = null - [8] (0) = null - [9] (0) = null - [10] (0) = null - ", a.toString());
		
		a.add(11);
		assertEquals (0.5, a.getCollisionRate(), 0.01);
		assertEquals("[0] (1) = 0 - [1] (1) = 1 - [2] (1) = 11 - [3] (0) = null - [4] (0) = null - [5] (1) = 5 - [6] (0) = null - [7] (0) = null - [8] (0) = null - [9] (0) = null - [10] (0) = null - ", a.toString());
		
		a.add(22);
		assertEquals (0.0, a.getCollisionRate(), 0.01);
	}
}






































