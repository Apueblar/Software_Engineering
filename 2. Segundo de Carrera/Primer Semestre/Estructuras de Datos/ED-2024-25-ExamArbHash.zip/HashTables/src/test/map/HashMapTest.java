package test.map;
import static org.junit.Assert.*;

import org.junit.Test;

import main.map.HashMap;

/**
 * Test class for the HashMap implementation.
 * Uses JUnit to verify the correctness of the HashMap methods.
 */
public class HashMapTest {

	/**
     * Tests the default state of a newly initialized HashMap.
     * Ensures the toString() representation is correct.
     */
	@Test
    public void testTable() {
        // Class Examples
        HashMap<Integer, String> h = new HashMap<Integer, String>(5, HashMap.LINEAR_PROBING, 0.5);
        
        assertEquals (h.toString(),"[0] (0) = {null-null} - [1] (0) = {null-null} - [2] (0) = {null-null} - [3] (0) = {null-null} - [4] (0) = {null-null} - ");
    }
	
	/**
     * Tests the hash function 'f' for integer elements with linear and quadratic probing.
     */
	@Test
	public void testFInteger() {
		// Example
		HashMap<Integer, String> a = new HashMap<Integer, String>(5, HashMap.LINEAR_PROBING, 0.5);
		assertEquals(2, a.f(7, 0));
		assertEquals(3, a.f(7, 1));
		assertEquals(4, a.f(7, 2));
		assertEquals(0, a.f(7, 3));
		
		// Example
		HashMap<Integer, String> b = new HashMap<Integer, String>(5, HashMap.QUADRATIC_PROBING, 0.5);
		assertEquals(2, b.f(7, 0));
		assertEquals(3, b.f(7, 1));
		assertEquals(1, b.f(7, 2));
		assertEquals(1, b.f(7, 3));
	}
	
	/**
     * Tests the hash function 'f' for character elements with linear and quadratic probing.
     */
	@Test
	public void testFCharacter() {
		// Example
		HashMap<Character, String> a = new HashMap<Character, String>(5, HashMap.LINEAR_PROBING, 0.5);
		assertEquals(0, a.f('A', 0));
		assertEquals(1, a.f('A', 1));
		assertEquals(2, a.f('A', 2));
		assertEquals(3, a.f('A', 3));
		
		// Example
		HashMap<Character, String> b = new HashMap<Character, String>(5, HashMap.QUADRATIC_PROBING, 0.5);
		assertEquals(0, b.f('A', 0));
		assertEquals(1, b.f('A', 1));
		assertEquals(4, b.f('A', 2));
		assertEquals(4, b.f('A', 3));
	}
	
	/**
     * Tests the prime number utility methods for finding primes and checking primality.
     */
	@Test
	public void testPrimeNumber() {
		assertFalse(HashMap.isPrime(1));
		assertTrue(HashMap.isPrime(2));
		assertTrue(HashMap.isPrime(3));
		assertFalse(HashMap.isPrime(4));
		assertTrue(HashMap.isPrime(5));
		assertFalse(HashMap.isPrime(6));
		assertTrue(HashMap.isPrime(7));
		assertFalse(HashMap.isPrime(8));
		assertFalse(HashMap.isPrime(9));
		assertFalse(HashMap.isPrime(10));
		assertTrue(HashMap.isPrime(11));
		assertFalse(HashMap.isPrime(12));
		assertTrue(HashMap.isPrime(13));
		assertFalse(HashMap.isPrime(14));
		assertFalse(HashMap.isPrime(15));
		assertFalse(HashMap.isPrime(16));
		assertTrue(HashMap.isPrime(17));
		
		assertEquals(2, HashMap.getNextPrimeNumber(1));
		assertEquals(3, HashMap.getNextPrimeNumber(2));
		assertEquals(5, HashMap.getNextPrimeNumber(3));
		assertEquals(5, HashMap.getNextPrimeNumber(4));
		assertEquals(7, HashMap.getNextPrimeNumber(5));
		assertEquals(7, HashMap.getNextPrimeNumber(6));
		assertEquals(11, HashMap.getNextPrimeNumber(7));
		assertEquals(11, HashMap.getNextPrimeNumber(8));
		assertEquals(11, HashMap.getNextPrimeNumber(9));
		assertEquals(11, HashMap.getNextPrimeNumber(10));
		assertEquals(13, HashMap.getNextPrimeNumber(11));
		
		assertEquals(13, HashMap.getPrevPrimeNumber(15));
		assertEquals(13, HashMap.getPrevPrimeNumber(14));
		assertEquals(11, HashMap.getPrevPrimeNumber(13));
		assertEquals(11, HashMap.getPrevPrimeNumber(12));
		assertEquals(7, HashMap.getPrevPrimeNumber(11));
		assertEquals(7, HashMap.getPrevPrimeNumber(10));
		assertEquals(7, HashMap.getPrevPrimeNumber(9));
		assertEquals(7, HashMap.getPrevPrimeNumber(8));
		assertEquals(5, HashMap.getPrevPrimeNumber(7));
		assertEquals(5, HashMap.getPrevPrimeNumber(6));
		assertEquals(3, HashMap.getPrevPrimeNumber(5));
		assertEquals(3, HashMap.getPrevPrimeNumber(4));
		assertEquals(2, HashMap.getPrevPrimeNumber(3));
	}
	
	/**
     * Tests puting, searching, and removing elements from the HashMap.
     */
	@Test
	public void testputSearchRemove() {
		// Example
		HashMap<Integer, Character> b = new HashMap<Integer, Character>(5, HashMap.QUADRATIC_PROBING, 1.0);
		b.put(4, 'D');
		b.put(13, 'M');
		b.put(24, 'W');
		b.put(3, 'C');
		
		assertEquals("[0] (1) = {24-W} - [1] (0) = {null-null} - [2] (1) = {3-C} - [3] (1) = {13-M} - [4] (1) = {4-D} - ", b.toString());
		assertTrue('C' == b.search(3));
		assertTrue(null == b.search(12));
		
		b.remove(24);
		assertEquals("[0] (2) = {24-W} - [1] (0) = {null-null} - [2] (1) = {3-C} - [3] (1) = {13-M} - [4] (1) = {4-D} - ", b.toString());
		
		assertTrue('C' == b.search(3));
		b.put(15, 'N');
		assertTrue('C' == b.search(3));
		assertEquals("[0] (1) = {15-N} - [1] (0) = {null-null} - [2] (1) = {3-C} - [3] (1) = {13-M} - [4] (1) = {4-D} - ", b.toString());
	}
	
	/**
     * Tests the Load Factor (LF) calculation and behavior of HashMap during element insertion/removal.
     */
	@Test
	public void testLF() {
		// Example
		HashMap<Integer, Character> a = new HashMap<Integer, Character>(5, HashMap.LINEAR_PROBING, 1.0);
		a.put(4, 'D');
		assertEquals (0.2, a.getLF(), 0.01);
		a.put(13, 'M');
		assertEquals (0.4, a.getLF(), 0.01);
		a.put(24, 'W');
		assertEquals (0.6, a.getLF(), 0.01);
		a.put(3, 'C');
		assertEquals (0.8, a.getLF(), 0.01);
		
		assertEquals("[0] (1) = {24-W} - [1] (1) = {3-C} - [2] (0) = {null-null} - [3] (1) = {13-M} - [4] (1) = {4-D} - ", a.toString());
		
		a.remove(24);
		assertEquals("[0] (2) = {24-W} - [1] (1) = {3-C} - [2] (0) = {null-null} - [3] (1) = {13-M} - [4] (1) = {4-D} - ", a.toString());
		assertEquals (0.6, a.getLF(), 0.01);
		
		a.put(15, 'N');
		assertEquals("[0] (1) = {15-N} - [1] (1) = {3-C} - [2] (0) = {null-null} - [3] (1) = {13-M} - [4] (1) = {4-D} - ", a.toString());
		
		assertEquals (0.8, a.getLF(), 0.01);
	}
}
