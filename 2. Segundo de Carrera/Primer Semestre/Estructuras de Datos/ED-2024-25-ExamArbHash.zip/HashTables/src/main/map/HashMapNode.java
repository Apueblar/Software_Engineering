package main.map;

/**
 * Represents a single node in a hash table for a hash map implementation.
 * Each node stores a key-value pair along with a state that indicates whether the node is valid, empty, or deleted.
 *
 * @param <K> The type of the key stored in the node.
 * @param <V> The type of the value stored in the node.
 */
public class HashMapNode<K, V> {

	private K key; // The key associated with the node.
	private V value; // The value associated with the node.
	private int state = EMPTY; // The current state of the node (default is EMPTY).
	
	// Constants representing the possible states of the node.
	public final static int EMPTY = 0; // The node is empty and can be used for new data.
	public final static int VALID = 1; // The node contains valid key-value data.
	public final static int DELETED = 2; // The node has been marked as deleted.
	
	/**
     * Creates a new instance of HashMapNode. The node is initialized as EMPTY.
     */
	public HashMapNode() {}
	
	/**
     * Retrieves the key stored in the node.
     * 
     * @return The key of the node, or {@code null} if the node is empty or deleted.
     */
	public K getKey() {
		return key;
	}

	/**
     * Sets the key for this node.
     * This method allows assigning or updating the key associated with the node.
     * 
     * @param key The key to set for the node.
     */
	public void setKey(K key) {
		this.key = key;
	}

	/**
     * Retrieves the value stored in the node.
     * 
     * @return The value of the node, or {@code null} if the node is empty or deleted.
     */
	public V getValue() {
		return value;
	}

	/**
     * Sets the value for this node.
     * This method allows assigning or updating the value associated with the node.
     * 
     * @param value The value to set for the node.
     */
	public void setValue(V value) {
		this.value = value;
	}

	/**
     * Retrieves the current state of the node.
     * The state indicates whether the node is {@code EMPTY}, {@code VALID}, or {@code DELETED}.
     * 
     * @return The current state of the node:
     *         <ul>
     *           <li>{@code EMPTY}: The node is unoccupied and ready for new data.</li>
     *           <li>{@code VALID}: The node contains a valid key-value pair.</li>
     *           <li>{@code DELETED}: The node has been deleted but can be reused.</li>
     *         </ul>
     */
	public int getState() {
		return state;
	}

	/**
     * Sets the state of the node.
     * This method is used to update the node's state to {@code EMPTY}, {@code VALID}, or {@code DELETED}.
     * 
     * @param state The new state of the node (must be one of {@code EMPTY}, {@code VALID}, or {@code DELETED}).
     * @throws IllegalArgumentException If the state is not one of the predefined constants.
     */
	public void setState(int state) {
		if (state != EMPTY && state != VALID && state != DELETED) {
            throw new IllegalArgumentException("Invalid state: " + state + ". Must be EMPTY, VALID, or DELETED.");
        }
		this.state = state;
	}
}
