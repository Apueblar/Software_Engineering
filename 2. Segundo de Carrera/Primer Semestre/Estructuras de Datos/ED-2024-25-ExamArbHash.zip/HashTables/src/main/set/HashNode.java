package main.set;

/**
 * Represents a single node in a hash table.
 * Each node holds a value and a state, which indicates whether the node is empty, valid, or marked as deleted.
 *
 * @param <T> The type of the element stored in the node.
 */
public class HashNode<T> {

	private T value; // The value stored in this node.
	private int state = EMPTY; // The current state of this node (default: EMPTY).
	
	// Constants representing possible node states:
	public final static int EMPTY = 0; // The node is empty and available for insertion.
	public final static int VALID = 1; // The node contains a valid (active) element.
	public final static int DELETED = 2; // The node has been marked as deleted.
	
	/**
     * Creates a new instance of HashNode. The node is initialized as EMPTY.
     */
	public HashNode() {}

	/**
     * Retrieves the value stored in this node.
     * 
     * @return The value of the node; or {@code null}, if the node is in the EMPTY or DELETED state.
     */
	public T getValue() {
		return value;
	}

	/**
     * Assigns a value to this node.
     * 
     * @param value The value to store in the node.
     */
	public void setValue(T value) {
		this.value = value;
	}

	/**
     * Retrieves the current state of the node.
     * The state indicates whether the node is {@code EMPTY}, {@code VALID}, or {@code DELETED}.
     * 
     * @return The current state of the node:
     *         <ul>
     *           <li>{@code EMPTY}: The node is unoccupied and ready for new data.</li>
     *           <li>{@code VALID}: The node contains a valid element.</li>
     *           <li>{@code DELETED}: The node has been deleted but can be reused.</li>
     *         </ul>
     */
	public int getState() {
		return state;
	}

	/**
     * Sets the state of the node.
     * This method is used to update the node's state to {@code EMPTY}, {@code VALID}, or {@code DELETED}.
     * 
     * @param state The new state of the node (must be one of {@code EMPTY}, {@code VALID}, or {@code DELETED}).
     * @throws IllegalArgumentException If the state is not one of the predefined constants.
     */
	public void setState(int state) {
		if (state != EMPTY && state != VALID && state != DELETED) {
            throw new IllegalArgumentException("Invalid state: " + state + ". Must be EMPTY, VALID, or DELETED.");
        }
		this.state = state;
	}
}
