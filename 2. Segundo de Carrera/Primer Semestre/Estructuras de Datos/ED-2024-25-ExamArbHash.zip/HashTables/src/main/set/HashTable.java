package main.set;

/**
 * Generic implementation of a Closed Hash Table. 
 * Supports linear, quadratic, or double hashing for collision resolution.
 * 
 * @param <T> The type of elements stored in the HashTable.
 */
public class HashTable<T> {

	private int B; // Size of the array (number of slots).
	private int R; // Previous prime number smaller than B; used for double hashing.
	private int redispersionType; // Collision resolution type (linear, quadratic, or double hashing).
	private HashNode<T>[] array; // Array to store elements (as nodes).
	private int numberOfElements; // Number of valid (non-deleted) elements in the HashTable.
	
	private double maxLF; // Maximum load factor threshold (i.e., elements / B).
	private double minLF; // Minimum load factor threshold.
	
	 // Constants representing collision resolution strategies:
	public static final int LINEAR_PROBING = 0; // Resolves collisions using linear probing.
	public static final int QUADRATIC_PROBING = 1; // Resolves collisions using quadratic probing.
	public static final int DOUBLE_HASHING = 2; // Resolves collisions using double hashing.
	
	/**
     * Constructs a HashTable with a specified size, probing method, and maximum load factor.
     * 
     * @param B                The size of the HashTable (number of slots).
     * @param redispersionType The collision resolution method (0 for linear, 1 for quadratic, 2 for double hashing).
     * @param maxLF            The maximum allowable load factor (e.g., 0.75).
     */
	@SuppressWarnings("unchecked")
	public HashTable(int B, int redispersionType, double maxLF) {
		this.B = B;
		this.R = getPrevPrimeNumber(B);
		this.redispersionType = redispersionType;
		this.maxLF = maxLF;
		this.minLF = 0;
		array = (HashNode<T>[]) new HashNode[B];
		for (int i = 0; i < B; i++) {
			array[i] = new HashNode<T>();
		}
	}
	
	/**
     * Constructs a HashTable with additional control over the minimum load factor.
     * 
     * @param B                The size of the HashTable.
     * @param redispersionType The collision resolution method.
     * @param maxLF            The maximum allowable load factor.
     * @param minLF            The minimum allowable load factor.
     */
	public HashTable(int B, int redispersionType, double maxLF, double minLF) {
		this(B, redispersionType, maxLF);
		this.minLF = minLF;
	}

	/**
     * Computes the hash index for an element using the configured collision resolution method.
     * 
     * @param element  The element to hash.
     * @param attempts The number of collision resolution attempts made so far.
     * @return The calculated index, bounded within [0, B).
     */
	public int f(T element, int attempts) {
		switch (redispersionType) {
			case LINEAR_PROBING: return (Math.abs(element.hashCode()) + attempts) % B;
			case QUADRATIC_PROBING: return (Math.abs(element.hashCode()) + attempts * attempts) % B;
			case DOUBLE_HASHING: return (Math.abs(element.hashCode()) + attempts * h(element)) % B;
			default: throw new IllegalStateException("f: This should not happen");
		}
	}

	/**
     * Calculates the secondary hash for double hashing.
     * 
     * @param element The element to hash.
     * @return A secondary index within the range [1, R].
     */
	private int h(T element) {
		return R - (Math.abs(element.hashCode()) % R);
	}

	/**
     * Provides a string representation of the HashTable.
     * 
     * @return A formatted string showing each slot's state and value.
     */
	@Override
	public String toString() {
		String str = "";
		for (int i = 0; i < B; i++) {
			// If a node value is null, then is prints "null" otherwise the value.toString()
			str = String.format("%s[%d] (%d) = %s - ", str, i, array[i].getState(), array[i].getValue() == null ? "null" : array[i].getValue().toString());
		}
		return str;
	}

	/**
     * Computes the current load factor of the HashTable.
     * 
     * @return The load factor, defined as (number of elements / size of HashTable).
     */
	public double getLF() {
		return (double) numberOfElements / B;
	}

	/**
     * Adds an element to the HashTable. Resolves collisions using the chosen probing method.
     * 
     * @param element The element to add.
     * @throws NullPointerException If the element is null.
     */
	public void add(T element) {
		if (element == null) {throw new NullPointerException("The item you try to add is null");}
		int attempts = 0;
		int index;
		int indexFirstDeleted = -1;
		boolean empty;
		boolean equal;
		do {
			equal = false;
			index = f(element, attempts);
			attempts++;
			
			// If the item is the first deleted, store it
			if (array[index].getState() == HashNode.DELETED && indexFirstDeleted == -1) {indexFirstDeleted = index;}
			
			empty = array[index].getState() == HashNode.EMPTY;
			if (!empty && array[index].getValue().equals(element)) {equal = true;}
		} while (!(empty || equal) && attempts < B);
		if (equal) {
			switch (array[index].getState()) {
				case HashNode.VALID: {return ;}
				case HashNode.DELETED: {
					array[index].setValue(element);
					array[index].setState(HashNode.VALID);
					break;
				}
				case HashNode.EMPTY: {throw new IllegalStateException("The equals must not be activated if the state is EMPTY");}
				default: {throw new IllegalStateException("Unexpected value: " + array[index].getState());}
			}
		} else {
			if (indexFirstDeleted == -1) {
				array[index].setValue(element);
				array[index].setState(HashNode.VALID);
			} else {
				array[indexFirstDeleted].setValue(element);
				array[indexFirstDeleted].setState(HashNode.VALID);
			}
		}
		numberOfElements++;
		if (getLF() >= maxLF) { dynamicResize(getNextPrimeNumber(B * 2)); }
	}

	/**
     * Removes an element from the HashTable.
     * 
     * @param element The element to remove.
     * @throws NullPointerException If the element is null.
     * @throws IllegalArgumentException If the element is not found.
     */
	public void remove(T element) {
		if (element == null) {throw new NullPointerException("The item you try to remove is null");}
		int attempts = 0;
		int index;
		do {
			index = f(element, attempts++);
		} while (array[index].getState() != HashNode.EMPTY && array[index].getValue() != element);
		if (array[index].getState() == HashNode.EMPTY) {throw new IllegalArgumentException("The element you try to remove is not in the set");}
		array[index].setState(HashNode.DELETED);
		numberOfElements--;
		if (getLF() < minLF) { dynamicResize(getNextPrimeNumber(B / 2)); }
	}

	/**
     * Searches for an element in the HashTable.
     * 
     * @param element The element to search for.
     * @return {@code true} if the element exists and is not deleted; {@code false} otherwise.
     * @throws NullPointerException If the element is null.
     */
	public boolean search(T element) {
		if (element == null) {throw new NullPointerException("The item you try to search is null");}
		int attempts = 0;
		int index;
		do {
			index = f(element, attempts);
			if (array[index].getValue() == element && array[index].getState() != HashNode.DELETED) {return true;}
			attempts++;
		} while (array[index].getState() != HashNode.EMPTY);
		return false;
	}

	/**
     * Checks if a given number is prime.
     * 
     * @param number The number to evaluate.
     * @return {@code true} if the number is prime; {@code false} otherwise.
     */
	public static boolean isPrime(int number) {
		if (number <= 1) {return false;} // Numbers less than 2 are not prime.
		if (number == 2) {return true;}
		for (int i = 2; i <= Math.sqrt(number); i++) {
			if (number % i == 0) {return false;} // Divisible by i -> not prime.
		}
		return true; // No divisors found -> prime number.
	}

	/**
     * Finds the next prime number greater than or equal to the given number.
     * 
     * @param number The starting point for the search.
     * @return The next prime number.
     */
	public static int getNextPrimeNumber(int number) {
		if (number <= 1) {return 2;} // Smallest prime number.
		if (number % 2 == 1) {number++;} // Start with the next odd number.
		while (!isPrime(++number)) {number++;} // Skip even numbers.
		return number;
	}

	/**
     * Finds the largest prime number smaller than the given number.
     * 
     * @param number The starting point for the search.
     * @return The largest prime number smaller than {@code number}.
     */
	public static int getPrevPrimeNumber(int number) {
		while (--number > 1) { // Decrease number until a prime is found.
            if (isPrime(number)) return number;
        }
        return 2; // The last prime number
    }
	
	/**
     * Dynamically resizes the HashTable to accommodate more elements or improve efficiency.
     * 
     * @param newSize The new size for the HashTable; must be a prime number and at least as large as the number of elements.
     * @throws IllegalArgumentException If the new size is smaller than the current number of elements.
     */
	public void dynamicResize(int newSize) {
		if (newSize < numberOfElements) {throw new IllegalArgumentException("The size must be at least the number of elements");}
		HashTable<T> newHashTable = new HashTable<T>(newSize, redispersionType, maxLF);
		
		for (HashNode<T> node : array) {
			if (node.getState() == HashNode.VALID) {
				newHashTable.add(node.getValue());
			}
		}
		
		this.B = newHashTable.B;
		this.R = newHashTable.R;
		this.array = newHashTable.array;
	}
}
