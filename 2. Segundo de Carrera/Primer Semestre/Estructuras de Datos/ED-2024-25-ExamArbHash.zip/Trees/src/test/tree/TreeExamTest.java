package test.tree;

import static org.junit.Assert.*;
import org.junit.Test;
import main.tree.BSTree;
import main.tree.BinaryHeap;

public class TreeExamTest {
	
	@Test
	public void testNumberOfDescendants() {
		
		BSTree<Integer> tree = new BSTree<Integer>();
		tree.add(4);
		assertEquals(0, tree.numberOfDescendants(4));
		tree.add(2);
		assertEquals(1, tree.numberOfDescendants(4));
		tree.add(1);
		assertEquals(2, tree.numberOfDescendants(4));
		assertEquals(1, tree.numberOfDescendants(2));
		tree.add(6);
		assertEquals(3, tree.numberOfDescendants(4));
		assertEquals(0, tree.numberOfDescendants(6));
		tree.add(5);
		assertEquals(4, tree.numberOfDescendants(4));
		assertEquals(1, tree.numberOfDescendants(6));
		tree.remove(2);
		assertEquals(3, tree.numberOfDescendants(4));
		
		try {
			tree.numberOfDescendants(null);
		} catch (IllegalArgumentException IAE) {
			assertFalse(IAE.getMessage().isBlank());
		}
		
		try {
			tree.numberOfDescendants(10);
		} catch (IllegalArgumentException IAE) {
			assertFalse(IAE.getMessage().isBlank());
		}
	}
	
	@Test
	public void testGetDepth() {
		
		BSTree<Integer> tree = new BSTree<Integer>();
		tree.add(4);
		assertEquals(0, tree.getDepth(4));
		tree.add(2);
		assertEquals(0, tree.getDepth(4));
		assertEquals(1, tree.getDepth(2));
		tree.add(1);
		assertEquals(0, tree.getDepth(4));
		assertEquals(1, tree.getDepth(2));
		assertEquals(2, tree.getDepth(1));
		tree.add(3);
		tree.add(6);
		tree.add(5);
		tree.add(7);
		
		assertEquals(2, tree.getDepth(1));
		assertEquals(1, tree.getDepth(2));
		assertEquals(2, tree.getDepth(3));
		assertEquals(0, tree.getDepth(4));
		assertEquals(2, tree.getDepth(5));
		assertEquals(1, tree.getDepth(6));
		assertEquals(2, tree.getDepth(7));
		
		try {
			tree.getDepth(null);
		} catch (IllegalArgumentException IAE) {
			assertFalse(IAE.getMessage().isBlank());
		}
		
		try {
			tree.getDepth(10);
		} catch (IllegalArgumentException IAE) {
			assertFalse(IAE.getMessage().isBlank());
		}
	}
	
	@Test
	public void testGetBrother() {
		
		BinaryHeap<Integer> heap = new BinaryHeap<Integer>(1000);
		heap.add(0);
		assertTrue(heap.getBrother(0) == null);
		
		heap.add(1);
		heap.add(2);
		assertTrue(heap.getBrother(2).equals(1));
		assertTrue(heap.getBrother(1).equals(2));
		
		heap.add(3);
		assertTrue(heap.getBrother(3) == null);
		heap.add(4);
		assertTrue(heap.getBrother(3).equals(4));
		assertTrue(heap.getBrother(4).equals(3));
		
		heap.getMin();
		assertTrue(heap.getBrother(1) == null); // The new root
		assertTrue(heap.getBrother(2).equals(3));
		assertTrue(heap.getBrother(3).equals(2));
		assertTrue(heap.getBrother(4) == null);
		
		try {
			heap.getBrother(null);
		} catch (IllegalArgumentException IAE) { // I would prefer NPE but you don't want
			assertFalse(IAE.getMessage().isBlank());
		}
		
		try {
			heap.getBrother(5);
		} catch (IllegalArgumentException IAE) {
			assertFalse(IAE.getMessage().isBlank());
		}
		
		heap.add(2);
		assertTrue(heap.getBrother(2).equals(2));
		
	}
}
