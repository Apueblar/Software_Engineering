package test.tree;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.tree.BSTree;

class BSTBasicTest {

	@Test
	void testAddSearch() {
		BSTree<Character> bst = new BSTree<Character>();
		char[] elements = new char[] { 'b', 'a', 'd', 'c', 'g', 'i', 'h' };
		
		for (char element : elements)
			bst.add(element);
		
		for (char element : elements)
			assertTrue(bst.search(element));
		
		assertFalse(bst.search('f'));
		assertFalse(bst.search('e'));
		assertFalse(bst.search('j'));
		
		for (char element : elements) {
			IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> bst.add(element));
			assertNotNull(ex.getMessage());
			assertNotEquals(ex.getMessage(), "");
		}
	}

	@Test
	void testAddTostring() {
		BSTree<Character> a = new BSTree<Character>();
		a.add('b');
		assertEquals("b--", a.toString());
		a.add('a');
		assertEquals("ba---", a.toString());
		a.add('d');
		assertEquals("ba--d--", a.toString());
		a.add('c');
		assertEquals("ba--dc---", a.toString());
		a.add('g');
		assertEquals("ba--dc--g--", a.toString());
		a.add('i');
		assertEquals("ba--dc--g-i--", a.toString());
		a.add('h');
		assertEquals("ba--dc--g-ih---", a.toString());

	}

	@Test
	void testGetMax() {
		BSTree<Character> a = new BSTree<Character>();

		IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> a.getMax(null));
		assertNotNull(ex.getMessage());
		assertNotEquals(ex.getMessage(), "");
		
		a.add('b');
		assertEquals('b', (char) a.getMax(a.getRoot()));
		a.add('a');
		assertEquals('b', (char) a.getMax(a.getRoot()));
		a.add('d');
		assertEquals('d', (char) a.getMax(a.getRoot()));
		a.add('c');
		assertEquals('d', (char) a.getMax(a.getRoot()));
		a.add('g');
		assertEquals('g', (char) a.getMax(a.getRoot()));
		a.add('i');
		assertEquals('i', (char) a.getMax(a.getRoot()));
		a.add('h');
		assertEquals('i', (char) a.getMax(a.getRoot()));

	}
}
