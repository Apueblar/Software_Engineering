package test.tree;
import static org.junit.Assert.*;

import org.junit.Test;

import main.tree.AVLTree;

public class L9BFTest {

	@Test
	public void test() {
		AVLTree<String> avl=new AVLTree<String>();
		
		avl.add("C");
		// 0 children
		assertEquals(avl.getRoot().getBF(), 0);

		avl.add("A");

		assertEquals(avl.getRoot().getBF(), -1);
		
		avl.add("B");
		

		assertEquals(avl.getRoot().getBF(), -2);
		
		avl.add("E");
		
		assertEquals(avl.getRoot().getBF(), -1);
		
		avl.add("D");

		assertEquals(avl.getRoot().getBF(), 0);
		

		avl.add("F");

		assertEquals(avl.getRoot().getBF(), 0);
		

		avl.add("G");

		assertEquals(avl.getRoot().getBF(), 1);
		
		avl.add("H");

		assertEquals(avl.getRoot().getBF(), 2);
		

		avl.add("I");

		assertEquals(avl.getRoot().getBF(), 3);
		
		avl.remove("B");
		
		
		assertEquals(avl.getRoot().getBF(), 4);
		
		avl.remove("A");
		
		assertEquals(avl.getRoot().getBF(), 5);
		
		avl.remove("E");
		
		assertEquals(avl.getRoot().getBF(), 5);
		
		avl.remove("D");
		
		assertEquals(avl.getRoot().getBF(), 4);
		
		avl.remove("F");
		
		assertEquals(avl.getRoot().getBF(), 3);
		
		avl.remove("G");
		

		assertEquals(avl.getRoot().getBF(), 2);
		
		
		
		
		
	}
}