package test.tree;

import static org.junit.Assert.*;

import org.junit.Test;

import main.tree.BSTree;


public class BSTTest {
	
	@Test
	public void testAdd() {
	
		BSTree <Character> charTree = new BSTree<Character>();
		charTree.add('a');
		charTree.add('b');
		charTree.add('c');
		
		assertEquals ("a-b-c--", charTree.toString());
		
		charTree.add('d');
		assertEquals ("a-b-c-d--", charTree.toString());
		
	}
	
	
	@Test
	public void testRemove() {
	
		// Example
		BSTree<Character> a = new BSTree<Character>();
		a.add('b');
		a.add('a');
		a.add('d');
		a.add('c');
		a.add('g');
		a.add('i');
		a.add('h');
		assertEquals ("ba--dc--g-ih---", a.toString());
	
		// Scenery III
		a.remove('d');
		assertEquals ("ba--c-g-ih---", a.toString());
		
		// Scenery II
		a.remove('g');
		// Scenery I
		a.remove('a');
		assertEquals ("b-c-ih---", a.toString());
		
		IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, ()-> a.remove('a'));
		assertNotNull(ex.getMessage());
		assertNotEquals(ex.getMessage(), "");
		
		ex = assertThrows(IllegalArgumentException.class, ()-> a.remove('x'));
		assertNotNull(ex.getMessage());
		assertNotEquals(ex.getMessage(), "");
	}	

	
	
	@Test
	public void testRemoveB() {
	
		// Example
		BSTree<Integer> a = new BSTree<Integer>();
		a.add(5);
		a.add(3);
		a.add(1);
		a.add(2);
		a.add(7);

		assertEquals ("531-2---7--", a.toString());
		
		a.remove(5);
		
		assertEquals("31-2--7--", a.toString());
		
		a.remove(7);

		assertEquals("31-2---", a.toString());
		
		a.remove(3);
		
		assertEquals("1-2--", a.toString());	

		a.remove(2);
		
		assertEquals("1--", a.toString());
		

		a.remove(1);
		
		assertEquals("-", a.toString());
	}


}
