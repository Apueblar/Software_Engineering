package test.tree;
import static org.junit.Assert.*;

import org.junit.Test;

import main.tree.AVLTree;


public class L9AVLTest {

	@Test
    public void testAVLgetHeight() {
                 
        AVLTree <Integer> tree = new AVLTree<Integer>();
        
        assertEquals(0, tree.getTreeHeight());
        
       tree.add(4); // root
       assertEquals(1, tree.getTreeHeight());
       
       tree.add(2); // left child
       assertEquals(2, tree.getTreeHeight());
       
       tree.add(6); // right child
       assertEquals(2, tree.getTreeHeight());
       
       tree.add(1);
       assertEquals(3, tree.getTreeHeight());
       
       tree.add(0);
       assertEquals(3, tree.getTreeHeight());
	}
	
	@Test
    public void testAVLcountTreeLeaves() {
                 
        AVLTree <Integer> tree = new AVLTree<Integer>();
        
       assertEquals(0, tree.countTreeLeaves());
        
       tree.add(4); // root
       assertEquals(1, tree.countTreeLeaves());
       
       tree.add(2); 
       assertEquals(1, tree.countTreeLeaves());
       
       tree.add(6);
       assertEquals(2, tree.countTreeLeaves());
       
       tree.add(1);
       assertEquals(2, tree.countTreeLeaves());
       
       tree.add(3);
       assertEquals(3, tree.countTreeLeaves());
       
       tree.add(5);
       assertEquals(3, tree.countTreeLeaves());
       
       tree.add(7);
       assertEquals(4, tree.countTreeLeaves());
	}
	
    @Test
    public void testAVLA() {
                 
        AVLTree <Integer> ti = new AVLTree<Integer>();
         
        ti.add(10);
        ti.add(6);
        ti.add(15);
        ti.add(3);
        ti.add(9);
        ti.add(14);
        ti.add(20);
        
        assertEquals ("10(0)6(0)3(0)--9(0)--15(0)14(0)--20(0)--", ti.toString());
        
  
        ti.add(2);
        ti.add(4);
        ti.add(7);
        ti.add(12);
        
        assertEquals ("10(0)6(0)3(0)2(0)--4(0)--9(-1)7(0)---15(-1)14(-1)12(0)---20(0)--", ti.toString());
        
        ti.add(1);
         
        assertEquals ("10(-1)6(-1)3(-1)2(-1)1(0)---4(0)--9(-1)7(0)---15(-1)14(-1)12(0)---20(0)--", ti.toString());
 
        ti.remove(20);
        
        assertEquals ("6(0)3(-1)2(-1)1(0)---4(0)--10(0)9(-1)7(0)---14(0)12(0)--15(0)--", ti.toString());
         
        ti.remove(4);
         
        assertEquals ("6(1)2(0)1(0)--3(0)--10(0)9(-1)7(0)---14(0)12(0)--15(0)--", ti.toString());
         
        ti.remove(10);
         
        assertEquals ("6(1)2(0)1(0)--3(0)--9(1)7(0)--14(0)12(0)--15(0)--", ti.toString());
         
        ti.remove(9);
        
        assertEquals ("6(1)2(0)1(0)--3(0)--14(-1)7(1)-12(0)--15(0)--", ti.toString());

        ti.remove(6);
        
        assertEquals ("3(1)2(-1)1(0)---14(-1)7(1)-12(0)--15(0)--", ti.toString());
 
        ti.remove(3);
        assertEquals ("7(0)2(-1)1(0)---14(0)12(0)--15(0)--", ti.toString());
    }
    
	@Test
	public void testAVLB() {
				
		AVLTree <Integer> ti = new AVLTree<Integer>();
		
		ti.add(1);
	    
	    assertEquals ("1(0)--", ti.toString());
	    
	    ti.add(2);
	    
	    assertEquals ("1(1)-2(0)--", ti.toString());
	    
	    ti.add(3);
	    
	    assertEquals ("2(0)1(0)--3(0)--", ti.toString());
	    
	    ti.add(4);
	    
	    assertEquals ("2(1)1(0)--3(1)-4(0)--", ti.toString());
	    
	    ti.add(5);
	    
	    assertEquals ("2(1)1(0)--4(0)3(0)--5(0)--", ti.toString());
	    
	    ti.add(6);
	    
	    assertEquals ("4(0)2(0)1(0)--3(0)--5(1)-6(0)--", ti.toString());
	    
	    ti.add(10);
	    
	    assertEquals ("4(0)2(0)1(0)--3(0)--6(0)5(0)--10(0)--", ti.toString());
	    
	    ti.add(11);
	    
	    assertEquals ("4(1)2(0)1(0)--3(0)--6(1)5(0)--10(1)-11(0)--", ti.toString());
	    
	    ti.add(8);
	    
	    assertEquals ("4(1)2(0)1(0)--3(0)--6(1)5(0)--10(0)8(0)--11(0)--", ti.toString());
	    
	    ti.add(7);
	    
	    assertEquals ("4(1)2(0)1(0)--3(0)--8(0)6(0)5(0)--7(0)--10(1)-11(0)--", ti.toString());
	    
	    ti.remove(1);
	    assertEquals ("4(1)2(1)-3(0)--8(0)6(0)5(0)--7(0)--10(1)-11(0)--", ti.toString());
	    
	    ti.remove(3);
	    assertEquals ("8(-1)4(1)2(0)--6(0)5(0)--7(0)--10(1)-11(0)--", ti.toString());
	    
	    ti.remove(4);
	    assertEquals ("8(-1)6(-1)2(1)-5(0)--7(0)--10(1)-11(0)--", ti.toString());
	    
	    ti.remove(7);
	    assertEquals ("8(0)5(0)2(0)--6(0)--10(1)-11(0)--", ti.toString());
	    
	    ti.remove(11);
	    assertEquals ("8(-1)5(0)2(0)--6(0)--10(0)--", ti.toString());
	    
	    ti.remove(10);
	    assertEquals ("5(1)2(0)--8(-1)6(0)---", ti.toString());
	    
	}
}