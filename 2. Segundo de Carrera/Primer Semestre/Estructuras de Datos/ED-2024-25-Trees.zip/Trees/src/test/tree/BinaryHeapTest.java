package test.tree;

import static org.junit.Assert.*;

import org.junit.Test;

import main.tree.BinaryHeap;

public class BinaryHeapTest {

	@Test
	public void test_filter_up() {

		BinaryHeap<Integer> a = new BinaryHeap<Integer>(10);
		a.add(10);
		a.add(9);
		a.add(8);

		assertEquals(a.toString(), "[8, 10, 9]");
		a.add(7);
		assertEquals(a.toString(), "[7, 8, 9, 10]");
		a.add(6);
		assertEquals(a.toString(), "[6, 7, 9, 10, 8]");
		a.add(5);
		assertEquals(a.toString(), "[5, 7, 6, 10, 8, 9]");
		a.add(4);
		assertEquals(a.toString(), "[4, 7, 5, 10, 8, 9, 6]");
		a.add(3);
		assertEquals(a.toString(), "[3, 4, 5, 7, 8, 9, 6, 10]");
		a.add(2);
		assertEquals(a.toString(), "[2, 3, 5, 4, 8, 9, 6, 10, 7]");
		a.add(1);
		assertEquals(a.toString(), "[1, 2, 5, 4, 3, 9, 6, 10, 7, 8]");

		BinaryHeap<Character> b = new BinaryHeap<Character>(50);

		b.add('f');
		b.add('g');
		b.add('a');
		b.add('z');
		b.add('d');

		assertEquals(b.toString(), "[a, d, f, z, g]");
		assertEquals('a', (char) b.getMin());
		assertEquals(b.toString(), "[d, g, f, z]");
	}

	@Test
	public void test_getMin() {

		String[] input = { "Z", "X", "R", "P", "O", "G", "E", "D", "B", "A" };
		BinaryHeap<String> heap = new BinaryHeap<String>(10, input);

		String result = "";

		while (!heap.isEmpty()) {
			String x = String.valueOf(heap.getMin());
			result += x;
		}

		assertEquals("ABDEGOPRXZ", result);
	}

	@Test
	public void test_getMinB() {

		BinaryHeap<Integer> heap = new BinaryHeap<Integer>(10);
		heap.add(200);
		heap.add(105);
		heap.add(1);

		String result = "";

		// print heap in sorted order
		while (!heap.isEmpty()) {
			int x = heap.getMin();
			result += x + "-";
		}

		assertEquals(result, "1-105-200-");
	}

	@Test
	public void test() {
		BinaryHeap<Integer> heap = new BinaryHeap<Integer>(10);
		heap.add(9);
		heap.add(8);
		heap.add(7);
		heap.add(6);

		assertEquals("[6, 7, 8, 9]", heap.toString());
		heap.add(5);
		assertEquals("[5, 6, 8, 9, 7]", heap.toString());
		heap.add(1);
		assertEquals("[1, 6, 5, 9, 7, 8]", heap.toString());
		heap.add(2);
		assertEquals("[1, 6, 2, 9, 7, 8, 5]", heap.toString());

		heap.add(3);
		heap.add(4);

		assertEquals("[1, 3, 2, 4, 7, 8, 5, 9, 6]", heap.toString());

		assertEquals(1, (int) heap.getMin());

		assertEquals("[2, 3, 5, 4, 7, 8, 6, 9]", heap.toString());
	}

	@Test
	public void testOneChild() {
		BinaryHeap<Integer> heap = new BinaryHeap<Integer>(10);

		heap.add(2);
		heap.add(3);
		heap.add(4);

		heap.add(5);
		heap.add(6);
		assertEquals("[2, 3, 4, 5, 6]", heap.toString());

		assertEquals((int) heap.getMin(), 2);

		assertEquals("[3, 5, 4, 6]", heap.toString());
	}
	
	@Test
	public void testExceptions() {
		BinaryHeap<Integer> heap = new BinaryHeap<Integer>(2);
		// If inserting null.
		assertThrows(NullPointerException.class, () -> heap.add(null));
		heap.add(2);
		heap.add(3);

		// If adding over capacity.
		assertThrows(IllegalStateException.class, () -> heap.add(4));
		heap.getMin();
		heap.getMin();

		// If getting the min of an empty heap.
		assertThrows(IllegalStateException.class, () -> heap.getMin());

	}

	@Test
	public void testGetAscendants() {
		BinaryHeap<Integer> heap = new BinaryHeap<Integer>(7);
		heap.add(1);
		heap.add(2);
		heap.add(3);
		heap.add(4);
		heap.add(5);
		heap.add(6);
		heap.add(7);

		assertEquals("1", heap.getAscendants(1));
		assertEquals("2 1", heap.getAscendants(2));
		assertEquals("3 1", heap.getAscendants(3));
		assertEquals("4 2 1", heap.getAscendants(4));
		assertEquals("5 2 1", heap.getAscendants(5));
		assertEquals("6 3 1", heap.getAscendants(6));
		assertEquals("7 3 1", heap.getAscendants(7));

	}
}
