package test.tree;

import static org.junit.Assert.*;
import org.junit.Test;
import main.tree.BSTree;



public class BSTHeightTest {
	
	@Test
	public void testHeight() {
	
		BSTree <Character> charTree = new BSTree<Character>();
		charTree.add('a');
		charTree.add('b');
		charTree.add('c');
		
		assertEquals ("a(2)-b(1)-c(0)--", charTree.toString());
		
		charTree.add('d');
		assertEquals ("a(3)-b(2)-c(1)-d(0)--", charTree.toString());
	}
	
	
	@Test
	public void testHeightB() {
	
		// Example
		BSTree<Character> a = new BSTree<Character>();
		a.add('b');
		a.add('a');
		a.add('d');
		a.add('c');
		a.add('g');
		a.add('i');
		a.add('h');
		assertEquals ("b(4)a(0)--d(3)c(0)--g(2)-i(1)h(0)---", a.toString());
	
		// Scenery III
		a.remove('d');
		assertEquals ("b(4)a(0)--c(3)-g(2)-i(1)h(0)---", a.toString());
		
		// Scenery II
		a.remove('g');
		assertEquals ("b(3)a(0)--c(2)-i(1)h(0)---", a.toString());
				
		// Scenery I
		a.remove('a');
		assertEquals ("b(3)-c(2)-i(1)h(0)---", a.toString());
	}	

	
	
	@Test
	public void testJoins() {
	
		// Example
		BSTree<Integer> a = new BSTree<Integer>();
		a.add(5);
		a.add(3);
		a.add(1);
		a.add(2);
		a.add(7);
		assertEquals ("5(3)3(2)1(1)-2(0)---7(0)--", a.toString());
		
		BSTree<Integer> b = new BSTree<Integer>();
		b.add(7);
		b.add(6);
		b.add(8);
		assertEquals ("7(1)6(0)--8(0)--", b.toString());
		
		BSTree<Integer> result = a.joins(b);
		int[] values = new int[] {5,3,1,2,7,6,8};
		for(int value : values) {
			assertTrue(result.search(value));
		}
	
		for(int value : values) {
			result.remove(value);
		}

		for(int value : values) {
			assertFalse(result.search(value));
		}
	}
	
	@Test
	public void testJoinsB() {
	
		BSTree<Character> a = new BSTree<Character>();
		a.add('b');
		a.add('a');
		a.add('d');
		assertEquals ("b(1)a(0)--d(0)--", a.toString());
	
		BSTree<Character> b = new BSTree<Character>();
		b.add('c');
		b.add('g');
		b.add('i');
		b.add('d');
		assertEquals ("c(2)-g(1)d(0)--i(0)--", b.toString());
		
		BSTree<Character> result = a.joins(b);
		char[] values = new char[] {'b','a','d','c','g','i'};
		for(char value : values) {
			assertTrue(result.search(value));
		}
	
		for(char value : values) {
			result.remove(value);
		}

		for(char value : values) {
			assertFalse(result.search(value));
		}
	}

}
