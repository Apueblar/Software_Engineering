package main.tree;

/**
 * A class representing an AVL Tree. 
 * AVL trees are self-balancing binary search trees where the height difference 
 * (balance factor) between the left and right subtrees of every node is at most 1.
 * @param <T> The type of elements stored in the tree (must be comparable).
 */
public class AVLTree<T extends Comparable<T>> {
	
	private AVLNode<T> root; // The root node of the tree
	
	/**
	 * Default constructor to create an empty AVL tree.
	 */
	public AVLTree() {}
	
	/**
	 * Adds an element to the tree. Throws exceptions for invalid inputs or duplicates.
	 * @param element The element to add. Must not be null.
	 * @throws NullPointerException if the element is null.
	 * @throws IllegalArgumentException if the element already exists in the tree.
	 */
	public void add(T element) {
		if(element == null) {throw new NullPointerException("add: The node you try to add is null");}
		root = add(root, element);
	}
	
	/**
	 * Recursive helper method to add an element to the subtree.
	 * @param root The root of the current subtree.
	 * @param element The element to add.
	 * @return The updated root of the subtree.
	 */
	private AVLNode<T> add(AVLNode<T> root, T element) {
		if(root == null) {return new AVLNode<T>(element);}
		if(root.getElement().compareTo(element) == 0) {throw new IllegalArgumentException("add: The element is already in the tree");}
		if(root.getElement().compareTo(element) > 0) { // root > element -> To the left
			root.setLeft(add(root.getLeft(), element));
		}
		if(root.getElement().compareTo(element) < 0) { // root < element -> To the right
			root.setRight(add(root.getRight(), element));
		}
		return updateBF(root);
	}

	/**
	 * Searches for an element in the tree.
	 * @param element The element to search for. Must not be null.
	 * @return true if the element is found, false otherwise.
	 * @throws NullPointerException if the element is null.
	 */
	public boolean search(T element) {
		if(element == null) {throw new NullPointerException("search: The node you try to search is null");}
		return search(root, element);
	}
	
	/**
	 * Recursive helper method to search for an element in the subtree.
	 * @param root The root of the current subtree.
	 * @param element The element to search for.
	 * @return true if the element is found, false otherwise.
	 */
	private boolean search(AVLNode<T> root, T element) {
		if(root == null) {return false;}
		if(root.getElement().compareTo(element) == 0) {return true;}
		if(root.getElement().compareTo(element) > 0) {return search(root.getLeft(), element);}
		if(root.getElement().compareTo(element) < 0) {return search(root.getRight(), element);}
		throw new IllegalStateException("search method does not work as intended.");
	}

	/**
	 * Gets the root node of the tree.
	 * @return The root node.
	 */
	public AVLNode<T> getRoot() {
		return root;
	}

	/**
	 * Finds the maximum value in the subtree rooted at the given node.
	 * @param root The root of the subtree.
	 * @return The maximum value in the subtree.
	 * @throws IllegalArgumentException if the root is null.
	 */
	public T getMax(AVLNode<T> root) {
		if (root == null) {throw new IllegalArgumentException("getMax: The root node is null");}
		if (root.getRight() == null) {return root.getElement();}
		return getMax(root.getRight());
	}

	@Override
	public String toString() {
		return preOrderToString(root);
	}
	
	/**
	 * Performs a pre-order traversal (root-left-right) to generate a string representation of the tree.
	 * Each node is represented as "value(balanceFactor)".
	 * @param root The root of the subtree.
	 * @return A string representation of the tree.
	 */
	private String preOrderToString(AVLNode<T> root) {
		if (root == null) {return "-";}
		return root.getElement().toString() + "(" + root.getBF() + ")" + preOrderToString(root.getLeft()) + preOrderToString(root.getRight());
	}
	
//	/**
//	 * PreOrder toString of the tree (root(height)-left-right)
//	 * @param root The root
//	 * @return recursive to string of the tree
//	 */
//	private String preOrderToStringWithHeight(AVLNode<T> root) {
//		if (root == null) {return "-";}
//		return root.getElement().toString() + "(" + root.getHeight() + ")" + preOrderToString(root.getLeft()) + preOrderToString(root.getRight());
//	}

//	/**
//	 * PreOrder toString of the tree (root-left-right)
//	 * @param root The root
//	 * @return recursive to string of the tree
//	 */
//	private String oldPreOrderToString(AVLNode<T> root) {
//		if (root == null) {return "-";}
//		return root.getElement().toString() + preOrderToString(root.getLeft()) + preOrderToString(root.getRight());
//	}
	
	/**
	 * Removes an element from the tree. Throws exceptions for invalid inputs or missing elements.
	 * @param nodeToEliminate The element to remove. Must not be null.
	 * @throws NullPointerException if the element is null.
	 * @throws IllegalArgumentException if the element is not in the tree.
	 */
	public void remove(T nodeToEliminate) {
		if(nodeToEliminate == null) {throw new NullPointerException("remove: The node you try to remove is null");}
		root = remove(root, nodeToEliminate);
	}

	/**
	 * Recursive helper method to remove an element from the subtree.
	 * @param root The root of the current subtree.
	 * @param nodeToEliminate The element to remove.
	 * @return The updated root of the subtree.
	 */
	private AVLNode<T> remove(AVLNode<T> root, T nodeToEliminate) {
		if(root == null) {throw new IllegalArgumentException("remove: The node you try to eliminate is not in the tree");}
		
		int comparation = root.getElement().compareTo(nodeToEliminate);

		if(comparation == 0) { // It found the node
			if(root.getLeft() == null) {return root.getRight();}
			if(root.getRight() == null) {return root.getLeft();}
			
			T maxLeft = getMax(root.getLeft()); // Max value of left branch
			root.setElement(maxLeft); // Sets the value of the current node to that max value
			
			root.setLeft(remove(root.getLeft(), maxLeft));
		}
		if(comparation > 0) { // root > element -> To the left
			root.setLeft(remove(root.getLeft(), nodeToEliminate));
		}
		if(comparation < 0) { // root < element -> To the right
			root.setRight(remove(root.getRight(), nodeToEliminate));
		}
		return updateBF(root);
	}

	/**
	 * Joins (union) the given tree with this tree by creating a new AVLTree.
	 * Combines the elements from both trees into a new tree without duplicates.
	 * @param b The second tree to join with this tree.
	 * @return A new AVLTree with the union of the elements from both trees.
	 */
	public AVLTree<T> joins(AVLTree<T> b) {
		AVLTree<T> newTree = new AVLTree<T>();
		
		newTree.addTree(root);
		newTree.addTree(b.getRoot());
		
		return newTree;
	}

	/**
	 * Helper method to recursively add all elements of a subtree into the current tree.
	 * Ensures elements are added in a way that maintains AVLtree properties.
	 * @param root The root of the subtree to add.
	 */
	private void addTree(AVLNode<T> root) {
		if(root == null) {return;}
		try {
			add(root.getElement());
		} catch(IllegalArgumentException e) {}
		
		addTree(root.getLeft());
		addTree(root.getRight());
	}
	
	/**
	 * Updates the balance factor of the given node and performs rotations if necessary
	 * to maintain the AVL tree's balance property.
	 * @param root The node to update.
	 * @return The updated node after rebalancing, if necessary.
	 */
	private AVLNode<T> updateBF(AVLNode<T> root) {
		if (root.getBF() < -1 ||  1 < root.getBF()) { // Do a rotation
			if (root.getBF() < -1) { // Left unbalanced
				if (root.getLeft().getBF() <= 0) {
					root = singleLeftRotation(root);
				} else {
					root = doubleLeftRotation(root);
				}
			} else { // Right unbalanced
				if (root.getRight().getBF() < 0) {
					root = doubleRightRotation(root);
				} else {
					root = singleRightRotation(root);
				}
			}
		}
		
		root.updateHeight();
		return root;
	}

	/**
	 * Performs a single left rotation to fix a left-heavy imbalance.
	 * @param root The root of the subtree to rotate.
	 * @return The new root after the rotation.
	 */
	private AVLNode<T> singleLeftRotation(AVLNode<T> root) {
		AVLNode<T> newRoot = root.getLeft();
		
		root.setLeft(newRoot.getRight());
		newRoot.setRight(root);
		
		root.updateHeight();
		return newRoot;
	}

	/**
	 * Performs a double left rotation to fix a left-right imbalance.
	 * @param root The root of the subtree to rotate.
	 * @return The new root after the rotation.
	 */
	private AVLNode<T> doubleLeftRotation(AVLNode<T> root) {
		root.setLeft(singleRightRotation(root.getLeft()));
		return singleLeftRotation(root);
	}

	/**
	 * Performs a single right rotation to fix a right-heavy imbalance.
	 * @param root The root of the subtree to rotate.
	 * @return The new root after the rotation.
	 */
	private AVLNode<T> singleRightRotation(AVLNode<T> root) {
		AVLNode<T> newRoot = root.getRight();
		
		root.setRight(newRoot.getLeft());
		newRoot.setLeft(root);
		
		root.updateHeight();
		return newRoot;
	}

	/**
	 * Performs a double right rotation to fix a right-left imbalance.
	 * @param root The root of the subtree to rotate.
	 * @return The new root after the rotation.
	 */
	private AVLNode<T> doubleRightRotation(AVLNode<T> root) {
		root.setRight(singleLeftRotation(root.getRight()));
		return singleRightRotation(root);
	}
	
	/**
	 * Returns the height of the tree. If the tree is empty, returns 0.
	 * If the tree contains only the root, returns 1.
	 * @return The height of the tree.
	 */
	public int getTreeHeight() {
		return getHeightNode(root);
	}
	
	/**
	 * Recursively calculates the height of the given node.
	 * @param root The node for which to calculate the height.
	 * @return The height of the subtree rooted at the given node.
	 */
	private int getHeightNode(AVLNode<T> root) {
		if (root == null) {return 0;}
		return Math.max( getHeightNode(root.getLeft()) , getHeightNode(root.getRight()) ) + 1;
	}

	/**
	 * Counts the number of leaves (nodes without children) in the tree.
	 * @return The number of leaves in the tree.
	 */
	public int countTreeLeaves() {
		if (root == null) {return 0;}
		return countLeavesOf(root);
	}

	/**
	 * Recursively counts the number of leaf nodes in the subtree rooted at the given node.
	 * @param root The root of the subtree.
	 * @return The number of leaf nodes in the subtree.
	 */
	private int countLeavesOf(AVLNode<T> root) {
		if (root.getLeft() == null && root.getRight() == null) {return 1;} // Both children null (leave)
		
		if (root.getLeft() == null) {return countLeavesOf(root.getRight());} // It does not have left child (see right)
		if (root.getRight() == null) {return countLeavesOf(root.getLeft());} // It does not have right child (see left)
		
		return countLeavesOf(root.getLeft()) + countLeavesOf(root.getRight()); // It has both
	}
}
