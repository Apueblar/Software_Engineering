package main.tree;

/**
 * Represents a node in an AVL Tree, which stores data and links to its children.
 * AVL trees are a special type of Binary Search Tree that keep themselves balanced.
 * @param <T> The type of data stored in the node (e.g., numbers or strings).
 */
public class AVLNode<T extends Comparable<T>> {

	private T element; // The actual data stored in the node
	private int height; // How tall this node is in the tree
	private AVLNode<T> left; // Link to the left child (smaller values)
	private AVLNode<T> right; // Link to the right child (larger values)
	
	/**
	 * Default constructor, creates an empty node (no data, no children)
	 */
	public AVLNode() {}
	
	/**
	 * Constructor initializing the node with a data (no children)
	 * @param element value or data that will be stored in this node
	 */
	public AVLNode(T element) {
		this.element = element;
	}

	/**
	 * Gets the data stored in this node
	 * @return data stored in this node
	 */
	public T getElement() {
		return element;
	}

	/**
	 * Updates the data stored in this node
	 * @param element The new data of this node
	 */
	public void setElement(T element) {
		this.element = element;
	}
	
	/**
	 * The height is the longest distance to a leaf from this node.
	 * @return The height of this node (0 for no children). Range: [0, +inf)
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Sets a new height for this node
	 * @param height new height for this node
	 */
	public void setHeight(int height) {
		this.height = height;
	}
	
	/**
	 * Calculates and updates the height of this node
	 * The height of a node is calculated as the maximum of the heights of the children + 1
	 * So it considers a null children as -1, so a leave node (without children) has height: 0
	 */
	public void updateHeight() {
		height = Math.max( left == null ? -1 : left.getHeight() , right == null ? -1 : right.getHeight() ) + 1;
	}
	
	/**
	 * Calculates the difference in heights between the children
	 * if the children node is null, its value is -1
	 * @return (right nodes height) - (left nodes height)
	 */
	public int getBF() {
	    int leftHeight = left == null ? -1 : left.getHeight();
	    int rightHeight = right == null ? -1 : right.getHeight();
	    return rightHeight - leftHeight;
	}

	/**
	 * Gets the left child of this node
	 * @return The left child of this node (AVLNode)
	 */
	public AVLNode<T> getLeft() {
		return left;
	}

	/**
	 * Sets a new left child for this node
	 * @param left new left child for this node
	 */
	public void setLeft(AVLNode<T> left) {
		this.left = left;
	}

	/**
	 * Gets the right child of this node
	 * @return The right child of this node (AVLNode)
	 */
	public AVLNode<T> getRight() {
		return right;
	}

	/**
	 * Sets a new right child for this node
	 * @param right new right child for this node
	 */
	public void setRight(AVLNode<T> right) {
		this.right = right;
	}
}
