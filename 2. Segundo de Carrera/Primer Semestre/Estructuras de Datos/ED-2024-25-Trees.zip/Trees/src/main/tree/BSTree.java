package main.tree;

/**
 * Represents a Binary Search Tree (BST) that stores comparable elements.
 * @param <T> The type of elements stored in the tree, must be comparable.
 */
public class BSTree<T extends Comparable<T>> {
	
	private BSTNode<T> root; // The root node of the tree.
	
	/**
	 * Default constructor for creating an empty BST.
	 */
	public BSTree() {}
	
	/**
	 * Adds a given element to the tree. If the element already exists, an exception is thrown.
	 * @param element The element to add, must not be null.
	 * @throws NullPointerException if the element is null.
	 * @throws IllegalArgumentException if the element already exists in the tree.
	 */
	public void add(T element) {
		if(element == null) {throw new NullPointerException("add: The node you try to add is null");}
		root = add(root, element);
		root.updateHeight();
	}
	
	/**
	 * Private helper method to recursively add a node to the tree.
	 * @param root The root of the current subtree.
	 * @param element The element to add.
	 * @return The updated root of the subtree.
	 */
	private BSTNode<T> add(BSTNode<T> root, T element) {
		if(root == null) {return new BSTNode<T>(element);}
		if(root.getElement().compareTo(element) == 0) {throw new IllegalArgumentException("add: The element is already in the tree");}
		if(root.getElement().compareTo(element) > 0) { // root > element -> To the left
			root.setLeft(add(root.getLeft(), element));
		}
		if(root.getElement().compareTo(element) < 0) { // root < element -> To the right
			root.setRight(add(root.getRight(), element));
		}
		root.updateHeight();
		return root;
	}

	/**
	 * Searches for a specific element in the tree.
	 * @param element The element to search for, must not be null.
	 * @return true if the element is found, false otherwise.
	 * @throws NullPointerException if the element is null.
	 */
	public boolean search(T element) {
		if(element == null) {throw new NullPointerException("search: The node you try to search is null");}
		return search(root, element);
	}
	
	/**
	 * Private helper method to recursively search for a node in the tree.
	 * @param root The current root of the subtree.
	 * @param element The element to search for.
	 * @return true if the element is found, false otherwise.
	 */
	private boolean search(BSTNode<T> root, T element) {
		if(root == null) {return false;}
		if(root.getElement().compareTo(element) == 0) {return true;}
		if(root.getElement().compareTo(element) > 0) {return search(root.getLeft(), element);}
		if(root.getElement().compareTo(element) < 0) {return search(root.getRight(), element);}
		throw new IllegalStateException("search method does not work as intended.");
	}

	/**
	 * Retrieves the root node of the tree.
	 * @return The root node of the tree.
	 */
	public BSTNode<T> getRoot() {
		return root;
	}

	/**
	 * Finds the maximum value in the subtree rooted at the given node.
	 * @param root The root of the subtree.
	 * @return The maximum value in the subtree.
	 * @throws IllegalArgumentException if the root is null.
	 */
	public T getMax(BSTNode<T> root) {
		if (root == null) {throw new IllegalArgumentException("getMax: The root node is null");}
		if (root.getRight() == null) {return root.getElement();}
		return getMax(root.getRight());
	}

	/**
	 * PreOrder toString of the tree (root(height)-left-right)
	 * @return recursive to string of the tree
	 */
	@Override
	public String toString() {
		return preOrderToString(root);
	}
	
	/**
	 * Helper method to recursively generate a pre-order string of the tree.
	 * @param root The current root of the subtree.
	 * @return A pre-order string representation of the subtree.
	 */
	private String preOrderToString(BSTNode<T> root) {
		if (root == null) {return "-";}
		return root.getElement().toString() + "(" + root.getHeight() + ")" + preOrderToString(root.getLeft()) + preOrderToString(root.getRight());
	}

//	/**
//	 * PreOrder toString of the tree (root-left-right)
//	 * @param root The root
//	 * @return recursive to string of the tree
//	 */
//	private String oldPreOrderToString(BSTNode<T> root) {
//		if (root == null) {return "-";}
//		return root.getElement().toString() + preOrderToString(root.getLeft()) + preOrderToString(root.getRight());
//	}
	
	/**
	 * Removes an element from the tree.
	 * @param nodeToEliminate The element to remove, must not be null.
	 * @throws NullPointerException if the element is null.
	 * @throws IllegalArgumentException if the element is not in the tree.
	 */
	public void remove(T nodeToEliminate) {
		if(nodeToEliminate == null) {throw new NullPointerException("remove: The node you try to remove is null");}
		root = remove(root, nodeToEliminate);
	}

	/**
	 * Helper method to recursively remove a node from the tree.
	 * @param root The current root of the subtree.
	 * @param nodeToEliminate The element to remove.
	 * @return The updated root of the subtree.
	 */
	private BSTNode<T> remove(BSTNode<T> root, T nodeToEliminate) {
		if(root == null) {throw new IllegalArgumentException("remove: The node you try to eliminate is not in the tree");}
		
		int comparation = root.getElement().compareTo(nodeToEliminate);

		if(comparation == 0) { // It found the node
			if(root.getLeft() == null) {return root.getRight();}
			if(root.getRight() == null) {return root.getLeft();}
			
			T maxLeft = getMax(root.getLeft()); // Max value of left branch
			root.setElement(maxLeft); // Sets the value of the current node to that max value
			
			root.setLeft(remove(root.getLeft(), maxLeft));
		}
		if(comparation > 0) { // root > element -> To the left
			root.setLeft(remove(root.getLeft(), nodeToEliminate));
		}
		if(comparation < 0) { // root < element -> To the right
			root.setRight(remove(root.getRight(), nodeToEliminate));
		}
		root.updateHeight();
		return root;
	}

	/**
	 * Joins (union) the given tree with this tree by creating a new BSTree.
	 * Combines the elements from both trees into a new tree without duplicates.
	 * @param b The second tree to join with this tree.
	 * @return A new BSTree with the union of the elements from both trees.
	 */
	public BSTree<T> joins(BSTree<T> b) {
		BSTree<T> newTree = new BSTree<T>();
		
		newTree.addTree(root);
		newTree.addTree(b.getRoot());
		
		return newTree;
	}

	/**
	 * Helper method to recursively add all elements of a subtree into the current tree.
	 * Ensures elements are added in a way that maintains BSTree properties.
	 * @param root The root of the subtree to add.
	 */
	private void addTree(BSTNode<T> root) {
		if(root == null) {return;}
		try {
			add(root.getElement());
		} catch(IllegalArgumentException e) {}
		
		addTree(root.getLeft());
		addTree(root.getRight());
	}
	
	
	
	
	
	
	
	
	
	
	
}







































