package main.tree;

/**
 * Represents a single node in a Binary Search Tree (BST).
 * @param <T> The type of the element stored in the node, must be comparable.
 */
public class BSTNode<T extends Comparable<T>> {

	private T element; // The value stored in the node.
	private int height; // The height of the node in the BST.
	private BSTNode<T> left; // The left child of the node.
	private BSTNode<T> right; // The right child of the node.
	
	/**
	 * Default constructor for an empty node.
	 */
	public BSTNode() {}
	
	/**
	 * Constructor to create a node with a specific element.
	 * @param element The value to store in the node.
	 */
	public BSTNode(T element) {
		this.element = element;
	}

	/**
	 * Retrieves the value stored in the node.
	 * @return The element stored in the node.
	 */
	public T getElement() {
		return element;
	}

	/**
	 * Sets the value of the node.
	 * @param element The value to set.
	 */
	public void setElement(T element) {
		this.element = element;
	}
	
	/**
	 * Retrieves the height of the node.
	 * @return The height of the node.
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Sets the height of the node.
	 * @param height The new height of the node.
	 */
	public void setHeight(int height) {
		this.height = height;
	}
	
	/**
	 * Calculates and updates the height of this node
	 * The height of a node is calculated as the maximum of the heights of the children + 1
	 * So it considers a null children as -1, so a leave node (without children) has height: 0
	 */
	public void updateHeight() {
		height = Math.max( left == null ? -1 : left.getHeight() , right == null ? -1 : right.getHeight() ) + 1;
	}

	/**
	 * Retrieves the left child of the node.
	 * @return The left child node.
	 */
	public BSTNode<T> getLeft() {
		return left;
	}

	/**
	 * Sets the left child of the node.
	 * @param left The new left child node.
	 */
	public void setLeft(BSTNode<T> left) {
		this.left = left;
	}

	/**
	 * Retrieves the right child of the node.
	 * @return The right child node.
	 */
	public BSTNode<T> getRight() {
		return right;
	}

	/**
	 * Sets the right child of the node.
	 * @param right The new right child node.
	 */
	public void setRight(BSTNode<T> right) {
		this.right = right;
	}
}
