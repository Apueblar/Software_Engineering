package main.map;

/**
 * Generic implementation of a Hash Map that supports collision resolution using 
 * linear probing, quadratic probing, or double hashing.
 * 
 * @param <K> The type of keys stored in the HashMap.
 * @param <V> The type of values stored in the HashMap.
 */
public class HashMap<K, V> {

	private int B; // Number of slots in the hash table (array size).
	private int R; // Previous prime number smaller than B; used for double hashing.
	private int redispersionType; // Collision resolution type (linear, quadratic, or double hashing).
	private HashMapNode<K, V>[] array; // Array to store keys-values (as nodes).
	private int numberOfElements; // Number of valid (non-deleted) elements in the HashMap.
	
	private double maxLF; // Maximum load factor threshold (i.e., elements / B).
	private double minLF; // Minimum load factor threshold.
	
	 // Constants representing collision resolution strategies:
	public static final int LINEAR_PROBING = 0; // Resolves collisions using linear probing.
	public static final int QUADRATIC_PROBING = 1; // Resolves collisions using quadratic probing.
	public static final int DOUBLE_HASHING = 2; // Resolves collisions using double hashing.
	
	/**
     * Constructs a HashMap with a specified size, probing method, and maximum load factor.
     * 
     * @param B                The size of the HashMap (number of slots).
     * @param redispersionType The collision resolution method (0 for linear, 1 for quadratic, 2 for double hashing).
     * @param maxLF            The maximum allowable load factor (e.g., 0.75).
     */
	@SuppressWarnings("unchecked")
	public HashMap(int B, int redispersionType, double maxLF) {
		this.B = B;
		this.R = getPrevPrimeNumber(B);
		this.redispersionType = redispersionType;
		this.maxLF = maxLF;
		this.minLF = 0;
		array = (HashMapNode<K, V>[]) new HashMapNode[B];
		for (int i = 0; i < B; i++) {
			array[i] = new HashMapNode<K, V>();
		}
	}
	
	/**
     * Constructs a HashMap with additional control over the minimum load factor.
     * 
     * @param B                The size of the HashMap.
     * @param redispersionType The collision resolution method.
     * @param maxLF            The maximum allowable load factor.
     * @param minLF            The minimum allowable load factor.
     */
	public HashMap(int B, int redispersionType, double maxLF, double minLF) {
		this(B, redispersionType, maxLF);
		this.minLF = minLF;
	}

	/**
     * Computes the hash index for an element using the configured collision resolution method.
     * 
     * @param key  The key to hash.
     * @param attempts The number of collision resolution attempts made so far.
     * @return The calculated index, bounded within [0, B).
     */
	public int f(K key, int attempts) {
		switch (redispersionType) {
			case LINEAR_PROBING: return (Math.abs(key.hashCode()) + attempts) % B;
			case QUADRATIC_PROBING: return (Math.abs(key.hashCode()) + attempts * attempts) % B;
			case DOUBLE_HASHING: return (Math.abs(key.hashCode()) + attempts * h(key)) % B;
			default: throw new IllegalStateException("f: This should not happen");
		}
	}

	/**
     * Calculates the secondary hash for double hashing.
     * 
     * @param key The key to hash.
     * @return A secondary index within the range [1, R].
     */
	private int h(K key) {
		return R - (Math.abs(key.hashCode()) % R);
	}

	/**
     * Provides a string representation of the HashMap.
     * 
     * @return A formatted string showing each slot's state and key-value.
     */
	@Override
	public String toString() {
		String str = "";
		for (int i = 0; i < B; i++) {
			// If a node value is null, then is prints "null" otherwise the value.toString()
			str = String.format("%s[%d] (%d) = {%s-%s} - ", str, i, array[i].getState(), array[i].getKey() == null ? "null" : array[i].getKey().toString(), array[i].getValue() == null ? "null" : array[i].getValue().toString());
		}
		return str;
	}

	/**
     * Computes the current load factor of the HashMap.
     * 
     * @return The load factor, defined as (number of elements / size of HashMap).
     */
	public double getLF() {
		return (double) numberOfElements / B;
	}

	/**
     * Adds a key-value pair to the HashMap, resolving collisions using the configured 
     * probing strategy. If the key already exists, updates its value.
     * 
     * @param key   The key to add or update.
     * @param value The value to associate with the key.
     * @return The previous value associated with the key, or null if the key was new.
     * @throws NullPointerException If the key is null.
     */
	public V put(K key, V value) {
		if (key == null) {throw new NullPointerException("The item you try to add is null");}
		int attempts = 0;
		int index;
		int indexFirstDeleted = -1;
		boolean empty;
		boolean equal;
		V previousValue = null;
		do {
			equal = false;
			index = f(key, attempts);
			attempts++;
			
			// If the item is the first deleted, store it
			if (array[index].getState() == HashMapNode.DELETED && indexFirstDeleted == -1) {indexFirstDeleted = index;}
			
			empty = array[index].getState() == HashMapNode.EMPTY;
			if (!empty && key.equals(array[index].getKey())) {equal = true;}
		} while (!(empty || equal));
		if (equal) {
			switch (array[index].getState()) {
				case HashMapNode.VALID: {
					previousValue = array[index].getValue();
					array[index].setValue(value);
					return previousValue;
				}
				case HashMapNode.DELETED: {
					array[index].setValue(value);
					array[index].setState(HashMapNode.VALID);
					break;
				}
				case HashMapNode.EMPTY: {throw new IllegalStateException("The equals must not be activated if the state is EMPTY");}
				default: {throw new IllegalStateException("Unexpected value: " + array[index].getState());}
			}
		} else {
			if (indexFirstDeleted == -1) {
				array[index].setKey(key);
				array[index].setValue(value);
				array[index].setState(HashMapNode.VALID);
			} else {
				array[indexFirstDeleted].setKey(key);
				array[indexFirstDeleted].setValue(value);
				array[indexFirstDeleted].setState(HashMapNode.VALID);
			}
		}
		numberOfElements++;
		if (getLF() >= maxLF) { dynamicResize(getNextPrimeNumber(B * 2)); }
		return previousValue;
	}

	/**
     * Removes a key-value pair from the HashMap.
     * 
     * @param key The key to remove.
     * @return The value associated with the key before removal.
     * @throws NullPointerException  If the key is null.
     * @throws IllegalArgumentException If the key is not found.
     */
	public V remove(K key) {
		if (key == null) {throw new NullPointerException("The key you try to remove is null");}
		int attempts = 0;
		int index;
		V value;
		do {
			index = f(key, attempts++);
		} while (array[index].getState() != HashMapNode.EMPTY && array[index].getKey() != key);
		if (array[index].getState() == HashMapNode.EMPTY) {throw new IllegalArgumentException("The element you try to remove is not in the set");}
		array[index].setState(HashMapNode.DELETED);
		value = array[index].getValue();
		numberOfElements--;
		if (getLF() < minLF) { dynamicResize(getNextPrimeNumber(B / 2)); }
		return value;
	}

	/**
     * Searches for a key in the HashMap.
     * 
     * @param key The key to search for.
     * @return The value associated with the key, or null if the key does not exist.
     * @throws NullPointerException If the key is null.
     */
	public V search(K key) {
		if (key == null) {throw new NullPointerException("The item you try to search is null");}
		int attempts = 0;
		int index;
		do {
			index = f(key, attempts);
			if (array[index].getKey() == key && array[index].getState() != HashMapNode.DELETED) {return array[index].getValue();}
			attempts++;
		} while (array[index].getState() != HashMapNode.EMPTY);
		return null;
	}

	/**
     * Checks if a given number is prime.
     * 
     * @param number The number to evaluate.
     * @return {@code true} if the number is prime; {@code false} otherwise.
     */
	public static boolean isPrime(int number) {
		if (number <= 1) {return false;} // Numbers less than 2 are not prime.
		for (int i = 2; i <= Math.sqrt(number); i++) {
			if (number % i == 0) {return false;} // Divisible by i -> not prime.
		}
		return true; // No divisors found -> prime number.
	}

	/**
     * Finds the next prime number greater than or equal to the given number.
     * 
     * @param number The starting point for the search.
     * @return The next prime number.
     */
	public static int getNextPrimeNumber(int number) {
		if (number <= 1) {return 2;} // Smallest prime number.
		if (number % 2 == 1) {number++;} // Start with the next odd number.
		while (!isPrime(++number)) {number++;} // Skip even numbers.
		return number;
	}

	/**
     * Finds the largest prime number smaller than the given number.
     * 
     * @param number The starting point for the search.
     * @return The largest prime number smaller than {@code number}.
     */
	public static int getPrevPrimeNumber(int number) {
		while (--number > 1) { // Decrease number until a prime is found.
            if (isPrime(number)) return number;
        }
        return 2; // The last prime number
    }
	
	/**
     * Dynamically resizes the HashMap to accommodate more elements or improve efficiency.
     * 
     * @param newSize The new size for the HashMap; must be a prime number and at least as large as the number of elements.
     * @throws IllegalArgumentException If the new size is smaller than the current number of elements.
     */
	public void dynamicResize(int newSize) {
		if (newSize < numberOfElements) {throw new IllegalArgumentException("The size must be at least the number of elements");}
		HashMap<K, V> newHashMap = new HashMap<K, V>(newSize, redispersionType, maxLF);
		
		for (HashMapNode<K, V> node : array) {
			if (node.getState() == HashMapNode.VALID) {
				newHashMap.put(node.getKey(), node.getValue());
			}
		}
		
		this.B = newHashMap.B;
		this.R = newHashMap.R;
		this.array = newHashMap.array;
	}
}
