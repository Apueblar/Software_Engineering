package test.set;
import static org.junit.Assert.*;

import org.junit.Test;

import main.set.HashTable;

/**
 * Test class for the HashTable implementation.
 * Uses JUnit to verify the correctness of the HashTable methods.
 */
public class HashTableTest {

	/**
     * Tests the default state of a newly initialized HashTable.
     * Ensures the toString() representation is correct.
     */
	@Test
    public void testTable() {
        // Class Examples
        HashTable<Integer> h = new HashTable<Integer>(5, HashTable.LINEAR_PROBING, 0.5);
        
        assertEquals (h.toString(),"[0] (0) = null - [1] (0) = null - [2] (0) = null - [3] (0) = null - [4] (0) = null - ");
    }
	
	/**
     * Tests the hash function 'f' for integer elements with linear and quadratic probing.
     */
	@Test
	public void testFInteger() {
		// Example
		HashTable<Integer> a = new HashTable<Integer>(5, HashTable.LINEAR_PROBING, 0.5);
		assertEquals(2, a.f(7, 0));
		assertEquals(3, a.f(7, 1));
		assertEquals(4, a.f(7, 2));
		assertEquals(0, a.f(7, 3));
		
		// Example
		HashTable<Integer> b = new HashTable<Integer>(5, HashTable.QUADRATIC_PROBING, 0.5);
		assertEquals(2, b.f(7, 0));
		assertEquals(3, b.f(7, 1));
		assertEquals(1, b.f(7, 2));
		assertEquals(1, b.f(7, 3));
	}
	
	/**
     * Tests the hash function 'f' for character elements with linear and quadratic probing.
     */
	@Test
	public void testFCharacter() {
		// Example
		HashTable<Character> a = new HashTable<Character>(5, HashTable.LINEAR_PROBING, 0.5);
		assertEquals(0, a.f('A', 0));
		assertEquals(1, a.f('A', 1));
		assertEquals(2, a.f('A', 2));
		assertEquals(3, a.f('A', 3));
		
		// Example
		HashTable<Character> b = new HashTable<Character>(5, HashTable.QUADRATIC_PROBING, 0.5);
		assertEquals(0, b.f('A', 0));
		assertEquals(1, b.f('A', 1));
		assertEquals(4, b.f('A', 2));
		assertEquals(4, b.f('A', 3));
	}
	
	/**
     * Tests the prime number utility methods for finding primes and checking primality.
     */
	@Test
	public void testPrimeNumber() {
		assertFalse(HashTable.isPrime(1));
		assertTrue(HashTable.isPrime(2));
		assertTrue(HashTable.isPrime(3));
		assertFalse(HashTable.isPrime(4));
		assertTrue(HashTable.isPrime(5));
		assertFalse(HashTable.isPrime(6));
		assertTrue(HashTable.isPrime(7));
		assertFalse(HashTable.isPrime(8));
		assertFalse(HashTable.isPrime(9));
		assertFalse(HashTable.isPrime(10));
		assertTrue(HashTable.isPrime(11));
		assertFalse(HashTable.isPrime(12));
		assertTrue(HashTable.isPrime(13));
		assertFalse(HashTable.isPrime(14));
		assertFalse(HashTable.isPrime(15));
		assertFalse(HashTable.isPrime(16));
		assertTrue(HashTable.isPrime(17));
		
		assertEquals(2, HashTable.getNextPrimeNumber(1));
		assertEquals(3, HashTable.getNextPrimeNumber(2));
		assertEquals(5, HashTable.getNextPrimeNumber(3));
		assertEquals(5, HashTable.getNextPrimeNumber(4));
		assertEquals(7, HashTable.getNextPrimeNumber(5));
		assertEquals(7, HashTable.getNextPrimeNumber(6));
		assertEquals(11, HashTable.getNextPrimeNumber(7));
		assertEquals(11, HashTable.getNextPrimeNumber(8));
		assertEquals(11, HashTable.getNextPrimeNumber(9));
		assertEquals(11, HashTable.getNextPrimeNumber(10));
		assertEquals(13, HashTable.getNextPrimeNumber(11));
		
		assertEquals(13, HashTable.getPrevPrimeNumber(15));
		assertEquals(13, HashTable.getPrevPrimeNumber(14));
		assertEquals(11, HashTable.getPrevPrimeNumber(13));
		assertEquals(11, HashTable.getPrevPrimeNumber(12));
		assertEquals(7, HashTable.getPrevPrimeNumber(11));
		assertEquals(7, HashTable.getPrevPrimeNumber(10));
		assertEquals(7, HashTable.getPrevPrimeNumber(9));
		assertEquals(7, HashTable.getPrevPrimeNumber(8));
		assertEquals(5, HashTable.getPrevPrimeNumber(7));
		assertEquals(5, HashTable.getPrevPrimeNumber(6));
		assertEquals(3, HashTable.getPrevPrimeNumber(5));
		assertEquals(3, HashTable.getPrevPrimeNumber(4));
		assertEquals(2, HashTable.getPrevPrimeNumber(3));
	}
	
	/**
     * Tests adding, searching, and removing elements from the HashTable.
     */
	@Test
	public void testAddSearchRemove() {
		// Example
		HashTable<Integer> b = new HashTable<Integer>(5, HashTable.QUADRATIC_PROBING, 1.0);
		b.add(4);
		b.add(13);
		b.add(24);
		b.add(3);
		
		assertEquals("[0] (1) = 24 - [1] (0) = null - [2] (1) = 3 - [3] (1) = 13 - [4] (1) = 4 - ", b.toString());
		assertTrue(b.search(3));
		assertFalse(b.search(12));
		
		b.remove(24);
		assertEquals("[0] (2) = 24 - [1] (0) = null - [2] (1) = 3 - [3] (1) = 13 - [4] (1) = 4 - ", b.toString());
		
		assertTrue(b.search(3));
		b.add(15);
		assertTrue(b.search(3));
		assertEquals("[0] (1) = 15 - [1] (0) = null - [2] (1) = 3 - [3] (1) = 13 - [4] (1) = 4 - ", b.toString());
	}
	
	/**
     * Tests the Load Factor (LF) calculation and behavior of HashTable during element insertion/removal.
     */
	@Test
	public void testLF() {
		// Example
		HashTable<Integer> a = new HashTable<Integer>(5, HashTable.LINEAR_PROBING, 1.0);
		a.add(4);
		assertEquals (0.2, a.getLF(), 0.01);
		a.add(13);
		assertEquals (0.4, a.getLF(), 0.01);
		a.add(24);
		assertEquals (0.6, a.getLF(), 0.01);
		a.add(3);
		assertEquals (0.8, a.getLF(), 0.01);
		
		assertEquals("[0] (1) = 24 - [1] (1) = 3 - [2] (0) = null - [3] (1) = 13 - [4] (1) = 4 - ", a.toString());
		
		a.remove(24);
		assertEquals("[0] (2) = 24 - [1] (1) = 3 - [2] (0) = null - [3] (1) = 13 - [4] (1) = 4 - ", a.toString());
		assertEquals (0.6, a.getLF(), 0.01);
		
		a.add(15);
		assertEquals("[0] (1) = 15 - [1] (1) = 3 - [2] (0) = null - [3] (1) = 13 - [4] (1) = 4 - ", a.toString());
		
		assertEquals (0.8, a.getLF(), 0.01);
	}
}
