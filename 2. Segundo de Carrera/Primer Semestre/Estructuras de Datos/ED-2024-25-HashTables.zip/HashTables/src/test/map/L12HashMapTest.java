package test.map;

import static org.junit.Assert.*;

import org.junit.Test;

import main.map.HashMap;

public class L12HashMapTest {

	@Test
	public void testFInteger() 
	{
		// Example
		HashMap<Integer, String> a = new HashMap<Integer, String>(5, HashMap.LINEAR_PROBING, 0.5);
		assertEquals(2, a.f(7, 0));
		assertEquals(3, a.f(7, 1));
		assertEquals(4, a.f(7, 2));
		assertEquals(0, a.f(7, 3));
		
		// Example
		HashMap<Integer, String> b = new HashMap<Integer, String>(5, HashMap.QUADRATIC_PROBING, 0.5);
		assertEquals(2, b.f(7, 0));
		assertEquals(3, b.f(7, 1));
		assertEquals(1, b.f(7, 2));
		assertEquals(1, b.f(7, 3));
		
		// Example
		HashMap<Integer, String> c = new HashMap<Integer, String>(5, HashMap.DOUBLE_HASHING, 0.5);
		assertEquals(2, c.f(7, 0));
		assertEquals(4, c.f(7, 1));
		assertEquals(1, c.f(7, 2));
		assertEquals(3, c.f(7, 3));
	}
	
	@Test
	public void testFCharacter() 
	{
		// Example
		HashMap<Character, Boolean> a = new HashMap<Character, Boolean>(5, HashMap.LINEAR_PROBING, 0.5);
		assertEquals(0, a.f('A', 0));
		assertEquals(1, a.f('A', 1));
		assertEquals(2, a.f('A', 2));
		assertEquals(3, a.f('A', 3));
		
		// Example
		HashMap<Character, Boolean> b = new HashMap<Character, Boolean>(5, HashMap.QUADRATIC_PROBING, 0.5);
		assertEquals(0, b.f('A', 0));
		assertEquals(1, b.f('A', 1));
		assertEquals(4, b.f('A', 2));
		assertEquals(4, b.f('A', 3));
		
		// Example
		HashMap<Character, Boolean> c = new HashMap<Character, Boolean>(5, HashMap.DOUBLE_HASHING, 0.5);
		assertEquals(0, c.f('A', 0));
		assertEquals(1, c.f('A', 1));
		assertEquals(2, c.f('A', 2));
		assertEquals(3, c.f('A', 3));
	}

	@Test
	public void testResizing()
	{
		// Example
		HashMap<Integer, Character> a = new HashMap<Integer, Character>(5, HashMap.LINEAR_PROBING, 0.5);
		a.put(4, 'D');
		assertEquals (0.2, a.getLF(), 0.01);
		a.put(13, 'M');
		assertEquals (0.4, a.getLF(), 0.01);
		assertEquals ("[0] (0) = {null-null} - [1] (0) = {null-null} - [2] (0) = {null-null} - [3] (1) = {13-M} - [4] (1) = {4-D} - ", a.toString());
        
		a.put(24, 'W');
		assertEquals (0.27, a.getLF(), 0.01);
		assertEquals("[0] (0) = {null-null} - [1] (0) = {null-null} - [2] (1) = {24-W} - [3] (1) = {13-M} - [4] (1) = {4-D} - [5] (0) = {null-null} - [6] (0) = {null-null} - [7] (0) = {null-null} - [8] (0) = {null-null} - [9] (0) = {null-null} - [10] (0) = {null-null} - ", a.toString());

		a.put(3, 'C');
		assertEquals("[0] (0) = {null-null} - [1] (0) = {null-null} - [2] (1) = {24-W} - [3] (1) = {13-M} - [4] (1) = {4-D} - [5] (1) = {3-C} - [6] (0) = {null-null} - [7] (0) = {null-null} - [8] (0) = {null-null} - [9] (0) = {null-null} - [10] (0) = {null-null} - ", a.toString());
	}
	
	@Test
	public void testModifiedput()
	{
		// Example
		HashMap<Integer, String> a = new HashMap<Integer, String>(5, HashMap.LINEAR_PROBING, 1);
		a.put(0, "0A");
		a.put(5, "5A");
		a.put(10, "10A");
		assertEquals("[0] (1) = {0-0A} - [1] (1) = {5-5A} - [2] (1) = {10-10A} - [3] (0) = {null-null} - [4] (0) = {null-null} - ", a.toString());
		a.remove(5);
		assertEquals("[0] (1) = {0-0A} - [1] (2) = {5-5A} - [2] (1) = {10-10A} - [3] (0) = {null-null} - [4] (0) = {null-null} - ", a.toString());
		a.put(15, "15A");
		assertEquals("[0] (1) = {0-0A} - [1] (1) = {15-15A} - [2] (1) = {10-10A} - [3] (0) = {null-null} - [4] (0) = {null-null} - ", a.toString());
		a.remove(0);
		a.remove(15);
		assertEquals("[0] (2) = {0-0A} - [1] (2) = {15-15A} - [2] (1) = {10-10A} - [3] (0) = {null-null} - [4] (0) = {null-null} - ", a.toString());
		a.put(15, "15A");
		assertEquals("[0] (2) = {0-0A} - [1] (1) = {15-15A} - [2] (1) = {10-10A} - [3] (0) = {null-null} - [4] (0) = {null-null} - ", a.toString());
		a.remove(15);
		assertEquals("[0] (2) = {0-0A} - [1] (2) = {15-15A} - [2] (1) = {10-10A} - [3] (0) = {null-null} - [4] (0) = {null-null} - ", a.toString());
		a.put(5, "5A");
		assertEquals("[0] (1) = {5-5A} - [1] (2) = {15-15A} - [2] (1) = {10-10A} - [3] (0) = {null-null} - [4] (0) = {null-null} - ", a.toString());
		a.put(0, "0A");
		assertEquals("[0] (1) = {5-5A} - [1] (1) = {0-0A} - [2] (1) = {10-10A} - [3] (0) = {null-null} - [4] (0) = {null-null} - ", a.toString());
		a.remove(5);
		a.remove(0);
		a.remove(10);
		// LOW MIN FACTOR
		assertEquals (0.0, a.getLF(), 0.01);
		assertEquals("[0] (2) = {5-5A} - [1] (2) = {0-0A} - [2] (2) = {10-10A} - [3] (0) = {null-null} - [4] (0) = {null-null} - ", a.toString());
		a.put(9, "9A");
		assertEquals("[0] (2) = {5-5A} - [1] (2) = {0-0A} - [2] (2) = {10-10A} - [3] (0) = {null-null} - [4] (1) = {9-9A} - ", a.toString());
		a.remove(9);
		a.put(0, "0A");
		assertEquals("[0] (2) = {5-5A} - [1] (1) = {0-0A} - [2] (2) = {10-10A} - [3] (0) = {null-null} - [4] (2) = {9-9A} - ", a.toString());
		a.put(0, "0B");
		assertEquals("[0] (2) = {5-5A} - [1] (1) = {0-0B} - [2] (2) = {10-10A} - [3] (0) = {null-null} - [4] (2) = {9-9A} - ", a.toString());
	}
}
