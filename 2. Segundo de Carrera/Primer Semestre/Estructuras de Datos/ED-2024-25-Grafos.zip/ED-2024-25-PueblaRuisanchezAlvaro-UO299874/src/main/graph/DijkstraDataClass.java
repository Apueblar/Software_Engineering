package main.graph;

public class DijkstraDataClass {
	
	int nodeIndex;
	double dDijkstra[];// Dijkstra's D Vector
	int pDijkstra[]; // Dijkstra's P vector

	public DijkstraDataClass(int nNodes, int index) {
		nodeIndex = index;
		dDijkstra = new double[nNodes]; // Vector D de Dijkstra
		pDijkstra = new int[nNodes]; // Vector P de Dijkstra
	}

	public DijkstraDataClass(int nNodes, int index, double[] d, int[] p) {
		this(nNodes, index);
		setdDijkstra(d);
		setpDijkstra(p);
	}

	/**
	 * Returns the origin node used for the Dijkstra algorithm
	 * @return The origin node
	 */
	public int getNodeIndex() {
		return nodeIndex;
	}

	/**
	 * Sets the origin node
	 * @param nodeIndex Origin node
	 */
	public void setNodeIndex(int nodeIndex) {
		this.nodeIndex = nodeIndex;
	}

	/**
	 * Returns Dijkstra's D matrix (Minimal cost path)
	 * @return Dijkstra's D matrix
	 */
	public double[] getdDijkstra() {
		return dDijkstra;
	}

	/**
	 * Sets Dijkstra's D matrix (Minimal cost path)
	 * @param dDijkstra Dijkstra's D matrix
	 */
	public void setdDijkstra(double[] dDijkstra) {
		this.dDijkstra = dDijkstra;
	}

	/**
	 * Returns Dijkstra's P matrix (Last Pivot from the minimal cost path)
	 * @return Dijkstra's D matrix
	 */
	public int[] getpDijkstra() {
		return pDijkstra;
	}

	/**
	 * Sets Dijkstra's P matrix (Last Pivot from the minimal cost path)
	 * @param pDijkstra Dijkstra's P matrix
	 */
	public void setpDijkstra(int[] pDijkstra) {
		this.pDijkstra = pDijkstra;
	}
}
