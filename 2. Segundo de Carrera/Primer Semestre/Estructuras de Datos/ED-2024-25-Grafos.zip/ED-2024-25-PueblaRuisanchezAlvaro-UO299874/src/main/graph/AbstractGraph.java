package main.graph;

import java.util.Locale;

public abstract class AbstractGraph<T> {

	protected int size;
	protected T[] nodes;
	protected boolean[][] edges;
	protected double[][] weights;
	public final static int INDEX_NOT_FOUND = -1;
	
	@SuppressWarnings("unchecked")
	public AbstractGraph(int maxSize) {
		if(maxSize <= 0) {throw new IllegalArgumentException("The capacity must be greater than 0");}
		size = 0;
		nodes = (T[]) new Object[maxSize];
		edges = new boolean[maxSize][maxSize];
		weights = new double[maxSize][maxSize];
	}
	
	/**
	 * Returns the size of the graph
	 * @return The size of the graph
	 */
	public int getSize() {
		return size;
	}

	@Override
	public String toString() {
		String arrayNodes = "";
		String matrixEdges = "";
		String matrixWeights = "";
		if (size != 0) {
			
			arrayNodes = nodes[0].toString();
			matrixEdges += "[";
			matrixWeights += "[";
			
			if(edges[0][0]) {
				matrixEdges += "true";
				matrixWeights = String.format(Locale.US, "%s%.1f", matrixWeights, weights[0][0]);
			} else {
				matrixEdges += "false";
				matrixWeights = String.format("%s0.0", matrixWeights);
			}
			for (int j = 1; j < size; j++) {
				if(edges[0][j]) {
					matrixEdges = String.format("%s, true", matrixEdges);
					matrixWeights = String.format(Locale.US, "%s, %.1f", matrixWeights, weights[0][j]);
				} else {
					matrixEdges = String.format("%s, false", matrixEdges);
					matrixWeights = String.format("%s, 0.0", matrixWeights);
				}
			}
			matrixEdges += "]";
			matrixWeights += "]";
			
			for (int i = 1; i < size; i++) {
				arrayNodes = String.format("%s,%s", arrayNodes, nodes[i].toString());
				matrixEdges += ",[";
				matrixWeights += ",[";
				
				if(edges[i][0]) {
					matrixEdges = String.format("%strue", matrixEdges);
					matrixWeights = String.format(Locale.US, "%s%.1f", matrixWeights, weights[i][0]);
				} else {
					matrixEdges = String.format("%sfalse", matrixEdges);
					matrixWeights = String.format("%s0.0", matrixWeights);
				}
				for (int j = 1; j < size; j++) {
					if(edges[i][j]) {
						matrixEdges = String.format("%s, true", matrixEdges);
						matrixWeights = String.format(Locale.US, "%s, %.1f", matrixWeights, weights[i][j]);
					} else {
						matrixEdges = String.format("%s, false", matrixEdges);
						matrixWeights = String.format("%s, 0.0", matrixWeights);
					}
				}
				matrixEdges += "]";
				matrixWeights += "]";
			}
		}
		arrayNodes = String.format("[%s]", arrayNodes);
		matrixEdges = String.format("[%s]", matrixEdges);
		matrixWeights = String.format("[%s]", matrixWeights);
		
		return String.format("AbstractGraph [nodes=%s, edges=%s, weights=%s]",  arrayNodes, matrixEdges, matrixWeights);
	}
}
