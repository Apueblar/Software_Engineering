package main.graph;

import exception.graph.ElementNotPresentException;
import exception.graph.FullStructureException;

public class Graph<T> extends AbstractGraph<T> {

	public static final double INFINITE = Double.POSITIVE_INFINITY;
	public static final int EMPTY = -1;
	private double[][] floydA;
	private int[][] floydP;
	
	public Graph(int maxSize) {
		super(maxSize);
		floydA = new double[maxSize][maxSize];
		floydP = new int[maxSize][maxSize];
	}
	
	/**
	 * Returns the node number at the graph.
	 * @param node Node to check. If null -> NullPointerException
	 * @return INDEX_NOT_FOUND if element does not exist in the graph, otherwise the node number.
	 */
	public int getNode(T node) {
		if (node == null) {throw new NullPointerException("getNode: The node you try to search is null");}
		for (int i = 0; i < size; i++) {
			if(nodes[i].equals(node)) {return i;}
		}
		return INDEX_NOT_FOUND;
	}
	
	/**
	 * Returns a boolean depending if there exists an edge between the origin and the destination
	 * @param origin The origin node
	 * @param destination The destination node
	 * @return true if it exists, false if not.
	 */
	public boolean existsEdge(T origin, T destination) {
		if (origin == null) {throw new NullPointerException("existEdge: The node origin is null");}
		if (destination == null) {throw new NullPointerException("existEdge: The node destination is null");}
		int originPos = getNode(origin);
		if (originPos == INDEX_NOT_FOUND) {return false;}
		int destinationPos = getNode(destination);
		if (destinationPos == INDEX_NOT_FOUND) {return false;}
		return edges[originPos][destinationPos];
	}
	
	/**
	 * Returns the value of the edge connecting the origin node and the destination node
	 * @param origin The origin node
	 * @param destination The destination node
	 * @return The weight of the edge if found, otherwise INDEX_NOT_FOUND
	 */
	public double getEdge(T origin, T destination) {
		if (origin == null) {throw new NullPointerException("getEdge: The node origin is null");}
		if (destination == null) {throw new NullPointerException("getEdge: The node destination is null");}
		int originPos = getNode(origin);
		if (originPos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("addEdge: The origin node you try to link is not in the graph");}
		int destinationPos = getNode(destination);
		if (destinationPos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("addEdge: The destination node you try to link is not in the graph");}
		double weight = weights[originPos][destinationPos];
		if(weight > 0) {return weight;}
		return INDEX_NOT_FOUND;
		
	}
	
	/**
	 * Inserts a new node that is passed as a parameter.
	 * If maximum size surpasses maximumSize -> FullStructureException
	 * @param node The node to add. If node null -> NullPointerException
	 * @return true if the node is correctly inserted, otherwise false.
	 */
	public boolean addNode(T node) {
		if (node == null) {throw new NullPointerException("addNode: The node you try to add is null");}
		if (size >= nodes.length) {throw new FullStructureException("addNode: The maximum size of nodes has passed the limit");}
		if (getNode(node) != INDEX_NOT_FOUND) {return false;}
		
		nodes[size] = node;

		for (int i = 0; i < size; i++) {
			edges[size][i] = false;
			edges[i][size] = false;
			weights[size][i] = 0;
			weights[i][size] = 0;
		}
		edges[size][size] = false;
		weights[size][size] = 0;
		size++;
		return true;
	}
	
	/**
	 * Inserts an edge between the origin and the destination, and records the weight
	 * If origin or destination not found -> ElementNotPresentException 
	 * @param origin the origin node of the edge. If node null -> NullPointerException
	 * @param destination the destination node of the edge. If node null -> NullPointerException
	 * @param weight the weight of the edge (>0)
	 * @return true if the edge is correctly inserted, otherwise false.
	 */
	public boolean addEdge(T origin, T destination, double weight) {
		if (origin == null) {throw new NullPointerException("addEdge: The origin node you try to link is null");}
		if (destination == null) {throw new NullPointerException("addEdge: The destination node you try link to add is null");}
		int originPos = getNode(origin);
		if (originPos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("addEdge: The origin node you try to link is not in the graph");}
		int destinationPos = getNode(destination);
		if (destinationPos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("addEdge: The destination node you try to link is not in the graph");}
		if (weight <= 0) {throw new IllegalArgumentException("addEdge: The weight of the edge must be positive.");}
		
		if(edges[originPos][destinationPos]) {return false;} //already exists an edge
		
		edges[originPos][destinationPos] = true;
		weights[originPos][destinationPos] = weight;
		return true;
		
	}
	
	/**
	 * Removes a given node from the graph
	 * @param node The node to add. If node null -> NullPointerException
	 * @return true if the node is correctly removed, false otherwise.
	 */
	public boolean removeNode(T node) {
		if (node == null) {throw new NullPointerException("removeNode: The node you try to remove is null");}
		int nodePos = getNode(node);
		if (nodePos == INDEX_NOT_FOUND) {return false;}

		size--;
		nodes[nodePos] = nodes[size];
		nodes[size] = null;

		for(int i = 0; i < size; i++) {
			if (i != nodePos) {
				edges[i][nodePos] = edges[i][size];
				weights[i][nodePos] = weights[i][size];
				edges[nodePos][i] = edges[size][i];
				weights[nodePos][i] = weights[size][i];
			}
		}
		edges[nodePos][nodePos] = edges[size][size];
		weights[nodePos][nodePos] = weights[size][size];
		return true;
	}
	
	/**
	 * Removes the edge between the origin and the destination nodes given.
	 * @param origin the origin node of the edge. If node null -> NullPointerException
	 * @param destination the destination node of the edge. If node null -> NullPointerException
	 * @return true if the edge is correctly removed, otherwise false.
	 */
	public boolean removeEdge(T origin, T destination) {
		if (origin == null) {throw new NullPointerException("removeEdge: The origin node you try to disconnect is null");}
		int originPos = getNode(origin);
		if (originPos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("removeEdge: The origin node you try to disconnect is not in the graph");}
		if (destination == null) {throw new NullPointerException("removeEdge: The destination node you try to disconnect is null");}
		int destinationPos = getNode(destination);
		if (destinationPos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("removeEdge: The destination node you try to disconnect is not in the graph");}
		
		if (!edges[originPos][destinationPos]) {return false;} //edge does not exist
		
		edges[originPos][destinationPos] = false;
		weights[originPos][destinationPos] = 0;
		return true;
	}

	/**
	 * Returns the edges matrix of booleans
	 * @return the edges matrix of the graph
	 */
	public boolean[][] getEdges() {
		return edges;
	}

	/**
	 * Returns the weights matrix of doubles
	 * @return the weight matrix of the graph
	 */
	public double[][] getWeights() {
		return weights;
	}
	
	/**
	 * Checks if the out degree of a node is 0 and also if its in degree is greater than 0
	 * @param node The node to check
	 * @return true if it is a drain node, false otherwise
	 */
	public boolean isDrain(T node) {
		if (node == null) {throw new NullPointerException("isDrain: The node you try to check is null");}
		int nodePos = getNode(node);
		if (nodePos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("isDrain: The node you try to check is not in the graph");}
//		boolean in = false;
		for(int j = 0; j < getSize(); j++) {
			if(edges[nodePos][j]) {return false;} //out degree
//			in |= edges[j][nodePos]; //bitwise boolean or
		}
//		return in; //if it must have at least an in degree of 1
		return true;
	}
	
	/**
	 * Checks if the in degree of a node == 0 and also if its out degree > 0
	 * @param node The node to check
	 * @return true if it is a drain node, false otherwise
	 */
	public boolean isSource(T node) {
		if (node == null) {throw new NullPointerException("isSource: The node you try to check is null");}
		int nodePos = getNode(node);
		if (nodePos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("isSource: The node you try to check is not in the graph");}
//		boolean out = false;
		for(int i = 0; i < getSize(); i++) {
			if(edges[i][nodePos]) {return false;} //in degree
//			out |= edges[nodePos][i]; //bitwise boolean or
		}
//		return out; //if it must have at least an out degree of 1
		return true;
	}
	
	/**
	 * Checks if the out degree of a node is 0 and also if its in degree is also 0
	 * @param node The node to check
	 * @return true if it is a drain node, false otherwise
	 */
	public boolean isIsolated(T node) {
		if (node == null) {throw new NullPointerException("isSource: The node you try to check is null");}
		int nodePos = getNode(node);
		if (nodePos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("isSource: The node you try to check is not in the graph");}
		for(int i = 0; i < getSize(); i++) {
			if(edges[i][nodePos] || edges[nodePos][i]) {return false;} //in degree or out degree > 0
		}
		return true;
	}

	/**
	 * Creates a string with the Depth First Traversal of a given node O(n^2)
	 * @param element The node to be searched
	 * @return a string with the Depth First Traversal of the given node
	 */
	public String traverseGraphDF(T element) {
		if (element == null) {throw new NullPointerException("traverseGraphDF: The initial node you try to transverse is null");}
		int elementPos = getNode(element);
		if (elementPos == INDEX_NOT_FOUND) {return null;}
		boolean[] visited = new boolean[getSize()];
		return DFPrint(elementPos, visited);
	}

	/**
	 * Recursive method for traverseGraphDF
	 * @param currentIndex Index to be checked
	 * @param visited Matrix of visited elements
	 * @return A string with the Depth First Traversal of the currentIndex + the previous
	 */
	private String DFPrint(int currentIndex, boolean[] visited) {
		String actual = nodes[currentIndex].toString() + "-";
		visited[currentIndex] = true;
		for(int i = 0; i < getSize(); i++) {
			if(!visited[i] && edges[currentIndex][i]) {actual = String.format("%s%s",actual, DFPrint(i, visited));}
		}
		return actual;
	}

	/**
	 * Initializes the floyd matrices (A and P)
	 * A with 0s in the diagonal and weights, if edge = false -> INFINITE
	 * P with -1s
	 * @param size THe size of the nodes array
	 */
	private void initsFloyd(int size) {
		for(int i = 0; i < size; i++) {
			for(int j = 0; j < size; j++) {
				floydA[i][j] = edges[i][j] ? weights[i][j] : INFINITE;
				floydP[i][j] = EMPTY;
			}
			floydA[i][i] = 0;
		}
	}
	
	/**
	 * Floyd gives the minimal cost paths (A) and a pivot of the minimal paths (P).
	 * Complexity of O(n^3) due to the 3 nested loops
	 */
	public void floyd() {
		initsFloyd(getSize());
		
		for(int pivot = 0; pivot < getSize(); pivot++) {
			for(int i = 0; i < getSize(); i++) {
				for(int j = 0; j < getSize(); j++) {
					if(floydA[i][j] > floydA[i][pivot] + floydA[pivot][j]) {
						floydA[i][j] = floydA[i][pivot] + floydA[pivot][j];
						floydP[i][j] = pivot;
					}
				}
			}
		}
	}

	/**
	 * Returns floyd's A matrix
	 * @return floyd's A matrix
	 */
	public double[][] getA() {
		return floydA;
	}

	/**
	 * Returns floyd's P matrix
	 * @return floyd's P matrix
	 */
	public int[][] getP() {
		return floydP;
	}

	/**
	 * Prints the minimal path between the origin node and the destination node
	 * @param origin origin node
	 * @param destination destination node
	 * @return A string with the to string of the nodes in the middle of the minimal cost path
	 */
	public String printFloydPath(T origin, T destination) {
		if (origin == null) {throw new NullPointerException("printFloydPath: The origin node is null");}
		if (destination == null) {throw new NullPointerException("printFloydPath: The destination node is null");}
		int originPos = getNode(origin);
		int destinationPos = getNode(destination);
		if (originPos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("printFloydPath: The node you try to check is not in the graph");}
		if (destinationPos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("printFloydPath: The node you try to check is not in the graph");}
		
		final String NOTPATHFOUND = "_NO_PATH_FOUND_TO_";
		if(floydA[originPos][destinationPos] == INFINITE) {return NOTPATHFOUND;}
		if(floydP[originPos][destinationPos] == EMPTY) {return "";}
		return printPath(originPos, destinationPos);
	}

	/**
	 * Recursive method to find all the pivots between the origin and destination positions.
	 * @param originPos The origin position
	 * @param destinationPos The destination position
	 * @return The middle pivots.toString() in a string
	 */
	private String printPath(int originPos, int destinationPos) {
		int pivotPos = floydP[originPos][destinationPos]; // Origin - ... - Pivot - ... - Destination
		if(pivotPos == EMPTY) {return "";} // If Origin - Pivot or Pivot - Destination then ""
		return printPath(originPos, pivotPos) + nodes[pivotPos].toString() + printPath(pivotPos, destinationPos);
	}

	/**
	 * Calculates the minimum cost from an origin node to every node in the graph
	 * Complexity of O(n^2) as it has a main loop O(n) and inside (*) it has the getPivot(...) function O(n)
	 * @param originNode The origin node
	 * @return An instance of the DijkstraDataClass with the starting node given as parameter
	 */
	public DijkstraDataClass dijkstra(T originNode) {
		int originNodePos = getNode(originNode);
		if (originNodePos == INDEX_NOT_FOUND) {return null;}
		
		DijkstraDataClass ddc = new DijkstraDataClass(size, getNode(originNode));
		double[] dMinCostOriginTo = ddc.getdDijkstra();
		int[] pLastPivotTo = ddc.getpDijkstra();
		
		initsDijkstra(dMinCostOriginTo , pLastPivotTo , originNodePos);
		
		boolean[] passedNodesS = new boolean[size];
		int pivot = getPivot(passedNodesS, dMinCostOriginTo);
		
		while (pivot != EMPTY) {
			passedNodesS[pivot] = true;
			for(int dest = 0; dest < getSize(); dest++) {
				if(weights[pivot][dest] != 0 && dMinCostOriginTo[dest] > dMinCostOriginTo[pivot] + weights[pivot][dest]) { //if exists edge and currentCost > newCost
					dMinCostOriginTo[dest] = dMinCostOriginTo[pivot] + weights[pivot][dest];
					pLastPivotTo[dest] = pivot;
				}
			}
			pivot = getPivot(passedNodesS, dMinCostOriginTo);
		}
		return ddc;
	}

	/**
	 * Initializes Dijkstra's D and P matrices 
	 * @param dDijkstra Matrix of the minimal cost paths from the origin node to the destination node position (i)
	 * @param pDijkstra Matrix of the latest pivot from the minimal path to the destination node (i)
	 * @param originNode The starting node
	 */
	private void initsDijkstra(double[] dDijkstra, int[] pDijkstra, int originNode) {
		for(int i = 0; i < size; i++) {
			if (edges[originNode][i]) {
				dDijkstra[i] = weights[originNode][i];
				pDijkstra[i] = originNode;
			} else {
				dDijkstra[i] = Graph.INFINITE;
				pDijkstra[i] = Graph.EMPTY;
			}
		}
		dDijkstra[originNode] = 0;
		pDijkstra[originNode] = originNode;
	}
	
	/**
	 * Checks for a possible pivot with the minimum cost to reach that has not been checked already
	 * Complexity of O(n) as it has only 1 loop
	 * @param passedNodesS The boolean list that contains if a node has been checked already
	 * @param dMinCostOriginTo D matrix of minimal costs from the origin to the destination position (i)
	 * @return The node position with minimum cost and not checked, else EMPTY 
	 */
	private int getPivot(boolean[] passedNodesS, double[] dMinCostOriginTo) {
	    double minCost = INFINITE;
	    int pivot = EMPTY;
	    for (int i = 0; i < passedNodesS.length; i++) {
	        if (!passedNodesS[i] && dMinCostOriginTo[i] < minCost) { // Si no ha sido pasado y coste menor
	            minCost = dMinCostOriginTo[i];
	            pivot = i;
	        }
	    }
	    return pivot; // return EMPTY if no valid pivot found (All passed or cost INF)
	}
	
	
	//Extra Methods
	
	/**
	 * Returns number of inward edges
	 * @param node The given node
	 * @return int of number of inward edges
	 */
	public int getInputDegree(T node) {
		if (node == null) {throw new NullPointerException("getInputDegree: The node you try to check is null");}
		int nodePos = getNode(node);
		if (nodePos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("getInputDegree: The node you try to check is not in the graph");}
		int inDegree = 0;
		for(int i = 0; i < getSize(); i++) {
			if(edges[i][nodePos]) {inDegree++;} //in degree + 1
		}
		return inDegree;
	}
	
	/**
	 * Returns number of outward edges
	 * @param node The given node
	 * @return int of number of outward edges
	 */
	public int getOutDegree(T node) {
		if (node == null) {throw new NullPointerException("getOutDegree: The node you try to check is null");}
		int nodePos = getNode(node);
		if (nodePos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("getOutDegree: The node you try to check is not in the graph");}
		int outDegree = 0;
		for(int j = 0; j < getSize(); j++) {
			if(edges[nodePos][j]) {outDegree++;} //out degree + 1
		}
		return outDegree;
	}
	
	/**
	 * Returns the average number of outward degrees / number of nodes
	 * @return number of outward edges / number of nodes
	 */
	public double getBranchingFactor() {
		int outWardDegree = 0;
		for (int i = 0; i < size; i++) {
			T actualNode = nodes[i];
			outWardDegree += getOutDegree(actualNode);
		}
		return (double) outWardDegree / size;
	}
	
	/**
	 * Returns the number of reciprocal edges / total amount of edges
	 * Reciprocal: Exists an AB edge and a BA edges, both with the same weight.
	 * We count a reciprocal edge as 1
	 * @return number of reciprocal edges / total amount of edges
	 */
	public double getReciprocity() {
		double reciprocalEdges = 0;
		double numberOfEdges = 0;
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				if (edges[i][j]) {
					if(i == j) {
						numberOfEdges++;
						reciprocalEdges++;
					}else {
						if(edges[j][i] && weights[i][j] == weights[j][i]) {
							reciprocalEdges += 0.5;
							numberOfEdges += 0.5;
						}else {
							numberOfEdges++;
						}
						
					}
				}
			}
		}
		if (reciprocalEdges == 0) {return 0;}

		return reciprocalEdges / numberOfEdges;
	}
	
	/**
	 * A graph is undirected if all its edges are reciprocal (Reciprocity == 1)
	 * @return True if all the graph is reciprocal
	 */
	public boolean isUndirected() {
		return getReciprocity() == 1.0;
	}
	
	/**
	 * Updates the floyd matrix for only the paths between those nodes, instead of all the graph
	 * @param floydNodes Array of updating nodes
	 */
	public void arrayFloyd(T[] floydNodes) {
		if (floydNodes == null) {throw new NullPointerException("arrayFloyd: The array of nodes you try to check is null");}
		
		for(T pivotT : floydNodes) {
			if (pivotT == null) {throw new NullPointerException("arrayFloyd: The nodes you try to check is null");}
			int pivot = getNode(pivotT);
			if (pivot == INDEX_NOT_FOUND) {throw new ElementNotPresentException("arrayFloyd: The node you try to check is not in the graph");}
			for(int j = 0; j < size; j++) {
				floydA[pivot][j] = edges[pivot][j] ? weights[pivot][j] : INFINITE;
				floydP[pivot][j] = EMPTY;
				floydA[j][pivot] = edges[j][pivot] ? weights[j][pivot] : INFINITE;
				floydP[j][pivot] = EMPTY;
			}
			floydA[pivot][pivot] = 0;
		}
		
		for(T pivotT : floydNodes) {
			int pivot = getNode(pivotT);
			for(int i = 0; i < getSize(); i++) {
				for(int j = 0; j < getSize(); j++) {
					if(floydA[i][pivot] != Graph.INFINITE && floydA[pivot][j] != Graph.INFINITE && floydA[i][j] > floydA[i][pivot] + floydA[pivot][j]) {
						floydA[i][j] = floydA[i][pivot] + floydA[pivot][j];
						floydP[i][j] = pivot;
					}
				}
			}
		}
	}
	
	/**
	 * A node is strongly connected if you can in a node reach every node, and from every other node you can reach the starting node
	 * @param node The node
	 * @return true if is strongly connected
	 */
	public boolean isStronglyConnected(T node) {
		if (node == null) {throw new NullPointerException("isStronglyConnected: The nodes you try to check is null");}
		int nodePos = getNode(node);
		if (nodePos == INDEX_NOT_FOUND) {throw new ElementNotPresentException("isStronglyConnected: The node you try to check is not in the graph");}
		
		floyd();
		
		for(int i = 0; i < size; i++) {
			if (floydA[nodePos][i] == INFINITE || floydA[i][nodePos] == INFINITE) {return false;}
		}
		return true;
	}
	
	/**
	 * A graph is undirected if all their edges are reciprocal
	 * @return A copy of the weight matrix as an undirected graph
	 */
	public double[][] getUndirectedWeights() {
		double[][] newWeights = new double[getSize()][getSize()];
		for (int i = 0; i < getSize(); i++) {
			for (int j = 0; j < getSize(); j++) {
				if (i == j) {
					newWeights[i][j] = weights[i][j];
				} else {
					if (edges[i][j] || edges[j][i]) {
						if (!edges[i][j]) {
							newWeights[i][j] = weights[j][i];
							newWeights[j][i] = weights[j][i];
						} else if (!edges[j][i]) {
							newWeights[i][j] = weights[i][j];
							newWeights[j][i] = weights[i][j];
						} else {
							newWeights[i][j] = Math.min(weights[i][j] , weights[j][i]);
							newWeights[j][i] = Math.min(weights[i][j] , weights[j][i]);
						}
					}
				}
			}
		}
		return newWeights;
	} 
}
















































