package test.graph;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import exception.graph.ElementNotPresentException;
import main.graph.Graph;

public class ExtraExerciseTest {

	Graph<Character> initGraphOfLengthWithNodes(int length) {
		Graph<Character> graph = new Graph<Character>(length);

		for(int i = 0; i < length; i++) {
			graph.addNode((char) (( (int)'A') + i) );
		}
		return graph;
	}
	
	Graph<Character> graphSimplePath1() {
		Graph<Character> g = initGraphOfLengthWithNodes(4); // A B C D
		
		g.addEdge('A', 'B', 1); // A -> B
		g.addEdge('B', 'C', 1); // B -> C
		g.addEdge('C', 'D', 1); // C -> D
		return g; // A -> B -> C -> D
	}
	
	Graph<Character> graphLoopPath1() {
		Graph<Character> g = initGraphOfLengthWithNodes(4); // A B C D
		
		g.addEdge('A', 'B', 1); // A -> B
		g.addEdge('B', 'C', 1); // B -> C
		g.addEdge('C', 'D', 1); // C -> D
		g.addEdge('D', 'A', 1); // D -> A
		return g; // A -> B -> C -> D -> A
	}
	
	Graph<Character> graphFromToAPath1() {
		Graph<Character> g = initGraphOfLengthWithNodes(4); // A B C D
		
		g.addEdge('A', 'B', 1); // A -> B
		g.addEdge('A', 'C', 1); // A -> C
		g.addEdge('A', 'D', 1); // A -> D
		g.addEdge('B', 'A', 1); // B -> A
		g.addEdge('C', 'A', 1); // C -> A
		g.addEdge('D', 'A', 1); // D -> A
		return g; // A <-> B   A <-> C   A <-> D
	}
	
	
	@Test
	public void nullParamsInOutTest() {
		Graph<Character> g = initGraphOfLengthWithNodes(1); //Only A
		
		ElementNotPresentException ex = assertThrows(ElementNotPresentException.class, () -> g.getInputDegree('B'));
		ElementNotPresentException ex1 = assertThrows(ElementNotPresentException.class, () -> g.getOutDegree('B'));
		
		assertNotEquals(null, ex.getMessage());
		assertNotEquals(0, ex.getMessage().length());
		assertNotEquals(null, ex1.getMessage());
		assertNotEquals(0, ex1.getMessage().length());
		
		assertEquals(0, g.getInputDegree('A'), 0.01);
		assertEquals(0, g.getOutDegree('A'), 0.01);
	}
	
	@Test
	public void BranchingInOutTest() {
		Graph<Character> g = initGraphOfLengthWithNodes(2);
		
		g.addEdge('A', 'A', 1); // A -> A
		g.addEdge('A', 'B', 1); // A -> B
		g.addEdge('B', 'A', 1); // B -> A
		g.addEdge('B', 'B', 1); // B -> B
		
		assertEquals(2, g.getInputDegree('A'), 0.01);
		assertEquals(2, g.getOutDegree('A'), 0.01);
		assertEquals(2, g.getBranchingFactor(), 0.01);
	}
	
	@Test
	public void BranchingInOut2Test() {
		Graph<Character> g = initGraphOfLengthWithNodes(6);
		
		g.addEdge('A', 'A', 1); // A -> A
		g.addEdge('A', 'B', 1); // A -> B
		g.addEdge('B', 'B', 1); // B -> B
		
		assertEquals(2, g.getInputDegree('B'), 0.01);
		assertEquals(1, g.getOutDegree('B'), 0.01);
		assertEquals(0.5, g.getBranchingFactor(), 0.01);
	}
	
	@Test
	public void fullReciprocityTest() {
		Graph<Character> g = initGraphOfLengthWithNodes(3);
		assertFalse(g.isUndirected());
		
		g.addEdge('A', 'A', 1); // A -> A
		g.addEdge('A', 'B', 1); // A -> B
		g.addEdge('B', 'A', 1); // B -> A
		g.addEdge('B', 'B', 1); // B -> B
		
		assertEquals(1, g.getReciprocity(), 0.01);
		assertTrue(g.isUndirected());
	}
	
	@Test
	public void partReciprocityTest() {
		Graph<Character> g = initGraphOfLengthWithNodes(3);
		
		g.addEdge('A', 'A', 1); // A -> A
		g.addEdge('B', 'A', 1); // B -> A
		g.addEdge('B', 'B', 1); // B -> B
		
		assertEquals(0.66, g.getReciprocity(), 0.01);
		assertFalse(g.isUndirected());
	}
	
	@Test
	public void differentWeightReciprocityTest() {
		Graph<Character> g = initGraphOfLengthWithNodes(3);
		
		g.addEdge('A', 'A', 2); // A -> A
		g.addEdge('B', 'A', 1); // B -> A (1)
		g.addEdge('A', 'B', 2); // A -> B (2)
		g.addEdge('B', 'B', 3); // B -> B
		g.addEdge('A', 'C', 1); // A -> C
		
		assertEquals(0.4, g.getReciprocity(), 0.01);
		assertFalse(g.isUndirected());
	}

	@Test
	public void ceroReciprocityTest() {
		Graph<Character> g = initGraphOfLengthWithNodes(3);
		
		g.addEdge('A', 'B', 2); // A -> B
		g.addEdge('B', 'C', 3); // B -> C
		g.addEdge('C', 'A', 1); // C -> A
		
		assertEquals(0.0, g.getReciprocity(), 0.01);
		assertFalse(g.isUndirected());
	}
	
	@Test
	public void arrayFloydTest() {
		Graph<Character> g = graphSimplePath1();
		
		assertArrayEquals(new boolean[][] { 
			{ false, true, false, false }, 
			{ false, false, true, false }, 
			{ false, false, false, true },
			{ false, false, false, false }},
				g.getEdges());
		
		assertArrayEquals(new double[][] { 
			{ 0.0, 1.0, 0.0, 0.0 }, 
			{ 0.0, 0.0, 1.0, 0.0 }, 
			{ 0.0, 0.0, 0.0, 1.0 },
			{ 0.0, 0.0, 0.0, 0.0 }}, 
				g.getWeights());
		
		g.floyd();
		
		assertArrayEquals(new int[][] { 
			{ -1, -1,  1,  2 }, 
			{ -1, -1, -1,  2 }, 
			{ -1, -1, -1, -1 },
			{ -1, -1, -1, -1 } }, 
				g.getP());
		assertArrayEquals(new double[][] { 
			{ 00.0,           1.0,            2.0,            3.0 },
			{ Graph.INFINITE, 00.0,           1.0,            2.0 },
			{ Graph.INFINITE, Graph.INFINITE, 0.0,            1.0 },
			{ Graph.INFINITE, Graph.INFINITE, Graph.INFINITE, 00.0 } },
				g.getA());
		
		g.addEdge('A', 'C', 0.5);
		Character[] nodesCharacters = new Character[4];
		nodesCharacters[0] = 'A';
		nodesCharacters[1] = 'B';
		nodesCharacters[2] = 'C';
		nodesCharacters[3] = 'D';
		g.arrayFloyd(nodesCharacters);
		
		assertArrayEquals(new int[][] { 
			{ -1, -1, -1,  2 }, 
			{ -1, -1, -1,  2 }, 
			{ -1, -1, -1, -1 },
			{ -1, -1, -1, -1 } }, 
				g.getP());
		assertArrayEquals(new double[][] { 
			{ 00.0,           1.0,            0.5,            1.5 },
			{ Graph.INFINITE, 00.0,           1.0,            2.0 },
			{ Graph.INFINITE, Graph.INFINITE, 0.0,            1.0 },
			{ Graph.INFINITE, Graph.INFINITE, Graph.INFINITE, 00.0 } },
				g.getA());
		
		g.removeEdge('A', 'C');
		g.arrayFloyd(nodesCharacters);
		assertArrayEquals(new int[][] { 
			{ -1, -1,  1,  2 }, 
			{ -1, -1, -1,  2 }, 
			{ -1, -1, -1, -1 },
			{ -1, -1, -1, -1 } }, 
				g.getP());
		assertArrayEquals(new double[][] { 
			{ 00.0,           1.0,            2.0,            3.0 },
			{ Graph.INFINITE, 00.0,           1.0,            2.0 },
			{ Graph.INFINITE, Graph.INFINITE, 0.0,            1.0 },
			{ Graph.INFINITE, Graph.INFINITE, Graph.INFINITE, 00.0 } },
				g.getA());
	}
	
	@Test
	public void arrayFloydTestNullTest() {
		Graph<Character> g = initGraphOfLengthWithNodes(4); //A B C D
		
		NullPointerException ex = assertThrows(NullPointerException.class, () -> g.arrayFloyd(null));
		Character[] c = new Character[1];
		NullPointerException ex1 = assertThrows(NullPointerException.class, () -> g.arrayFloyd(c));
		c[0] = 'E';
		ElementNotPresentException ex2 = assertThrows(ElementNotPresentException.class, () -> g.arrayFloyd(c));
		
		assertNotEquals(null, ex.getMessage());
		assertNotEquals(0, ex.getMessage().length());
		assertNotEquals(null, ex1.getMessage());
		assertNotEquals(0, ex1.getMessage().length());
		assertNotEquals(null, ex2.getMessage());
		assertNotEquals(0, ex2.getMessage().length());
	}

	@Test
	public void getUndirectedWeightsTest() {
		Graph<Character> g = graphSimplePath1();
		
		assertArrayEquals(new double[][] { 
			{ 0, 1, 0, 0 }, 
			{ 1, 0, 1, 0 }, 
			{ 0, 1, 0, 1 },
			{ 0, 0, 1, 0 } }, 
				g.getUndirectedWeights());
		
		g.addEdge('A', 'C', 2);
		assertArrayEquals(new double[][] { 
			{ 0, 1, 2, 0 }, 
			{ 1, 0, 1, 0 }, 
			{ 2, 1, 0, 1 },
			{ 0, 0, 1, 0 } }, 
				g.getUndirectedWeights());
		
		g.addEdge('B', 'A', 0.5);
		assertArrayEquals(new double[][] { 
			{ 0, 0.5, 2, 0 }, 
			{ 0.5, 0, 1, 0 }, 
			{ 2, 1, 0, 1 },
			{ 0, 0, 1, 0 } }, 
				g.getUndirectedWeights());
	}
	
	@Test
	public void isStronglyConnectedTest() {
		Graph<Character> g = graphSimplePath1(); // None are strongly connected
		
		assertFalse(g.isStronglyConnected('A'));
		assertFalse(g.isStronglyConnected('B'));
		assertFalse(g.isStronglyConnected('C'));
		assertFalse(g.isStronglyConnected('D'));
		
		Graph<Character> g1 = graphLoopPath1(); // All are stronngly connected
		
		assertTrue(g1.isStronglyConnected('A'));
		assertTrue(g1.isStronglyConnected('B'));
		assertTrue(g1.isStronglyConnected('C'));
		assertTrue(g1.isStronglyConnected('D'));
		
		Graph<Character> g2 = graphFromToAPath1(); // Only A is strongly connected
		
		assertTrue(g2.isStronglyConnected('A'));
		assertTrue(g2.isStronglyConnected('B'));
		assertTrue(g2.isStronglyConnected('C'));
		assertTrue(g2.isStronglyConnected('D'));
	}
	
	@Test
	public void isStronglyConnectedNullTest() {
		Graph<Character> g = initGraphOfLengthWithNodes(4); //A B C D
		
		NullPointerException ex = assertThrows(NullPointerException.class, () -> g.isStronglyConnected(null));
		ElementNotPresentException ex1 = assertThrows(ElementNotPresentException.class, () -> g.isStronglyConnected('E'));
		
		assertNotEquals(null, ex.getMessage());
		assertNotEquals(0, ex.getMessage().length());
		assertNotEquals(null, ex1.getMessage());
		assertNotEquals(0, ex1.getMessage().length());
	}
}

























