package test.graphEx24;

import static org.junit.Assert.*;

import org.junit.Test;

import exception.graph.ElementNotPresentException;
import main.graph.GraphEx24;

public class ExamTests {

	GraphEx24<Character> initGraphOfLengthWithNodes(int length) {
		GraphEx24<Character> graph = new GraphEx24<Character>(length);

		for(int i = 0; i < length; i++) {
			graph.addNode((char) (( (int)'A') + i) );
		}
		return graph;
	}
	
	GraphEx24<Character> graphSimplePath1() {
		GraphEx24<Character> g = initGraphOfLengthWithNodes(4); // A B C D
		
		g.addEdge('A', 'B', 1); // A -> B
		g.addEdge('B', 'C', 1); // B -> C
		g.addEdge('C', 'D', 1); // C -> D
		return g; // A -> B -> C -> D
	}
	
	GraphEx24<Character> graphLoopPath1() {
		GraphEx24<Character> g = initGraphOfLengthWithNodes(4); // A B C D
		
		g.addEdge('A', 'B', 1); // A -> B
		g.addEdge('B', 'C', 1); // B -> C
		g.addEdge('C', 'D', 1); // C -> D
		g.addEdge('D', 'A', 1); // D -> A
		return g; // A -> B -> C -> D -> A
	}
	
	GraphEx24<Character> graphFromToAPath1() {
		GraphEx24<Character> g = initGraphOfLengthWithNodes(4); // A B C D
		
		g.addEdge('A', 'B', 1); // A -> B
		g.addEdge('A', 'C', 1); // A -> C
		g.addEdge('A', 'D', 1); // A -> D
		g.addEdge('B', 'A', 1); // B -> A
		g.addEdge('C', 'A', 1); // C -> A
		g.addEdge('D', 'A', 1); // D -> A
		return g; // A <-> B   A <-> C   A <-> D
	}
	
	@Test
	public void printDijkstraPathNullTest() {
		GraphEx24<Character> g = initGraphOfLengthWithNodes(4); //A B C D
		
		NullPointerException ex = assertThrows(NullPointerException.class, () -> g.printDijkstraPath(null, 'A'));
		NullPointerException ex1 = assertThrows(NullPointerException.class, () -> g.printDijkstraPath('E', null));
		
		ElementNotPresentException ex2 = assertThrows(ElementNotPresentException.class, () -> g.printDijkstraPath('E', 'B'));
		ElementNotPresentException ex3 = assertThrows(ElementNotPresentException.class, () -> g.printDijkstraPath('A', 'F'));
		
		assertNotEquals(null, ex.getMessage());
		assertNotEquals(0, ex.getMessage().length());
		assertNotEquals(null, ex1.getMessage());
		assertNotEquals(0, ex1.getMessage().length());
		assertNotEquals(null, ex2.getMessage());
		assertNotEquals(0, ex2.getMessage().length());
		assertNotEquals(null, ex3.getMessage());
		assertNotEquals(0, ex3.getMessage().length());
	}
	
	@Test
	public void printDijkstraPath1Test() {
		GraphEx24<Character> g = graphSimplePath1(); // A -> B -> C -> D
		
		Character origin = 'A';
		Character destination = 'D';
		
		assertEquals("A\tB\tC\tD", g.printDijkstraPath(origin, destination));
		
		destination = 'B';
		assertEquals("A\tB", g.printDijkstraPath(origin, destination));
		
		destination = 'A';
		assertEquals("A", g.printDijkstraPath(origin, destination));
		
		g.removeEdge(origin, 'B'); // A  B -> C -> D
		assertEquals("", g.printDijkstraPath(origin, 'D'));
	}

	@Test
	public void printDijkstraPath2Test() {
		GraphEx24<Character> g = graphLoopPath1(); // A -> B -> C -> D -> A
		
		Character origin = 'A';
		Character destination = 'D';
		
		assertEquals("A\tB\tC\tD", g.printDijkstraPath(origin, destination));
		
		destination = 'B';
		assertEquals("A\tB", g.printDijkstraPath(origin, destination));
		
		destination = 'A';
		assertEquals("A", g.printDijkstraPath(origin, destination));
	}
	
	@Test
	public void printDijkstraPath3Test() {
		GraphEx24<Character> g = graphSimplePath1(); // A -> B -> C -> D
		
		Character origin = 'A';
		Character destination = 'D';
		
		g.addEdge(origin, 'C', 0.5);
		
		assertEquals("A\tC\tD", g.printDijkstraPath(origin, destination));
		
		destination = 'B';
		assertEquals("A\tB", g.printDijkstraPath(origin, destination));
		
		destination = 'C';
		assertEquals("A\tC", g.printDijkstraPath(origin, destination));
		
		destination = 'A';
		assertEquals("A", g.printDijkstraPath(origin, destination));
	}
	
	@Test
	public void floydShortNullTest() {
		GraphEx24<Character> g = new GraphEx24<Character>(4);
		
		IllegalStateException ex = assertThrows(IllegalStateException.class, () -> g.floydShort());
		
		assertNotEquals(null, ex.getMessage());
		assertNotEquals(0, ex.getMessage().length());
	}
	
	@Test
	public void floydShort1Test() {
		GraphEx24<Character> g = graphSimplePath1();
		
		g.floydShort();
		
		assertArrayEquals(new int[][] { 
			{ -1, -1,  1,  2 }, 
			{ -1, -1, -1,  2 }, 
			{ -1, -1, -1, -1 },
			{ -1, -1, -1, -1 }
			}, g.getPShort());
		
		assertArrayEquals(new double[][] { 
			{  0,  1,  2,  3 }, 
			{ GraphEx24.INFINITE,  0,  1,  2 }, 
			{ GraphEx24.INFINITE, GraphEx24.INFINITE,  0,  1 },
			{ GraphEx24.INFINITE, GraphEx24.INFINITE, GraphEx24.INFINITE,  0 }
			}, g.getAShort());
		
		
		g.addEdge('A', 'C', 3.0);
		g.floydShort();
		
		assertArrayEquals(new int[][] { 
			{ -1, -1, -1,  2 }, 
			{ -1, -1, -1,  2 }, 
			{ -1, -1, -1, -1 },
			{ -1, -1, -1, -1 }
			}, g.getPShort());
		
		assertArrayEquals(new double[][] { 
			{  0, 1, 1, 2 }, 
			{ GraphEx24.INFINITE,  0,  1,  2 }, 
			{ GraphEx24.INFINITE, GraphEx24.INFINITE,  0,  1 },
			{ GraphEx24.INFINITE, GraphEx24.INFINITE, GraphEx24.INFINITE,  0 }
			}, g.getAShort());
	}
	
	@Test
	public void floydShort2Test() {
		GraphEx24<Character> g = graphLoopPath1(); // A -> B -> C -> D -> A
		
		g.floydShort();
		
		assertArrayEquals(new int[][] { 
			{ -1, -1,  1,  2 }, 
			{  3, -1, -1,  2 }, 
			{  3,  3, -1, -1 },
			{ -1,  0,  1, -1 }
			}, g.getPShort());
		
		assertArrayEquals(new double[][] { 
			{ 0, 1, 2, 3 }, 
			{ 3, 0, 1, 2 }, 
			{ 2, 3, 0, 1 },
			{ 1, 2, 3, 0 }
			}, g.getAShort());
	}
	
	@Test
	public void floydShort3Test() {
		GraphEx24<Character> g = graphFromToAPath1(); // A <-> B   A <-> C   A <-> D
		
		g.floydShort();
		
		assertArrayEquals(new int[][] { 
			{ -1, -1, -1, -1 }, 
			{ -1, -1,  0,  0 }, 
			{ -1,  0, -1,  0 },
			{ -1,  0,  0, -1 }
			}, g.getPShort());
		
		assertArrayEquals(new double[][] { 
			{ 0, 1, 1, 1 }, 
			{ 1, 0, 2, 2 }, 
			{ 1, 2, 0, 2 },
			{ 1, 2, 2, 0 }
			}, g.getAShort());
		
		g.addEdge('D', 'B', 100);
		g.addEdge('B', 'D', 1000);
		g.floydShort();
		
		assertArrayEquals(new int[][] { 
			{ -1, -1, -1, -1 }, 
			{ -1, -1,  0, -1 }, 
			{ -1,  0, -1,  0 },
			{ -1, -1,  0, -1 }
			}, g.getPShort());
		
		assertArrayEquals(new double[][] { 
			{ 0, 1, 1, 1 }, 
			{ 1, 0, 2, 1 }, 
			{ 1, 2, 0, 2 },
			{ 1, 1, 2, 0 }
			}, g.getAShort());
	}
	
	@Test
	public void isWeaklyConnected1Test() {
		GraphEx24<Character> g = graphSimplePath1(); // A -> B -> C -> D
		
		assertTrue(g.isWeaklyConnected());
		
		g.removeEdge('B', 'C');
		assertFalse(g.isWeaklyConnected());
		
		g.addEdge('A', 'D', 1);
		assertTrue(g.isWeaklyConnected());
		
		g.removeEdge('C', 'D');
		assertFalse(g.isWeaklyConnected());
		
		g.addEdge('D', 'C', 1);
		assertTrue(g.isWeaklyConnected());
	}
	
	@Test
	public void isWeaklyConnected2Test() {
		GraphEx24<Character> g = graphLoopPath1(); // A -> B -> C -> D
		
		assertTrue(g.isWeaklyConnected());
		
		g.removeEdge('B', 'C');
		assertTrue(g.isWeaklyConnected());
		
		g.removeEdge('C', 'D');
		assertFalse(g.isWeaklyConnected());
	}
	
	@Test
	public void isWeaklyConnected3Test() {
		GraphEx24<Character> g = graphFromToAPath1(); // A -> B -> C -> D
		
		assertTrue(g.isWeaklyConnected());
	}
}










































