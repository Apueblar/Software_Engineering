package app.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import app.model.Order;
import app.model.Product;
import app.service.Logic;

import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JScrollPane;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import javax.swing.JList;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;

/**
 * Represents the screen for reviewing placed orders in the "Papa Slice" application.
 * This screen displays the user's completed orders, their total price, and available 
 * incentives such as games or prizes.
 * 
 * Key Features:
 * - Displays a list of completed orders with their details.
 * - Shows the total price for all completed orders.
 * - Allows users to either place additional orders or finish and pay for their reservation.
 * - Integrates with a game incentive system that can be displayed conditionally.
 * - Provides a help system for user guidance.
 */
public class PlacedOrderScreen extends JDialog {

	private static final long serialVersionUID = 1L;
	
	private Logic logic;
	private ResourceBundle texts;
	
	private JLabel lblPlacedOrders;
	private JButton btnOrderMore;
	private JButton btnFinish;
	private JPanel panelGame;
	private JDialog gameScreen;
	private JScrollPane sPDoneOrders;
	private JPanel panelDoneOrders;
	private JLabel lblFinalPrice;
	private JTextField tFinalPrice;
	private JPanel pnPlayGame;
	private JPanel pnShowPrizes;
	private JLabel lblGameIncentive;
	private JButton btnPlayGame;
	private JPanel pnNoPrizes;
	private JLabel lblPrizes;
	private JPanel pnPrizes;
	private JLabel lblNoPrize;
	private JPanel pnButtons;

	/**
     * Constructs the screen for placed orders.
     * Initializes all components, sets up the game panel, and loads the help system.
     * 
     * @param logic the Logic instance responsible for managing business operations.
     * @param texts the ResourceBundle for localized text resources.
     */
	public PlacedOrderScreen(Logic logic, ResourceBundle texts) {
		this.logic = logic;
		this.texts = texts;
		this.setTitle("Papa Slice");
		String logo = "/img/logo.png";
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(StartScreen.class.getResource(logo)));
		
		setResizable(false);
		getContentPane().setBackground(Color.LIGHT_GRAY);
		setBackground(Color.WHITE);
		setBounds(100, 100, 800, 600);
		getContentPane().setLayout(null);
		getContentPane().add(getLblPlacedOrders());
		getContentPane().add(getPanelGame());
		getContentPane().add(getSPDoneOrders());
		getContentPane().add(getLblFinalPrice());
		getContentPane().add(getTFinalPrice());
		getContentPane().add(getPnButtons());
		
		updateGamePanel();
		loadHelp();
	}
	
	/**
     * Updates the game panel based on the current state of the game.
     * Displays one of the following subpanels:
     * - "Play Game" if the user can play the game.
     * - "Show Prizes" if the user has earned prizes.
     * - "No Prizes" if neither condition is met.
     */
	private void updateGamePanel() {
		if (logic.canPlayGame()) {
			showPnPlayGame();
		} else if (logic.getPrizes().size() > 0) {
			addPrizes();
			showPnShowPrizes();
		} else {
			showPnNoPrizes();
		}
	}
	
	/**
	 * Retrieves and initializes the label for placed orders.
	 * Displays a localized text indicating the section for completed orders.
	 *
	 * @return the JLabel instance for the placed orders section.
	 */
	private JLabel getLblPlacedOrders() {
		if (lblPlacedOrders == null) {
			lblPlacedOrders = new JLabel(texts.getString("pos.PlacedOrders") + ":");
			lblPlacedOrders.setFont(new Font("Rockwell", Font.BOLD, 30));
			lblPlacedOrders.setBounds(19, 10, 360, 36);
		}
		return lblPlacedOrders;
	}
	
	/**
	 * Retrieves and initializes the panel for action buttons.
	 * Contains the "Order More" and "Finish and Pay" buttons.
	 *
	 * @return the JPanel instance for action buttons.
	 */
	private JPanel getPnButtons() {
		if (pnButtons == null) {
			pnButtons = new JPanel();
			pnButtons.setBackground(Color.LIGHT_GRAY);
			pnButtons.setBounds(6, 430, 774, 127);
			pnButtons.setLayout(new BorderLayout(0, 0));
			pnButtons.add(getBtnOrderMore(), BorderLayout.WEST);
			pnButtons.add(getBtnFinish(), BorderLayout.EAST);
		}
		return pnButtons;
	}
	
	/**
	 * Retrieves and initializes the "Order More" button.
	 * Allows users to return to the ordering screen to place additional orders.
	 *
	 * @return the JButton instance for placing more orders.
	 */
	private JButton getBtnOrderMore() {
		if (btnOrderMore == null) {
			btnOrderMore = new JButton(texts.getString("pos.OrderMore"));
			btnOrderMore.setMnemonic(texts.getString("pos.OrderMoreMnemonic").charAt(0));
			btnOrderMore.setToolTipText(texts.getString("pos.btnOrderMoreToolTip"));
			btnOrderMore.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnOrderMore.setFont(new Font("Rockwell", Font.BOLD, 25));
			btnOrderMore.setBackground(Color.LIGHT_GRAY);
		}
		return btnOrderMore;
	}
	
	/**
	 * Retrieves and initializes the "Finish and Pay" button.
	 * Finalizes the reservation process and confirms payment.
	 *
	 * @return the JButton instance for finishing the reservation.
	 */
	private JButton getBtnFinish() {
		if (btnFinish == null) {
			btnFinish = new JButton(texts.getString("pos.FinishAndPay"));
			btnFinish.setMnemonic(texts.getString("pos.FinishAndPayMnemonic").charAt(0));
			btnFinish.setToolTipText(texts.getString("pos.btnFinishToolTip"));
			btnFinish.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					finishReservation();
				}
			});
			btnFinish.setFont(new Font("Rockwell", Font.BOLD, 25));
			btnFinish.setBackground(Color.LIGHT_GRAY);
		}
		return btnFinish;
	}
	
	/**
	 * Handles the logic for completing the reservation.
	 * Displays a confirmation dialog before marking the reservation as finished.
	 */
	private void finishReservation() {
		int resp = JOptionPane.showConfirmDialog(null, texts.getString("pos.finishReservationAndPay"), texts.getString("pos.finishReservationAndPayTittle"), JOptionPane.YES_NO_OPTION);
		if (resp == JOptionPane.YES_OPTION) {
			logic.setFinishReservation(true);
			dispose();
		}
	}
	
	/**
	 * Retrieves and initializes the panel for the game section.
	 * Contains subpanels for the game, prizes, and no prizes states.
	 *
	 * @return the JPanel instance for the game section.
	 */
	private JPanel getPanelGame() {
		if (panelGame == null) {
			panelGame = new JPanel();
			panelGame.setBackground(Color.GRAY);
			panelGame.setBounds(5, 250, 775, 175);
			panelGame.setLayout(new CardLayout(0, 0));
			panelGame.add(getPnPlayGame(), "pnPlayGame");
			panelGame.add(getPnShowPrizes(), "pnShowPrizes");
			panelGame.add(getPnNoPrizes(), "pnNoPrizes");
		}
		return panelGame;
	}
	
	/**
	 * Retrieves and initializes the play game panel.
	 * Displays the game incentive message and the button to start the game.
	 *
	 * @return the JPanel instance for the play game section.
	 */
	private JPanel getPnPlayGame() {
		if (pnPlayGame == null) {
			pnPlayGame = new JPanel();
			pnPlayGame.setLayout(new BorderLayout(0, 3));
			pnPlayGame.add(getLblGameIncentive(), BorderLayout.NORTH);
			pnPlayGame.add(getBtnPlayGame(), BorderLayout.CENTER);
		}
		return pnPlayGame;
	}
	
	/**
	 * Retrieves and initializes the game incentive label.
	 * Displays a localized message encouraging users to play the game.
	 *
	 * @return the JLabel instance for the game incentive message.
	 */
	private JLabel getLblGameIncentive() {
		if (lblGameIncentive == null) {
			lblGameIncentive = new JLabel(texts.getString("pos.GameIncentive"));
			lblGameIncentive.setFont(new Font("SansSerif", Font.BOLD, 20));
			lblGameIncentive.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblGameIncentive;
	}
	
	/**
	 * Retrieves and initializes the button to play the game.
	 * Launches the game screen and updates the game panel afterward.
	 *
	 * @return the JButton instance for starting the game.
	 */
	private JButton getBtnPlayGame() {
		if (btnPlayGame == null) {
			btnPlayGame = new JButton(texts.getString("pos.PlayGameMessage"));
			btnPlayGame.setMnemonic(texts.getString("pos.PlayGameMnemonic").charAt(0));
			btnPlayGame.setToolTipText(texts.getString("pos.btnPlayGameToolTip"));
			btnPlayGame.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showGameScreen();
					updateGamePanel();
				}
			});
			btnPlayGame.setFont(new Font("SansSerif", Font.BOLD, 20));
		}
		return btnPlayGame;
	}
	
	/**
	 * Displays the game screen dialog.
	 * Updates the game panel after the game ends.
	 */
	private void showGameScreen() {
		gameScreen = new GameScreen(logic, texts);
		gameScreen.setLocationRelativeTo(this);
		gameScreen.setModal(true);
		gameScreen.setVisible(true);
	}
	
	/**
	 * Retrieves and initializes the panel for displaying prizes.
	 * Contains a label and a grid layout to show earned prizes.
	 *
	 * @return the JPanel instance for displaying prizes.
	 */
	private JPanel getPnShowPrizes() {
		if (pnShowPrizes == null) {
			pnShowPrizes = new JPanel();
			pnShowPrizes.setLayout(new BorderLayout(0, 0));
			pnShowPrizes.add(getLblPrizes(), BorderLayout.NORTH);
			pnShowPrizes.add(getPnPrizes(), BorderLayout.CENTER);
		}
		return pnShowPrizes;
	}
	
	/**
	 * Retrieves and initializes the label for the prize section.
	 * Displays a localized message congratulating users for winning prizes.
	 *
	 * @return the JLabel instance for the prize section.
	 */
	private JLabel getLblPrizes() {
		if (lblPrizes == null) {
			lblPrizes = new JLabel(" " + texts.getString("pos.Youwon"));
			lblPrizes.setFont(new Font("SansSerif", Font.BOLD, 20));
		}
		return lblPrizes;
	}
	
	/**
	 * Retrieves and initializes the panel for the grid of prizes.
	 * Dynamically displays the prizes earned by the user.
	 *
	 * @return the JPanel instance for the prize grid.
	 */
	private JPanel getPnPrizes() {
		if (pnPrizes == null) {
			pnPrizes = new JPanel();
			pnPrizes.setLayout(new GridLayout(1, 0, 0, 0));
		}
		return pnPrizes;
	}
	
	/**
	 * Dynamically adds earned prizes to the prizes panel.
	 * Updates the display with prize names and images.
	 */
	private void addPrizes() {
		getPnPrizes().removeAll();
		for (Product p : logic.getPrizes()) {
			JPanel pnPrize = new JPanel();
			pnPrize.setLayout(new BorderLayout(0, 0));
			
				JLabel lblPrizeName = new JLabel(p.getName() + ":");
				lblPrizeName.setFont(new Font("Rockwell", Font.PLAIN, 15));
			pnPrize.add(lblPrizeName, BorderLayout.NORTH);
			
				JLabel lblImage = new JLabel();
				lblImage.setIcon(loadResizedIcon("/img/" + p.getPicture(), 125, 125));
			pnPrize.add(lblImage, BorderLayout.CENTER);
			
			getPnPrizes().add(pnPrize);
		}
		validate();
	}
	
	/**
	 * Retrieves and initializes the "No Prizes" panel.
	 * Displays a message when no prizes are available.
	 *
	 * @return the JPanel instance for the "No Prizes" section.
	 */
	private JPanel getPnNoPrizes() {
		if (pnNoPrizes == null) {
			pnNoPrizes = new JPanel();
			pnNoPrizes.setLayout(new BorderLayout(0, 0));
			pnNoPrizes.add(getLblNoPrize(), BorderLayout.CENTER);
		}
		return pnNoPrizes;
	}
	
	/**
     * Loads and resizes an icon from the specified resource path.
     * Maintains the original aspect ratio of the image.
     * 
     * @param resourcePath the path to the image resource.
     * @param maxWidth the maximum width of the resized icon.
     * @param maxHeight the maximum height of the resized icon.
     * @return a resized ImageIcon instance, or the original if resizing is unnecessary.
     */
	private ImageIcon loadResizedIcon(String resourcePath, int maxWidth, int maxHeight) {
	    ImageIcon originalIcon = new ImageIcon(getClass().getResource(resourcePath));
	    int originalWidth = originalIcon.getIconWidth();
	    int originalHeight = originalIcon.getIconHeight();

	    // Resize only if the original image exceeds max dimensions
	    if (originalWidth > maxWidth || originalHeight > maxHeight) {
	        // Calculate scaled dimensions while maintaining aspect ratio
	        double widthRatio = (double) maxWidth / originalWidth;
	        double heightRatio = (double) maxHeight / originalHeight;
	        double scaleFactor = Math.min(widthRatio, heightRatio);

	        int newWidth = (int) (originalWidth * scaleFactor);
	        int newHeight = (int) (originalHeight * scaleFactor);

	        // Resize the image
	        Image resizedImage = originalIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
	        return new ImageIcon(resizedImage);
	    }
	    return originalIcon; // Return original icon if no resizing is needed
	}
	
	/**
	 * Displays the "Play Game" panel in the game section.
	 */
	private void showPnPlayGame() {
		((CardLayout) getPanelGame().getLayout()).show(panelGame, "pnPlayGame");
	}
	
	/**
	 * Displays the "Show Prizes" panel in the game section.
	 */
	private void showPnShowPrizes() {
		((CardLayout) getPanelGame().getLayout()).show(panelGame, "pnShowPrizes");
	}
	
	/**
	 * Displays the "No Prizes" panel in the game section.
	 */
	private void showPnNoPrizes() {
		((CardLayout) getPanelGame().getLayout()).show(panelGame, "pnNoPrizes");
	}
	
	/**
	 * Retrieves and initializes the scroll pane for completed orders.
	 * Provides a container to display the list of placed orders.
	 *
	 * @return the JScrollPane instance for completed orders.
	 */
	private JScrollPane getSPDoneOrders() {
		if (sPDoneOrders == null) {
			sPDoneOrders = new JScrollPane();
			sPDoneOrders.setBounds(5, 50, 775, 195);
			sPDoneOrders.setViewportView(getPanelDoneOrders());
		}
		return sPDoneOrders;
	}
	
	/**
	 * Retrieves and initializes the panel for displaying completed orders.
	 * Contains the individual order details and their respective items.
	 *
	 * @return the JPanel instance for the completed orders section.
	 */
	private JPanel getPanelDoneOrders() {
		if (panelDoneOrders == null) {
			panelDoneOrders = new JPanel();
			panelDoneOrders.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			addDoneOrders();
		}
		return panelDoneOrders;
	}
	
	/**
	 * Dynamically adds completed orders to the done orders panel.
	 * Updates the display with order details and their respective items.
	 */
	private void addDoneOrders() {
		getPanelDoneOrders().removeAll();
		List<Order> doneOrders = logic.getDoneOrders();
		for (int i = 1; i <= doneOrders.size(); i++) {
			Order o = doneOrders.get(i - 1);
			
			JScrollPane sPOrder = new JScrollPane();
			
				DefaultListModel<String> listOrderToString = new DefaultListModel<>();
				for (String productString : logic.getDoneOrders().get(i - 1).toUserString()) {
				    listOrderToString.addElement(productString);
				}
				JList<String> list = new JList<String>(listOrderToString);
				// Calculate the required height based on the number of elements
		        int cellHeight = list.getFixedCellHeight() > 0 ? list.getFixedCellHeight() : 20; // cellHeight to 20 if not set
		        int listHeight = Math.min(175, listOrderToString.getSize() * cellHeight); // Cap height to 175
		        list.setVisibleRowCount(listOrderToString.getSize());
		        list.setPreferredSize(new Dimension((int) list.getPreferredSize().getWidth(), listHeight));
			sPOrder.setViewportView(list);
			
				String orderPrice = String.format("%.2f €", o.getTotalPrice());
				JLabel lblOrder = new JLabel("Order " + i + ": " + orderPrice);
			sPOrder.setColumnHeaderView(lblOrder);
			
			getPanelDoneOrders().add(sPOrder);
		}
		String orderPrice = String.format("%.2f €", logic.getFinalPrice());
		getTFinalPrice().setText(orderPrice);
	}
	
	/**
	 * Retrieves and initializes the label for the final price display.
	 * Displays a localized text indicating the total price of all orders.
	 *
	 * @return the JLabel instance for the final price section.
	 */
	private JLabel getLblFinalPrice() {
		if (lblFinalPrice == null) {
			lblFinalPrice = new JLabel(texts.getString("pos.FinalPrice") + ":");
			lblFinalPrice.setHorizontalAlignment(SwingConstants.TRAILING);
			lblFinalPrice.setFont(new Font("Rockwell", Font.BOLD, 30));
			lblFinalPrice.setBounds(391, 10, 220, 36);
		}
		return lblFinalPrice;
	}
	
	/**
	 * Retrieves and initializes the text field for the final price.
	 * Displays the total price of all completed orders.
	 *
	 * @return the JTextField instance for the final price display.
	 */
	private JTextField getTFinalPrice() {
		if (tFinalPrice == null) {
			tFinalPrice = new JTextField();
			tFinalPrice.setToolTipText(texts.getString("pos.tFinalPriceToolTip"));
			tFinalPrice.setFont(new Font("Rockwell", Font.PLAIN, 25));
			tFinalPrice.setEditable(false);
			tFinalPrice.setColumns(10);
			tFinalPrice.setBounds(620, 10, 160, 36);
		}
		return tFinalPrice;
	}
	
	/**
	 * Retrieves and initializes the "No Prize" label.
	 * Displays a localized message indicating that no prizes were earned.
	 *
	 * @return the JLabel instance for the "No Prize" message.
	 */
	private JLabel getLblNoPrize() {
		if (lblNoPrize == null) {
			lblNoPrize = new JLabel(texts.getString("pos.NoPrize"));
			lblNoPrize.setFont(new Font("SansSerif", Font.BOLD, 36));
			lblNoPrize.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblNoPrize;
	}
	
	/**
	 * Loads and initializes the help system for this screen.
	 * Associates help content with specific UI components.
	 */
	private void loadHelp() {
		try {
			File fichero = new File("help/Help.hs");
			URL hsURL = fichero.toURI().toURL();
			HelpSet hs = new HelpSet(null, hsURL);
			
			HelpBroker hb = hs.createHelpBroker();
			
			hb.enableHelpKey(getRootPane(),"endTheReservation", hs);
		} catch (Exception e){
			System.out.println("Help not found!");
	    }
	}
}
