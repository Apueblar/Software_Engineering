package app.ui;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import app.model.Product;
import app.model.TypeOfProduct;
import app.service.Logic;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.net.URL;

/**
 * Represents the game screen of the application "Papa Slice."
 * This screen provides an interactive memory game where users can match pairs of hidden elements.
 * 
 * Key Features:
 * - Interactive grid-based memory game with customizable number of attempts.
 * - Prize allocation based on game progress.
 * - Integration with the application's logic for fetching menu items as prizes.
 * - Localization support for tooltips and labels.
 * - Help system integration.
 * 
 * Gameplay:
 * - Users click on grid cells to reveal hidden elements and attempt to match pairs.
 * - Each match rewards a prize and reduces the available attempts.
 * - The game ends when attempts reach zero.
 */
public class GameScreen extends JDialog {

	private static final long serialVersionUID = 1L;
	
	private final static int NUM_OF_ROWS = 4; // Number of rows in the game grid
	private final static int NUM_OF_COLS = 4; // Number of columns in the game grid
	private int[] numbers = new int[NUM_OF_COLS * NUM_OF_ROWS]; // Grid content
	
	private final static int MAX_NUM_OF_ATTEMPTS = 5; // Maximum number of attempts
	private int attempts; // Remaining attempts
	
	// Temporary game variables
	private int compare1 = -1;
	private boolean buttonProcesing = false;
	
	private Logic logic; // logic handler
	private ResourceBundle texts; // Localization texts
	
	// UI components for the game screen
	private JPanel contentPane;
	private JButton btnInfo;
	private JButton btnLeave;
	private JPanel panelCells;
	private JLabel lblPrizes;
	private JScrollPane scrollPanePrizes;
	private JLabel lblAtempts;
	private JTextField textAttempts;
	private DefaultListModel<Product> listModelPrizes;
	private JList<Product> listPrizes;
	
	private ShowCell sC = new ShowCell(); // Action listener for grid cells
	
	/**
     * Constructs the game screen dialog.
     * Initializes the UI components, sets up the game grid, and loads the help system.
     *
     * @param logic the Logic instance responsible for business operations.
     * @param texts the ResourceBundle for localized text resources.
     */
	public GameScreen(Logic logic, ResourceBundle texts) {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				leaveGame();
			}
		});
		this.logic = logic;
		this.texts = texts;
		
		generateRandomNumbers(numbers);
		attempts = MAX_NUM_OF_ATTEMPTS;
		
		this.setTitle("Papa Slice");
		String logo = "/img/logo.png";
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(StartScreen.class.getResource(logo)));
		
		setResizable(false);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBackground(Color.WHITE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getBtnInfo());
		contentPane.add(getBtnLeave());
		contentPane.add(getPanelCells());
		contentPane.add(getScrollPanePrizes());
		contentPane.add(getLblAtempts());
		contentPane.add(getLblPrizes());
		contentPane.add(getTextAttempts());
		
		loadHelp();
	}
	
	/**
     * Generates random numbers for the game grid, ensuring each pair is placed exactly twice.
     *
     * @param numbers the array to be filled with randomized pairs.
     */
	private void generateRandomNumbers(int[] numbers) {
		boolean[] placed = new boolean[numbers.length];
		Random r = new Random();
		for (int number = 0; number < numbers.length; number++) {
			int placeNumber = number / 2;
			int position;
			do {
				position = r.nextInt(numbers.length);
			} while (placed[position]);
			numbers[position] = placeNumber;
			placed[position] = true;
		}
		for (int i = 0; i < numbers.length; i++) {
			if (i % NUM_OF_COLS == 0) {System.out.println("");}
			if (numbers[i] == 0) {
				System.out.print("W ");
			} else {
				System.out.print(numbers[i] + " ");
			}
		} // Shown in the screen for testing
		System.out.println("");
	}
	
	/**
	 * Inner class handling actions performed on grid cells.
	 * Implements ActionListener to respond to user clicks on grid cells.
	 */
	private class ShowCell implements ActionListener {
		
		/**
	     * Handles the cell click event to manage game logic.
	     *
	     * @param e the ActionEvent triggered by a cell click.
	     */
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() instanceof JButton) {
				if (!buttonProcesing) {
					JButton button = (JButton) e.getSource();
					button.setEnabled(false);
					
					int index = Integer.valueOf(e.getActionCommand());
					
					if (compare1 < 0) { compare1 = index; return ; } // First click
					
					if (compare1 == index) {throw new IllegalStateException("You cannot click twice the same cell");}
					
					switch(match(compare1, index)) { //Second click
					case 3:	// Double wild
						addPrize();
					case 2: // A wild
					case 1: // Same without Wild
						addPrize();
						attempts--;
						getTextAttempts().setText(attempts + "/" + MAX_NUM_OF_ATTEMPTS);
						compare1 = -1;
						if (attempts == 0) { finishGame(); }
						break;
					case 0: // Different without Wild
						buttonProcesing = true;
				
						SwingUtilities.invokeLater(() -> {
						    try {
						        Thread.sleep(2000); // Blocking operation
						        enableIndex(compare1);
					            enableIndex(index);
					            attempts--;
								getTextAttempts().setText(attempts + "/" + MAX_NUM_OF_ATTEMPTS);
								compare1 = -1;
								if (attempts == 0) { finishGame(); }
								buttonProcesing = false;
						    } catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
						});
						break;
					default: throw new IllegalStateException("This case is not included");
					}
				}
			}
		}
	}
	
	/**
	 * Compares the buttons pressed
	 * @param compare1 First index
	 * @param compare2 Second index
	 * @return {
	 * 	- 0 -> If they are different and not Wild cards
	 * 	- 1 -> If they are equal and not Wild cards
	 * 	- 2 -> If one is a Wild card
	 * 	- 3 -> If both are Wild card
	 * }
	 */
	private int match(int compare1, int compare2) {
		boolean isWild1 = numbers[compare1] == 0;
		boolean isWild2 = numbers[compare2] == 0;
		if (isWild1 && isWild2) {return 3;}
		if (isWild1 || isWild2) {return 2;}
		boolean areEqual = numbers[compare1] == numbers[compare2];
		return areEqual ? 1 : 0;
	}
	
	/**
	 * Retrieves and initializes the help button.
	 * The button provides users with help information.
	 *
	 * @return the initialized JButton for displaying help.
	 */
	private JButton getBtnInfo() {
		if (btnInfo == null) {
			btnInfo = new JButton("?");
			btnInfo.setToolTipText(texts.getString("gs.btnInfoToolTip"));
			btnInfo.setContentAreaFilled(false);
			btnInfo.setBorder(new LineBorder(new Color(0, 0, 0), 5, true));
			btnInfo.setForeground(Color.BLACK);
			btnInfo.setFont(new Font("Rockwell", Font.BOLD, 50));
			btnInfo.setMnemonic('i');
			btnInfo.setBackground(Color.WHITE);
			btnInfo.setBounds(706, 16, 64, 64);
		}
		return btnInfo;
	}
	
	/**
	 * Retrieves and initializes the leave game button.
	 * The button allows users to exit the game, prompting a confirmation dialog.
	 *
	 * @return the initialized JButton for leaving the game.
	 */
	private JButton getBtnLeave() {
		if (btnLeave == null) {
			btnLeave = new JButton(texts.getString("gs.Leave"));
			btnLeave.setToolTipText(texts.getString("gs.btnLeaveToolTip"));
			btnLeave.setMnemonic(texts.getString("gs.LeaveMnemonic").charAt(0));
			btnLeave.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					leaveGame();
				}
			});
			btnLeave.setContentAreaFilled(false);
			btnLeave.setBorder(new LineBorder(Color.BLACK, 5, true));
			btnLeave.setFont(new Font("Rockwell", Font.BOLD, 30));
			btnLeave.setBounds(20, 16, 173, 45);
		}
		return btnLeave;
	}
	
	/**
     * Handles the logic for the leave button.
     * Displays a confirmation dialog and exits if confirmed.
     */
	private void leaveGame() {
		if (attempts == 0) {dispose(); return ;}
		int resp = JOptionPane.showConfirmDialog(null, texts.getString("gs.LeaveGame"), texts.getString("gs.LeaveGameTittle"), JOptionPane.YES_NO_OPTION);
		if (resp == JOptionPane.YES_OPTION) {
			finishGame();
			dispose();
		}
	}
	
	/**
	 * Retrieves and initializes the game grid panel.
	 * The grid contains cells representing hidden elements that players can interact with.
	 *
	 * @return the initialized JPanel containing the game grid.
	 */
	private JPanel getPanelCells() {
		if (panelCells == null) {
			panelCells = new JPanel();
			panelCells.setBounds(75, 85, 400, 400);
			panelCells.setLayout(new GridLayout(NUM_OF_ROWS, NUM_OF_COLS, 0, 0));
			addCells();
		}
		return panelCells;
	}
	
	/**
     * Adds and configures the game grid cells to the panel.
     * Each cell represents a hidden game element.
     */
	private void addCells() {
		panelCells.removeAll();
		for (int row = 0; row < NUM_OF_ROWS; row++) {
			for (int col = 0; col < NUM_OF_COLS; col++) {
				JButton cell = new JButton("");
				int f = row * NUM_OF_COLS + col;
				cell.setActionCommand("" + f);
				if (numbers[f] == 0) {
					cell.setDisabledIcon(loadResizedIcon("/img/gameW.png", 75, 75));
				} else {
					cell.setDisabledIcon(loadResizedIcon("/img/game" + numbers[f] + ".png", 75, 75));
				}
				cell.addActionListener(sC);
				panelCells.add(cell);
			}
			validate();
		}
	}
	
	/**
     * Loads and resizes an icon from the specified resource path.
     * Maintains the original aspect ratio of the image.
     * 
     * @param resourcePath the path to the image resource.
     * @param maxWidth the maximum width of the resized icon.
     * @param maxHeight the maximum height of the resized icon.
     * @return a resized ImageIcon instance, or the original if resizing is unnecessary.
     */
	private ImageIcon loadResizedIcon(String resourcePath, int maxWidth, int maxHeight) {
	    ImageIcon originalIcon = new ImageIcon(getClass().getResource(resourcePath));
	    int originalWidth = originalIcon.getIconWidth();
	    int originalHeight = originalIcon.getIconHeight();

	    // Resize only if the original image exceeds max dimensions
	    if (originalWidth > maxWidth || originalHeight > maxHeight) {
	        // Calculate scaled dimensions while maintaining aspect ratio
	        double widthRatio = (double) maxWidth / originalWidth;
	        double heightRatio = (double) maxHeight / originalHeight;
	        double scaleFactor = Math.min(widthRatio, heightRatio);

	        int newWidth = (int) (originalWidth * scaleFactor);
	        int newHeight = (int) (originalHeight * scaleFactor);

	        // Resize the image
	        Image resizedImage = originalIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
	        return new ImageIcon(resizedImage);
	    }
	    return originalIcon; // Return original icon if no resizing is needed
	}

	/**
     * Handles logic for enabling a cell.
     * 
     * @param index the cell index to be enabled.
     */
	private void enableIndex(int index) {
		for (Component c : getPanelCells().getComponents()) {
			if (c instanceof JButton) {
				JButton cell = (JButton) c;
				if (cell.getActionCommand().equals("" + index)) {cell.setEnabled(true);}
			}
		}
	}
	
//	/**
//     * Handles logic for disabling a cell.
//     * 
//     * @param index the cell index to be disabled.
//     */
//	private void disableIndex(int index) {
//		for (Component c : getPanelCells().getComponents()) {
//			if (c instanceof JButton) {
//				JButton cell = (JButton) c;
//				if (cell.getActionCommand().equals("" + index)) {cell.setEnabled(false);}
//			}
//		}
//	}
	
	/**
     * Adds a prize to the user's collection based on the remaining attempts.
     * The type of prize corresponds to predefined categories.
     */
	private void addPrize() {
		switch (attempts) {
		case 5: addRandom(TypeOfProduct.Pizza); return ;
		case 4: addRandom(TypeOfProduct.Starter); return ;
		case 3: addRandom(TypeOfProduct.Salad); return ;
		case 2: addRandom(TypeOfProduct.Dessert); return ;
		case 1: addRandom(TypeOfProduct.Drink); return ;
		default: throw new IllegalArgumentException("Unexpected value: " + attempts);
		}
	}
	
	/**
     * Retrieves a random product from the specified product type.
     * 
     * @param type the type of product to retrieve.
     */
	private void addRandom(TypeOfProduct type) {
		List<TypeOfProduct> types = Arrays.asList(type);
		List<Product> products = logic.getMenuTypeProduct(types);
		Random r = new Random();
		int index = r.nextInt(products.size());
		listModelPrizes.addElement(products.get(index));
	}
	
	/**
     * Disables all actions and finalizes the game.
     * Saves earned prizes using the logic instance.
     */
	private void finishGame() {
		for (Component c : getPanelCells().getComponents()) {
			if (c instanceof JButton) {
				JButton cell = (JButton) c;
				cell.setEnabled(false);
			}
		}
		List<Product> prizes = new ArrayList<Product>();
		for (int i = 0; i < listModelPrizes.getSize(); i++) {
			prizes.add(listModelPrizes.get(i));
		}
		logic.setPrices(prizes); // Also sets the game as played
	}
	
	/**
	 * Retrieves and initializes the label for the prizes list.
	 * Displays a localized text indicating the section for earned prizes.
	 *
	 * @return the JLabel instance for the prizes section.
	 */
	private JLabel getLblPrizes() {
		if (lblPrizes == null) {
			lblPrizes = new JLabel(texts.getString("gs.Prizes") + ":");
			lblPrizes.setLabelFor(getListPrizes());
			lblPrizes.setBounds(501, 278, 193, 36);
			lblPrizes.setFont(new Font("Rockwell", Font.BOLD, 30));
		}
		return lblPrizes;
	}
	
	/**
	 * Retrieves and initializes the scrollable pane for the prizes list.
	 * Provides a container to display the earned prizes in a scrollable view.
	 *
	 * @return the JScrollPane instance for the prizes list.
	 */
	private JScrollPane getScrollPanePrizes() {
		if (scrollPanePrizes == null) {
			scrollPanePrizes = new JScrollPane();
			scrollPanePrizes.setBounds(501, 315, 268, 170);
			scrollPanePrizes.setViewportView(getListPrizes());
		}
		return scrollPanePrizes;
	}
	
	/**
	 * Retrieves and initializes the label for the remaining attempts display.
	 * Displays a localized text indicating the section for attempts tracking.
	 *
	 * @return the JLabel instance for the attempts section.
	 */
	private JLabel getLblAtempts() {
		if (lblAtempts == null) {
			lblAtempts = new JLabel(texts.getString("gs.Attempts") + ":");
			lblAtempts.setLabelFor(getTextAttempts());
			lblAtempts.setBounds(501, 92, 269, 36);
			lblAtempts.setFont(new Font("Rockwell", Font.BOLD, 30));
		}
		return lblAtempts;
	}
	
	/**
	 * Retrieves and initializes the non-editable text field for attempts tracking.
	 * Displays the current and maximum number of attempts left for the game.
	 *
	 * @return the JTextField instance for the attempts display.
	 */
	private JTextField getTextAttempts() {
		if (textAttempts == null) {
			textAttempts = new JTextField();
			textAttempts.setToolTipText(texts.getString("gs.textAttemptsToolTip"));
			textAttempts.setHorizontalAlignment(SwingConstants.CENTER);
			textAttempts.setText(attempts + "/" + MAX_NUM_OF_ATTEMPTS);
			textAttempts.setEditable(false);
			textAttempts.setBounds(501, 133, 65, 36);
			textAttempts.setFont(new Font("Rockwell", Font.BOLD, 30));
			textAttempts.setColumns(10);
		}
		return textAttempts;
	}
	
	/**
	 * Retrieves and initializes the list component for displaying earned prizes.
	 * Links to a DefaultListModel that dynamically updates with prize data.
	 *
	 * @return the JList instance for displaying the prizes.
	 */
	private JList<Product> getListPrizes() {
		if (listPrizes == null) {
			listModelPrizes = new DefaultListModel<Product>();
			listPrizes = new JList<Product>(listModelPrizes);
			listPrizes.setToolTipText(texts.getString("gs.listPrizesToolTip"));
		}
		return listPrizes;
	}
	
	/**
     * Loads and initializes the help system for this screen.
     * Associates help content with specific UI components.
     */
	private void loadHelp() {
		try {
			File fichero = new File("help/Help.hs");
			URL hsURL = fichero.toURI().toURL();
			HelpSet hs = new HelpSet(null, hsURL);
			
			HelpBroker hb = hs.createHelpBroker();
			
			hb.enableHelpKey(getRootPane(),"playGame", hs);
			hb.enableHelpOnButton(btnInfo, "playGame", hs);
		} catch (Exception e){
			System.out.println("Help not found!");
	    }
	}
}
