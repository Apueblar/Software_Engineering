package app.ui;

import java.awt.Color;

import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.border.LineBorder;

import app.model.Order;
import app.model.Product;
import app.service.Logic;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Dimension;

import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.BoxLayout;
import javax.swing.JSpinner;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.File;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.BorderLayout;

/**
 * Represents the order screen of the "Papa Slice" application.
 * This screen displays the details of the current order and allows users to manage 
 * it by adding, modifying, or removing items.
 * 
 * Key Features:
 * - View detailed order items with their quantities and prices.
 * - Modify item quantities or remove items.
 * - Submit the order for processing.
 * - Integrated help system.
 */
public class OrderScreen extends JDialog {

	private static final long serialVersionUID = 1L;
	
	private Logic logic;
	private ResourceBundle texts;
	
	private JButton btnResetOrder;
	private JTextField txtID;
	private JLabel lblID;
	private JButton btnBack;
	private JLabel lblTotalPrice;
	private JDialog placedOrderScreen;
	private JTextField textFieldTotalPrice;
	private JButton btnSendOrder;
	private JScrollPane scrollPaneProducts;
	private JPanel panelProducts;
	private JPanel panelTop;
	private JPanel panelID;
	private JPanel panelDown;
	private JPanel panelTotalPrice;
	private JPanel panelCenter;
	private JLabel lblVIP;

	/**
     * Constructs the order screen dialog.
     * Initializes UI components, sets up the layout, and loads the help system.
     * 
     * @param logic the Logic instance responsible for managing operations.
     * @param texts the ResourceBundle for localized text resources.
     */
	public OrderScreen(Logic logic, ResourceBundle texts) {
		this.logic = logic;
		this.texts = texts;
		this.setTitle("Papa Slice");
		String logo = "/img/logo.png";
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(StartScreen.class.getResource(logo)));
		
		setResizable(false);
		getContentPane().setBackground(Color.LIGHT_GRAY);
		setBackground(Color.WHITE);
		setBounds(100, 100, 800, 600);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		getTxtID().setText(logic.getCurrentID());
		getContentPane().add(getPanelTop(), BorderLayout.NORTH);
		getContentPane().add(getPanelCenter(), BorderLayout.CENTER);
		getContentPane().add(getPanelDown(), BorderLayout.SOUTH);
		
		loadHelp();
	}
	
	/**
	 * Retrieves and initializes the "Reset Order" button.
	 * Clears all items from the current order when clicked.
	 *
	 * @return the JButton instance for resetting the order.
	 */
	private JButton getBtnResetOrder() {
		if (btnResetOrder == null) {
			btnResetOrder = new JButton(texts.getString("os.ResetOrder"));
			btnResetOrder.setMnemonic(texts.getString("os.ResetOrderMnemonic").charAt(0));
			btnResetOrder.setToolTipText(texts.getString("os.btnResetOrderToolTip"));
			btnResetOrder.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					resetOrder();
				}
			});
			btnResetOrder.setFont(new Font("Rockwell", Font.BOLD, 25));
			btnResetOrder.setContentAreaFilled(false);
			btnResetOrder.setBorder(new LineBorder(Color.BLACK, 5, true));
		}
		return btnResetOrder;
	}
	
	/**
     * Resets the current order.
     * Displays a confirmation dialog and clears the order if confirmed.
     */
	private void resetOrder() {
		if (logic.getOrderProducts().size() > 0) {
			int resp = JOptionPane.showConfirmDialog(null, texts.getString("ms.resetOrder"), texts.getString("ms.resetOrderTittle"), JOptionPane.YES_NO_OPTION);
			if (resp == JOptionPane.YES_OPTION) {
				logic.resetOrder();
				addProducts();
			}
		}
	}
	
	/**
	 * Retrieves and initializes the text field for the user ID.
	 * Displays the unique ID for the current reservation.
	 *
	 * @return the JTextField instance for the user ID.
	 */
	private JTextField getTxtID() {
		if (txtID == null) {
			txtID = new JTextField();
			txtID.setToolTipText(texts.getString("os.txtIDToolTip"));
			txtID.setFont(new Font("Rockwell", Font.BOLD, 25));
			txtID.setEditable(false);
		}
		return txtID;
	}
	
	/**
	 * Retrieves and initializes the label for the user ID.
	 * Displays the user’s unique identifier for their order.
	 *
	 * @return the JLabel instance for the user ID.
	 */
	private JLabel getLblID() {
		if (lblID == null) {
			lblID = new JLabel(texts.getString("os.ID") + ":");
			lblID.setLabelFor(getTxtID());
			lblID.setHorizontalAlignment(SwingConstants.TRAILING);
			lblID.setFont(new Font("Rockwell", Font.BOLD, 25));
		}
		return lblID;
	}
	
	/**
	 * Retrieves and initializes the "Back" button.
	 * Returns the user to the previous screen when clicked.
	 *
	 * @return the JButton instance for navigating back.
	 */
	private JButton getBtnBack() {
		if (btnBack == null) {
			btnBack = new JButton(" " + texts.getString("os.Back") + " ");
			btnBack.setMnemonic(texts.getString("os.BackMnemonic").charAt(0));
			btnBack.setToolTipText(texts.getString("os.btnBackToolTip"));
			btnBack.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnBack.setFont(new Font("Rockwell", Font.BOLD, 25));
			btnBack.setContentAreaFilled(false);
			btnBack.setBorder(new LineBorder(Color.BLACK, 5, true));
		}
		return btnBack;
	}
	
	/**
	 * Retrieves and initializes the label for the total price.
	 * Displays the total cost of the current order.
	 *
	 * @return the JLabel instance for the total price.
	 */
	private JLabel getLblTotalPrice() {
		if (lblTotalPrice == null) {
			lblTotalPrice = new JLabel(texts.getString("os.TotalPrice") + ":");
			lblTotalPrice.setHorizontalAlignment(SwingConstants.TRAILING);
			lblTotalPrice.setFont(new Font("Rockwell", Font.BOLD, 20));
		}
		return lblTotalPrice;
	}
	
	/**
	 * Retrieves and initializes the text field for displaying total price.
	 * Shows the calculated total cost of the current order.
	 *
	 * @return the JTextField instance for the total price.
	 */
	private JTextField getTextFieldTotalPrice() {
		if (textFieldTotalPrice == null) {
			textFieldTotalPrice = new JTextField();
			textFieldTotalPrice.setToolTipText(texts.getString("os.textFieldTotalPriceToolTip"));
			textFieldTotalPrice.setFont(new Font("Rockwell", Font.PLAIN, 20));
			textFieldTotalPrice.setEditable(false);
			textFieldTotalPrice.setColumns(10);
		}
		return textFieldTotalPrice;
	}
	
	/**
	 * Retrieves and initializes the "Send Order" button.
	 * Finalizes and sends the current order for processing.
	 *
	 * @return the JButton instance for submitting the order.
	 */
	private JButton getBtnSendOrder() {
		if (btnSendOrder == null) {
			btnSendOrder = new JButton(texts.getString("os.SendOrder"));
			btnSendOrder.setMnemonic(texts.getString("os.SendOrderMnemonic").charAt(0));
			btnSendOrder.setToolTipText(texts.getString("os.btnSendOrderToolTip"));
			btnSendOrder.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					logic.orderSort();
					logic.sendOrder();
					JOptionPane.showMessageDialog(null, texts.getString("os.orderSent"), texts.getString("os.orderSentTittle"), JOptionPane.CLOSED_OPTION);
					showPlacedOrderScreen();
					dispose();
				}
			});
			btnSendOrder.setFont(new Font("Rockwell", Font.BOLD, 25));
			btnSendOrder.setBackground(Color.LIGHT_GRAY);
		}
		return btnSendOrder;
	}
	
	/**
     * Displays the placed orders screen.
     * Updates the application state and opens the placed orders dialog.
     */
	private void showPlacedOrderScreen() {
		placedOrderScreen = new PlacedOrderScreen(logic, texts);
		placedOrderScreen.setLocationRelativeTo(this);
		placedOrderScreen.setModal(true);
		placedOrderScreen.setVisible(true);
	}
	
	/**
	 * Retrieves and initializes the scroll pane for the product list.
	 * Provides a scrollable container for viewing products in the current order.
	 *
	 * @return the JScrollPane instance for the product list.
	 */
	private JScrollPane getScrollPaneProducts() {
		if (scrollPaneProducts == null) {
			scrollPaneProducts = new JScrollPane();
			scrollPaneProducts.setViewportView(getPanelProducts());
		}
		return scrollPaneProducts;
	}
	
	/**
     * Loads and resizes an icon from the specified resource path.
     * Maintains the original aspect ratio of the image.
     * 
     * @param resourcePath the path to the image resource.
     * @param maxWidth the maximum width of the resized icon.
     * @param maxHeight the maximum height of the resized icon.
     * @return a resized ImageIcon instance, or the original if resizing is unnecessary.
     */
	private ImageIcon loadResizedIcon(String resourcePath, int maxWidth, int maxHeight) {
	    ImageIcon originalIcon = new ImageIcon(getClass().getResource(resourcePath));
	    int originalWidth = originalIcon.getIconWidth();
	    int originalHeight = originalIcon.getIconHeight();

	    // Resize only if the original image exceeds max dimensions
	    if (originalWidth > maxWidth || originalHeight > maxHeight) {
	        // Calculate scaled dimensions while maintaining aspect ratio
	        double widthRatio = (double) maxWidth / originalWidth;
	        double heightRatio = (double) maxHeight / originalHeight;
	        double scaleFactor = Math.min(widthRatio, heightRatio);

	        int newWidth = (int) (originalWidth * scaleFactor);
	        int newHeight = (int) (originalHeight * scaleFactor);

	        // Resize the image
	        Image resizedImage = originalIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
	        return new ImageIcon(resizedImage);
	    }
	    return originalIcon; // Return original icon if no resizing is needed
	}
	
	/**
	 * Retrieves and initializes the panel for displaying products.
	 * Dynamically updates based on the current order.
	 *
	 * @return the JPanel instance for the product list.
	 */
	private JPanel getPanelProducts() {
		if (panelProducts == null) {
			panelProducts = new JPanel();
			panelProducts.setLayout(new BoxLayout(panelProducts, BoxLayout.Y_AXIS));
			addProducts();
		}
		return panelProducts;
	}
	
	/**
     * Adds products from the current order to the products panel.
     * Updates the UI with order details or displays a "No Products" message if empty.
     */
	private void addProducts() {
		List<Product> products = logic.getOrderProducts();
		if (products.size() == 0) {
			addNoProducts();
		} else {
			addProductsToPanel(products);
		}
		String orderPrice = String.format("%.2f €", logic.getOrderTotal());
		getTextFieldTotalPrice().setText(orderPrice);
		validate();
	}
	
	/**
	 * Adds a panel indicating that no products are available.
	 * Disables the "Send Order" button and provides an option to go back to the previous screen.
	 */
	private void addNoProducts() {
		getBtnSendOrder().setEnabled(false);
		getPanelProducts().removeAll();
		
		JPanel productPanel = new JPanel();
		productPanel.setBorder(new LineBorder(Color.DARK_GRAY, 3));
		productPanel.setLayout(null);
		productPanel.setBackground(Color.LIGHT_GRAY);
		
		productPanel.setPreferredSize(new Dimension(745, 360));
		
		JLabel lblNameProduct = new JLabel(texts.getString("os.NoProducts"));
		lblNameProduct.setFont(new Font("Rockwell", Font.BOLD, 30));
		lblNameProduct.setForeground(Color.RED);
		lblNameProduct.setBounds(10, 10, 700, 45);
		productPanel.add(lblNameProduct);
		
		JButton btnBack = new JButton(texts.getString("os.Back"));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBack.setFont(new Font("Rockwell", Font.BOLD, 50));
		btnBack.setContentAreaFilled(false);
		btnBack.setBorder(new LineBorder(Color.BLACK, 5, true));
		btnBack.setBounds(10, 50, 500, 75);
		productPanel.add(btnBack);
		
		getPanelProducts().add(productPanel);
	}
	
	/**
	 * Adds the list of products to the products panel.
	 * For each product, it creates a panel displaying the product's name, price, quantity selector, 
	 * and options to modify or remove the product.
	 * 
	 * @param products the list of products to be added to the panel.
	 */
	private void addProductsToPanel(List<Product> products) {
		getBtnSendOrder().setEnabled(true);
		getPanelProducts().removeAll();
		for (Product p : products) {
			JPanel productPanel = new JPanel();
			productPanel.setBorder(new LineBorder(Color.DARK_GRAY, 3));
			productPanel.setLayout(null);
			productPanel.setBackground(Color.LIGHT_GRAY);
			
			productPanel.setPreferredSize(new Dimension(745, 60));
			
			JLabel lblNameProduct = new JLabel(p.getName());
			lblNameProduct.setFont(new Font("Rockwell", Font.BOLD, 17));
			lblNameProduct.setBounds(10, 5, 210, 28);
			productPanel.add(lblNameProduct);
			
			JLabel lblPrice = new JLabel(texts.getString("os.Price") + ":");
			lblPrice.setIconTextGap(10);
			lblPrice.setHorizontalTextPosition(SwingConstants.LEFT);
			lblPrice.setFont(new Font("Rockwell", Font.PLAIN, 15));
			lblPrice.setBounds(545, 13, 50, 36);
			productPanel.add(lblPrice);
			
			JTextField tFProductPrice = new JTextField();
			
			JSpinner spinner = new JSpinner();
			spinner.setFont(new Font("Rockwell", Font.PLAIN, 15));
			spinner.setModel(new SpinnerNumberModel(1, 1, 99, 1));
			spinner.setValue(p.getUnits());
			spinner.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					logic.changeUnitsOfProductFromOrder(p, (int) spinner.getValue());
					updatePrice();
				}

				private void updatePrice() {
					tFProductPrice.setText(String.format("%.2f €", (int) spinner.getValue() * p.getPrice()));
					String orderPrice = String.format("%.2f €", logic.getOrderTotal());
			        getTextFieldTotalPrice().setText(orderPrice);
				}
			});
			spinner.setBounds(476, 13, 60, 36);
			productPanel.add(spinner);
			
			tFProductPrice.setText(String.format("%.2f €", (int) spinner.getValue() * p.getPrice()));
			tFProductPrice.setFont(new Font("Rockwell", Font.PLAIN, 14));
			tFProductPrice.setEditable(false);
			tFProductPrice.setColumns(10);
			tFProductPrice.setBounds(593, 12, 80, 40);
			productPanel.add(tFProductPrice);
			
			JButton btnRemove = new JButton("");
			btnRemove.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					logic.changeUnitsOfProductFromOrder(p, 0);
					addProducts();
				}
			});
			btnRemove.setBounds(673, 7, 50, 50);
			btnRemove.setIcon(loadResizedIcon("/img/bin.png", btnRemove.getWidth() - 6, btnRemove.getHeight() - 6));
			productPanel.add(btnRemove);
			
			if(p.isPizzaOfTheDay()) {
				JLabel lblDiscount = new JLabel(String.format("-%d", (int) (Product.PIZZA_OF_THE_DAY_DISCOUNT * 100)) + "%");
				lblDiscount.setFont(new Font("Rockwell", Font.BOLD, 25));
				lblDiscount.setForeground(Color.RED);
				lblDiscount.setBounds(400, 7, 110, 25);
				productPanel.add(lblDiscount);
			}
			
			if (p.hasIntolerances()) {
			
				JCheckBox chkbxGluten = new JCheckBox(texts.getString("os.GlutenFree"));
				chkbxGluten.setFont(new Font("Rockwell", Font.PLAIN, 12));
				chkbxGluten.setBounds(5, 35, 110, 18);
				chkbxGluten.setSelected(p.getObservations().contains("Gluten"));
				chkbxGluten.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (chkbxGluten.isSelected()) {
							if (!p.getObservations().contains("Gluten")) {p.getObservations().add("Gluten");}
						} else {
							if (p.getObservations().contains("Gluten")) {p.getObservations().remove("Gluten");}
						}
					}
				});
				productPanel.add(chkbxGluten);
				
				JCheckBox chkbxLactose = new JCheckBox(texts.getString("os.LactoseFree"));
				chkbxLactose.setFont(new Font("Rockwell", Font.PLAIN, 12));
				chkbxLactose.setBounds(115, 35, 110, 18);
				chkbxLactose.setSelected(p.getObservations().contains("Lactose"));
				chkbxLactose.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (chkbxLactose.isSelected()) {
							if (!p.getObservations().contains("Lactose")) {p.getObservations().add("Lactose");}
						} else {
							if (p.getObservations().contains("Lactose")) {p.getObservations().remove("Lactose");}
						}
					}
				});
				productPanel.add(chkbxLactose);
				
				JCheckBox chkbxFructose = new JCheckBox(texts.getString("os.FructoseFree"));
				chkbxFructose.setFont(new Font("Rockwell", Font.PLAIN, 12));
				chkbxFructose.setBounds(225, 6, 110, 18);
				chkbxFructose.setSelected(p.getObservations().contains("Fructose"));
				chkbxFructose.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (chkbxFructose.isSelected()) {
							if (!p.getObservations().contains("Fructose")) {p.getObservations().add("Fructose");}
						} else {
							if (p.getObservations().contains("Fructose")) {p.getObservations().remove("Fructose");}
						}
					}
				});
				productPanel.add(chkbxFructose);
				
				JTextField tFOther = new JTextField();
				
				JCheckBox chkbxOther = new JCheckBox(texts.getString("os.Other"));
				chkbxOther.setFont(new Font("Rockwell", Font.PLAIN, 12));
				chkbxOther.setBounds(225, 35, 64, 18);
				chkbxOther.setSelected(p.getObservations().contains("Other"));
				chkbxOther.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int index = p.getObservations().indexOf("Other");
						if (chkbxOther.isSelected()) {
							tFOther.setEnabled(true);
							if (index == -1) {
								p.getObservations().add("Other");
								p.getObservations().add(tFOther.getText());
							}
						} else {
							tFOther.setEnabled(false);
							if (index != -1) {
								p.getObservations().remove(index + 1); // Removes the other text (always in index + 1)
								p.getObservations().remove(index);
							}
						}
					}
				});
				productPanel.add(chkbxOther);
				
				tFOther.setText(texts.getString("os.WriteHere"));
				tFOther.setColumns(10);
				tFOther.setBounds(290, 30, 181, 28);
				tFOther.setEnabled(false);
				int index = p.getObservations().indexOf("Other");
				if (index != -1) {
					tFOther.setEnabled(true);
					tFOther.setText(p.getObservations().get(index + 1));
				}
				tFOther.addFocusListener(new FocusAdapter() {
					@Override
					public void focusLost(FocusEvent e) {
						int index = p.getObservations().indexOf("Other");
						if (chkbxOther.isSelected()) {
							if (index != -1) {
								p.getObservations().set(index + 1, tFOther.getText());
							}
						} else {
							throw new IllegalStateException("This other text box cannot be modifiable if the other checkbox is unselected");
						}
					}
				});
				productPanel.add(tFOther);
			}
			
			getPanelProducts().add(productPanel);
		}
	}
	
	/**
	 * Retrieves and initializes the top panel of the screen.
	 * Contains navigation and reset buttons.
	 *
	 * @return the JPanel instance for the top section.
	 */
	private JPanel getPanelTop() {
		if (panelTop == null) {
			panelTop = new JPanel();
			panelTop.setLayout(new BorderLayout(3, 0));
			panelTop.add(getBtnBack(), BorderLayout.WEST);
			panelTop.add(getBtnResetOrder(), BorderLayout.CENTER);
			panelTop.add(getPanelID(), BorderLayout.EAST);
		}
		return panelTop;
	}
	
	/**
	 * Retrieves and initializes the panel for the user ID section.
	 * Displays the user ID with a label and text field.
	 *
	 * @return the JPanel instance for the user ID section.
	 */
	private JPanel getPanelID() {
		if (panelID == null) {
			panelID = new JPanel();
			panelID.setLayout(new BorderLayout(2, 0));
			panelID.add(getLblID(), BorderLayout.WEST);
			panelID.add(getTxtID(), BorderLayout.CENTER);
		}
		return panelID;
	}
	
	/**
	 * Retrieves and initializes the bottom panel of the screen.
	 * Contains the total price display and the send order button.
	 *
	 * @return the JPanel instance for the bottom section.
	 */
	private JPanel getPanelDown() {
		if (panelDown == null) {
			panelDown = new JPanel();
			panelDown.setLayout(new BorderLayout(0, 0));
			panelDown.add(getBtnSendOrder(), BorderLayout.EAST);
			panelDown.add(getPanelTotalPrice(), BorderLayout.WEST);
			if (logic.getCurrentVip()) {
				panelDown.add(getLblVIP(), BorderLayout.CENTER);
			}
		}
		return panelDown;
	}
	
	/**
	 * Retrieves and initializes the panel for the total price section.
	 * Displays the total cost of the current order with a label and text field.
	 *
	 * @return the JPanel instance for the total price section.
	 */
	private JPanel getPanelTotalPrice() {
		if (panelTotalPrice == null) {
			panelTotalPrice = new JPanel();
			panelTotalPrice.setLayout(new BorderLayout(0, 0));
			panelTotalPrice.add(getLblTotalPrice(), BorderLayout.WEST);
			panelTotalPrice.add(getTextFieldTotalPrice(), BorderLayout.CENTER);
		}
		return panelTotalPrice;
	}
	
	/**
	 * Retrieves and initializes the center panel of the screen.
	 * Contains the scrollable list of products in the current order.
	 *
	 * @return the JPanel instance for the center section.
	 */
	private JPanel getPanelCenter() {
		if (panelCenter == null) {
			panelCenter = new JPanel();
			panelCenter.setLayout(new BorderLayout(0, 0));
			panelCenter.add(getScrollPaneProducts(), BorderLayout.CENTER);
		}
		return panelCenter;
	}
	
	/**
     * Loads the help system for this screen.
     * Associates help content with UI components.
     */
	private void loadHelp() {
		URL hsURL;
		HelpSet hs;
		try {
			File fichero = new File("help/Help.hs");
			hsURL = fichero.toURI().toURL();
			hs = new HelpSet(null, hsURL);
		} catch (Exception e){
			System.out.println("Help not found!");
	    	return;
		}
	   HelpBroker hb = hs.createHelpBroker();
	   hb.enableHelpKey(getRootPane(),"orderSummary", hs);   
	}
	private JLabel getLblVIP() {
		if (lblVIP == null) {
			lblVIP = new JLabel(texts.getString("os.Vip") + String.format(" (-%.0f%% %s)", Order.VIP_DISCOUNT, texts.getString("os.discount")));
			lblVIP.setForeground(Color.RED);
			lblVIP.setFont(new Font("Tahoma", Font.BOLD, 20));
			lblVIP.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblVIP;
	}
}
