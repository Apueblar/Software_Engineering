package app.model;

/** 
 * Represents a reservation made by a client, containing details such as client ID, 
 * reservation code, and number of orders.
 */
public class Reservation {
	
	private String clientID; // DNI
	private boolean vip; // VIP
	private String reservationCode; // 6 random characters, excluding the @
	private boolean gamePlayed = false; // True if game was played
	private int numberOfOrders = 1;
	
	/** Constructs a reservation with specified client ID, vip and reservation code. */
	public Reservation(String clientID, boolean vip, String reservationCode) {
		this.clientID = clientID;
		this.vip = vip;
		this.reservationCode = reservationCode;
	}

	/** Constructs a reservation with specified client ID and reservation code. */
	public Reservation(String clientID, String reservationCode) {
		this.clientID = clientID;
		this.reservationCode = reservationCode;
	}

	/** Retrieves the client ID associated with this reservation. */
	public String getClientID() {
		return clientID;
	}
	
	/** Retrieves the associated vip status with this reservation. */
	public boolean isVip() {
		return vip;
	}

	/** Retrieves the reservation code. */
	public String getReservationCode() {
		return reservationCode;
	}
	
	public void setVip(boolean vip) {
		this.vip = vip;	
	}
	
	/** 
     * Sets whether the client has played the game associated with this reservation.
     * @param gamePlayed True if the game was played, false otherwise.
     */
	public void setGamePlayed(boolean gamePlayed) {
		this.gamePlayed = gamePlayed;
	}
	
	/** Indicates if the game has been played for this reservation. */
	public boolean isGamePlayed() {
		return gamePlayed;
	}
	
	/** Increments the number of orders associated with this reservation. */
	public void incrementNumberOfOrders() {
		numberOfOrders++;
	}

	/** Retrieves the number of orders associated with this reservation. */
	public int getNumberOfOrders() {
		return numberOfOrders;
	}
}
