package app.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import app.model.Menu;
import app.model.Order;
import app.model.Product;
import app.model.Reservation;
import app.model.TypeOfProduct;
import app.util.FileUtil;

/** 
 * Handles the business logic of the application, including managing reservations, 
 * orders, menus, and game logic.
 */
public class Logic {
	public final static String RESERVATIONS_FILENAME = "files/reservations.dat";
	
	private List<Reservation> reservations = new ArrayList<Reservation>();
	private List<Order> doneOrders = new ArrayList<Order>();
	private Reservation currentReservation;
	private List<Product> prizes;
	private Menu menu = new Menu();
	private Order order;
	
	private boolean finishReservation = false;
	
	/** Initializes the Logic instance, loading reservations and setting up initial data. */
	public Logic() {
		initialize();
	}

	/** Loads the reservations from the file and resets the current order. */
	public void initialize() {
		FileUtil.loadReservationFile(RESERVATIONS_FILENAME, reservations);
		order = new Order();
	}
	
	public void saveReservation() {
		FileUtil.saveReservationFile(RESERVATIONS_FILENAME, reservations);
	}
	
	/**
	 * Validates reservation details and removes the reservation if valid.
	 * 
	 * <p>This method iterates through the list of reservations to find a match for the 
	 * provided client ID and reservation code. If a match is found, the reservation is 
	 * removed, and an appropriate status code is returned.</p>
	 * 
	 * @param reservation the code of the reservation to validate
	 * @return the result of the validation:
	 *         <ul>
	 *             <li>{@code 0} if the reservation is valid and removed successfully,</li>
	 *             <li>{@code -1} if the client ID is not found,</li>
	 *             <li>{@code -2} if the reservation code is incorrect.</li>
	 *         </ul>
	 */
	public int checkReservationDetails(Reservation reservation) {
	    Iterator<Reservation> iterator = reservations.iterator();
	    while (iterator.hasNext()) {
	        Reservation r = iterator.next();
	        if (r.getClientID().equals(reservation.getClientID())) {
	        	if (r.getReservationCode().equals(reservation.getReservationCode())) {
	        		reservation.setVip(r.isVip());
	        		iterator.remove();
	        		saveReservation();
	            	return 0;
	        	}
	        	return -2;
	        }
	    }
	    return -1;
	}
	
	/** Retrieves all products available in the menu. */
	public List<Product> getMenuProducts() {
		return menu.getProducts();
	}
	
	/** Retrieves products from the menu filtered by specified types. */
	public List<Product> getMenuTypeProduct(List<TypeOfProduct> types) {
		return menu.getTypeProduct(types);
	}

	/** Adds a product to the current order with specified units and observations. */
	public void addToOrder(Product p, int units, List<String> observations) {
		order.add(p, units, observations);
	}
	
	/** Changes the quantity of a specific product in the current order. */
	public void changeUnitsOfProductFromOrder(Product item, int units) {
		order.changeUnits(item, units);
	}

	/** Retrieves the total price of the current order. */
	public double getOrderTotal() {
		return order.getTotalPrice();
	}
	
	/** Retrieves the unique code of the current order. */
	public String getCurrentCode() {
		return order.getCode();
	}

	/** Associates a reservation with the current order. */
	public void setReservation(Reservation reservation) {
		this.currentReservation = reservation;
		order.setReservation(reservation);
	}
	
	 /** Resets the current order and associates it with the current reservation. */
	public void resetOrder() {
		order = new Order();
		order.setReservation(currentReservation);
	}

	/** Retrieves all products in the current order. */
	public List<Product> getOrderProducts() {
		return order.getOrderList();
	}
	
	/** Sorts the products in the current order. */
	public void orderSort() {
		order.sort();
	}
	
	/** Retrieves the client ID of the current reservation. */
	public String getCurrentID() {
		return currentReservation.getClientID();
	}
	
	public boolean getCurrentVip() {
		return currentReservation.isVip();
	}
	
	/** Determines if the client can play the game. */
	public boolean canPlayGame() {
		return !currentReservation.isGamePlayed();
	}
	
	/** Determines if multiple orders are available to show. */
	public boolean canShowOrders() {
		return currentReservation.getNumberOfOrders() > 1;
	}

	/** Sends the current order, saving it and resetting for a new order. */
	public void sendOrder() {
		doneOrders.add(order);
		FileUtil.saveOrderFile(order);
		
		currentReservation.incrementNumberOfOrders();
		resetOrder();
	}

	/** Sets the prizes won in the game for the current reservation. */
	public void setPrices(List<Product> prizes) {
		currentReservation.setGamePlayed(true);
		this.prizes = prizes;
	}
	
	/** Retrieves the list of prizes won in the game. */
	public List<Product> getPrizes() {
		return prizes;
	}

	/** Retrieves all orders that have been completed. */
	public List<Order> getDoneOrders() {
		return doneOrders;
	}
	
	/** Calculates the total price of all completed orders. */
	public double getFinalPrice() {
		double total = 0;
		for (Order o : getDoneOrders()) { total += o.getTotalPrice(); }
		return total;
	}

	/** Indicates if the reservation is marked as finished. */
	public boolean isFinishReservation() {
		return finishReservation;
	}

	/** Marks the reservation as finished. */
	public void setFinishReservation(boolean finishReservation) {
		this.finishReservation = finishReservation;
	}
	
	/** Finalizes the reservation, clearing all completed orders. */
	public void finishReservation() {
		setFinishReservation(false);
		doneOrders.clear();
		order = new Order();
	}
}
