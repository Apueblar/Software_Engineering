package app.model;

import java.util.*;

/** 
 * Represents an order made by a client, containing a list of products, 
 * associated reservation details, and a unique code.
 */
public class Order {
	
	private List<Product> orderList = new ArrayList<Product>();
	private Reservation reservation;
	private String code;
	public final static double VIP_DISCOUNT = 10; // total -10%
	
	/** Default constructor for creating an empty order. */
	public Order() {}
	
	/** Retrieves the unique code associated with this order. */
	public String getCode() {
		return code;
	}
	
	/** 
     * Adds a product to the order or updates the quantity if it already exists in the order.
     * @param item The product to add.
     * @param units The quantity of the product to add.
     * @param observations A list of additional observations for the product.
     */
	public void add(Product item, int units, List<String> observations){
		Product addItem = null;
	
		for (Product a : orderList){
			if (a.getCode().equals(item.getCode()) && a.getObservations().equals(observations)) {
				addItem = a;
				addItem.setUnits(addItem.getUnits() + units);
				return ;
			}
		}
		
		if (addItem == null){
			addItem = new Product(item);
			addItem.setUnits(units);
			addItem.setObservations(observations);
			orderList.add(addItem);
		}
	}
	
	/** 
     * Calculates the total price of all products in the order.
     * @return The total price of the order.
     */
	public double getTotalPrice(){
		double total = 0.0;
		for (Product a : orderList){
			total += a.getPrice()* a.getUnits();
		}
		boolean isVip = reservation.isVip();
		return isVip ?  total * (100 - VIP_DISCOUNT) / 100: total;
	}
	
	/** Retrieves the list of products in the order. */
	public List<Product> getOrderList() {
		return orderList;
	}
	
	/** Retrieves the reservation associated with this order. */
	public Reservation getReservation() {
		return reservation;
	}

	/** 
     * Associates a reservation with this order and generates a unique order code.
     * @param reservation The reservation to associate.
     */
	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
		code = String.format("%s_C%d", reservation.getReservationCode(), reservation.getNumberOfOrders());
	}

	 /** Sorts the products in the order by name and number of observations. */
	public void sort() {
		orderList.sort(new Comparator<Product>() {

			@Override
			public int compare(Product o1, Product o2) {
				int nameComparison = o1.getName().compareTo(o2.getName());
	            if (nameComparison != 0) { return nameComparison; }
	            
	            int observationsSize1 = o1.getObservations() == null ? 0 : o1.getObservations().size();
	            int observationsSize2 = o2.getObservations() == null ? 0 : o2.getObservations().size();

	            return Integer.compare(observationsSize1, observationsSize2);
			}
			
		});
		joinEquals();
	}
	private void joinEquals() {
		List<Product> newOrderList = new ArrayList<Product>();
		for (Product p : orderList) {
			int index = newOrderList.indexOf(p);
			if (index != -1) {
				newOrderList.get(index).setUnits(newOrderList.get(index).getUnits() + p.getUnits());
			} else {
				newOrderList.add(p);
			}
		}
		orderList = newOrderList;
	}

	/** 
     * Updates the quantity of a specific product in the order.
     * If the quantity is zero or less, the product is removed from the order.
     * @param item The product to update.
     * @param units The new quantity of the product.
     */
	public void changeUnits(Product item, int units) {
		Product itemInOrder = null;
		for (Product a : orderList) {
			if (a.getCode().equals(item.getCode())) {
				itemInOrder = a;
				itemInOrder.setUnits(units);
				if (itemInOrder.getUnits() <= 0) {
					itemInOrder.setUnits(0);
					orderList.remove(itemInOrder);
				}
				break;
			}
		}
		if(itemInOrder == null) {throw new IllegalStateException("The remove method has a problem");}
	}

	/** 
     * Converts the order details into a formatted string for storage.
     * @return A string representation of the order.
     */
	@Override
	public String toString() {
		StringBuilder text = new StringBuilder();
		StringBuilder obs = new StringBuilder();
		obs.append("Observations: \n");
		String sep = "@";
        
		for (Product p : getOrderList()) { 
			text.append(String.format("%s%s%s%s%s\n", p.getCode(), sep, p.getName(), sep, p.getUnits())); 
			if (p.getObservations().size() != 0) {
				StringBuilder currentObs = new StringBuilder();
				currentObs.append( p.getName() + " ");
				if (p.getObservations().contains("Gluten")) {
					currentObs.append("without gluten, ");
				}
				if (p.getObservations().contains("Lactose")) {
					currentObs.append("without lactose, ");
				}
				if (p.getObservations().contains("Fructose")) {
					currentObs.append("without fructose, ");
				}
				int index = p.getObservations().indexOf("Other");
				if (index != -1) {
					currentObs.append("other: " + p.getObservations().get(index + 1) + ", ");
				}
				if (currentObs.length() > 0) { 
					currentObs.setLength(currentObs.length() - 2);
					currentObs.append("\n");
				} // Remove last ", "
				
				obs.append(currentObs);
			}
		}
		
		text.append(obs);
        return text.toString();
	}
	
	/** 
     * Converts the order details into a user-friendly string format.
     * @return A list of strings representing the order details for the user.
     */
	public List<String> toUserString() {
		List<String> info = new ArrayList<String>();
		
		String sep = "-";
		for (Product p : getOrderList()) {
			StringBuilder text = new StringBuilder();
			text.append(String.format("%s %s %s", p.getName(), sep, p.getUnits()));
			
			if (p.getObservations().size() != 0) {
				StringBuilder currentObs = new StringBuilder();
				currentObs.append(" " + sep + " ");
				if (p.getObservations().contains("Gluten")) {
					currentObs.append("without gluten, ");
				}
				if (p.getObservations().contains("Lactose")) {
					currentObs.append("without lactose, ");
				}
				if (p.getObservations().contains("Fructose")) {
					currentObs.append("without fructose, ");
				}
				int index = p.getObservations().indexOf("Other");
				if (index != -1) {
					currentObs.append(p.getObservations().get(index + 1) + ", ");
				}
				
				currentObs.setLength(currentObs.length() - 2);
				
				text.append(currentObs);
			}
			
			info.add(text.toString());
		}
		
        return info;
	}
}