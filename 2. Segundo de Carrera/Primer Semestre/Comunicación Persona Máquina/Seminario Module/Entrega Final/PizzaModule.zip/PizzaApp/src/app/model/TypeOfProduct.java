package app.model;

public enum TypeOfProduct {
	Drink, Salad, Starter, Bread, Pasta, Pizza, Dessert;
}
