package app.model;

import java.util.ArrayList;
import java.util.List;

import app.util.FileUtil;

/**
 * Represents the menu of products available in the application, including a special "Pizza of the Day".
 * The menu is loaded from a file and provides methods to retrieve products by type or the pizza of the day.
 */
public class Menu {
	
	/** The file path for the menu data. */
	public final static String MENU_FILENAME = "files/menu.dat";
	
	/** List of all products available in the menu. */
	private List<Product> products = new ArrayList<Product>();
	
	/**
     * Constructs a Menu object and initializes the product list by loading data from the file.
     */
	public Menu(){
		loadProducts();
	}

	/**
     * Loads the product list from the file and assigns the "Pizza of the Day".
     */
	private void loadProducts(){
		FileUtil.loadMenuFile(MENU_FILENAME, products);
		assignPizzaOfTheDay();
	}

	/**
     * Randomly selects a pizza product from the menu and designates it as the "Pizza of the Day".
     * Ensures the selected product is of type {@code TypeOfProduct.Pizza}.
     */
	private void assignPizzaOfTheDay() {
		boolean notAssigned = true;
		while (notAssigned) {
			int index = (int) (Math.random() * products.size());
			if (products.get(index).getType().equals(TypeOfProduct.Pizza)) {
				products.get(index).setPizzaOfTheDay(true);
				products.get(index);
				notAssigned = false;
			}
		}
	}
	
	/**
     * Retrieves the complete list of products in the menu.
     *
     * @return the list of products.
     */
	public List<Product> getProducts(){
		return products;
	}
	
	/**
     * Retrieves a list of products filtered by the specified types.
     * If no types are specified, the entire product list is returned.
     *
     * @param types the list of product types to filter by.
     * @return a list of products matching the specified types, or all products if no types are specified.
     */
	public List<Product> getTypeProduct(List<TypeOfProduct> types) {
		if (types.size() == 0) {return getProducts();}
		List<Product> productsTypeList = new ArrayList<Product>();
		for (int i = 0; i < products.size(); i++) {
			for (TypeOfProduct type : types) {
				if(products.get(i).getType().equals(type)) {productsTypeList.add(products.get(i));}
			}
		}
		return productsTypeList;
	}
}
