package app.ui;

import javax.help.*;
import java.net.*;
import java.io.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;

import javax.swing.border.LineBorder;

import app.model.Reservation;
import app.service.Logic;

import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Represents the starting screen of the application "Papa Slice."
 * This screen allows users to enter their reservation details and access the main menu.
 * It also provides options for language selection, help, and about information.
 * 
 * Features include:
 * - Multi-language support
 * - Integrated help system
 * - Reservation validation
 */
public class StartScreen extends JFrame {

	private static final long serialVersionUID = 1L; // Serialization ID for the JFrame
	
	// Application logic and localization resources
	private Logic logic;
	private ResourceBundle texts;
	
	// UI Components
    private JPanel contentPane; // Main content container
    private JLabel lblLogo; // Logo label
    private JButton btnInfo; // Info button
    private JLabel lblID; // Label for client ID
    private JTextField textFieldID; // Input field for client ID
    private JLabel lblReserveNumber; // Label for reservation number
    private JTextField textFieldReserveNumber; // Input field for reservation number
    private JMenuBar menuBar; // Top menu bar
    private JMenu mnLanguaje; // Language menu
    private JRadioButtonMenuItem rdbtnmntmEspanol; // Spanish language option
    private JRadioButtonMenuItem rdbtnmntmEnglish; // English language option
    private JRadioButtonMenuItem rdbtnmntmFrancaise; // French language option
    private JMenu mnHelp; // Help menu
    private JMenuItem mntmContent; // Help content menu item
    private JMenuItem mntmAbout; // About menu item
    private JSeparator HelpSeparator; // Separator for the help menu
    private JButton btnEnter; // Enter button
    private JDialog menuScreen; // Dialog for the menu screen

    /**
     * Constructs the starting screen frame.
     * Initializes the UI components, loads the default language, and sets up the help system.
     * 
     * @param logic the Logic instance responsible for handling business logic.
     */
	public StartScreen(Logic logic) {
		addWindowListener(new WindowAdapter() { // Handle window closing
			@Override
			public void windowClosing(WindowEvent e) {
				exit(); // Confirm before exiting
			}
		});
		this.logic = logic; // Store the logic reference
		
		this.setTitle("Papa Slice"); // Set the window title
		String logo = "/img/logo.png"; // Set the application icon
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(StartScreen.class.getResource(logo)));
		
		setResizable(false); // Prevent resizing the window
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblLogo());
		contentPane.add(getBtnInfo());
		contentPane.add(getLblID());
		contentPane.add(getTextFieldID());
		contentPane.add(getLblReserveNumber());
		contentPane.add(getTextFieldReserveNumber());
		contentPane.add(getBtnEnter());
		
		localize(Locale.of("en")); // Default language
		loadHelp();
	}
	
	/**
     * Displays a confirmation dialog before exiting the application.
     * If the user confirms, the application exits; otherwise, it remains open.
     */
	private void exit() {
		int resp = JOptionPane.showConfirmDialog(null, texts.getString("ss.exit"), texts.getString("ss.exitTittle"), JOptionPane.YES_NO_OPTION);
		if (resp == JOptionPane.YES_OPTION) {
			System.exit(0);
		}
	}
	
	/**
     * Retrieves and configures the menu bar at the top of the window.
     * The menu bar contains language selection and help options.
     *
     * @return the JMenuBar instance for the application.
     */
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.setBorderPainted(false);
			menuBar.setBackground(Color.GRAY);
			menuBar.add(getMnLanguaje());
			menuBar.add(getMnHelp());
		}
		return menuBar;
	}
	
	/**
     * Retrieves and configures the language menu.
     * The menu allows users to select the application's language.
     *
     * @return the JMenu instance for language selection.
     */
	private JMenu getMnLanguaje() {
		if (mnLanguaje == null) {
			mnLanguaje = new JMenu("Language");
			mnLanguaje.setFont(new Font("Rockwell", Font.BOLD, 15));
			
			ButtonGroup languaje = new ButtonGroup(); // For only have 1 selected
			languaje.add(getRdbtnmntmEspanol());
			languaje.add(getRdbtnmntmEnglish());
			languaje.add(getRdbtnmntmFrancaise());
			
			mnLanguaje.add(getRdbtnmntmEspanol());
			mnLanguaje.add(getRdbtnmntmEnglish());
			mnLanguaje.add(getRdbtnmntmFrancaise());
		}
		return mnLanguaje;
	}
	
	/**
     * Retrieves and configures the Spanish language option in the language menu.
     *
     * @return the JRadioButtonMenuItem instance for Spanish.
     */
	private JRadioButtonMenuItem getRdbtnmntmEspanol() {
		if (rdbtnmntmEspanol == null) {
			rdbtnmntmEspanol = new JRadioButtonMenuItem("Español");
			rdbtnmntmEspanol.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					localize(Locale.of("es"));
				}
			});
			rdbtnmntmEspanol.setFont(new Font("Rockwell", Font.PLAIN, 15));
		}
		return rdbtnmntmEspanol;
	}
	
	/**
     * Retrieves and configures the English language option in the language menu.
     *
     * @return the JRadioButtonMenuItem instance for English.
     */
	private JRadioButtonMenuItem getRdbtnmntmEnglish() {
		if (rdbtnmntmEnglish == null) {
			rdbtnmntmEnglish = new JRadioButtonMenuItem("English");
			rdbtnmntmEnglish.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					localize(Locale.of("en"));
				}
			});
			rdbtnmntmEnglish.setSelected(true);
			rdbtnmntmEnglish.setFont(new Font("Rockwell", Font.PLAIN, 15));
		}
		return rdbtnmntmEnglish;
	}
	
	/**
     * Retrieves and configures the French language option in the language menu.
     *
     * @return the JRadioButtonMenuItem instance for French.
     */
	private JRadioButtonMenuItem getRdbtnmntmFrancaise() {
		if (rdbtnmntmFrancaise == null) {
			rdbtnmntmFrancaise = new JRadioButtonMenuItem("Française");
			rdbtnmntmFrancaise.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					localize(Locale.of("fr"));
				}
			});
			rdbtnmntmFrancaise.setFont(new Font("Rockwell", Font.PLAIN, 15));
		}
		return rdbtnmntmFrancaise;
	}
	
	/**
     * Retrieves and configures the Help menu.
     * The menu contains options to view help content and about information.
     *
     * @return the JMenu instance for the Help menu.
     */
	private JMenu getMnHelp() {
		if (mnHelp == null) {
			mnHelp = new JMenu("Help");
			mnHelp.setFont(new Font("Rockwell", Font.BOLD, 15));
			mnHelp.add(getMntmContent());
			mnHelp.add(getHelpSeparator());
			mnHelp.add(getMntmAbout());
		}
		return mnHelp;
	}
	
	/**
     * Retrieves and configures the Help Content menu item.
     *
     * @return the JMenuItem instance for Help Content.
     */
	private JMenuItem getMntmContent() {
		if (mntmContent == null) {
			mntmContent = new JMenuItem("Content");
			mntmContent.setFont(new Font("Rockwell", Font.PLAIN, 15));
		}
		return mntmContent;
	}
	
	/**
     * Retrieves and configures the About menu item.
     * This option displays an information dialog with details about the application.
     *
     * @return the JMenuItem instance for About.
     */
	private JMenuItem getMntmAbout() {
		if (mntmAbout == null) {
			mntmAbout = new JMenuItem("About");
			mntmAbout.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, texts.getString("all.AboutMessage"), texts.getString("all.About") + ": " + "Papa Slice", JOptionPane.INFORMATION_MESSAGE, loadResizedIcon("/img/logo.png", 120, 120));
				}
			});
			mntmAbout.setFont(new Font("Rockwell", Font.PLAIN, 15));
		}
		return mntmAbout;
	}
	
	/**
     * Retrieves and configures the separator in the Help menu.
     *
     * @return the JSeparator instance for the Help menu.
     */
	private JSeparator getHelpSeparator() {
		if (HelpSeparator == null) {
			HelpSeparator = new JSeparator();
		}
		return HelpSeparator;
	}
	
	/**
     * Loads and resizes an icon from the specified resource path.
     * Maintains the original aspect ratio of the image.
     * 
     * @param resourcePath the path to the image resource.
     * @param maxWidth the maximum width of the resized icon.
     * @param maxHeight the maximum height of the resized icon.
     * @return a resized ImageIcon instance, or the original if resizing is unnecessary.
     */
	private ImageIcon loadResizedIcon(String resourcePath, int maxWidth, int maxHeight) {
	    ImageIcon originalIcon = new ImageIcon(getClass().getResource(resourcePath));
	    int originalWidth = originalIcon.getIconWidth();
	    int originalHeight = originalIcon.getIconHeight();

	    // Resize only if the original image exceeds max dimensions
	    if (originalWidth > maxWidth || originalHeight > maxHeight) {
	        // Calculate scaled dimensions while maintaining aspect ratio
	        double widthRatio = (double) maxWidth / originalWidth;
	        double heightRatio = (double) maxHeight / originalHeight;
	        double scaleFactor = Math.min(widthRatio, heightRatio);

	        int newWidth = (int) (originalWidth * scaleFactor);
	        int newHeight = (int) (originalHeight * scaleFactor);

	        // Resize the image
	        Image resizedImage = originalIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
	        return new ImageIcon(resizedImage);
	    }
	    return originalIcon; // Return original icon if no resizing is needed
	}
	
	/**
     * Retrieves and initializes the logo label.
     *
     * @return the JLabel instance for the logo.
     */
	private JLabel getLblLogo() {
		if (lblLogo == null) {
			lblLogo = new JLabel(" Papa Slice");
			lblLogo.setIcon(loadResizedIcon("/img/logo.png", 300, 200));

			lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
			lblLogo.setBackground(Color.LIGHT_GRAY);
			lblLogo.setFont(new Font("SansSerif", Font.BOLD, 50));
			lblLogo.setBounds(50, 50, 650, 200);
		}
		return lblLogo;
	}
	
	/**
     * Retrieves and initializes the information/help button.
     *
     * @return the JButton instance for the information/help button.
     */
	private JButton getBtnInfo() {
		if (btnInfo == null) {
			btnInfo = new JButton("?");
			btnInfo.setContentAreaFilled(false);
			btnInfo.setBorder(new LineBorder(new Color(0, 0, 0), 5, true));
			btnInfo.setForeground(Color.BLACK);
			btnInfo.setFont(new Font("Rockwell", Font.BOLD, 50));
			btnInfo.setMnemonic('i');
			btnInfo.setBackground(Color.WHITE);
			btnInfo.setBounds(706, 16, 64, 64);
		}
		return btnInfo;
	}
	
	/**
     * Retrieves and initializes the ID label.
     * 
     * @return the JLabel instance for the user ID input label.
     */
	private JLabel getLblID() {
		if (lblID == null) {
			lblID = new JLabel("ID:");
			lblID.setLabelFor(getTextFieldID());
			lblID.setFont(new Font("Rockwell", Font.BOLD, 35));
			lblID.setBounds(50, 263, 426, 52);
		}
		return lblID;
	}
	
	/**
     * Retrieves and initializes the user ID text field.
     * 
     * @return the JTextField instance for the user ID input.
     */
	private JTextField getTextFieldID() {
		if (textFieldID == null) {
			textFieldID = new JTextField();
			textFieldID.addKeyListener(new KeyAdapter() {
				@Override
				public void keyTyped(KeyEvent e) {
					if (!Character.isDigit(e.getKeyChar())) {e.consume();}
					final int MAX_CODE_LENGTH = 10;
					if (textFieldID.getText().length() >= MAX_CODE_LENGTH) {e.consume();} // Avoid extra characters over the max length
				}
			});
			textFieldID.setFont(new Font("Rockwell", Font.PLAIN, 40));
			textFieldID.setBounds(488, 262, 235, 52);
			textFieldID.setColumns(10);
		}
		return textFieldID;
	}
	
	/**
     * Retrieves and initializes the reservation number label.
     * 
     * @return the JLabel instance for the reservation number input label.
     */
	private JLabel getLblReserveNumber() {
		if (lblReserveNumber == null) {
			lblReserveNumber = new JLabel("Reserve Number:");
			lblReserveNumber.setLabelFor(getTextFieldReserveNumber());
			lblReserveNumber.setFont(new Font("Rockwell", Font.BOLD, 35));
			lblReserveNumber.setBounds(50, 347, 426, 52);
		}
		return lblReserveNumber;
	}
	
	/**
     * Retrieves and initializes the reservation number text field.
     * 
     * @return the JTextField instance for the reservation number input.
     */
	private JTextField getTextFieldReserveNumber() {
		if (textFieldReserveNumber == null) {
			textFieldReserveNumber = new JTextField();
			textFieldReserveNumber.addKeyListener(new KeyAdapter() {
				@Override
				public void keyTyped(KeyEvent e) {
					final int MAX_CODE_LENGTH = 6;
					if (textFieldReserveNumber.getText().length() >= MAX_CODE_LENGTH) {e.consume();} // Avoid extra characters over the max length
				}
			});
			textFieldReserveNumber.setFont(new Font("Rockwell", Font.PLAIN, 40));
			textFieldReserveNumber.setColumns(10);
			textFieldReserveNumber.setBounds(488, 346, 235, 52);
		}
		return textFieldReserveNumber;
	}
	
	/**
     * Retrieves and initializes the "Enter" button.
     * 
     * @return the JButton instance for the "Enter" button.
     */
	private JButton getBtnEnter() {
		if (btnEnter == null) {
			btnEnter = new JButton("ENTER");
			btnEnter.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Reservation reservation = new Reservation(getTextFieldID().getText(), getTextFieldReserveNumber().getText());
					switch (checkReservationDetails(reservation)) {
					case 0: showMenuScreen(reservation); break;
					case -1: JOptionPane.showMessageDialog(null, texts.getString("ss.IDNotFound"), texts.getString("ss.IDNotFoundTittle"), JOptionPane.ERROR_MESSAGE); break;
					case -2: JOptionPane.showMessageDialog(null, texts.getString("ss.WrongReservationCode"), texts.getString("ss.WrongReservationCodeTittle"), JOptionPane.ERROR_MESSAGE); break;
					default: throw new IllegalStateException("Enter check failed");
					}
				}
			});
			btnEnter.setBorder(new LineBorder(new Color(128, 128, 128), 5, true));
			btnEnter.setBackground(Color.LIGHT_GRAY);
			btnEnter.setFont(new Font("Rockwell", Font.BOLD, 40));
			btnEnter.setBounds(448, 432, 275, 76);
		}
		return btnEnter;
	}
	
	/**
	 * Displays a MenuScreen instance
	 * @param reservation The current reservation
	 */
	private void showMenuScreen(Reservation reservation) {
		menuScreen = new MenuScreen(logic, reservation, texts);
		menuScreen.setLocationRelativeTo(this);
		menuScreen.setModal(true);
		menuScreen.setVisible(true);
	}
	
	/**
     * Updates the UI texts based on the selected language.
     * 
     * @param locale the selected locale for localization.
     */
	private void localize(Locale lo) {
		texts = ResourceBundle.getBundle("properties/texts",lo);
		
		getBtnInfo().setToolTipText(texts.getString("ss.btnInfoToolTip"));
		
		getLblID().setText(texts.getString("ss.ID") + ":");
		getTextFieldID().setToolTipText(texts.getString("ss.textFieldIDToolTip"));
		
		getLblReserveNumber().setText(texts.getString("ss.ReserveNumber") + ":");
		getTextFieldReserveNumber().setToolTipText(texts.getString("ss.textFieldReserveNumberToolTip"));
		
		getBtnEnter().setText(texts.getString("ss.Enter"));
		getBtnEnter().setMnemonic(texts.getString("ss.EnterMnemonic").charAt(0));
		getBtnEnter().setToolTipText(texts.getString("ss.btnEnterToolTip"));
		
		getMnLanguaje().setText(texts.getString("ss.language"));
		getMnLanguaje().setMnemonic(texts.getString("ss.LanguageMnemonic").charAt(0));
		getRdbtnmntmEspanol().setMnemonic(texts.getString("ss.EspanolMnemonic").charAt(0));
		getRdbtnmntmEnglish().setMnemonic(texts.getString("ss.EnglishMnemonic").charAt(0));
		getRdbtnmntmFrancaise().setMnemonic(texts.getString("ss.FrancaiseMnemonic").charAt(0));
		getMnHelp().setText(texts.getString("ss.help"));
		getMnHelp().setMnemonic(texts.getString("ss.HelpMnemonic").charAt(0));
		getMntmContent().setText(texts.getString("ss.content"));
		getMntmContent().setMnemonic(texts.getString("ss.ContentMnemonic").charAt(0));
		getMntmAbout().setText(texts.getString("ss.about"));
		getMntmAbout().setMnemonic(texts.getString("ss.AboutMnemonic").charAt(0));
		
	}
	
	/**
	 * Calls the checkReservationDetails(clientID, reservationCode) of logic
	 * @param reservation 
	 * @param clientID the ID of the client whose reservation is being checked
	 * @param reservationCode the code of the reservation to validate
	 * @return the result of the validation:
	 *         <ul>
	 *             <li>{@code 0} if the reservation is valid and removed successfully,</li>
	 *             <li>{@code -1} if the client ID is not found,</li>
	 *             <li>{@code -2} if the reservation code is incorrect.</li>
	 *         </ul>
	 */
	private int checkReservationDetails(Reservation reservation) {
		return logic.checkReservationDetails(reservation);
	}
	
	/**
     * Initializes the help system by loading the help set file.
     */
	private void loadHelp() {
		URL hsURL;
		HelpSet hs;
		try {
			File fichero = new File("help/Help.hs");
			hsURL = fichero.toURI().toURL();
			hs = new HelpSet(null, hsURL);
		} catch (Exception e){
			System.out.println("Help not found!");
	    	return;
		}
	   HelpBroker hb = hs.createHelpBroker();
	   hb.enableHelpKey(getRootPane(),"introduction", hs);
	   hb.enableHelpOnButton(mntmContent, "introduction", hs);
	   hb.enableHelpOnButton(btnInfo, "login", hs);
	   hb.enableHelp(textFieldID, "login", hs);
	   hb.enableHelp(textFieldReserveNumber, "login", hs);	   
	}
}
