package app.model;

import java.util.List;
import java.util.Objects;

/** 
 * Represents a product available for ordering, with attributes such as code, name, 
 * description, type, price, and observations.
 */
public class Product {
	
	private final static int MAX_NUMBER_OF_SAME_PRODUCTS_PER_ORDER = 99;
	public static final double PIZZA_OF_THE_DAY_DISCOUNT = 0.2;
	
	private String code;
	private String name;
	private String description;
	private boolean intolerances;
	private TypeOfProduct type;
	private int units;
	private double price;
	private List<String> observations;
	private boolean pizzaOfTheDay = false;
	
	/** Constructs a product with specified details. */
	public Product(String code, String name, String description, boolean intolerances, TypeOfProduct type,
			double price) {
		this.code = code;
		this.name = name;
		this.description = description;
		this.intolerances = intolerances;
		this.type = type;
		this.price = price;
	}

	/** 
     * Constructs a product by copying the details of another product.
     * @param newProduct The product to copy.
     */
	public Product(Product newProduct) {
		this(newProduct.getCode(), newProduct.getName(), newProduct.getDescription(), newProduct.hasIntolerances(), newProduct.getType(), newProduct.getPrice());
		this.setPizzaOfTheDay(newProduct.isPizzaOfTheDay());
	}

	/** Retrieves the unique code of the product. */
	public String getCode() {
		return code;
	}

	/** Retrieves the name of the product. */
	public String getName() {
		return name;
	}

	/** Retrieves the description of the product. */
	public String getDescription() {
		return description;
	}
	
	/** Retrieves the image file name of the product. */
	public String getPicture() {
		return code + ".png";
	}

	/** Indicates if the product has intolerances. */
	public boolean hasIntolerances() {
		return intolerances;
	}

	/** Retrieves the type of the product. */
	public TypeOfProduct getType() {
		return type;
	}

	/** 
     * Retrieves the price of the product, applying a discount if it is the "Pizza of the Day".
     * @return The price of the product.
     */
	public double getPrice() {
		if (isPizzaOfTheDay()) {
			return price * (1 - PIZZA_OF_THE_DAY_DISCOUNT);
		}
		return price;
	}

	/** Retrieves the quantity of the product in the order. */
	public int getUnits() {
		return units;
	}

	/** 
     * Sets the quantity of the product, ensuring it does not exceed the maximum allowed.
     * @param units The quantity to set.
     */
	public void setUnits(int units) {
		if (units > MAX_NUMBER_OF_SAME_PRODUCTS_PER_ORDER) {
			this.units = MAX_NUMBER_OF_SAME_PRODUCTS_PER_ORDER;
		} else {
			this.units = units;
		}
	}

	/** Retrieves the list of observations for the product. */
	public List<String> getObservations() {
		return observations;
	}

	/** 
     * Sets the list of observations for the product.
     * @param observations The observations to set.
     */
	public void setObservations(List<String> observations) {
		this.observations = observations;
	}

	/** Indicates if the product is designated as the "Pizza of the Day". */
	public boolean isPizzaOfTheDay() {
		return pizzaOfTheDay;
	}

	/** 
     * Sets the product as the "Pizza of the Day".
     * @param pizzaOfTheDay True if the product is the "Pizza of the Day".
     */
	public void setPizzaOfTheDay(boolean pizzaOfTheDay) {
		this.pizzaOfTheDay = pizzaOfTheDay;
	}

	/** 
     * Converts the product details into a formatted string.
     * @return A string representation of the product.
     */
	@Override
	public String toString() {
		return "- " + name;
	}

	/** 
     * Calculates a hash code for the product based on its attributes.
     * @return The hash code of the product.
     */
	@Override
	public int hashCode() {
		return Objects.hash(intolerances, name, observations);
	}

	/** 
     * Compares this product with another for equality based on attributes.
     * @param obj The object to compare.
     * @return True if the products are equal, false otherwise.
     */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {return true;}
		if (obj == null) {return false;}
		if (getClass() != obj.getClass()) {return false;}
		Product other = (Product) obj;
		if (!name.equals(other.name)) {return false;}
	    if (intolerances != other.intolerances) {return false;}

	    if (observations == null && other.observations == null) {return true;}
	    if (observations == null || other.observations == null) {return false;}
	    
	    if (observations.size() != other.observations.size()) {return false;}
	    for (String s : observations) { if (!other.observations.contains(s)) {return false;} }
	    return true;
	}
}
