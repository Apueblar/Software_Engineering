package app.ui;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import app.model.Product;
import app.model.Reservation;
import app.model.TypeOfProduct;
import app.service.Logic;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JTextPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.ImageIcon;
import java.awt.Dimension;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;

import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.Box;
import javax.swing.BoxLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.net.URL;
import java.awt.BorderLayout;

/**
 * Represents the menu screen of the "Papa Slice" application.
 * This screen allows users to browse and filter menu items, manage their current order, 
 * and navigate to other sections like placed orders or the order summary.
 * 
 * Key Features:
 * - Filter products by category.
 * - View detailed product information.
 * - Manage orders: reset, finalize, or add items.
 * - Integrated help system.
 */
public class MenuScreen extends JDialog {

	private static final long serialVersionUID = 1L;
	
	private Logic logic;
	private ResourceBundle texts;
	
	private JDialog placedOrderScreen;
	private JDialog orderScreen;
	private JPanel panelTop;
	private JButton btnResetOrder;
	private JButton btnPlacedOrders;
	private JLabel lblID;
	private JTextField txtID;
	private JPanel panelLeft;
	private JPanel panelDown;
	private JPanel panelCenter;
	private JLabel lblCategory;
	private JPanel filterPanel;
	private JToggleButton tglbtnStarter;
	private JToggleButton tglbtnSalad;
	private JToggleButton tglbtnPizza;
	private JToggleButton tglbtnPasta;
	private JToggleButton tglbtnBread;
	private JToggleButton tglbtnDrink;
	private JToggleButton tglbtnDessert;
	private JLabel lblTotalPrice;
	private JTextField textFieldTotalPrice;
	private JButton btnSeeOrder;
	private JScrollPane scrollPaneProducts;
	private JPanel panelProducts;
	private JPanel panelID;
	private JButton btnFinishReservation;
	private JPanel panelPrice;
	private JButton btnAllProducts;

	/**
     * Constructs the menu screen dialog.
     * Initializes UI components, loads the reservation, and sets up the layout.
     * 
     * @param logic the Logic instance responsible for managing operations.
     * @param reservation the user's current reservation.
     * @param texts the ResourceBundle for localized text resources.
     */
	public MenuScreen(Logic logic, Reservation reservation, ResourceBundle texts) {
//		addComponentListener(new ComponentAdapter() {
//			@Override
//			public void componentResized(ComponentEvent e) {
//				System.out.println(getSize());
//			}
//		});
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				finishReservation();
			}
		});
		this.logic = logic;
		logic.setReservation(reservation);
		this.texts = texts;
		
		this.setTitle("Papa Slice");
		String logo = "/img/logo.png";
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(StartScreen.class.getResource(logo)));
		
		setMinimumSize(new Dimension(1000, 600));
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		getContentPane().setBackground(Color.LIGHT_GRAY);
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(getPanelTop(), BorderLayout.NORTH);
		getContentPane().add(getPanelLeft(), BorderLayout.WEST);
		getContentPane().add(getPanelDown(), BorderLayout.SOUTH);
		getContentPane().add(getPanelCenter(), BorderLayout.CENTER);
		setBackground(Color.WHITE);
		setBounds(100, 100, 800, 600);
		
		getTxtID().setText(logic.getCurrentID());
		String orderPrice = String.format("%.2f €", logic.getOrderTotal());
        getTextFieldTotalPrice().setText(orderPrice);
        getBtnPlacedOrders().setEnabled(logic.canShowOrders());
        
        loadHelp();
	}
	
	/**
     * Finalizes the current reservation.
     * Displays a confirmation dialog and processes the reservation if confirmed.
     */
	private void finishReservation() {
		int resp = JOptionPane.showConfirmDialog(null, texts.getString("ms.finishReservation"), texts.getString("ms.finishReservationTittle"), JOptionPane.YES_NO_OPTION);
		if (resp == JOptionPane.YES_OPTION) {
			logic.finishReservation();
			dispose();
		}
	}
	
	/**
     * Resets the current order.
     * Displays a confirmation dialog and clears the order if confirmed.
     */
	private void resetOrder() {
		if (logic.getOrderProducts().size() > 0) {
			int resp = JOptionPane.showConfirmDialog(null, texts.getString("ms.resetOrder"), texts.getString("ms.resetOrderTittle"), JOptionPane.YES_NO_OPTION);
			if (resp == JOptionPane.YES_OPTION) {
				logic.resetOrder();
				String orderPrice = String.format("%.2f €", logic.getOrderTotal());
		        getTextFieldTotalPrice().setText(orderPrice);
			}
		}
	}
	
	/**
	 * Retrieves and initializes the panel for the top section of the screen.
	 * Contains the user ID, reset, and placed orders buttons.
	 *
	 * @return the JPanel instance for the top section.
	 */
	private JPanel getPanelTop() {
		if (panelTop == null) {
			panelTop = new JPanel();
			panelTop.setLayout(new BorderLayout(2, 0));
			panelTop.add(getPanelID(), BorderLayout.EAST);
			panelTop.add(getBtnPlacedOrders(), BorderLayout.CENTER);
			panelTop.add(getBtnFinishReservation(), BorderLayout.WEST);
		}
		return panelTop;
	}
	
	/**
	 * Retrieves and initializes the "Reset Order" button.
	 * Allows the user to reset their current order.
	 *
	 * @return the JButton instance for resetting the order.
	 */
	private JButton getBtnResetOrder() {
		if (btnResetOrder == null) {
			btnResetOrder = new JButton(" " + texts.getString("ms.ResetOrder") + " ");
			btnResetOrder.setToolTipText(texts.getString("ms.btnResetOrderToolTip"));
			btnResetOrder.setMnemonic(texts.getString("ms.ResetOrderMnemonic").charAt(0));
			btnResetOrder.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					resetOrder();
				}
			});
			btnResetOrder.setFont(new Font("Rockwell", Font.BOLD, 20));
			btnResetOrder.setContentAreaFilled(false);
			btnResetOrder.setBorder(new LineBorder(Color.BLACK, 2, true));
		}
		return btnResetOrder;
	}
	
	/**
	 * Retrieves and initializes the "Finish Reservation" button.
	 * Allows the user to finalize their reservation and proceed.
	 *
	 * @return the JButton instance for finishing the reservation.
	 */
	private JButton getBtnFinishReservation() {
		if (btnFinishReservation == null) {
			btnFinishReservation = new JButton(" " + texts.getString("ms.FinishReservation") + " ");
			btnFinishReservation.setToolTipText(texts.getString("ms.btnFinishReservationToolTip"));
			btnFinishReservation.setMnemonic(texts.getString("ms.FinishReservationMnemonic").charAt(0));
			btnFinishReservation.setFont(new Font("Rockwell", Font.BOLD, 25));
			btnFinishReservation.setContentAreaFilled(false);
			btnFinishReservation.setBorder(new LineBorder(Color.BLACK, 2, true));
			btnFinishReservation.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					finishReservation();
				}
			});
		}
		return btnFinishReservation;
	}
	
	/**
	 * Retrieves and initializes the "Placed Orders" button.
	 * Opens the screen to view previously placed orders.
	 *
	 * @return the JButton instance for viewing placed orders.
	 */
	private JButton getBtnPlacedOrders() {
		if (btnPlacedOrders == null) {
			btnPlacedOrders = new JButton(" " + texts.getString("ms.PlacedOrders") + " ");
			btnPlacedOrders.setToolTipText(texts.getString("ms.btnPlacedOrdersToolTip"));
			btnPlacedOrders.setMnemonic(texts.getString("ms.PlacedOrdersMnemonic").charAt(0));
			btnPlacedOrders.setFont(new Font("Rockwell", Font.BOLD, 25));
			btnPlacedOrders.setContentAreaFilled(false);
			btnPlacedOrders.setBorder(new LineBorder(Color.BLACK, 2, true));
			btnPlacedOrders.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showPlacedOrderScreen();
					if (logic.isFinishReservation()) {
			        	logic.finishReservation();
			        	dispose();
			        }
				}
			});
			btnPlacedOrders.setFont(new Font("Rockwell", Font.BOLD, 25));
			btnPlacedOrders.setBounds(249, 13, 219, 45);
		}
		return btnPlacedOrders;
	}
	
	 /**
     * Displays the dialog for placed orders.
     * Updates the application state if the reservation is finished.
     */
	private void showPlacedOrderScreen() {
		placedOrderScreen = new PlacedOrderScreen(logic, texts);
		placedOrderScreen.setLocationRelativeTo(this);
		placedOrderScreen.setModal(true);
		placedOrderScreen.setVisible(true);
	}
	
	/**
	 * Retrieves and initializes the panel for displaying the user ID.
	 * Contains a label and a text field showing the user's unique identifier for their order.
	 *
	 * @return the JPanel instance for the user ID section.
	 */
	private JPanel getPanelID() {
		if (panelID == null) {
			panelID = new JPanel();
			panelID.setLayout(new BorderLayout(1, 0));
			panelID.add(getLblID(), BorderLayout.WEST);
			panelID.add(getTxtID(), BorderLayout.CENTER);
		}
		return panelID;
	}
	
	/**
	 * Retrieves and initializes the label for the user ID.
	 * Displays the user’s unique identifier for their order.
	 *
	 * @return the JLabel instance for the user ID.
	 */
	private JLabel getLblID() {
		if (lblID == null) {
			lblID = new JLabel(texts.getString("ms.ID") + ": ");
			lblID.setHorizontalAlignment(SwingConstants.TRAILING);
			lblID.setBounds(480, 12, 120, 36);
			lblID.setLabelFor(getTxtID());
			lblID.setFont(new Font("Rockwell", Font.BOLD, 27));
		}
		return lblID;
	}
	
	/**
	 * Retrieves and initializes the text field for the user ID.
	 * Displays the unique ID for the current reservation.
	 *
	 * @return the JTextField instance for the user ID.
	 */
	private JTextField getTxtID() {
		if (txtID == null) {
			txtID = new JTextField();
			txtID.setToolTipText(texts.getString("ms.txtIDToolTip"));
			txtID.setBounds(602, 13, 173, 36);
			txtID.setFont(new Font("Rockwell", Font.BOLD, 27));
			txtID.setEditable(false);
		}
		return txtID;
	}
	
	/**
	 * Retrieves and initializes the panel for the left section of the screen.
	 * Contains the category filters.
	 *
	 * @return the JPanel instance for the left section.
	 */
	private JPanel getPanelLeft() {
		if (panelLeft == null) {
			panelLeft = new JPanel();
			panelLeft.setLayout(new BorderLayout(0, 0));
			panelLeft.add(getLblCategory(), BorderLayout.NORTH);
			panelLeft.add(getFilterPanel(), BorderLayout.CENTER);
		}
		return panelLeft;
	}
	
	/**
	 * Retrieves and initializes the panel for the bottom section of the screen.
	 * Contains the total price display and order buttons.
	 *
	 * @return the JPanel instance for the bottom section.
	 */
	private JPanel getPanelDown() {
		if (panelDown == null) {
			panelDown = new JPanel();
			panelDown.setLayout(new BorderLayout(0, 0));
			panelDown.add(getPanelPrice(), BorderLayout.WEST);
			panelDown.add(getBtnSeeOrder(), BorderLayout.CENTER);
		}
		return panelDown;
	}
	
	/**
	 * Retrieves and initializes the panel for displaying total price information.
	 * Displays the total cost of items in the current order.
	 *
	 * @return the JPanel instance for the total price section.
	 */
	private JPanel getPanelPrice() {
		if (panelPrice == null) {
			panelPrice = new JPanel();
			panelPrice.setLayout(new BorderLayout(0, 0));
			panelPrice.add(getTextFieldTotalPrice(), BorderLayout.CENTER);
			panelPrice.add(getLblTotalPrice(), BorderLayout.WEST);
			panelPrice.add(getBtnResetOrder(), BorderLayout.EAST);
		}
		return panelPrice;
	}
	
	/**
	 * Retrieves and initializes the panel for the center section of the screen.
	 * Displays the filtered product list.
	 *
	 * @return the JPanel instance for the center section.
	 */
	private JPanel getPanelCenter() {
		if (panelCenter == null) {
			panelCenter = new JPanel();
			panelCenter.setLayout(new BorderLayout(0, 0));
			panelCenter.add(getScrollPaneProducts(), BorderLayout.CENTER);
		}
		return panelCenter;
	}
	
	/**
	 * Retrieves and initializes the label for the category section.
	 * Displays a title for the product category filters.
	 *
	 * @return the JLabel instance for the category section.
	 */
	private JLabel getLblCategory() {
		if (lblCategory == null) {
			lblCategory = new JLabel(" " + texts.getString("ms.Category") + ": ");
			lblCategory.setToolTipText(texts.getString("ms.lblCategoryToolTip"));
			lblCategory.setBounds(12, 75, 240, 36);
			lblCategory.setFont(new Font("Rockwell", Font.BOLD, 25));
		}
		return lblCategory;
	}
	
	/**
     * Loads and resizes an icon from the specified resource path.
     * Maintains the original aspect ratio of the image.
     * 
     * @param resourcePath the path to the image resource.
     * @param maxWidth the maximum width of the resized icon.
     * @param maxHeight the maximum height of the resized icon.
     * @return a resized ImageIcon instance, or the original if resizing is unnecessary.
     */
	private ImageIcon loadResizedIcon(String resourcePath, int maxWidth, int maxHeight) {
	    ImageIcon originalIcon = new ImageIcon(getClass().getResource(resourcePath));
	    int originalWidth = originalIcon.getIconWidth();
	    int originalHeight = originalIcon.getIconHeight();

	    // Resize only if the original image exceeds max dimensions
	    if (originalWidth > maxWidth || originalHeight > maxHeight) {
	        // Calculate scaled dimensions while maintaining aspect ratio
	        double widthRatio = (double) maxWidth / originalWidth;
	        double heightRatio = (double) maxHeight / originalHeight;
	        double scaleFactor = Math.min(widthRatio, heightRatio);

	        int newWidth = (int) (originalWidth * scaleFactor);
	        int newHeight = (int) (originalHeight * scaleFactor);

	        // Resize the image
	        Image resizedImage = originalIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
	        return new ImageIcon(resizedImage);
	    }
	    return originalIcon; // Return original icon if no resizing is needed
	}
	
	/**
	 * Retrieves and initializes the filter panel.
	 * Contains toggle buttons for filtering products by categories, and a button to reset filters.
	 *
	 * @return the JPanel instance for the filter panel.
	 */
	private JPanel getFilterPanel() {
		if (filterPanel == null) {
			filterPanel = new JPanel();
			filterPanel.setBackground(Color.GRAY);
			filterPanel.setLayout(new GridLayout(4, 2, 3, 3));
			filterPanel.add(getTglbtnStarter());
			filterPanel.add(getTglbtnSalad());
			filterPanel.add(getTglbtnPizza());
			filterPanel.add(getTglbtnPasta());
			filterPanel.add(getTglbtnBread());
			filterPanel.add(getTglbtnDrink());
			filterPanel.add(getTglbtnDessert());
			filterPanel.add(getBtnAllProducts());
		}
		return filterPanel;
	}
	
	/**
	 * Retrieves and initializes the toggle button for filtering "Starter" products.
	 * Allows users to include or exclude starters in the displayed product list.
	 *
	 * @return the JToggleButton instance for "Starter" products.
	 */
	private JToggleButton getTglbtnStarter() {
		if (tglbtnStarter == null) {
			tglbtnStarter = new JToggleButton(texts.getString("ms.Starter"));
			tglbtnStarter.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					validateProducts();
				}
			});
			tglbtnStarter.setFont(new Font("Rockwell", Font.BOLD, 20));
			tglbtnStarter.setActionCommand(TypeOfProduct.Starter.toString());
		}
		return tglbtnStarter;
	}
	
	/**
	 * Retrieves and initializes the toggle button for filtering "Salad" products.
	 * Allows users to include or exclude salads in the displayed product list.
	 *
	 * @return the JToggleButton instance for "Salad" products.
	 */
	private JToggleButton getTglbtnSalad() {
		if (tglbtnSalad == null) {
			tglbtnSalad = new JToggleButton(texts.getString("ms.Salad"));
			tglbtnSalad.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					validateProducts();
				}
			});
			tglbtnSalad.setFont(new Font("Rockwell", Font.BOLD, 20));
			tglbtnSalad.setActionCommand(TypeOfProduct.Salad.toString());
		}
		return tglbtnSalad;
	}
	
	/**
	 * Retrieves and initializes the toggle button for filtering "Pizza" products.
	 * Allows users to include or exclude pizzas in the displayed product list.
	 *
	 * @return the JToggleButton instance for "Pizza" products.
	 */
	private JToggleButton getTglbtnPizza() {
		if (tglbtnPizza == null) {
			tglbtnPizza = new JToggleButton(texts.getString("ms.Pizza"));
			tglbtnPizza.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					validateProducts();
				}
			});
			tglbtnPizza.setFont(new Font("Rockwell", Font.BOLD, 20));
			tglbtnPizza.setActionCommand(TypeOfProduct.Pizza.toString());
		}
		return tglbtnPizza;
	}
	
	/**
	 * Retrieves and initializes the toggle button for filtering "Pasta" products.
	 * Allows users to include or exclude pastas in the displayed product list.
	 *
	 * @return the JToggleButton instance for "Pasta" products.
	 */
	private JToggleButton getTglbtnPasta() {
		if (tglbtnPasta == null) {
			tglbtnPasta = new JToggleButton(texts.getString("ms.Pasta"));
			tglbtnPasta.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					validateProducts();
				}
			});
			tglbtnPasta.setFont(new Font("Rockwell", Font.BOLD, 20));
			tglbtnPasta.setActionCommand(TypeOfProduct.Pasta.toString());
		}
		return tglbtnPasta;
	}
	
	/**
	 * Retrieves and initializes the toggle button for filtering "Bread" products.
	 * Allows users to include or exclude bread in the displayed product list.
	 *
	 * @return the JToggleButton instance for "Bread" products.
	 */
	private JToggleButton getTglbtnBread() {
		if (tglbtnBread == null) {
			tglbtnBread = new JToggleButton(texts.getString("ms.Bread"));
			tglbtnBread.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					validateProducts();
				}
			});
			tglbtnBread.setFont(new Font("Rockwell", Font.BOLD, 20));
			tglbtnBread.setActionCommand(TypeOfProduct.Bread.toString());
		}
		return tglbtnBread;
	}
	
	/**
	 * Retrieves and initializes the toggle button for filtering "Drink" products.
	 * Allows users to include or exclude drinks in the displayed product list.
	 *
	 * @return the JToggleButton instance for "Drink" products.
	 */
	private JToggleButton getTglbtnDrink() {
		if (tglbtnDrink == null) {
			tglbtnDrink = new JToggleButton(texts.getString("ms.Drink"));
			tglbtnDrink.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					validateProducts();
				}
			});
			tglbtnDrink.setFont(new Font("Rockwell", Font.BOLD, 20));
			tglbtnDrink.setActionCommand(TypeOfProduct.Drink.toString());
		}
		return tglbtnDrink;
	}
	
	/**
	 * Retrieves and initializes the toggle button for filtering "Dessert" products.
	 * Allows users to include or exclude desserts in the displayed product list.
	 *
	 * @return the JToggleButton instance for "Dessert" products.
	 */
	private JToggleButton getTglbtnDessert() {
		if (tglbtnDessert == null) {
			tglbtnDessert = new JToggleButton(texts.getString("ms.Dessert"));
			tglbtnDessert.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					validateProducts();
				}
			});
			tglbtnDessert.setFont(new Font("Rockwell", Font.BOLD, 20));
			tglbtnDessert.setActionCommand(TypeOfProduct.Dessert.toString());
		}
		return tglbtnDessert;
	}
	
	/**
	 * Retrieves and initializes the "All Products" button.
	 * Resets the product filters to show all available products.
	 *
	 * @return the JButton instance for resetting filters.
	 */
	private JButton getBtnAllProducts() {
		if (btnAllProducts == null) {
			btnAllProducts = new JButton(texts.getString("ms.AllProducts"));
			btnAllProducts.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					for (Component c : getFilterPanel().getComponents()) {
						if (c instanceof JToggleButton) {
							JToggleButton tB = (JToggleButton) c;
							tB.setSelected(false);
						}
					}
					validateProducts();
				}
			});
			btnAllProducts.setFont(new Font("Rockwell", Font.BOLD, 20));
		}
		return btnAllProducts;
	}
	
	/**
	 * Retrieves and initializes the label for the total price display.
	 * Indicates the cost of the current order.
	 *
	 * @return the JLabel instance for the total price.
	 */
	private JLabel getLblTotalPrice() {
		if (lblTotalPrice == null) {
			lblTotalPrice = new JLabel(texts.getString("ms.TotalPrice") + ": ");
			lblTotalPrice.setHorizontalAlignment(SwingConstants.TRAILING);
			lblTotalPrice.setLabelFor(getTextFieldTotalPrice());
			lblTotalPrice.setFont(new Font("Rockwell", Font.BOLD, 20));
		}
		return lblTotalPrice;
	}
	
	/**
	 * Retrieves and initializes the text field for displaying total price.
	 * Shows the calculated total cost of the current order.
	 *
	 * @return the JTextField instance for the total price.
	 */
	private JTextField getTextFieldTotalPrice() {
		if (textFieldTotalPrice == null) {
			textFieldTotalPrice = new JTextField();
			textFieldTotalPrice.setToolTipText(texts.getString("ms.textFieldTotalPriceToolTip"));
			textFieldTotalPrice.setFont(new Font("Rockwell", Font.PLAIN, 20));
			textFieldTotalPrice.setEditable(false);
			textFieldTotalPrice.setColumns(10);
		}
		return textFieldTotalPrice;
	}
	
	/**
	 * Retrieves and initializes the "See Order" button.
	 * Opens the order summary screen to review current orders.
	 *
	 * @return the JButton instance for viewing the order summary.
	 */
	private JButton getBtnSeeOrder() {
		if (btnSeeOrder == null) {
			btnSeeOrder = new JButton(texts.getString("ms.SeeOrder"));
			btnSeeOrder.setToolTipText(texts.getString("ms.btnSeeOrderToolTip"));
			btnSeeOrder.setMnemonic(texts.getString("ms.SeeOrderMnemonic").charAt(0));
			btnSeeOrder.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					logic.orderSort();
					showOrderScreen();
					String orderPrice = String.format("%.2f €", logic.getOrderTotal());
			        getTextFieldTotalPrice().setText(orderPrice);
			        getBtnPlacedOrders().setEnabled(logic.canShowOrders());
			        if (logic.isFinishReservation()) {
			        	logic.finishReservation();
			        	dispose();
			        }
				}
			});
			btnSeeOrder.setBackground(Color.LIGHT_GRAY);
			btnSeeOrder.setFont(new Font("Rockwell", Font.BOLD, 20));
		}
		return btnSeeOrder;
	}
	
	/**
	 * Displays the order screen dialog.
	 * Opens a new screen to manage and review the current order.
	 */
	private void showOrderScreen() {
		orderScreen = new OrderScreen(logic, texts);
		orderScreen.setLocationRelativeTo(this);
		orderScreen.setModal(true);
		orderScreen.setVisible(true);
	}
	
	/**
	 * Retrieves and initializes the scroll pane for the products list.
	 * Provides a scrollable container for viewing available products.
	 *
	 * @return the JScrollPane instance for the product list.
	 */
	private JScrollPane getScrollPaneProducts() {
		if (scrollPaneProducts == null) {
			scrollPaneProducts = new JScrollPane();
			scrollPaneProducts.setViewportView(getPanelProducts());
		}
		return scrollPaneProducts;
	}
	
	/**
	 * Retrieves and initializes the panel for displaying products.
	 * Dynamically updates based on selected filters.
	 *
	 * @return the JPanel instance for the product list.
	 */
	private JPanel getPanelProducts() {
		if (panelProducts == null) {
			panelProducts = new JPanel();
			panelProducts.setLayout(new BoxLayout(panelProducts, BoxLayout.Y_AXIS));
			validateProducts();
			panelProducts.add(Box.createVerticalGlue());
		}
		return panelProducts;
	}
	
	/**
     * Validates and updates the displayed products based on selected filters.
     */
	private void validateProducts() {
		List<TypeOfProduct> types = new ArrayList<TypeOfProduct>();
		checkFilterProducts(types);
		List<Product> products = logic.getMenuTypeProduct(types);
		addProductsToPanel(products);
		validate();
	}
	
	/**
     * Checks the selected filters and adds corresponding product types to the list.
     * 
     * @param types the list to store the selected product types.
     */
	private void checkFilterProducts(List<TypeOfProduct> types) {
		types.clear();
		for (Component component : getFilterPanel().getComponents()) {
			if (component instanceof JToggleButton) {
				JToggleButton tb = (JToggleButton) component;
				if (tb.isSelected()) {
					types.add(TypeOfProduct.valueOf(tb.getActionCommand()));
				}
			}
		}
	}
	
	/**
     * Adds filtered products to the products panel.
     * Updates the UI with the filtered list of products.
     */
	private void addProductsToPanel(List<Product> products) {
		getPanelProducts().removeAll();
		for (Product p : products) {
			JPanel productPanel = new JPanel();
			productPanel.setBorder(new LineBorder(Color.DARK_GRAY, 3));
			productPanel.setLayout(new BorderLayout(0, 2));
			productPanel.setBackground(Color.LIGHT_GRAY);
			
				JPanel panelUp = new JPanel();
				panelUp.setLayout(new GridLayout(1, 0, 3, 0));
				
					JLabel lblProductName = new JLabel(p.getName());
					lblProductName.setFont(new Font("Rockwell", Font.BOLD, 17));
				panelUp.add(lblProductName);
				
					JPanel panelPrice = new JPanel();
					panelPrice.setLayout(new BorderLayout(3, 0));
					
						JLabel lblPrice = new JLabel(texts.getString("ms.Price") + ":");
						lblPrice.setFont(new Font("Rockwell", Font.PLAIN, 15));
					panelPrice.add(lblPrice, BorderLayout.WEST);
						JTextField tFPrice = new JTextField();
						tFPrice.setText(String.format("%.2f €" , p.getPrice()));
						tFPrice.setFont(new Font("Rockwell", Font.PLAIN, 14));
						tFPrice.setEditable(false);
					panelPrice.add(tFPrice, BorderLayout.CENTER);
					if(p.isPizzaOfTheDay()) {
							JLabel lblDiscount = new JLabel(String.format("-%d", (int) (Product.PIZZA_OF_THE_DAY_DISCOUNT * 100)) + "%");
							lblDiscount.setFont(new Font("Rockwell", Font.BOLD, 25));
							lblDiscount.setForeground(Color.RED);
						panelPrice.add(lblDiscount, BorderLayout.EAST);
					}
						
				panelUp.add(panelPrice);
			
			productPanel.add(panelUp, BorderLayout.NORTH);
			
				JPanel panelCenter  = new JPanel();
				panelCenter.setLayout(new BorderLayout(0, 0));
				
					JLabel lblImage = new JLabel("");
					lblImage.setIcon(loadResizedIcon("/img/" + p.getPicture(), 120, 120)); // CAMBIAR?
				panelCenter.add(lblImage, BorderLayout.WEST);
				
					JPanel panelRight = new JPanel();
					panelRight.setLayout(new BorderLayout(0, 2));
					
						JTextPane txtDescription = new JTextPane();
						txtDescription.setText(p.getDescription());
						txtDescription.setFont(new Font("Rockwell", Font.PLAIN, 12));
						txtDescription.setEditable(false);
						txtDescription.setPreferredSize(new Dimension(250,55));
						
					panelRight.add(txtDescription, BorderLayout.CENTER);
					
						JPanel panelRightUpIntolerances = new JPanel();
						panelRightUpIntolerances.setLayout(new GridLayout(0, 1, 0, 0));
						
							JLabel lblInto = new JLabel(texts.getString("ms.Intolerances") + ":");
							lblInto.setFont(new Font("Rockwell", Font.PLAIN, 15));
						panelRightUpIntolerances.add(lblInto);
						
							JCheckBox chkbxGluten = new JCheckBox(texts.getString("ms.GlutenFree"));
							chkbxGluten.setFont(new Font("Rockwell", Font.PLAIN, 12));
						panelRightUpIntolerances.add(chkbxGluten);
						
							JCheckBox chkbxLactose = new JCheckBox(texts.getString("ms.LactoseFree"));
							chkbxLactose.setFont(new Font("Rockwell", Font.PLAIN, 12));
						panelRightUpIntolerances.add(chkbxLactose);
						
							JCheckBox chkbxFructose = new JCheckBox(texts.getString("ms.FructoseFree"));
							chkbxFructose.setFont(new Font("Rockwell", Font.PLAIN, 12));
						panelRightUpIntolerances.add(chkbxFructose);
						
							JPanel panelOther = new JPanel();
							panelOther.setLayout(new BorderLayout(1, 0));
							
								JTextField tFOther = new JTextField();
								tFOther.setText(texts.getString("ms.WriteHere"));
								tFOther.setEnabled(false);
								tFOther.setColumns(10);
							panelOther.add(tFOther, BorderLayout.CENTER);
							
								JCheckBox chkbxOther = new JCheckBox(texts.getString("ms.Other"));
								chkbxOther.setFont(new Font("Rockwell", Font.PLAIN, 12));
								chkbxOther.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										tFOther.setEnabled(chkbxOther.isSelected());
									}
								});
							panelOther.add(chkbxOther, BorderLayout.WEST);
						panelRightUpIntolerances.add(panelOther);
						
					if (p.hasIntolerances()) { // Add if the product can be adapted
						panelRight.add(panelRightUpIntolerances, BorderLayout.NORTH);
					}
					
						JPanel panelDown = new JPanel();
						panelDown.setLayout(new GridLayout(1, 0, 2, 0));
						
							JSpinner spinner = new JSpinner();
							spinner.setFont(new Font("Rockwell", Font.PLAIN, 15));
							spinner.setModel(new SpinnerNumberModel(1, 1, 99, 1));
							productPanel.add(spinner);
						panelDown.add(spinner);
						
							JButton btnAdd = new JButton(texts.getString("ms.Add"));
							btnAdd.setFont(new Font("Rockwell", Font.BOLD, 15));
							btnAdd.addActionListener(new ActionListener() {
							    public void actionPerformed(ActionEvent e) {
							        int units = (int) spinner.getValue();
							        spinner.setValue(1);
							        List<String> observations = getIntolerances(p);
							        logic.addToOrder(p, units, observations);
							        String orderPrice = String.format("%.2f €", logic.getOrderTotal());
							        getTextFieldTotalPrice().setText(orderPrice);
							        getBtnSeeOrder().setEnabled(true);
							    }
		
								private List<String> getIntolerances(Product p) {
									List<String> intolerances = new ArrayList<String>();
									if (p.hasIntolerances()) {
										if (chkbxGluten.isSelected()) { intolerances.add("Gluten"); }
										if (chkbxLactose.isSelected()) { intolerances.add("Lactose"); }
										if (chkbxFructose.isSelected()) { intolerances.add("Fructose"); }
										if (chkbxOther.isSelected()) { 
											intolerances.add("Other");
											intolerances.add(tFOther.getText());
										}
										return intolerances;
									}
									return intolerances;
								}
							});
						panelDown.add(btnAdd);
					panelRight.add(panelDown, BorderLayout.SOUTH);
				panelCenter.add(panelRight, BorderLayout.CENTER);
			productPanel.add(panelCenter, BorderLayout.CENTER);
			
			getPanelProducts().add(productPanel);
		}
	}
	
	/**
     * Loads the help system for this screen.
     * Associates help content with UI components.
     */
	private void loadHelp() {
		URL hsURL;
		HelpSet hs;
		try {
			File fichero = new File("help/Help.hs");
			hsURL = fichero.toURI().toURL();
			hs = new HelpSet(null, hsURL);
		} catch (Exception e){
			System.out.println("Help not found!");
	    	return;
		}
	   HelpBroker hb = hs.createHelpBroker();
	   hb.enableHelpKey(getRootPane(),"browseMenu", hs);   
	}
}
