package app.util;

import java.io.*;
import java.util.*;

import app.model.Order;
import app.model.Product;
import app.model.Reservation;
import app.model.TypeOfProduct;

/**
 * Utility class for managing file input and output operations related to reservations, 
 * menu items, and orders in the application.
 * This class provides methods to load data from files and save data back to files.
 */
public abstract class FileUtil {
	
	/**
     * Loads reservation data from a specified file and populates the provided list of reservations.
     * The file should have each line formatted as: client_id@reservation_code.
     *
     * @param reservationFileName the name of the file containing reservation data.
     * @param reservationList     the list to populate with reservation objects.
     */
	public static void loadReservationFile (String reservationFileName, List<Reservation> reservationList) {
	    String line;
	    String[] reservationData = null;
	    
	    try (BufferedReader file = new BufferedReader(new FileReader(reservationFileName))){
			while (file.ready()) {
				line = file.readLine();
				if (line.length() > 0) {
					reservationData = line.split("@");
					// client_id@reservation_code
					reservationList.add(new Reservation(reservationData[0],reservationData[1]));
				}
			}
	    } catch (FileNotFoundException fnfe) {
	    	System.out.println("File not found.");
	    } catch (IOException ioe) {
	    	throw new RuntimeException("I/O Error.");
	    } 
	}
	
	/**
     * Loads menu data from a specified file and populates the provided list of products.
     * The file should have each line formatted as:
     * code@name@description@intolerances@category@price.
     *
     * @param menuFileName the name of the file containing menu data.
     * @param productList  the list to populate with product objects.
     */
	public static void loadMenuFile (String menuFileName, List<Product> reservationList) {
	    String line;
	    String[] pD = null;
	    
	    try (BufferedReader file = new BufferedReader(new FileReader(menuFileName))){
			while (file.ready()) {
				line = file.readLine();
				if (line.length() != 0) { // Avoid empty lines
					pD = line.split("@");
					// code@name@description@intolerances@category@price
					boolean into = "YES".equals(pD[3]);
					reservationList.add(new Product(pD[0],pD[1], pD[2], into, 
							TypeOfProduct.valueOf(pD[4]), Double.parseDouble(pD[5])));
				}
			}
	    } catch (FileNotFoundException fnfe) {
	    	System.out.println("File not found.");
	    } catch (IOException ioe) {
	    	throw new RuntimeException("I/O Error.");
	    } 
	}
	
	/**
     * Saves the current list of reservations to a specified file.
     * Each reservation is saved in the format: client_id@reservation_code.
     *
     * @param reservationFileName the name of the file where reservations will be saved.
     * @param reservations        the list of reservations to save.
     */
	public static void saveReservationFile(String reservationFileName, List<Reservation> reservations) {
		try (BufferedWriter file = new BufferedWriter(new FileWriter(reservationFileName))){
			StringBuilder text = new StringBuilder();
	        
			for (Reservation r : reservations) { text.append(String.format("%s@%s\n", r.getClientID(), r.getReservationCode()));}
	        
	        if (text.length() > 0) { text.setLength(text.length() - 1);} // Remove the last \n
	        file.write(text.toString());
		} catch (FileNotFoundException fnfe) {
		    System.out.println("The file could not be saved.");
		} catch (IOException ioe) {
			throw new RuntimeException("I/O Error.");
		}
	}
	
	/**
     * Saves the details of an order to a file.
     * The file is saved in the "files/" directory with the file name corresponding to the order code.
     *
     * @param order the order object to save.
     */
	public static void saveOrderFile(Order order) {
		try (BufferedWriter file = new BufferedWriter(new FileWriter("files/" + order.getCode()))){
	        file.write(order.toString());
		} catch (FileNotFoundException fnfe) {
		    System.out.println("The file could not be saved.");
		} catch (IOException ioe) {
			throw new RuntimeException("I/O Error.");
		}
	}
}
