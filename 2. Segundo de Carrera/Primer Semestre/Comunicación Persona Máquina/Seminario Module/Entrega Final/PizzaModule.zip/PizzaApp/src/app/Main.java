package app;
import java.awt.EventQueue;
import javax.swing.UIManager;

import app.service.Logic;
import app.ui.StartScreen;

public class Main {
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Logic l = new Logic();
			    	UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
			    	
					StartScreen start = new StartScreen(l);
					start.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
