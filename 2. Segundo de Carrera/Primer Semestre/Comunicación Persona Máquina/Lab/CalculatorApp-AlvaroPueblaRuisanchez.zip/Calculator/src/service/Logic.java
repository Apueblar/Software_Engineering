package service;

public class Logic {

	int operand1;
	int operand2;
	Operator operator;
		
	public Logic() {}

	public void setOperand1(int operand1) {
		this.operand1 = operand1;
	}

	public void setOperand2(int operand2) {
		this.operand2 = operand2;
	}

	public void setOperator(Operator operator) {
		this.operator = operator;
	}
	
	public int result() {
		if(operator == null) {operator = Operator.ADDITION;} //In case the operand is not chosen
		switch(operator) {
			case Operator.ADDITION:
				return operand1 + operand2;
			case SUBSTRACTION:
				return operand1 - operand2;
			case MULTIPLICATION:
				return operand1 * operand2;
			default:
				throw new IllegalStateException("Incorrect Operand: " + operator.toString());
		}
	}
}