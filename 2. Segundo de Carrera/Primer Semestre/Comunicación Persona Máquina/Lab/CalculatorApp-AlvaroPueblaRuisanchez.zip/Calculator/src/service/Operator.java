package service;

public enum Operator {
	
	ADDITION, SUBSTRACTION, MULTIPLICATION;

	private Operator() {}
}
