package ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import service.Logic;
import service.Operator;

import java.awt.SystemColor;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Calculator extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtResult;
	private JButton btn0;
	private JButton btn1;
	private JButton btn2;
	private JButton btn3;
	private JButton btn4;
	private JButton btn5;
	private JButton btn6;
	private JButton btn7;
	private JButton btn8;
	private JButton btn9;
	private JButton btnPlus;
	private JButton btnMinus;
	private JButton btnMult;
	private JButton btnEqual;
	private Logic logic;
	private int operand;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculator frame = new Calculator();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Calculator() {
		logic = new Logic();
		setTitle("Calculator");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 380, 530);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getTxtResult());
		contentPane.add(getBtn0());
		contentPane.add(getBtn1());
		contentPane.add(getBtn2());
		contentPane.add(getBtn3());
		contentPane.add(getBtn4());
		contentPane.add(getBtn5());
		contentPane.add(getBtn6());
		contentPane.add(getBtn7());
		contentPane.add(getBtn8());
		contentPane.add(getBtn9());
		contentPane.add(getBtnPlus());
		contentPane.add(getBtnMinus());
		contentPane.add(getBtnMult());
		contentPane.add(getBtnEqual());
	}

	private JTextField getTxtResult() {
		if (txtResult == null) {
			txtResult = new JTextField();
			txtResult.setHorizontalAlignment(SwingConstants.RIGHT);
			txtResult.setFont(new Font("Tahoma", Font.BOLD, 45));
			txtResult.setBackground(new Color(152, 251, 152));
			txtResult.setEditable(false);
			txtResult.setBounds(40, 40, 280, 70);
			txtResult.setColumns(10);
		}
		return txtResult;
	}
	
	private JButton getBtn0() {
		if (btn0 == null) {
			btn0 = new JButton("0");
			btn0.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(0);
				}
			});
			btn0.setHorizontalTextPosition(SwingConstants.CENTER);
			btn0.setForeground(Color.WHITE);
			btn0.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn0.setBorderPainted(false);
			btn0.setBackground(Color.GRAY);
			btn0.setBounds(25, 380, 70, 70);
		}
		return btn0;
	}
	
	private JButton getBtn1() {
		if (btn1 == null) {
			btn1 = new JButton("1");
			btn1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(1);
				}
			});
			btn1.setHorizontalTextPosition(SwingConstants.CENTER);
			btn1.setForeground(Color.WHITE);
			btn1.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn1.setBorderPainted(false);
			btn1.setBackground(Color.GRAY);
			btn1.setBounds(25, 300, 70, 70);
		}
		return btn1;
	}
	
	private JButton getBtn2() {
		if (btn2 == null) {
			btn2 = new JButton("2");
			btn2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(2);
				}
			});
			btn2.setHorizontalTextPosition(SwingConstants.CENTER);
			btn2.setForeground(Color.WHITE);
			btn2.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn2.setBorderPainted(false);
			btn2.setBackground(Color.GRAY);
			btn2.setBounds(105, 300, 70, 70);
		}
		return btn2;
	}
	
	private JButton getBtn3() {
		if (btn3 == null) {
			btn3 = new JButton("3");
			btn3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(3);
				}
			});
			btn3.setHorizontalTextPosition(SwingConstants.CENTER);
			btn3.setForeground(Color.WHITE);
			btn3.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn3.setBorderPainted(false);
			btn3.setBackground(Color.GRAY);
			btn3.setBounds(185, 300, 70, 70);
		}
		return btn3;
	}
	
	private JButton getBtn4() {
		if (btn4 == null) {
			btn4 = new JButton("4");
			btn4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(4);
				}
			});
			btn4.setHorizontalTextPosition(SwingConstants.CENTER);
			btn4.setForeground(Color.WHITE);
			btn4.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn4.setBorderPainted(false);
			btn4.setBackground(Color.GRAY);
			btn4.setBounds(25, 220, 70, 70);
		}
		return btn4;
	}
	
	private JButton getBtn5() {
		if (btn5 == null) {
			btn5 = new JButton("5");
			btn5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(5);
				}
			});
			btn5.setHorizontalTextPosition(SwingConstants.CENTER);
			btn5.setForeground(Color.WHITE);
			btn5.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn5.setBorderPainted(false);
			btn5.setBackground(Color.GRAY);
			btn5.setBounds(105, 220, 70, 70);
		}
		return btn5;
	}
	
	private JButton getBtn6() {
		if (btn6 == null) {
			btn6 = new JButton("6");
			btn6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(6);
				}
			});
			btn6.setHorizontalTextPosition(SwingConstants.CENTER);
			btn6.setForeground(Color.WHITE);
			btn6.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn6.setBorderPainted(false);
			btn6.setBackground(Color.GRAY);
			btn6.setBounds(185, 220, 70, 70);
		}
		return btn6;
	}
	
	private JButton getBtn7() {
		if (btn7 == null) {
			btn7 = new JButton("7");
			btn7.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(7);
				}
			});
			btn7.setHorizontalTextPosition(SwingConstants.CENTER);
			btn7.setForeground(Color.WHITE);
			btn7.setBorderPainted(false);
			btn7.setBackground(Color.GRAY);
			btn7.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn7.setBounds(25, 140, 70, 70);
		}
		return btn7;
	}
	
	private JButton getBtn8() {
		if (btn8 == null) {
			btn8 = new JButton("8");
			btn8.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(8);
				}
			});
			btn8.setHorizontalTextPosition(SwingConstants.CENTER);
			btn8.setForeground(Color.WHITE);
			btn8.setBorderPainted(false);
			btn8.setBackground(Color.GRAY);
			btn8.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn8.setBounds(105, 140, 70, 70);
		}
		return btn8;
	}
	
	private JButton getBtn9() {
		if (btn9 == null) {
			btn9 = new JButton("9");
			btn9.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					incrementOperand(9);
				}
			});
			btn9.setHorizontalTextPosition(SwingConstants.CENTER);
			btn9.setForeground(Color.WHITE);
			btn9.setBorderPainted(false);
			btn9.setBackground(Color.GRAY);
			btn9.setFont(new Font("Tahoma", Font.BOLD, 45));
			btn9.setBounds(185, 140, 70, 70);
		}
		return btn9;
	}
	
	private JButton getBtnPlus() {
		if (btnPlus == null) {
			btnPlus = new JButton("+");
			btnPlus.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setOperator(Operator.ADDITION);
				}
			});
			btnPlus.setVerticalAlignment(SwingConstants.TOP);
			btnPlus.setAlignmentY(Component.TOP_ALIGNMENT);
			btnPlus.setAlignmentX(Component.CENTER_ALIGNMENT);
			btnPlus.setActionCommand("+");
			btnPlus.setHorizontalTextPosition(SwingConstants.CENTER);
			btnPlus.setForeground(Color.WHITE);
			btnPlus.setBorderPainted(false);
			btnPlus.setBackground(SystemColor.textHighlight);
			btnPlus.setFont(new Font("Tahoma", Font.BOLD, 45));
			btnPlus.setBounds(265, 140, 71, 70);
		}
		return btnPlus;
	}
	
	private JButton getBtnMinus() {
		if (btnMinus == null) {
			btnMinus = new JButton("−");
			btnMinus.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setOperator(Operator.SUBSTRACTION);
				}
			});
			btnMinus.setVerticalAlignment(SwingConstants.TOP);
			btnMinus.setHorizontalTextPosition(SwingConstants.CENTER);
			btnMinus.setForeground(Color.WHITE);
			btnMinus.setFont(new Font("Tahoma", Font.BOLD, 45));
			btnMinus.setBorderPainted(false);
			btnMinus.setBackground(SystemColor.textHighlight);
			btnMinus.setAlignmentY(0.0f);
			btnMinus.setAlignmentX(0.5f);
			btnMinus.setActionCommand("+");
			btnMinus.setBounds(265, 220, 71, 70);
		}
		return btnMinus;
	}
	
	private JButton getBtnMult() {
		if (btnMult == null) {
			btnMult = new JButton("×");
			btnMult.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setOperator(Operator.MULTIPLICATION);
				}
			});
			btnMult.setVerticalAlignment(SwingConstants.TOP);
			btnMult.setHorizontalTextPosition(SwingConstants.CENTER);
			btnMult.setForeground(Color.WHITE);
			btnMult.setFont(new Font("Tahoma", Font.BOLD, 45));
			btnMult.setBorderPainted(false);
			btnMult.setBackground(SystemColor.textHighlight);
			btnMult.setAlignmentY(0.0f);
			btnMult.setAlignmentX(0.5f);
			btnMult.setActionCommand("+");
			btnMult.setBounds(265, 300, 71, 70);
		}
		return btnMult;
	}
	
	private JButton getBtnEqual() {
		if (btnEqual == null) {
			btnEqual = new JButton("=");
			btnEqual.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					equal();
				}
			});
			btnEqual.setVerticalAlignment(SwingConstants.TOP);
			btnEqual.setHorizontalTextPosition(SwingConstants.CENTER);
			btnEqual.setForeground(Color.WHITE);
			btnEqual.setFont(new Font("Tahoma", Font.BOLD, 45));
			btnEqual.setBorderPainted(false);
			btnEqual.setBackground(Color.RED);
			btnEqual.setAlignmentY(0.0f);
			btnEqual.setAlignmentX(0.5f);
			btnEqual.setActionCommand("+");
			btnEqual.setBounds(105, 380, 230, 70);
		}
		return btnEqual;
	}
	
	private void incrementOperand(int number) {
		if(Integer.toString(number).length() != 1) {throw new IllegalArgumentException(String.format("The number %d must have length 1", number));}
		
		operand = operand * 10 + number;
		getTxtResult().setText(Integer.toString(operand));
	}
	
	private void setOperator(Operator operator) {
		if(operator == null) {throw new IllegalArgumentException("The operator is null");}
		logic.setOperand1(operand);
		operand = 0;
		setEnableOperand(false);
		logic.setOperator(operator);
	}
	
	private void equal() {
		logic.setOperand2(operand);
		operand = 0;
		setEnable(false);
		getTxtResult().setText(Integer.toString(logic.result()));
	}
	
	private void setEnable(boolean on) {
		setEnableBtns(on);
		setEnableOperand(on);
		btnEqual.setEnabled(on);
	}
	
	private void setEnableOperand(boolean on) {
		btnPlus.setEnabled(on);
		btnMinus.setEnabled(on);
		btnMult.setEnabled(on);
	}
	
	private void setEnableBtns(boolean on) {
		btn0.setEnabled(on);
		btn1.setEnabled(on);
		btn2.setEnabled(on);
		btn3.setEnabled(on);
		btn4.setEnabled(on);
		btn5.setEnabled(on);
		btn6.setEnabled(on);
		btn7.setEnabled(on);
		btn8.setEnabled(on);
		btn9.setEnabled(on);
	}
}













