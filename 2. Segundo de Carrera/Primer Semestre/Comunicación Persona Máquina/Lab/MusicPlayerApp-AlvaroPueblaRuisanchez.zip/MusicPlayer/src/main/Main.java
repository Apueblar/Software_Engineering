package main;

import java.awt.EventQueue;
import java.util.Properties;

import javax.swing.UIManager;

import com.jtattoo.plaf.hifi.HiFiLookAndFeel;

import main.player.MusicPlayer;
import main.ui.MainWindow;

public class Main {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MusicPlayer mp = new MusicPlayer();
					 Properties props = new Properties();
			    	  props.put("logoString", "");
			    	  props.put("focusColor", "0 0 0");
			    	  HiFiLookAndFeel.setCurrentTheme(props);
			    	  UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
					
			    	MainWindow frame = new MainWindow(mp);
					    frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
