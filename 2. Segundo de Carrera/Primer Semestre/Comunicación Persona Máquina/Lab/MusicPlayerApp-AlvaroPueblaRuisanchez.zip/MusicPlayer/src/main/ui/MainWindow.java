package main.ui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.GridLayout;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JSlider;
import java.awt.Font;
import javax.swing.JTextField;

import main.player.MusicPlayer;
import main.player.MyFile;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.event.ChangeEvent;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;

import javax.help.*;
import java.net.*;
import java.io.*;

public class MainWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel panelNorth;
	private JPanel panelCenter;
	private JLabel lblNewLabel;
	private JSlider slider;
	private JPanel panelVol;
	private JLabel lblVol;
	private JTextField textFieldVol;
	private JPanel panelLibrary;
	private JPanel panelPlayList;
	private JLabel lblLibrary;
	private JLabel lblPlayList;
	private JPanel panelButtonsLibrary;
	private JPanel panelButtonsPlayList;
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	private JButton btnAddToPlayList;
	private JButton btnDelete;
	private JList<MyFile> listLibrary;
	private JList<MyFile> listPlayList;
	private JButton btnRew;
	private JButton btnPlay;
	private JButton btnStop;
	private JButton btnForw;
	private JButton btnDel;
	private JMenuBar menuBar;
	private JMenu mnFile;
	private JMenu mnPlay;
	private JMenu mnOptions;
	private JMenu mnHelp;
	private DefaultListModel<MyFile> listModelLibrary;
	private DefaultListModel<MyFile> listModelPlayList;
	private JMenuItem mntmOpen;
	private JMenuItem mntmExit;
	private JSeparator fileSeparator;
	private JFileChooser selector;
	private MusicPlayer musicPlayer;
	private JButton btnClearAll;
	private JButton btnClear;
	private JButton btnRandom;
	private JMenuItem mntmContent;
	private JMenuItem mntmAbout;
	private JSeparator helpSeparator;
	private JMenuItem mntmRandom;
	private JMenuItem mntmPlay;
	private JMenuItem mntmStop;
	private JMenuItem mntmRewind;
	private JMenuItem mntmForeward;

	/**
	 * Create the frame.
	 * @param mp A MusicPlayer instance
	 */
	public MainWindow(MusicPlayer mp) {
		this.musicPlayer = mp;
//		addComponentListener(new ComponentAdapter() {
//			@Override
//			public void componentResized(ComponentEvent e) {
//				System.out.println(getSize());
//			}
//		});
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				exit();
			}
		});
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 1000, 680);
		getContentPane().add(getPanelNorth(), BorderLayout.NORTH);
		getContentPane().add(getPanelCenter(), BorderLayout.CENTER);
		setJMenuBar(getMenuBar_1());
		setMinimumSize(new Dimension(625, 400));
		
		loadHelp();
	}
	
	/**
	 * Shows a confirm dialog to exit or not the app
	 */
	private void exit() {
		int resp = JOptionPane.showConfirmDialog(null, "Are you sure to leave the app?", "The app is being closed", JOptionPane.YES_NO_OPTION);
		if (resp == JOptionPane.YES_OPTION) {
			System.exit(0);
		}
	}
	
	private JPanel getPanelNorth() {
		if (panelNorth == null) {
			panelNorth = new JPanel();
			panelNorth.setLayout(new GridLayout(0, 3, 0, 0));
			panelNorth.add(getLblNewLabel());
			panelNorth.add(getSlider());
			panelNorth.add(getPanelVol());
		}
		return panelNorth;
	}
	private JPanel getPanelCenter() {
		if (panelCenter == null) {
			panelCenter = new JPanel();
			panelCenter.setLayout(new GridLayout(0, 2, 0, 0));
			panelCenter.add(getPanelLibrary());
			panelCenter.add(getPanelPlayList());
		}
		return panelCenter;
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("");
			lblNewLabel.setIcon(new ImageIcon(MainWindow.class.getResource("/img/logo.png")));
		}
		return lblNewLabel;
	}
	private JSlider getSlider() {
		if (slider == null) {
			slider = new JSlider();
			slider.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					getTextFieldVol().setText("" + getSlider().getValue());
					musicPlayer.setVolume(getSlider().getValue(), getSlider().getMaximum());
				}
			});
			slider.setPaintTicks(true);
			slider.setPaintLabels(true);
			slider.setMajorTickSpacing(20);
			slider.setMinorTickSpacing(10);
		}
		return slider;
	}
	private JPanel getPanelVol() {
		if (panelVol == null) {
			panelVol = new JPanel();
			panelVol.setLayout(new BoxLayout(panelVol, BoxLayout.X_AXIS));
			panelVol.add(getLblVol());
			panelVol.add(getTextFieldVol());
		}
		return panelVol;
	}
	private JLabel getLblVol() {
		if (lblVol == null) {
			lblVol = new JLabel(" Vol: ");
			lblVol.setLabelFor(getTextFieldVol());
			lblVol.setFont(new Font("Tahoma", Font.BOLD, 30));
		}
		return lblVol;
	}
	private JTextField getTextFieldVol() {
		if (textFieldVol == null) {
			textFieldVol = new JTextField();
			textFieldVol.setForeground(Color.WHITE);
			textFieldVol.setOpaque(false);
			textFieldVol.setText("50");
			textFieldVol.setFont(new Font("Tahoma", Font.PLAIN, 30));
			textFieldVol.setColumns(10);
		}
		return textFieldVol;
	}
	private JPanel getPanelLibrary() {
		if (panelLibrary == null) {
			panelLibrary = new JPanel();
			panelLibrary.setLayout(new BorderLayout(0, 0));
			panelLibrary.add(getLblLibrary(), BorderLayout.NORTH);
			panelLibrary.add(getPanelButtonsLibrary(), BorderLayout.SOUTH);
			panelLibrary.add(getScrollPane(), BorderLayout.CENTER);
		}
		return panelLibrary;
	}
	private JPanel getPanelPlayList() {
		if (panelPlayList == null) {
			panelPlayList = new JPanel();
			panelPlayList.setLayout(new BorderLayout(0, 0));
			panelPlayList.add(getLblPlayList(), BorderLayout.NORTH);
			panelPlayList.add(getPanelButtonsPlayList(), BorderLayout.SOUTH);
			panelPlayList.add(getScrollPane_1(), BorderLayout.CENTER);
		}
		return panelPlayList;
	}
	private JLabel getLblLibrary() {
		if (lblLibrary == null) {
			lblLibrary = new JLabel("Library:");
			lblLibrary.setFont(new Font("Tahoma", Font.BOLD, 15));
		}
		return lblLibrary;
	}
	private JLabel getLblPlayList() {
		if (lblPlayList == null) {
			lblPlayList = new JLabel("PlayList:");
			lblPlayList.setFont(new Font("Tahoma", Font.BOLD, 15));
		}
		return lblPlayList;
	}
	private JPanel getPanelButtonsLibrary() {
		if (panelButtonsLibrary == null) {
			panelButtonsLibrary = new JPanel();
			panelButtonsLibrary.setLayout(new GridLayout(0, 3, 0, 0));
			panelButtonsLibrary.add(getBtnAddToPlayList());
			panelButtonsLibrary.add(getBtnDelete());
			panelButtonsLibrary.add(getBtnClearAll());
		}
		return panelButtonsLibrary;
	}
	private JPanel getPanelButtonsPlayList() {
		if (panelButtonsPlayList == null) {
			panelButtonsPlayList = new JPanel();
			panelButtonsPlayList.setLayout(new GridLayout(0, 7, 0, 0));
			panelButtonsPlayList.add(getBtnRew());
			panelButtonsPlayList.add(getBtnPlay());
			panelButtonsPlayList.add(getBtnRandom());
			panelButtonsPlayList.add(getBtnStop());
			panelButtonsPlayList.add(getBtnForw());
			panelButtonsPlayList.add(getBtnDel());
			panelButtonsPlayList.add(getBtnClear());
		}
		return panelButtonsPlayList;
	}
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getListLibrary());
		}
		return scrollPane;
	}
	private JScrollPane getScrollPane_1() {
		if (scrollPane_1 == null) {
			scrollPane_1 = new JScrollPane();
			scrollPane_1.setViewportView(getListPlayList());
		}
		return scrollPane_1;
	}
	private JButton getBtnAddToPlayList() {
		if (btnAddToPlayList == null) {
			btnAddToPlayList = new JButton("Add to PlayList");
			btnAddToPlayList.setMnemonic('i');
			btnAddToPlayList.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					for (MyFile file : getListLibrary().getSelectedValuesList()) {
						if (!listModelPlayList.contains(file)) { // Not repeated elements
							listModelPlayList.addElement(file);
						}
					}
				}
			});
		}
		return btnAddToPlayList;
	}
	private JButton getBtnDelete() {
		if (btnDelete == null) {
			btnDelete = new JButton("Delete");
			btnDelete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					for (MyFile file : getListLibrary().getSelectedValuesList()) {
						int index = listModelLibrary.indexOf(file);
						listModelLibrary.remove(index);
						if (listModelPlayList.contains(file)) {
							index = listModelPlayList.indexOf(file);
							listModelPlayList.remove(index);
						}
					}
				}
			});
			btnDelete.setMnemonic('d');
		}
		return btnDelete;
	}
	private JList<MyFile> getListLibrary() {
		if (listLibrary == null) {
			listModelLibrary = new DefaultListModel<>();
			listLibrary = new JList<MyFile>(listModelLibrary);
		}
		return listLibrary;
	}
	private JList<MyFile> getListPlayList() {
		if (listPlayList == null) {
			listModelPlayList = new DefaultListModel<>();
			listPlayList = new JList<MyFile>(listModelPlayList);
		}
		return listPlayList;
	}
	private JButton getBtnRew() {
		if (btnRew == null) {
			btnRew = new JButton("\u25C4\u25C4");
			btnRew.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int index = getListPlayList().getSelectedIndex();
					if (index != 0) {
						getListPlayList().setSelectedIndex(index - 1);
					}
					musicPlayer.play(getListPlayList().getSelectedValue().getF());
					
				}
			});
		}
		return btnRew;
	}
	private JButton getBtnPlay() {
		if (btnPlay == null) {
			btnPlay = new JButton("\u25BA");
			btnPlay.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					musicPlayer.play(getListPlayList().getSelectedValue().getF());
				}
			});
		}
		return btnPlay;
	}
	private JButton getBtnStop() {
		if (btnStop == null) {
			btnStop = new JButton("\u25A0");
			btnStop.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					musicPlayer.stop();
				}
			});
		}
		return btnStop;
	}
	private JButton getBtnForw() {
		if (btnForw == null) {
			btnForw = new JButton("\u25BA\u25BA");
			btnForw.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int index = getListPlayList().getSelectedIndex();
					if (index != listModelPlayList.getSize()) {
						getListPlayList().setSelectedIndex(index + 1);
					}
					musicPlayer.play(getListPlayList().getSelectedValue().getF());
					
				}
			});
		}
		return btnForw;
	}
	private JButton getBtnDel() {
		if (btnDel == null) {
			btnDel = new JButton("Del");
			btnDel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					for (MyFile file : getListPlayList().getSelectedValuesList()) {
						int index = listModelPlayList.indexOf(file);
						listModelPlayList.remove(index);
					}
				}
			});
			btnDel.setMnemonic('e');
		}
		return btnDel;
	}
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnFile());
			menuBar.add(getMnPlay());
			menuBar.add(getMnOptions());
			menuBar.add(getMnHelp());
		}
		return menuBar;
	}
	private JMenu getMnFile() {
		if (mnFile == null) {
			mnFile = new JMenu("File");
			mnFile.setMnemonic('F');
			mnFile.add(getMntmOpen());
			mnFile.add(getFileSeparator());
			mnFile.add(getMntmExit());
		}
		return mnFile;
	}
	private JMenu getMnPlay() {
		if (mnPlay == null) {
			mnPlay = new JMenu("Play");
			mnPlay.setMnemonic('P');
			mnPlay.add(getMntmPlay());
			mnPlay.add(getMntmStop());
			mnPlay.add(getMntmRewind());
			mnPlay.add(getMntmForeward());
		}
		return mnPlay;
	}
	private JMenu getMnOptions() {
		if (mnOptions == null) {
			mnOptions = new JMenu("Options");
			mnOptions.setMnemonic('O');
			mnOptions.add(getMntmRandom());
		}
		return mnOptions;
	}
	private JMenu getMnHelp() {
		if (mnHelp == null) {
			mnHelp = new JMenu("Help");
			mnHelp.add(getMntmContent());
			mnHelp.add(getHelpSeparator());
			mnHelp.add(getMntmAbout());
		}
		return mnHelp;
	}
	private JMenuItem getMntmOpen() {
		if (mntmOpen == null) {
			mntmOpen = new JMenuItem("Open");
			mntmOpen.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int answer = getSelector().showOpenDialog(null);
					if (answer == JFileChooser.APPROVE_OPTION) { // We have the file
						for (File file : getSelector().getSelectedFiles()) {
							listModelLibrary.addElement(new MyFile(file));
						}
					}
				}
			});
		}
		return mntmOpen;
	}
	private JMenuItem getMntmExit() {
		if (mntmExit == null) {
			mntmExit = new JMenuItem("Exit");
			mntmExit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					exit();
				}
			});
		}
		return mntmExit;
	}
	private JSeparator getFileSeparator() {
		if (fileSeparator == null) {
			fileSeparator = new JSeparator();
		}
		return fileSeparator;
	}
	public JFileChooser getSelector() {
		if (selector == null) {
			selector = new JFileChooser();
			selector.setMultiSelectionEnabled(true); //For being able to select several files
			selector.setFileFilter(new FileNameExtensionFilter("Mp3 files", "mp3"));
			String downloadPath = System.getProperty("user.home") + "/Downloads";
			selector.setCurrentDirectory(new File(downloadPath));
		}
		return selector;
	}
	private JButton getBtnClearAll() {
		if (btnClearAll == null) {
			btnClearAll = new JButton("Clear All");
			btnClearAll.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					listModelLibrary.clear();
					listModelPlayList.clear();
				}
			});
		}
		return btnClearAll;
	}
	private JButton getBtnClear() {
		if (btnClear == null) {
			btnClear = new JButton("Clear");
			btnClear.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					listModelPlayList.clear();
				}
			});
		}
		return btnClear;
	}
	private JButton getBtnRandom() {
		if (btnRandom == null) {
			btnRandom = new JButton("R");
			btnRandom.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					getListPlayList().setSelectedIndex((int) (Math.random() * listModelPlayList.getSize()));
					musicPlayer.play(getListPlayList().getSelectedValue().getF());
				}
			});
		}
		return btnRandom;
	}
	private JMenuItem getMntmContent() {
		if (mntmContent == null) {
			mntmContent = new JMenuItem("Content");
			mntmContent.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
		}
		return mntmContent;
	}

	private void loadHelp(){

	   URL hsURL;
	   HelpSet hs;

	    try {
		    	File fichero = new File("help/Help.hs");
		    	hsURL = fichero.toURI().toURL();
		        hs = new HelpSet(null, hsURL);
		      }

	    catch (Exception e){
	      System.out.println("Help not found!");
	      return;
	   }

	   HelpBroker hb = hs.createHelpBroker();

	   hb.enableHelpKey(getRootPane(),"intro", hs);
	   hb.enableHelpOnButton(mntmContent, "intro", hs);
	   hb.enableHelp(listLibrary, "remove", hs);
	 }

	
	private JMenuItem getMntmAbout() {
		if (mntmAbout == null) {
			mntmAbout = new JMenuItem("About");
		}
		return mntmAbout;
	}
	private JSeparator getHelpSeparator() {
		if (helpSeparator == null) {
			helpSeparator = new JSeparator();
		}
		return helpSeparator;
	}
	private JMenuItem getMntmRandom() {
		if (mntmRandom == null) {
			mntmRandom = new JMenuItem("Random");
		}
		return mntmRandom;
	}
	private JMenuItem getMntmPlay() {
		if (mntmPlay == null) {
			mntmPlay = new JMenuItem("Play");
		}
		return mntmPlay;
	}
	private JMenuItem getMntmStop() {
		if (mntmStop == null) {
			mntmStop = new JMenuItem("Stop");
		}
		return mntmStop;
	}
	private JMenuItem getMntmRewind() {
		if (mntmRewind == null) {
			mntmRewind = new JMenuItem("Rewind");
		}
		return mntmRewind;
	}
	private JMenuItem getMntmForeward() {
		if (mntmForeward == null) {
			mntmForeward = new JMenuItem("Foreward");
		}
		return mntmForeward;
	}
}
