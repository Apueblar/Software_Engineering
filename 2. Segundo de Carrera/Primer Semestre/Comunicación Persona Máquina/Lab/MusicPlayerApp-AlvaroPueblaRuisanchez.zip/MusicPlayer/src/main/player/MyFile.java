package main.player;

import java.io.*;

public class MyFile {
	private File f;
	
	public MyFile (File f){
		this.f = f;
	}
	
	public File getF() {
		return f;
	}

	public String toString() {
		int pos = f.getName().lastIndexOf('.');
	    if(pos > -1) {return f.getName().substring(0, pos);}
	    return f.getName();
	}
}
