package uo.cpm.p3.util;

import java.io.*;
import java.util.*;

import uo.cpm.p3.model.Order;
import uo.cpm.p3.model.Product;

public abstract class FileUtil {
	
public static void loadFile (String fileName, List<Product> productsList) {
		
	    String line;
	    String[] productData= null;	   
	    
	    try {
	    	BufferedReader file = new BufferedReader(new FileReader(fileName));
			while (file.ready()) {
				line = file.readLine();
				productData = line.split("@");
			productsList.add(new Product(productData[0],productData[1],productData[2],Float.parseFloat(productData[3]),0));
			}
			file.close();
	    } catch (FileNotFoundException fnfe) {
	    	System.out.println("File not found.");
	    } catch (IOException ioe) {
	    	new RuntimeException("I/O Error.");
	    } 
	  }
	
	
	
	public static String setFileName(){
		String code = "";
		String base = "0123456789abcdefghijklmnopqrstuvwxyz";
		int length = 8;
		for(int i=0; i<length;i++){ 
			int numero = (int)(Math.random()*(base.length())); 
			code += base.charAt(numero);
		}
		return code;
	}

	public static void saveToFile(Order order) {
		try {
	        BufferedWriter file = new BufferedWriter(new FileWriter("files/" + order.getCode() + ".dat"));
	        String text = String.format("Cliente: %s\n-------------------------------", order.getCustomer().getName()); //Customer info
	        for (Product p : order.getOrderList()) { text = String.format("%s\n%s", text, p.toPersonalString());} // Add products
	        text = String.format("%s\nTotal: %.2f", text, order.getPrice());
	        if(order.isTakeAway()) {text = String.format("%s\nOrder for take away", text);}
	        file.write(text);
	        file.close();
		} catch (FileNotFoundException fnfe) {
		    System.out.println("The file could not be saved.");
		} catch (IOException ioe) {
			new RuntimeException("I/O Error.");
		}
	}
}
