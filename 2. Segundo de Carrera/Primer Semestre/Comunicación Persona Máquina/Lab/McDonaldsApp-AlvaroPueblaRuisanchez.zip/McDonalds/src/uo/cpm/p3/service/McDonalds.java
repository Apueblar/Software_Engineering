package uo.cpm.p3.service;

import uo.cpm.p3.model.Customer;
import uo.cpm.p3.model.Menu;
import uo.cpm.p3.model.Order;
import uo.cpm.p3.model.Product;

public class McDonalds {

	Menu menu = new Menu();
	Order order = new Order();
	public static final int EDAD_MIN=16;
	public static final int EDAD_MAX=100;
	public final static String LINESEPARATOR = "\n";
	final static String TAKEAWAYTEXT = "Plastic bag"; 
	
	public McDonalds() {
		initOrder();
	}
	
	public void initOrder() {
		order.initialize(); // Cleans previous orders
	}
	
	public String getOrderCode() {
		return order.getCode();
	}
	
	public void addToOrder ( Product p, Integer units ) {
		order.add(p, units);
	}
	
	public void removeFromOrder ( Product p, Integer units ) {
		order.remove(p, units);
	}
	
	public boolean isProductInOrder (Product p) {
		return order.isProductInOrder(p);
	}
	
	public float getOrderTotal() {
		return order.getPrice();
	}
	
	public String getOrderProducts() {
		String orderString = "";
		for (Product p : order.getOrderList()) {
			orderString = String.format("%s%s%s", orderString, p.toString(), LINESEPARATOR);
		}
		if(order.isTakeAway()) {orderString = String.format("%s%s - %.2f €%s", orderString, TAKEAWAYTEXT, Order.TAKEAWAYFEE, LINESEPARATOR);}
		return orderString;
	}
	
	public void saveCustomerData (String name, Integer year, String password) {
		order.setCustomer ( new Customer ( name, password, year ));
	}
	
	public void setOrderType( boolean takeAway ) {
		order.setTakeAway( takeAway);
	}
	
	public Product[] getMenuProducts() {
		return menu.getProducts();
	}
	
	public Product[] getMenuProductsType(String type) {
		return menu.getTypeProduct(type);
	}
	
	public void saveOrder() {
		order.saveOrder();
	}
}
