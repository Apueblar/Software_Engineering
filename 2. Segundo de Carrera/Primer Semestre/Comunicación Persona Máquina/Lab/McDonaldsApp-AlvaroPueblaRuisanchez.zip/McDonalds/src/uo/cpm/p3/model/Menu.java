package uo.cpm.p3.model;

import java.util.*;

import uo.cpm.p3.util.FileUtil;

public class Menu {
	
	private static final String PRODUCTS_FILE = "files/products.dat";
	private List<Product> productsList = null;
	
	public Menu(){
		productsList = new ArrayList<Product>();
		loadProducts();
	}

	/**
	 * Loads the products from the file (PRODUCTS_FILE) into the list (productsList)
	 */
	private void loadProducts(){
		FileUtil.loadFile (PRODUCTS_FILE, productsList);
	  }

	/**
	 * Transforms the list of products into an array of products
	 * @return An array of all products
	 */
	public Product[] getProducts(){
		Product[] products = productsList.toArray(new Product[productsList.size()]);
		return products;
	}
	
	/**
	 * Transforms the list of products into an array of products
	 * @param type The type of products to search for
	 * @return An array of products of an specific type
	 */
	public Product[] getTypeProduct(String type) {
		List<Product> productsTypeList = new ArrayList<Product>();
		for (int i = 0; i < productsList.size(); i++) {
			if(productsList.get(i).getType().equals(type)) {productsTypeList.add(productsList.get(i));}
		}
		Product[] products = productsTypeList.toArray(new Product[productsTypeList.size()]);
		
		return products;
	}
	
}
