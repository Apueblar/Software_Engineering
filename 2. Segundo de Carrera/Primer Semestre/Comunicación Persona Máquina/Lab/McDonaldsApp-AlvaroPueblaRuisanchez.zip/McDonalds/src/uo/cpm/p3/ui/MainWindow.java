package uo.cpm.p3.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import uo.cpm.p3.model.Product;
import uo.cpm.p3.service.McDonalds;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JSpinner;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SpinnerNumberModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import javax.swing.JSeparator;
import java.awt.GridLayout;
import javax.swing.SwingConstants;

public class MainWindow extends JFrame {

//	System.exit(0); //Cierra todo
//	dispose(); //Cierra la ventana en la que estoy
//	showRegistryForm(); //Abre ventana específica
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel panel;
	private JLabel lblProducts;
	private JLabel lblUnits;
	@SuppressWarnings("rawtypes")
	private JComboBox comboBoxProducts;
	private JSpinner spinner;
	private JLabel lblLogo;
	private JButton btnAdd;
	private JButton btnNext;
	private JButton btnCancel;
	private JTextField textOrderPrice;
	private RegistryForm registryForm;
	private McDonalds mcDonalds;
	private JLabel lblOrderPrice;
	private JButton btnRemove;
	private JScrollPane scrollOrderPane;
	private JTextArea textOrderArea;
	private JToggleButton tglbtnNewToggleButton;
	private JLabel lblProductImage;
	private JMenuBar menuBar;
	private JMenu mnOrder;
	private JMenu mnHelp;
	private JMenuItem mntmNew;
	private JMenuItem mntmExit;
	private JSeparator separator;
	private JMenuItem mntmContent;
	private JMenuItem mntmAbout;
	private JSeparator separator_1;
	private JPanel productTypes;
	private JButton btnBurguers;
	private JButton btnSides;
	private JButton btnDrinks;
	private JButton btnDesserts;

	/**
	 * Create the frame.
	 * @param mcDonalds 
	 */
	public MainWindow(McDonalds mcDonalds) {
		setTitle("McDonald's");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				exit();
			}
		});
		this.mcDonalds = mcDonalds;
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 770, 468);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		contentPane.add(getPanel(), BorderLayout.CENTER);
		contentPane.add(getProductTypes(), BorderLayout.WEST);
		initialize();
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(Color.WHITE);
			panel.setLayout(null);
			panel.add(getLblProducts());
			panel.add(getLblUnits());
			panel.add(getComboBoxProducts());
			panel.add(getSpinner());
			panel.add(getLblLogo());
			panel.add(getBtnAdd());
			panel.add(getBtnNext());
			panel.add(getBtnCancel());
			panel.add(getTextOrderPrice());
			panel.add(getLblOrderPrice());
			panel.add(getBtnRemove());
			panel.add(getScrollOrderPane());
			panel.add(getTglbtnNewToggleButton());
			panel.add(getLblProductImage());
		}
		return panel;
	}
	
	private JLabel getLblProducts() {
		if (lblProducts == null) {
			lblProducts = new JLabel("Products:");
			lblProducts.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblProducts.setBounds(31, 182, 63, 19);
		}
		return lblProducts;
	}
	private JLabel getLblUnits() {
		if (lblUnits == null) {
			lblUnits = new JLabel("Units:");
			lblUnits.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblUnits.setBounds(323, 182, 38, 19);
		}
		return lblUnits;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private JComboBox getComboBoxProducts() {
		if (comboBoxProducts == null) {
			comboBoxProducts = new JComboBox();
			comboBoxProducts.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					getSpinner().setValue(1);
					getBtnRemove().setEnabled(false);
					if(mcDonalds.isProductInOrder((Product) comboBoxProducts.getSelectedItem())) {getBtnRemove().setEnabled(true);}
					changeProductImage();
				}
			});
			comboBoxProducts.setFont(new Font("Tahoma", Font.PLAIN, 10));
			comboBoxProducts.setBounds(28, 207, 285, 40);
			comboBoxProducts.setModel(new DefaultComboBoxModel(mcDonalds.getMenuProducts()));
			
		}
		return comboBoxProducts;
	}
	
	private void changeProductImage() {
		getLblProductImage().setIcon(new ImageIcon(MainWindow.class.getResource("/uo/cpm/p3/ui/img/" + ((Product) getComboBoxProducts().getSelectedItem()).getCode() + ".PNG")));		
	}

	private JSpinner getSpinner() {
		if (spinner == null) {
			spinner = new JSpinner();
			spinner.setModel(new SpinnerNumberModel(Integer.valueOf(1), Integer.valueOf(1), null, Integer.valueOf(1)));
			spinner.setFont(new Font("Tahoma", Font.PLAIN, 15));
			spinner.setBounds(323, 207, 49, 40);
		}
		return spinner;
	}
	private JLabel getLblLogo() {
		if (lblLogo == null) {
			lblLogo = new JLabel("Mc Donald's");
			lblLogo.setFont(new Font("Tahoma", Font.BOLD, 25));
			lblLogo.setIcon(new ImageIcon(MainWindow.class.getResource("/uo/cpm/p3/ui/img/logo.PNG")));
			lblLogo.setBounds(-19, 22, 368, 140);
		}
		return lblLogo;
	}
	private JButton getBtnAdd() {
		if (btnAdd == null) {
			btnAdd = new JButton("Add");
			btnAdd.setBackground(Color.GREEN);
			btnAdd.setBorderPainted(false);
			btnAdd.setToolTipText("Adds the selected product to the order");
			btnAdd.setMnemonic('A');
			btnAdd.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Product product = (Product) getComboBoxProducts().getSelectedItem();
					int units = (int) getSpinner().getValue();
					mcDonalds.addToOrder(product, units);
					String orderPrice = String.format("%.2f €", mcDonalds.getOrderTotal());
					getTextOrderPrice().setText(orderPrice);
					getBtnNext().setEnabled(true);
					getBtnRemove().setEnabled(true);
					updateOrderArea();
				}
			});
			btnAdd.setBounds(382, 207, 73, 40);
		}
		return btnAdd;
	}
	
	private JButton getBtnNext() {
		if (btnNext == null) {
			btnNext = new JButton("Next");
			btnNext.setBackground(Color.GREEN);
			btnNext.setBorderPainted(false);
			btnNext.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showRegistryForm();
				}
			});
			btnNext.setBounds(354, 342, 89, 23);
		}
		return btnNext;
	}
	
	private void showRegistryForm() {
		registryForm = new RegistryForm(this);
		registryForm.setLocationRelativeTo(this);
		registryForm.setModal(true);
		registryForm.setVisible(true);
	}
	
	private JButton getBtnCancel() {
		if (btnCancel == null) {
			btnCancel = new JButton("Cancel");
			btnCancel.setBorderPainted(false);
			btnCancel.setBackground(Color.RED);
			btnCancel.setForeground(Color.WHITE);
			btnCancel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int resp = JOptionPane.showConfirmDialog(null, "Are you sure to cancel the order?", "The Order Is Being Cancelled", JOptionPane.YES_NO_OPTION);
					if (resp == JOptionPane.YES_OPTION) {
						System.exit(0);
					}
				}
			});
			btnCancel.setBounds(462, 342, 89, 23);
		}
		return btnCancel;
	}
	
	private JTextField getTextOrderPrice() {
		if (textOrderPrice == null) {
			textOrderPrice = new JTextField();
			textOrderPrice.setFont(new Font("Tahoma", Font.PLAIN, 15));
			textOrderPrice.setEditable(false);
			textOrderPrice.setBounds(354, 288, 83, 28);
			textOrderPrice.setColumns(10);
		}
		return textOrderPrice;
	}

	protected McDonalds getMcDonalds() {
		return mcDonalds;
	}

	void initialize() {
		if (registryForm != null) {
			if (registryForm.getConfirmationWindow() != null) {
				registryForm.getConfirmationWindow().dispose();
			}
			registryForm.dispose();
		}
		getSpinner().setValue(1);
		getTextOrderPrice().setText("0 €");
		getBtnNext().setEnabled(false);
		getBtnRemove().setEnabled(false);
		mcDonalds.initOrder();
		updateOrderArea();
		changeProductImage();
		getTglbtnNewToggleButton().setSelected(false);
		getTextOrderArea().setVisible(getTglbtnNewToggleButton().isSelected());;
		getScrollOrderPane().setVisible(getTglbtnNewToggleButton().isSelected());;
		
	}
	
	private JLabel getLblOrderPrice() {
		if (lblOrderPrice == null) {
			lblOrderPrice = new JLabel("Order Price:");
			lblOrderPrice.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblOrderPrice.setBounds(354, 264, 89, 19);
		}
		return lblOrderPrice;
	}
	
	private JButton getBtnRemove() {
		if (btnRemove == null) {
			btnRemove = new JButton("Remove");
			btnRemove.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Product product = (Product) getComboBoxProducts().getSelectedItem();
					int units = (int) getSpinner().getValue();
					mcDonalds.removeFromOrder(product, units);
					String orderPrice = String.format("%.2f", mcDonalds.getOrderTotal());
					getTextOrderPrice().setText(orderPrice);
					if(mcDonalds.getOrderTotal() <= 0) {getBtnNext().setEnabled(false);}
					if(!mcDonalds.isProductInOrder((Product) getComboBoxProducts().getSelectedItem())) {getBtnRemove().setEnabled(false);}
					updateOrderArea();
				}
			});
			btnRemove.setEnabled(false);
			btnRemove.setForeground(Color.WHITE);
			btnRemove.setToolTipText("Removes the selected product to the order");
			btnRemove.setMnemonic('R');
			btnRemove.setBorderPainted(false);
			btnRemove.setBackground(Color.RED);
			btnRemove.setBounds(465, 207, 86, 40);
		}
		return btnRemove;
	}
	private JScrollPane getScrollOrderPane() {
		if (scrollOrderPane == null) {
			scrollOrderPane = new JScrollPane();
			scrollOrderPane.setBounds(369, 82, 272, 95);
			scrollOrderPane.setViewportView(getTextOrderArea());
		}
		return scrollOrderPane;
	}
	private JTextArea getTextOrderArea() {
		if (textOrderArea == null) {
			textOrderArea = new JTextArea();
			textOrderArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
			textOrderArea.setEditable(false);
		}
		return textOrderArea;
	}
	
	public void updateOrderArea() {
		getTextOrderArea().setText(String.format("%sTotal: %.2f €" , mcDonalds.getOrderProducts(), mcDonalds.getOrderTotal()));
	}
	private JToggleButton getTglbtnNewToggleButton() {
		if (tglbtnNewToggleButton == null) {
			tglbtnNewToggleButton = new JToggleButton("Order:");
			tglbtnNewToggleButton.setToolTipText("Shows the order items selected");
			tglbtnNewToggleButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					getTextOrderArea().setVisible(getTglbtnNewToggleButton().isSelected());;
					getScrollOrderPane().setVisible(getTglbtnNewToggleButton().isSelected());;
				}
			});
			tglbtnNewToggleButton.setFont(new Font("Tahoma", Font.BOLD, 15));
			tglbtnNewToggleButton.setBorderPainted(false);
			tglbtnNewToggleButton.setBackground(new Color(255, 255, 255));
			tglbtnNewToggleButton.setIcon(new ImageIcon(MainWindow.class.getResource("/uo/cpm/p3/ui/img/order.png")));
			tglbtnNewToggleButton.setBounds(369, 22, 155, 55);
		}
		return tglbtnNewToggleButton;
	}
	private JLabel getLblProductImage() {
		if (lblProductImage == null) {
			lblProductImage = new JLabel("");
			lblProductImage.setBounds(58, 258, 221, 107);
		}
		return lblProductImage;
	}
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnOrder());
			menuBar.add(getMnHelp());
		}
		return menuBar;
	}
	private JMenu getMnOrder() {
		if (mnOrder == null) {
			mnOrder = new JMenu("Order");
			mnOrder.setMnemonic('O');
			mnOrder.add(getMntmNew());
			mnOrder.add(getSeparator());
			mnOrder.add(getMntmExit());
		}
		return mnOrder;
	}
	private JMenu getMnHelp() {
		if (mnHelp == null) {
			mnHelp = new JMenu("Help");
			mnHelp.setMnemonic('H');
			mnHelp.add(getMntmContent());
			mnHelp.add(getSeparator_1());
			mnHelp.add(getMntmAbout());
		}
		return mnHelp;
	}
	private JMenuItem getMntmNew() {
		if (mntmNew == null) {
			mntmNew = new JMenuItem("New");
			mntmNew.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					initialize();
				}
			});
			mntmNew.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
			mntmNew.setMnemonic('N');
		}
		return mntmNew;
	}
	private JMenuItem getMntmExit() {
		if (mntmExit == null) {
			mntmExit = new JMenuItem("Exit");
			mntmExit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					exit();
				}
			});
			mntmExit.setMnemonic('E');
		}
		return mntmExit;
	}
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	
	private void exit() {
		int resp = JOptionPane.showConfirmDialog(null, "Are you sure to leave the app?", "The app is being closed", JOptionPane.YES_NO_OPTION);
		if (resp == JOptionPane.YES_OPTION) {
			System.exit(0);
		}
	}
	private JMenuItem getMntmContent() {
		if (mntmContent == null) {
			mntmContent = new JMenuItem("Content");
			mntmContent.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "This option is being prepared for you", "Content", JOptionPane.INFORMATION_MESSAGE);
				}
			});
			mntmContent.setMnemonic('C');
		}
		return mntmContent;
	}
	private JMenuItem getMntmAbout() {
		if (mntmAbout == null) {
			mntmAbout = new JMenuItem("About");
			mntmAbout.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "McDonald's APP\nVersion: 1.0.0\nIn this app you can order your favourite burgers\nAuthor: Álvaro Puebla Ruisánchez", "About", JOptionPane.INFORMATION_MESSAGE);
				}
			});
			mntmAbout.setMnemonic('b');
		}
		return mntmAbout;
	}
	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
	private JPanel getProductTypes() {
		if (productTypes == null) {
			productTypes = new JPanel();
			productTypes.setLayout(new GridLayout(4, 1, 0, 0));
			productTypes.add(getBtnBurguers());
			productTypes.add(getBtnDrinks());
			productTypes.add(getBtnSides());
			productTypes.add(getBtnDesserts());
		}
		return productTypes;
	}
	private JButton getBtnBurguers() {
		if (btnBurguers == null) {
			btnBurguers = new JButton("Burguers");
			btnBurguers.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setProductType("Burger");
				}
			});
			btnBurguers.setBorderPainted(false);
			btnBurguers.setBackground(Color.WHITE);
			btnBurguers.setHorizontalTextPosition(SwingConstants.CENTER);
			btnBurguers.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnBurguers.setIcon(new ImageIcon(MainWindow.class.getResource("/uo/cpm/p3/ui/img/Burguer.png")));
		}
		return btnBurguers;
	}
	private JButton getBtnSides() {
		if (btnSides == null) {
			btnSides = new JButton("Sides");
			btnSides.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setProductType("Side");
				}
			});
			btnSides.setBackground(Color.WHITE);
			btnSides.setBorderPainted(false);
			btnSides.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnSides.setHorizontalTextPosition(SwingConstants.CENTER);
			btnSides.setIcon(new ImageIcon(MainWindow.class.getResource("/uo/cpm/p3/ui/img/Sides.png")));
			btnSides.setSelectedIcon(new ImageIcon(MainWindow.class.getResource("/uo/cpm/p3/ui/img/Sides.png")));
		}
		return btnSides;
	}
	private JButton getBtnDrinks() {
		if (btnDrinks == null) {
			btnDrinks = new JButton("Drinks");
			btnDrinks.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setProductType("Drink");
				}
			});
			btnDrinks.setBackground(Color.WHITE);
			btnDrinks.setBorderPainted(false);
			btnDrinks.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnDrinks.setHorizontalTextPosition(SwingConstants.CENTER);
			btnDrinks.setIcon(new ImageIcon(MainWindow.class.getResource("/uo/cpm/p3/ui/img/Drink.png")));
		}
		return btnDrinks;
	}
	private JButton getBtnDesserts() {
		if (btnDesserts == null) {
			btnDesserts = new JButton("Desserts");
			btnDesserts.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setProductType("Dessert");
				}
			});
			btnDesserts.setBackground(Color.WHITE);
			btnDesserts.setBorderPainted(false);
			btnDesserts.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnDesserts.setHorizontalTextPosition(SwingConstants.CENTER);
			btnDesserts.setIcon(new ImageIcon(MainWindow.class.getResource("/uo/cpm/p3/ui/img/Dessert.png")));
			btnDesserts.setSelectedIcon(new ImageIcon(MainWindow.class.getResource("/uo/cpm/p3/ui/img/Dessert.png")));
		}
		return btnDesserts;
	}
	
	private void setProductType(String prodType) {
		getComboBoxProducts().setModel(new DefaultComboBoxModel(mcDonalds.getMenuProductsType(prodType)));
		changeProductImage();
	}
}
