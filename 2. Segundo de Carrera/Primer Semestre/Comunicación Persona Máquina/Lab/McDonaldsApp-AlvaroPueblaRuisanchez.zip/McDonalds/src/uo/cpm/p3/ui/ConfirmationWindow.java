package uo.cpm.p3.ui;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ConfirmationWindow extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel contentPanel;
	private JLabel lblOrderNumber;
	private JLabel lblProcessingOrder;
	private JTextField textOrderCode;
	private JButton btnFinishButton;
	private JLabel lblTotalPrice;
	private JTextField textPrice;
	private JScrollPane scrollPane;
	private JTextArea txtOrderAreaConfirm;
	private MainWindow mainWindow;

	/**
	 * Create the dialog.
	 * @param mainWindow 
	 */
	public ConfirmationWindow(MainWindow mainWindow) {
		setTitle("McDonald's");
		this.mainWindow = mainWindow;
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(getContentPanel(), BorderLayout.CENTER);
	}

	private JPanel getContentPanel() {
		if (contentPanel == null) {
			contentPanel = new JPanel();
			contentPanel.setLayout(null);
			contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			contentPanel.setBackground(Color.WHITE);
			contentPanel.add(getLblOrderNumber());
			contentPanel.add(getLblProcessingOrder());
			contentPanel.add(getTextOrderCode());
			contentPanel.add(getBtnFinishButton());
			contentPanel.add(getLblTotalPrice());
			contentPanel.add(getTextPrice());
			contentPanel.add(getScrollPane());
		}
		return contentPanel;
	}
	private JLabel getLblOrderNumber() {
		if (lblOrderNumber == null) {
			lblOrderNumber = new JLabel("Your order number is:");
			lblOrderNumber.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblOrderNumber.setBounds(40, 173, 159, 31);
		}
		return lblOrderNumber;
	}
	private JLabel getLblProcessingOrder() {
		if (lblProcessingOrder == null) {
			lblProcessingOrder = new JLabel("We are processing your order:");
			lblProcessingOrder.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblProcessingOrder.setAlignmentX(0.5f);
			lblProcessingOrder.setBounds(40, 27, 205, 27);
		}
		return lblProcessingOrder;
	}
	private JTextField getTextOrderCode() {
		if (textOrderCode == null) {
			textOrderCode = new JTextField();
			textOrderCode.setText((mainWindow.getMcDonalds().getOrderCode()));
			textOrderCode.setFont(new Font("Tahoma", Font.PLAIN, 15));
			textOrderCode.setEditable(false);
			textOrderCode.setColumns(10);
			textOrderCode.setBounds(40, 204, 136, 35);
		}
		return textOrderCode;
	}
	private JButton getBtnFinishButton() {
		if (btnFinishButton == null) {
			btnFinishButton = new JButton("Finish");
			btnFinishButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int resp = JOptionPane.showConfirmDialog(null, "Sure to confirm the order?", "The Order Is Being Confirmed", JOptionPane.YES_NO_OPTION);
					if (resp == JOptionPane.YES_OPTION) {
						mainWindow.getMcDonalds().saveOrder();
						mainWindow.initialize();					
					}
				}
			});
			btnFinishButton.setBorderPainted(false);
			btnFinishButton.setBackground(Color.GREEN);
			btnFinishButton.setBounds(303, 215, 104, 31);
		}
		return btnFinishButton;
	}
	private JLabel getLblTotalPrice() {
		if (lblTotalPrice == null) {
			lblTotalPrice = new JLabel("Total Price:");
			lblTotalPrice.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblTotalPrice.setBounds(318, 27, 81, 27);
		}
		return lblTotalPrice;
	}
	private JTextField getTextPrice() {
		if (textPrice == null) {
			textPrice = new JTextField();
			textPrice.setText(String.format("%.2f €", mainWindow.getMcDonalds().getOrderTotal()));
			textPrice.setFont(new Font("Tahoma", Font.PLAIN, 15));
			textPrice.setEditable(false);
			textPrice.setColumns(10);
			textPrice.setBounds(318, 60, 80, 30);
		}
		return textPrice;
	}
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setBounds(40, 60, 250, 110);
			scrollPane.setViewportView(getTxtOrderAreaConfirm());
		}
		return scrollPane;
	}
	private JTextArea getTxtOrderAreaConfirm() {
		
		if (txtOrderAreaConfirm == null) {
			txtOrderAreaConfirm = new JTextArea();
			txtOrderAreaConfirm.setText(String.format("%sTotal: %.2f €" , mainWindow.getMcDonalds().getOrderProducts(), mainWindow.getMcDonalds().getOrderTotal()));
			txtOrderAreaConfirm.setEditable(false);
		}
		return txtOrderAreaConfirm;
	}
}
