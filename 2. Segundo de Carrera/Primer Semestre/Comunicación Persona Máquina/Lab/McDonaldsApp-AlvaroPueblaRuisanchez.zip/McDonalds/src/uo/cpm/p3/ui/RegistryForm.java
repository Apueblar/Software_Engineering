package uo.cpm.p3.ui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;

import uo.cpm.p3.service.McDonalds;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;

import java.time.*;
import java.util.Arrays;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JPasswordField;

public class RegistryForm extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel panleCustomerInfo;
	private JPanel panelOrder;
	private JLabel lblNameSurname;
	private JLabel lblBirthday;
	private JLabel lblPassword;
	private JLabel lblPasswordRepeat;
	@SuppressWarnings("rawtypes")
	private JComboBox comboBoxYear;
	private JTextField textFNameSurname;
	private JRadioButton rdbtnOnSite;
	private JRadioButton rdbtnTakeAway;
	private JButton btnNext;
	private JButton btnCancel;
	private JDialog confirmationWindow;
	private MainWindow mainWindow;
	
	private final int YEARS = 100; // Constant for the maximum number of years displayed for the age
	private JPasswordField passwordField;
	private JPasswordField passwordFieldRepeat;

	/**
	 * Create the frame.
	 */
	public RegistryForm(MainWindow mainWindow) {
		this.mainWindow = mainWindow;
		setBackground(Color.LIGHT_GRAY);
		setTitle("McDonald's");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getPanleCustomerInfo());
		contentPane.add(getPanelOrder());
		contentPane.add(getBtnNext());
		contentPane.add(getBtnCancel());
	}

	private JPanel getPanleCustomerInfo() {
		if (panleCustomerInfo == null) {
			panleCustomerInfo = new JPanel();
			panleCustomerInfo.setBorder(new TitledBorder(null, "Customer Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panleCustomerInfo.setBackground(Color.WHITE);
			panleCustomerInfo.setBounds(10, 11, 414, 167);
			panleCustomerInfo.setLayout(null);
			panleCustomerInfo.add(getLblNameSurname());
			panleCustomerInfo.add(getTextFNameSurname());
			panleCustomerInfo.add(getLblBirthday());
			panleCustomerInfo.add(getComboBoxProducts());
			panleCustomerInfo.add(getLblPassword());
			panleCustomerInfo.add(getPasswordField());
			panleCustomerInfo.add(getLblPasswordRepeat());
			panleCustomerInfo.add(getPasswordFieldRepeat());
			//To add more components
		}
		return panleCustomerInfo;
	}
	
	private JPanel getPanelOrder() {
		if (panelOrder == null) {
			
			ButtonGroup group = new ButtonGroup();
			group.add(getRdbtnOnSite());
			group.add(getRdbtnTakeAway());
			
			panelOrder = new JPanel();
			panelOrder.setBorder(new TitledBorder(null, "Order", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panelOrder.setBackground(Color.WHITE);
			panelOrder.setBounds(10, 181, 220, 69);
			panelOrder.setLayout(null);
			panelOrder.add(getRdbtnOnSite());
			panelOrder.add(getRdbtnTakeAway());
		}
		return panelOrder;
	}
	
	private JLabel getLblNameSurname() {
		if (lblNameSurname == null) {
			lblNameSurname = new JLabel("Name and Surname:");
			lblNameSurname.setLabelFor(getTextFNameSurname());
			lblNameSurname.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblNameSurname.setDisplayedMnemonic('A');
			lblNameSurname.setBounds(10, 30, 129, 14);
		}
		return lblNameSurname;
	}
	
	private JTextField getTextFNameSurname() {
		if (textFNameSurname == null) {
			textFNameSurname = new JTextField();
			textFNameSurname.setBounds(136, 22, 129, 28);
			textFNameSurname.setColumns(10);
		}
		return textFNameSurname;
	}
	
	private JLabel getLblBirthday() {
		if (lblBirthday == null) {
			lblBirthday = new JLabel("Birthday:");
			lblBirthday.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblBirthday.setDisplayedMnemonic('B');
			lblBirthday.setBounds(10, 65, 87, 14);
		}
		return lblBirthday;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private JComboBox getComboBoxProducts() {
		if (comboBoxYear == null) {
			comboBoxYear = new JComboBox();
			
			LocalDate time = LocalDate.now();
			
			String[] years = new String[YEARS];
			for(int i = 0; i < YEARS; i++) {
				years[i] = Integer.toString(time.getYear() - i);
			}
			
			comboBoxYear.setModel(new DefaultComboBoxModel(years));
			comboBoxYear.setBounds(84, 61, 95, 22);
			panleCustomerInfo.add(comboBoxYear);
			
		}
		return comboBoxYear;
	}
	
	private JLabel getLblPassword() {
		if (lblPassword == null) {
			lblPassword = new JLabel("Password:");
			lblPassword.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblPassword.setDisplayedMnemonic('C');
			lblPassword.setBounds(10, 98, 87, 14);
		}
		return lblPassword;
	}
	private JPasswordField getPasswordField() {
		if (passwordField == null) {
			passwordField = new JPasswordField();
			passwordField.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					if (getPasswordField().getPassword().length < 8) {
						JOptionPane.showMessageDialog(null, "The password must be more than 8 characters");
					}
				}
			});
			passwordField.setBounds(84, 91, 135, 28);
		}
		return passwordField;
	}
	
	private JLabel getLblPasswordRepeat() {
		if (lblPasswordRepeat == null) {
			lblPasswordRepeat = new JLabel("Repeat Password:");
			lblPasswordRepeat.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblPasswordRepeat.setDisplayedMnemonic('D');
			lblPasswordRepeat.setBounds(10, 134, 129, 14);
		}
		return lblPasswordRepeat;
	}
	
	private JPasswordField getPasswordFieldRepeat() {
		if (passwordFieldRepeat == null) {
			passwordFieldRepeat = new JPasswordField();
			passwordFieldRepeat.setBounds(122, 126, 135, 28);
		}
		return passwordFieldRepeat;
	}
	
	public JDialog getConfirmationWindow() {
		return confirmationWindow;
	}
	
	private JRadioButton getRdbtnOnSite() {
		if (rdbtnOnSite == null) {
			rdbtnOnSite = new JRadioButton("On site");
			rdbtnOnSite.setToolTipText("Select to eat in the restaurant");
			rdbtnOnSite.setSelected(true);
			rdbtnOnSite.setBackground(Color.WHITE);
			rdbtnOnSite.setBounds(16, 27, 78, 23);
		}
		return rdbtnOnSite;
	}
	
	private JRadioButton getRdbtnTakeAway() {
		if (rdbtnTakeAway == null) {
			rdbtnTakeAway = new JRadioButton("Take away");
			rdbtnTakeAway.setToolTipText("Select to take away your order");
			rdbtnTakeAway.setBackground(Color.WHITE);
			rdbtnTakeAway.setBounds(105, 27, 109, 23);
		}
		return rdbtnTakeAway;
	}
	
	private JButton getBtnNext() {
		if (btnNext == null) {
			btnNext = new JButton("Next");
			btnNext.setBorderPainted(false);
			btnNext.setForeground(Color.BLACK);
			btnNext.setBackground(Color.GREEN);
			btnNext.setBounds(240, 227, 89, 23);
			btnNext.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (!(getTextFNameSurname().getText().isEmpty())) {
						int age = LocalDate.now().getYear() - Integer.parseInt((String) getComboBoxProducts().getSelectedItem());
						if (getComboBoxProducts().getSelectedItem() != null && age >= McDonalds.EDAD_MIN && age <= McDonalds.EDAD_MAX) {
							if (passwordField.getPassword().length != 0) {
								if (passwordFieldRepeat.getPassword().length != 0) {
									if (Arrays.equals(passwordField.getPassword(), passwordFieldRepeat.getPassword())) {
										mainWindow.getMcDonalds().setOrderType(getRdbtnTakeAway().isSelected());
										mainWindow.getMcDonalds().saveCustomerData(getTextFNameSurname().getText(), age, getPasswordField().getPassword().toString());
										showConfirmationWindow();
									}else {
										JOptionPane.showMessageDialog(passwordField, "The passwords do not coincide.", "INCORRECT PASSWORDS", JOptionPane.ERROR_MESSAGE);
									}
								}else {
									JOptionPane.showMessageDialog(passwordFieldRepeat, "The repeated password is empty.", "EMPTY REPEATED PASWORD", JOptionPane.ERROR_MESSAGE);
								}
							}else {
							JOptionPane.showMessageDialog(passwordFieldRepeat, "The password is empty.", "EMPTY PASSWORD", JOptionPane.ERROR_MESSAGE);
							}
						}else {
							JOptionPane.showMessageDialog(getLblBirthday(), String.format("Age must be at least %d and not over %d.", McDonalds.EDAD_MIN, McDonalds.EDAD_MAX), "WRONG AGE", JOptionPane.ERROR_MESSAGE);	
						}
					}else {
						JOptionPane.showMessageDialog(getTextFNameSurname(), "The name is empty.", "EMPTY NAME", JOptionPane.ERROR_MESSAGE);
					}
					}
				});
		}
		return btnNext;
	}
	
	private void showConfirmationWindow() {
		confirmationWindow = new ConfirmationWindow(mainWindow);
		confirmationWindow.setLocationRelativeTo(this); //Adjust the pop up to the middle
		confirmationWindow.setModal(true); // You need to close the pop up to interact with this window
		confirmationWindow.setVisible(true); // Visible
	}
	
	private JButton getBtnCancel() {
		if (btnCancel == null) {
			btnCancel = new JButton("Cancel");
			btnCancel.setForeground(Color.WHITE);
			btnCancel.setBorderPainted(false);
			btnCancel.setBackground(Color.RED);
			btnCancel.setBounds(335, 227, 89, 23);
			btnCancel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
		}
		return btnCancel;
	}
	
	public int isOnSite() {
		if (rdbtnTakeAway.isSelected()) {return 1;}
		return 0;
	}
}
