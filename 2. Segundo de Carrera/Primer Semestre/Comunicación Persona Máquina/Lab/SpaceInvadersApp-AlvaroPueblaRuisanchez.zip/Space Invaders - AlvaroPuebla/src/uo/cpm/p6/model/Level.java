package uo.cpm.p6.model;

public enum Level {
	EASY(10, 2, 0, 5), INTERMEDIATE(8, 1, 1, 4), HARD( 6, 1, 2, 3);

	private int numCells, numInvaders, numMeteorites, numShots;

	Level( int numCells, int numInvaders, int numMeteorites, int numShots) {

		this.numCells = numCells;
		this.numInvaders = numInvaders;
		this.numMeteorites = numMeteorites;
		this.numShots = numShots;
	}

	public int getNumCells() {
		return numCells;
	}

	public int getNumInvaders() {
		return numInvaders;
	}

	public int getNumMeteorites() {
		return numMeteorites;
	}

	public int getNumShots() {
		return numShots;
	}
}