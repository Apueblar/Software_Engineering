package uo.cpm.p6.model;

public class Dice {
	
	/**
	 * Rolls a dice between [1 and Game.MAX_SHOOTS]
	 * @return The number
	 */
	public static int roll(int maxShots)
	{ 
		return ((int) (Math.random() * maxShots) + 1);
	}
}
