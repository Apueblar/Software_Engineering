package uo.cpm.p6.model;

public class Cell {

	public enum TypeCell {
		METEORITE, ENEMY, NEUTRAL
	};

	private String name;
	private TypeCell typeCell;
	private int score;
	private String picture;
	
	public Cell(String name, TypeCell typeCell, int score, String picture) {
		this.name = name;
		this.typeCell = typeCell;
		this.score = score;
		this.picture = picture;
	}

	/**
	 * Returns the actual picture of a given cell
	 * @return The string containing the address of the picture
	 */
	public String getPicture() {
		return picture;
	}

	/**
	 * Sets cell's address picture 
	 * @param picture
	 */
	public void setPicture(String picture) {
		this.picture = picture;
	}

	/**
	 * Returns the score of shooting this cell
	 * @return The score
	 */
	public int getScore() {
		return score;
	}

	/**
	 * Sets the score of shooting this cell
	 * @param score The score
	 */
	public void setScore(int score) {
		this.score = score;
	}

	/**
	 * Returns the cell name
	 * @return string cell name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name of the cell
	 * @param name The name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns the type of the cell
	 * @return type of cell
	 */
	public TypeCell getTypeCell() {
		return typeCell;
	}

	/**
	 * Sets the type of the cell
	 * @param typeCell The type of the cell
	 */
	public void setTypeCell(TypeCell typeCell) {
		this.typeCell = typeCell;
	}

}
