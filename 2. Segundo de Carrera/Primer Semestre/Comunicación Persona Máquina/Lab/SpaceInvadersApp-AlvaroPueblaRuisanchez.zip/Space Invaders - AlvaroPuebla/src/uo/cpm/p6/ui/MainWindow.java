package uo.cpm.p6.ui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import uo.cpm.p6.model.Level;
import uo.cpm.p6.service.SpaceInvaders;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JRadioButtonMenuItem;

public class MainWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private SpaceInvaders spaceInvaders;
	private JButton btnDice;
	private JLabel lblScore;
	private JTextField txtScore;
	private JPanel Cells;
	private JPanel panelShots;
	private JLabel lblShip;
	private JMenuBar menuBar;
	private JMenu mnGame;
	private JMenu mnHelp;
	private JMenuItem mntmContent;
	private JMenuItem mntmAbout;
	private JSeparator helpSeparator;
	private JMenuItem mntmRestart;
	private JMenuItem mntmExit;
	private JSeparator gameSeparator;
	private JLabel lblEarth;
	private JMenu mnLevel;
	private JRadioButtonMenuItem rdbtnmntmEasy;
	private JRadioButtonMenuItem rdbtnmntmIntermediate;
	private JRadioButtonMenuItem rdbtnmntmHard;
	private ProcessAction pa = null;

	/**
	 * Creates the frame.
	 * @param spaceInvaders 
	 */
	public MainWindow(SpaceInvaders spaceInvaders) {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				exit();
			}
		});
		getContentPane().setBackground(Color.BLACK);
		this.spaceInvaders = spaceInvaders;
		spaceInvaders.setLevel(Level.INTERMEDIATE);
		pa = new ProcessAction();
		
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 1080, 385);
		getContentPane().setLayout(null);
		getContentPane().add(getBtnDice());
		getContentPane().add(getLblShip());
		getContentPane().add(getLblScore());
		getContentPane().add(getTxtScore());
		getContentPane().add(getCells());
		getContentPane().add(getPanelShots());
		getContentPane().add(getLblEarth());
		prepareBoard(spaceInvaders.getLevel());
		
		enableBoard(false);
		getTxtScore().setText("" + spaceInvaders.getScore());
		
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	}
	
	/**
	 * Initializes the game if it is restarted
	 */
	private void initialize() {
		spaceInvaders.initialize();
		getBtnDice().setEnabled(true);
		getPanelShots().removeAll();
		getPanelShots().repaint();
		for(Component c : getCells().getComponents()) {
			ImageIcon icon = new ImageIcon(MainWindow.class.getResource(""));
			((JButton)c).setIcon(icon);
			((JButton)c).setDisabledIcon(icon);
		}
		validate();
		prepareBoard(spaceInvaders.getLevel());
		getTxtScore().setText("" + spaceInvaders.getScore());
	}

	/**
	 * Dice button
	 * @return Dice button
	 */
	private JButton getBtnDice() {
		if (btnDice == null) {
			btnDice = new JButton("");
			btnDice.setBorderPainted(false);
			btnDice.setDisabledIcon(new ImageIcon(MainWindow.class.getResource("/img/dice.jpg")));
			btnDice.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					rollDice();
				}
			});
			btnDice.setIcon(new ImageIcon(MainWindow.class.getResource("/img/dice.jpg")));
			btnDice.setBounds(10, 11, 113, 113);
		}
		return btnDice;
	}
	
	/**
	 * Used to confirm that the user wants to exit the game
	 */
	private void exit() {
		int resp = JOptionPane.showConfirmDialog(null, "Are you sure to leave the app?", "The app is being closed", JOptionPane.YES_NO_OPTION);
		if (resp == JOptionPane.YES_OPTION) {
			System.exit(0);
		}
	}
	
	/**
	 * Rolls the dice and updates the shots
	 */
	private void rollDice() {
		spaceInvaders.roll();
		
		paintShots();
		
		getBtnDice().setEnabled(false); // Disable dice
		
		enableBoard(true); // Enable cells
	}
	
	/**
	 * Paints the shots to visually see them
	 */
	private void paintShots() {
		for (int i = 0; i < spaceInvaders.getShots(); i++) {
			JLabel lbl = new JLabel(new ImageIcon(MainWindow.class.getResource("/img/shoot.png")));
			getPanelShots().add(lbl);
		}
		validate(); //reloads the screen
	}
	
	/**
	 * Label of the ship image
	 * @return Label of ship image
	 */
	private JLabel getLblShip() {
		if (lblShip == null) {
			lblShip = new JLabel("");
			lblShip.setIcon(new ImageIcon(MainWindow.class.getResource("/img/spaceship.png")));
			lblShip.setBounds(370, 11, 137, 74);
		}
		return lblShip;
	}
	
	/**
	 * Label of the Score
	 * @return Label of the score
	 */
	private JLabel getLblScore() {
		if (lblScore == null) {
			lblScore = new JLabel("Score:");
			lblScore.setFont(new Font("Tahoma", Font.BOLD, 20));
			lblScore.setLabelFor(getTxtScore());
			lblScore.setForeground(Color.WHITE);
			lblScore.setBounds(738, 28, 113, 30);
		}
		return lblScore;
	}
	
	/**
	 * Text Field to add the score
	 * @return Text Field to add the score
	 */
	private JTextField getTxtScore() {
		if (txtScore == null) {
			txtScore = new JTextField();
			txtScore.setFont(new Font("Tahoma", Font.BOLD, 20));
			txtScore.setText("0");
			txtScore.setForeground(Color.GREEN);
			txtScore.setBackground(Color.BLACK);
			txtScore.setEditable(false);
			txtScore.setBounds(738, 60, 82, 30);
			txtScore.setColumns(10);
		}
		return txtScore;
	}
	
	class ProcessAction implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			shoot(Integer.valueOf(e.getActionCommand()));
		}
		
	}
	
	/**
	 * JPanel with cells
	 * @return JPanel with cells
	 */
	private JPanel getCells() {
		if (Cells == null) {
			Cells = new JPanel();
			Cells.setBorder(new LineBorder(new Color(0, 0, 255)));
			Cells.setBackground(Color.BLUE);
			Cells.setBounds(40, 210, 640, 101);
			Cells.setLayout(new GridLayout(0, 8, 0, 0));
		}
		return Cells;
	}
	
	private void prepareBoard(Level level) {
		int width = 0;
		switch(level) {
		case EASY: {width = 1010; break;}
		case INTERMEDIATE: {width = 815; break;}
		case HARD: {width = 610; break;}
		}
		getCells().setBounds(40, 210, width, 101);
		getCells().setLayout(new GridLayout(1, spaceInvaders.getDimension(), 0, 0));
		getCells().removeAll();
		for (int i = 0; i < spaceInvaders.getDimension(); i++) {
			getCells().add(newButton(i));
		}
		enableBoard(false);
		validate();
	}
	
	private JButton newButton(int i) {
		final JButton button = new JButton("");
		button.setBorder(new LineBorder(Color.BLUE, 2));
		
		button.setActionCommand("" + i);
		button.addActionListener(pa);
		return button;
	}

	/**
	 * Shoots at a given cell and checks the content, shows the user if won, lost or nothing
	 * @param i The cell number
	 */
	private void shoot(int i) {
		// Paint image
		spaceInvaders.shoot(i);
		
		//Disable btn
		ImageIcon icon = new ImageIcon(MainWindow.class.getResource(spaceInvaders.getPicture(i)));
		((JButton)getCells().getComponent(i)).setIcon(icon);
		((JButton)getCells().getComponent(i)).setDisabledIcon(icon);
		
		//Disable Btn
		((JButton)getCells().getComponent(i)).setEnabled(false);
		
		//Remove shot
		getPanelShots().remove(0);
		getPanelShots().repaint();
		
		//Update Score
		getTxtScore().setText("" + spaceInvaders.getScore());
		
		//Check state of the game
		if (spaceInvaders.isGameOver()) {
			enableBoard(false);
			showBoard();
			if (spaceInvaders.isMeteoriteFound()) {
				JOptionPane.showMessageDialog(null, "A meteorite has destroyed you!", "You lost", JOptionPane.INFORMATION_MESSAGE);
			} else if (spaceInvaders.isInvaderFound()) {
				JOptionPane.showMessageDialog(null, "You found the invader!", "You won", JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null, "You ran out of shots!", "You lost", JOptionPane.INFORMATION_MESSAGE);
			}
		}
		
	}
	
	/**
	 * Used to enable or disable all the cells at the same time
	 * @param b true enables. false disables
	 */
	private void enableBoard(boolean b) {
		for(Component c : getCells().getComponents()) {
			c.setEnabled(b);
		}
	}
	
	/**
	 * Used to display all the images of the board
	 */
	private void showBoard() {
		for(int i = 0; i < getCells().getComponents().length; i++) {
			ImageIcon icon = new ImageIcon(MainWindow.class.getResource(spaceInvaders.getPicture(i)));
			((JButton)getCells().getComponent(i)).setIcon(icon);
			((JButton)getCells().getComponent(i)).setDisabledIcon(icon);
		}
	}
	
	/**
	 * JPanel with the number of shots
	 * @return
	 */
	private JPanel getPanelShots() {
		if (panelShots == null) {
			panelShots = new JPanel();
			panelShots.setBackground(Color.BLACK);
			panelShots.setBounds(241, 96, 400, 101);
		}
		return panelShots;
	}
	
	/**
	 * JMenuBar with the menu
	 * @return JMenuBar with the menu
	 */
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnGame());
			menuBar.add(getMnLevel());
			menuBar.add(getMnHelp());
		}
		return menuBar;
	}
	
	/**
	 * JMenu for related things of game
	 * @return JMenu for related things of game
	 */
	private JMenu getMnGame() {
		if (mnGame == null) {
			mnGame = new JMenu("Game");
			mnGame.setMnemonic('G');
			mnGame.add(getMntmRestart());
			mnGame.add(getGameSeparator());
			mnGame.add(getMntmExit());
		}
		return mnGame;
	}
	
	/**
	 * JMenu for related things of help
	 * @return JMenu for related things of help
	 */
	private JMenu getMnHelp() {
		if (mnHelp == null) {
			mnHelp = new JMenu("Help");
			mnHelp.setMnemonic('H');
			mnHelp.add(getMntmContent());
			mnHelp.add(getHelpSeparator());
			mnHelp.add(getMntmAbout());
		}
		return mnHelp;
	}
	
	/**
	 * Menu item of help for content
	 * @return Menu item of help for content
	 */
	private JMenuItem getMntmContent() {
		if (mntmContent == null) {
			mntmContent = new JMenuItem("Content");
			mntmContent.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "THERE IS NO CURRENT CONTENT", "Content", JOptionPane.INFORMATION_MESSAGE);
				}
			});
			mntmContent.setMnemonic('C');
		}
		return mntmContent;
	}

	/**
	 * Help Separator
	 * @return Help separator
	 */
	private JSeparator getHelpSeparator() {
		if (helpSeparator == null) {
			helpSeparator = new JSeparator();
		}
		return helpSeparator;
	}
	
	/**
	 * Menu item of help for about
	 * @return Menu item of help for about
	 */
	private JMenuItem getMntmAbout() {
		if (mntmAbout == null) {
			mntmAbout = new JMenuItem("About");
			mntmAbout.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Space Invaders 1.0\nCreated by Alvaro Puebla\nThe objective is to shoot at an Alien and have the highest score", "About", JOptionPane.INFORMATION_MESSAGE);
				}
			});
			mntmAbout.setMnemonic('A');
		}
		return mntmAbout;
	}
	
	/**
	 * Menu item of game for restart
	 * @return Menu item of game for restart
	 */
	private JMenuItem getMntmRestart() {
		if (mntmRestart == null) {
			mntmRestart = new JMenuItem("Restart");
			mntmRestart.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					initialize();
				}
			});
			mntmRestart.setMnemonic('R');
		}
		return mntmRestart;
	}
	
	/**
	 * Game Separator
	 * @return Game separator
	 */
	private JSeparator getGameSeparator() {
		if (gameSeparator == null) {
			gameSeparator = new JSeparator();
		}
		return gameSeparator;
	}
	
	/**
	 * Menu item of game for exit
	 * @return Menu item of game for exit
	 */
	private JMenuItem getMntmExit() {
		if (mntmExit == null) {
			mntmExit = new JMenuItem("Exit");
			mntmExit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					exit();
				}
			});
			mntmExit.setMnemonic('E');
		}
		return mntmExit;
	}
	
	/**
	 * Label of the earth image
	 * @return Label of the earth image
	 */
	private JLabel getLblEarth() {
		if (lblEarth == null) {
			lblEarth = new JLabel("");
			lblEarth.setIcon(new ImageIcon(MainWindow.class.getResource("/img/earth.jpg")));
			lblEarth.setBounds(861, 11, 193, 175);
		}
		return lblEarth;
	}
	
	/**
	 * Menu icon for selecting the level
	 * @return The menu
	 */
	private JMenu getMnLevel() {
		if (mnLevel == null) {
			mnLevel = new JMenu("Level");
			mnLevel.setMnemonic('L');
			mnLevel.add(getRdbtnmntmEasy());
			mnLevel.add(getRdbtnmntmIntermediate());
			mnLevel.add(getRdbtnmntmHard());
			
			ButtonGroup level = new ButtonGroup();
			level.add(rdbtnmntmEasy);
			level.add(rdbtnmntmIntermediate);
			level.add(rdbtnmntmHard);
		}
		return mnLevel;
	}
	private JRadioButtonMenuItem getRdbtnmntmEasy() {
		if (rdbtnmntmEasy == null) {
			rdbtnmntmEasy = new JRadioButtonMenuItem("Easy");
			rdbtnmntmEasy.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					spaceInvaders.setLevel(Level.EASY);
					initialize();
				}
			});
		}
		return rdbtnmntmEasy;
	}
	private JRadioButtonMenuItem getRdbtnmntmIntermediate() {
		if (rdbtnmntmIntermediate == null) {
			rdbtnmntmIntermediate = new JRadioButtonMenuItem("Intermediate");
			rdbtnmntmIntermediate.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					spaceInvaders.setLevel(Level.INTERMEDIATE);
					initialize();
				}
			});
			rdbtnmntmIntermediate.setSelected(true);
		}
		return rdbtnmntmIntermediate;
	}
	private JRadioButtonMenuItem getRdbtnmntmHard() {
		if (rdbtnmntmHard == null) {
			rdbtnmntmHard = new JRadioButtonMenuItem("Hard");
			rdbtnmntmHard.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					spaceInvaders.setLevel(Level.HARD);
					initialize();
				}
			});
		}
		return rdbtnmntmHard;
	}
}




























