package uo.cpm.p6.model;

import uo.cpm.p6.model.Cell.TypeCell;

public class Board {
	
	public int DIM;
	Cell[] cells;
	
	public Board(Level level) {
		if (level == null) {level = Level.INTERMEDIATE;} // used in main
		DIM = level.getNumCells();
		cells = new Cell[DIM];

		for (int i=0;i<DIM;i++) {cells[i] = new Cell("Space",TypeCell.NEUTRAL,-200,"/img/space.jpg");}
		for(int x = 0; x < level.getNumInvaders(); x++) {placeInvader();}
		for(int x = 0; x < level.getNumMeteorites(); x++) {placeMeteorite();}
	}
	
	/**
	 * Places the invader in a neutral cell
	 */
	private void placeInvader() {
		boolean notPlaced = true;
		while (notPlaced) {
			int posicionInvasor = (int) (Math.random() * DIM);
			if (cells[posicionInvasor].getTypeCell().equals(TypeCell.NEUTRAL)) {
				cells[posicionInvasor] = new Cell("Invader",TypeCell.ENEMY,3000,"/img/invader.jpg");	
				notPlaced = false;
			}
		}
	}
	
	/**
	 * Places the meteorite in a neutral cell
	 */
	private void placeMeteorite() {
		boolean notPlaced = true;
		while (notPlaced) {
			int posicionMeteorite = (int) (Math.random() * DIM);
			if (cells[posicionMeteorite].getTypeCell().equals(TypeCell.NEUTRAL)) {
				cells[posicionMeteorite] = new Cell("Meteorite",TypeCell.METEORITE,0,"/img/meteorite.png");	
				notPlaced = false;
			}
		}
	}

	/**
	 * Returns an array of cells
	 * @return a cell array
	 */
	public Cell[] getCells() {
		return cells;
	}

	/**
	 * Sets an array of cells
	 * @param cells Array of cells
	 */
	public void setCells(Cell[] cells) {
		this.cells = cells;
	}

	/**
	 * Returns the actual picture of a given cell
	 * @param position The position of the cell
	 * @return The string containing the address of the picture
	 */
	public String getPicture(Integer position)
	{
		return this.cells[position].getPicture();
	}
}
