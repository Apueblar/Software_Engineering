package uo.cpm.p6.rules;

import uo.cpm.p6.model.Board;
import uo.cpm.p6.model.Cell;
import uo.cpm.p6.model.Cell.TypeCell;
import uo.cpm.p6.model.Dice;
import uo.cpm.p6.model.Level;

public class Game {
	
	int score;
	int shots;
	private Board board; 
	private Cell cellShot;
	private boolean invaderFound;
	private boolean gameOver;
	private boolean meteoriteFound;
	private Level level;
	
	/**
	 * Returns the instance of the board class
	 * @return The board
	 */
	public Board getBoard() {
		return board;
	}

	public Game(){
		initialize();
	}
	
	/**
	 * Initializes the variables for the start of a new game
	 */
	public void initialize(){
		board = new Board(level);
		score = 1000;
		shots = 0;
		cellShot=null;
		invaderFound = false;
		gameOver = false;
		meteoriteFound = false;
	}

	/**
	 * Shoots at a given cell and updates end of game variables
	 * @param i The cell to shoot
	 */
	public void shoot(int i){
		shots--;
		setCellShot(board.getCells()[i]);
		invaderFound = board.getCells()[i].getTypeCell().equals(TypeCell.ENEMY);
		meteoriteFound = board.getCells()[i].getTypeCell().equals(TypeCell.METEORITE);
		gameOver = isGameFinished();
		score += board.getCells()[i].getScore();
		if(meteoriteFound) {score = 0;}
	}
	
	/**
	 * Return true if isGameFinished()
	 * @return true if isGameFinished()
	 */
	public boolean isGameOver() {
		return gameOver;
	}
	
	/**
	 * Returns true if the invader is found
	 * @return true if invader found
	 */
	public boolean isInvaderFound() {
		return invaderFound;
	}
	
	/**
	 * Returns true if the meteorite is found
	 * @return true if meteorite found
	 */
	public boolean isMeteoriteFound() {
		return meteoriteFound;
	}
	
	/**
	 * Returns true if Invader or Meteorite found or shots == 0
	 * @return true if Invader or Meteorite found or shots == 0
	 */
	public boolean isGameFinished() {
		return (getCellShot().getTypeCell().equals(TypeCell.ENEMY)|| getCellShot().getTypeCell().equals(TypeCell.METEORITE) || shots == 0);
	}

	/**
	 * Returns the score of the game
	 * @return the score of the game
	 */
	public int getScore() {
		return score;
	}

	/**
	 * Rolls the dice and sets the shots
	 */
	public void roll() {
		setShots(Dice.roll(level.getNumShots()));	
	}
	
	/**
	 * Returns the number of shots
	 * @return the number of shots
	 */
	public int getShots() {
		return shots;
	}

	/**
	 * Sets the number of shots
	 * @param shots The number of shots
	 */
	private void setShots(int shots) {
		this.shots = shots;
	}

	/**
	 * Returns cell's address picture
	 * @param i The cell number
	 * @return cell's address picture
	 */
	public String getPicture(int i) {
		return getBoard().getPicture(i);
	}

	/**
	 * Returns the last shot cell
	 * @return The last shot cell
	 */
	public Cell getCellShot() {
		return cellShot;
	}

	/**
	 * Sets the last shot cell
	 * @param cellShot The last shot cell
	 */
	public void setCellShot(Cell cellShot) {
		this.cellShot = cellShot;
	}

	/**
	 * Sets the level type
	 * @param level The difficulty of the game
	 */
	public void setLevel(Level level) {
		this.level = level;
	}
	
	/**
	 * Returns the level of the game
	 * @return level of the game
	 */
	public Level getLevel() {
		return level;
	}

	/**
	 * Returns the dimensions of the cells
	 * @return dimension of the cells
	 */
	public int getDimension() {
		return level.getNumCells();
	}
}
