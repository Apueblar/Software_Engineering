package uo.cpm.p6.service;

import uo.cpm.p6.model.Board;
import uo.cpm.p6.model.Level;
import uo.cpm.p6.rules.Game;

public class SpaceInvaders {

	private Game game = new Game();

	public Board getBoard()
	{
		return game.getBoard();
	}

	/**
	 * Initializes the game
	 */
	public void initialize()
	{
		game.initialize();
	}

	/**
	 * Shoots at a cell
	 * @param i The cell to shoot
	 */
	public void shoot(int i)
	{
		game.shoot(i);
	}

	/**
	 * Returns true if alien or meteorite found or shots == 0
	 * @return true if alien or meteorite found or shots == 0
	 */
	public boolean isGameOver()
	{
		return game.isGameOver();
	}
	
	/**
	 * Returns true if alien found
	 * @return true if alien found
	 */
	public boolean isInvaderFound()
	{
		return game.isInvaderFound();
	}
	
	/**
	 * Returns true if meteorite found
	 * @return true if meteorite found
	 */
	public boolean isMeteoriteFound() 
	{
		return game.isMeteoriteFound();
	}
	
	/**
	 * Returns the user score
	 * @return the user score
	 */
	public int getScore()
	{
		return game.getScore();
	}

	/**
	 * Rolls the dice
	 */
	public void roll()
	{
		game.roll();
	}

	/**
	 * Returns the available shots
	 * @return number of available shots
	 */
	public int getShots()
	{
		return game.getShots();
	}
	
	/**
	 * Returns cell's address picture
	 * @param i The cell number
	 * @return cell's address picture
	 */
	public String getPicture(int i) 
	{
		return game.getPicture(i);
	}

	public void setLevel(Level level) {
		game.setLevel(level);
	}

	public Level getLevel() {
		return game.getLevel();
	}

	public int getDimension() {
		return game.getDimension();
	}

}