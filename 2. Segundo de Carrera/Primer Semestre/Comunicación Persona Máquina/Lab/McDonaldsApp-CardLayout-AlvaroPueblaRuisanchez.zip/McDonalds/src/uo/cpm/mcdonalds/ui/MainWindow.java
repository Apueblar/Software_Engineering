package uo.cpm.mcdonalds.ui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints.Key;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.util.Iterator;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import uo.cpm.mcdonalds.model.Product;
import uo.cpm.mcdonalds.model.TypeOfProduct;
import uo.cpm.mcdonalds.service.McDonalds;
import uo.cpm.mcdonalds.util.FileUtil;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;

public class MainWindow extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblLogo;
	private JLabel lblLblname;
	private JPanel pnInfo1;
	private JPanel pnlLogo;
	private JPanel pnProducts;
	private ButtonAction aB;
	private JPanel pnBts1;
	private JPanel pnBts2;
	private JPanel pnBts3;
	private JPanel pnContents;
	private JPanel pn2;
	private JPanel pn3;
	private JPanel pnCustonerInfo;
	private JLabel lblName;
	private JTextField txtName;
	private JLabel lblYear;
	private JComboBox<String> cbYears;
	private JLabel lbPasw1;
	private JPasswordField psw1;
	private JLabel lbPasw2;
	private JPasswordField psw2;
	private JPanel pn1;
	private JPanel pnForm;
	private JPanel pnOrderData;
	private JRadioButton rbOnsite;
	private JRadioButton rbTakeAway;
	private JPanel pnInfo2;
	private JPanel pnConfirmationBts;
	private JPanel pnInfo3;
	private JLabel lblAdvise;
	private JLabel lbOk;
	private JLabel lblCode;
	private JTextField txtCode;
	private final ButtonGroup grOrder = new ButtonGroup();
	private McDonalds mcDonalds;
	private JPanel pnSouth;
	private JPanel pnInfo;
	private JTextField txtPrice;
	private JPanel pnBts;
	private JPanel pnMain;
	private JButton btnCancel1;
	private JButton btnNext1;
	private JPanel pnRegistry;
	private JButton btnBack2;
	private JButton btnNext2;
	private JPanel pnBtConfirmation;
	private JButton btnBack3;
	private JButton btnFinish;
	private JTabbedPane tabbedPane;
	private JScrollPane sPDrinks;
	private JScrollPane sPFood;
	private JList<Product> listDrinks;
	private JList<Product> listFood;
	DefaultListModel<Product> modelFood;
	DefaultListModel<Product> modelDrinks;
	private JPanel panelFilter;
	private JButton btnBurgers;
	private JButton btnDrinks;
	private JButton btnSides;
	private JButton btnDesserts;
	private JButton btnRemoveFilter;

	/**
	 * Create the frame.
	 */
	public MainWindow(McDonalds mcDonalds) {
		this.mcDonalds = mcDonalds;
		aB = new ButtonAction();
		setIconImage(Toolkit.getDefaultToolkit().getImage(
				MainWindow.class.getResource("/uo/cpm/mcdonalds/ui/img/logo.PNG")));
		setTitle("McDonald's Spain");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 820);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(getPnlLogo(), BorderLayout.NORTH);
		contentPane.add(getPnContents(), BorderLayout.CENTER);
		contentPane.add(getPnSouth(), BorderLayout.SOUTH);
		contentPane.add(getPanelFilter(), BorderLayout.WEST);

		// To change the size of the pictures when we resize the buttons.
		// This avoids the problem of the 0 size exception.
		this.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				associateImagesToButtons();
			}
		});
	}

		
	private JLabel getLblLogo() {
		if (lblLogo == null) {
			lblLogo = new JLabel("");
			lblLogo.setIcon(new ImageIcon(MainWindow.class
					.getResource("/uo/cpm/mcdonalds/ui/img/logo.PNG")));
		}
		return lblLogo;
	}

	private JLabel getLblLblName() {
		if (lblLblname == null) {
			lblLblname = new JLabel("McDonald's");
			lblLblname.setFont(new Font("Arial Black", Font.PLAIN, 44));
			lblLblname.setForeground(Color.BLACK);
		}
		return lblLblname;
	}

	protected void initialize() {
		mcDonalds.initOrder();
		modelFood.clear();
		modelDrinks.clear();
		getTxtPrice().setText("Price 0.00 €");
		getBtnNext1().setEnabled(false);
		clearRegistryForm();
		showPn1();
	}

	private void clearRegistryForm() {
		getTxtName().setText("");;
		getCbYears().setSelectedIndex(0);;
		getRbOnsite().setSelected(true);
		getRbTakeAway().setSelected(false);
		getPsw1().setText("");
		getPsw2().setText("");
	}


	private JPanel getPnInfo1() {
		if (pnInfo1 == null) {
			pnInfo1 = new JPanel();
			pnInfo1.setBackground(Color.WHITE);
			pnInfo1.setLayout(new BorderLayout(0, 0));
			pnInfo1.add(getPnBts1(), BorderLayout.SOUTH);

		}
		return pnInfo1;
	}

	private JPanel getPnlLogo() {
		if (pnlLogo == null) {
			pnlLogo = new JPanel();
			pnlLogo.setBackground(Color.WHITE);
			pnlLogo.setLayout(new GridLayout(1, 0, 0, 0));
			pnlLogo.add(getLblLogo());
			pnlLogo.add(getLblLblName());
		}
		return pnlLogo;
	}

	private JPanel getPnProducts() {
		if (pnProducts == null) {
			pnProducts = new JPanel();
			pnProducts.setBorder(new LineBorder(Color.ORANGE, 4));
			pnProducts.setBackground(Color.WHITE);
			pnProducts.setLayout(new GridLayout(0, 6, 3, 3));
			createProductButtons();

		}
		return pnProducts;
	}

	
	private void createProductButtons() {
		pnProducts.removeAll();
		
		int i = 0;
		for (Product p : mcDonalds.getMenuProducts()) {
			pnProducts.add(newButton(i, p));
			i++;
		}
	}

	private void adaptImage(JButton button, String imagePath) {
		 Image imgOriginal = new ImageIcon(getClass().getResource(imagePath)).getImage(); 
		 Image imgEscalada = imgOriginal.getScaledInstance((int) (100), (int) (100),Image.SCALE_SMOOTH);
		 button.setIcon(new ImageIcon(imgEscalada));
	}
	

	private void associateImagesToButtons() {
		for (int i = 0; i < pnProducts.getComponents().length; i++) {
			JButton boton = (JButton) (pnProducts.getComponents()[i]);
			adaptImage(boton, "/uo/cpm/mcdonalds/ui/img/"+mcDonalds.getMenuProducts()[i].getCode()+".png");
		}
	}

	private JButton newButton(Integer position, Product p) {
		JButton button = new JButton("");
		button.setBackground(Color.white);
		button.setBorder(new LineBorder(Color.LIGHT_GRAY, 2, true));
		button.setToolTipText(p.toString());
		button.setActionCommand(position.toString());
		button.addActionListener(aB);
		return button;
	}

	class ButtonAction implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JButton bt = (JButton) e.getSource();
			addToOrder(Integer.parseInt(bt.getActionCommand()));
		}
	}

	private void addToOrder(int position) {
		Product p = mcDonalds.getMenuProducts()[position];
		mcDonalds.addToOrder(p, 1);
		showInList(p);
		getTxtPrice().setText(String.format("Price: %.2f €", mcDonalds.getOrderTotal()));
		getBtnNext1().setEnabled(true);
	}

	// Complete 3
	private void showInList(Product a) {
		if (a.getType().equals("Drink")) {
			modelDrinks.addElement(a);
		} else {
			modelFood.addElement(a);
		}
	}

	private void showPn1() {
		((CardLayout) getPnBts().getLayout()).show(pnBts, "pnMain");
		((CardLayout) getPnContents().getLayout()).show(pnContents, "pn1");
	}

	private void showPn2() {
		((CardLayout) getPnBts().getLayout()).show(pnBts, "pnRegistry");
		((CardLayout) getPnContents().getLayout()).show(pnContents, "pn2");
	}

	private void showPn3() {
		
		if (checkFields()) { 
			((CardLayout) getPnBts().getLayout()).show(pnBts, "pnConfirmation");
			((CardLayout) getPnContents().getLayout()).show(pnContents, "pn3");
		}
	}
	
	private JPanel getPnBts1() {
		if (pnBts1 == null) {
			pnBts1 = new JPanel();
			pnBts1.setBackground(Color.WHITE);
			pnBts1.setLayout(new GridLayout(1, 3, 0, 0));
		}
		return pnBts1;
	}

	private JPanel getPnBts2() {
		if (pnBts2 == null) {
			pnBts2 = new JPanel();
			pnBts2.setBackground(Color.WHITE);
			pnBts2.setLayout(new GridLayout(1, 3, 0, 0));
		}
		return pnBts2;
	}

	private JPanel getPnBts3() {
		if (pnBts3 == null) {
			pnBts3 = new JPanel();
			pnBts3.setBackground(Color.WHITE);
			pnBts3.setLayout(new GridLayout(1, 3, 0, 0));
		}
		return pnBts3;
	}

	private JPanel getPnContents() {
		if (pnContents == null) {
			pnContents = new JPanel();
			pnContents.setLayout(new CardLayout(0, 0));
			pnContents.add(getPn1(), "pn1");
			pnContents.add(getPn2(), "pn2");
			pnContents.add(getPn3(), "pn3");
		}
		return pnContents;
	}

	private JPanel getPn2() {
		if (pn2 == null) {
			pn2 = new JPanel();
			pn2.setBackground(Color.WHITE);
			pn2.setLayout(new BorderLayout(0, 0));
			pn2.add(getPnForm(), BorderLayout.CENTER);
			pn2.add(getPnInfo2(), BorderLayout.SOUTH);
		}
		return pn2;
	}

	private JPanel getPn3() {
		if (pn3 == null) {
			pn3 = new JPanel();
			pn3.setBackground(Color.WHITE);
			pn3.setLayout(new BorderLayout(0, 0));
			pn3.add(getPnConfirmationBts());
			pn3.add(getPnInfo3(), BorderLayout.SOUTH);
		}
		return pn3;
	}

	private JComboBox<String> getCbYears() {
		if (cbYears == null) {
			String[] years = new String[90];
			for (int i = 0; i < 90; i++) {
				String year = "" + ((90 - i) + 1920);
				years[i] = year;
			}
			cbYears = new JComboBox<String>();
			cbYears.setFont(new Font("Arial", Font.PLAIN, 14));
			cbYears.setModel(new DefaultComboBoxModel<String>(years));
			cbYears.setBounds(new Rectangle(193, 77, 157, 25));
		}
		return cbYears;
	}

	private boolean isEmpty() {
		return (txtName.getText().equals("")
				|| (String.valueOf(psw1.getPassword()).equals("")) || (String
					.valueOf(psw2.getPassword()).equals("")));

	}

	private boolean isWrong() {
		return (!String.valueOf(psw1.getPassword()).equals(
				String.valueOf(psw2.getPassword())));
	}

	private JPanel getPnCustomerInfo() {
		if (pnCustonerInfo == null) {
			pnCustonerInfo = new JPanel();
			pnCustonerInfo.setBounds(104, 58, 558, 224);
			pnCustonerInfo.setBorder(new TitledBorder(null,
					"Customer Information", TitledBorder.LEADING,
					TitledBorder.TOP, null, null));
			pnCustonerInfo.setBackground(Color.WHITE);
			pnCustonerInfo.setLayout(null);
			pnCustonerInfo.add(getLbName());
			pnCustonerInfo.add(getTxtName());
			pnCustonerInfo.add(getLbYear());
			pnCustonerInfo.add(getCbYears());
			pnCustonerInfo.add(getLbPasw1());
			pnCustonerInfo.add(getPsw1());
			pnCustonerInfo.add(getLbPasw2());
			pnCustonerInfo.add(getPsw2());
		}
		return pnCustonerInfo;
	}

	private JLabel getLbName() {
		if (lblName == null) {
			lblName = new JLabel();
			lblName.setText("Name and Surname:");
			lblName.setFont(new Font("Arial", Font.PLAIN, 14));
			lblName.setDisplayedMnemonic('N');
			lblName.setBounds(30, 31, 132, 20);
		}
		return lblName;
	}

	private JTextField getTxtName() {
		if (txtName == null) {
			txtName = new JTextField();
			txtName.setFont(new Font("Arial", Font.PLAIN, 14));
			txtName.setBounds(193, 24, 330, 25);
		}
		return txtName;
	}

	private JLabel getLbYear() {
		if (lblYear == null) {
			lblYear = new JLabel("Birth Year:");
			lblYear.setFont(new Font("Arial", Font.PLAIN, 14));
			lblYear.setDisplayedMnemonic('A');
			lblYear.setBounds(30, 81, 121, 16);
		}
		return lblYear;
	}

	private JLabel getLbPasw1() {
		if (lbPasw1 == null) {
			lbPasw1 = new JLabel();
			lbPasw1.setText("Password:");
			lbPasw1.setFont(new Font("Arial", Font.PLAIN, 14));
			lbPasw1.setDisplayedMnemonic('P');
			lbPasw1.setBounds(new Rectangle(13, 123, 105, 16));
			lbPasw1.setBounds(30, 129, 105, 16);
		}
		return lbPasw1;
	}

	private JPasswordField getPsw1() {
		if (psw1 == null) {
			psw1 = new JPasswordField();
			psw1.setFont(new Font("Arial", Font.PLAIN, 14));
			psw1.setBounds(new Rectangle(176, 121, 218, 25));
			psw1.setBounds(193, 122, 218, 25);
		}
		return psw1;
	}

	private JLabel getLbPasw2() {
		if (lbPasw2 == null) {
			lbPasw2 = new JLabel();
			lbPasw2.setText("Repeat password:");
			lbPasw2.setFont(new Font("Arial", Font.PLAIN, 14));
			lbPasw2.setDisplayedMnemonic('R');
			lbPasw2.setBounds(new Rectangle(13, 167, 151, 16));
			lbPasw2.setBounds(30, 181, 151, 16);
		}
		return lbPasw2;
	}

	private JPasswordField getPsw2() {
		if (psw2 == null) {
			psw2 = new JPasswordField();
			psw2.setFont(new Font("Arial", Font.PLAIN, 14));
			psw2.setBounds(new Rectangle(176, 163, 218, 25));
			psw2.setBounds(193, 172, 218, 25);
		}
		return psw2;
	}

	public boolean checkFields() {
		if (isEmpty()) {
			JOptionPane.showMessageDialog(null, "Error: Some fields are empty");
			return false;
		} else {
			if (isWrong()) {
				JOptionPane.showMessageDialog(null,
						"Error: Passwords do not match");
				return false;
			}
		}
		return true;
	}


	private JPanel getPn1() {
		if (pn1 == null) {
			pn1 = new JPanel();
			pn1.setLayout(new BorderLayout(0, 0));
			pn1.add(getPnProducts(), BorderLayout.CENTER);
			pn1.add(getPnInfo1(), BorderLayout.SOUTH);
		}
		return pn1;
	}

	private JPanel getPnForm() {
		if (pnForm == null) {
			pnForm = new JPanel();
			pnForm.setBorder(new LineBorder(Color.ORANGE, 4));
			pnForm.setBackground(Color.WHITE);
			pnForm.setLayout(null);
			pnForm.add(getPnCustomerInfo());
			pnForm.add(getPnOrderData());
		}
		return pnForm;
	}

	private JPanel getPnOrderData() {
		if (pnOrderData == null) {
			pnOrderData = new JPanel();
			pnOrderData.setBorder(new TitledBorder(UIManager
					.getBorder("TitledBorder.border"), "Order Information",
					TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0,
							0, 0)));
			pnOrderData.setBackground(Color.WHITE);
			pnOrderData.setBounds(112, 304, 204, 60);
			pnOrderData.add(getRbOnsite());
			pnOrderData.add(getRbTakeAway());
		}
		return pnOrderData;
	}

	private JRadioButton getRbOnsite() {
		if (rbOnsite == null) {
			rbOnsite = new JRadioButton();
			grOrder.add(rbOnsite);
			rbOnsite.setText("On site");
			rbOnsite.setSelected(true);
			rbOnsite.setMnemonic('L');
			rbOnsite.setFont(new Font("Arial", Font.PLAIN, 14));
			rbOnsite.setBounds(new Rectangle(17, 27, 94, 24));
			rbOnsite.setBackground(Color.WHITE);
		}
		return rbOnsite;
	}

	private JRadioButton getRbTakeAway() {
		if (rbTakeAway == null) {
			rbTakeAway = new JRadioButton();
			grOrder.add(rbTakeAway);
			rbTakeAway.setText("Take Away");
			rbTakeAway.setMnemonic('r');
			rbTakeAway.setFont(new Font("Arial", Font.PLAIN, 14));
			rbTakeAway.setBounds(new Rectangle(115, 27, 86, 24));
			rbTakeAway.setBackground(Color.WHITE);
		}
		return rbTakeAway;
	}

	private JPanel getPnInfo2() {
		if (pnInfo2 == null) {
			pnInfo2 = new JPanel();
			pnInfo2.setBackground(Color.WHITE);
			pnInfo2.setLayout(new BorderLayout(0, 0));
			pnInfo2.add(getPnBts2(), BorderLayout.SOUTH);
		}
		return pnInfo2;
	}

	private JPanel getPnConfirmationBts() {
		if (pnConfirmationBts == null) {
			pnConfirmationBts = new JPanel();
			pnConfirmationBts.setBorder(new LineBorder(Color.ORANGE, 4));
			pnConfirmationBts.setBackground(Color.WHITE);
			pnConfirmationBts.setLayout(null);
			pnConfirmationBts.add(getLblAdvise());
			pnConfirmationBts.add(getLbOk());
			pnConfirmationBts.add(getLblCode());
			pnConfirmationBts.add(getTxtCode());
		}
		return pnConfirmationBts;
	}

	private JPanel getPnInfo3() {
		if (pnInfo3 == null) {
			pnInfo3 = new JPanel();
			pnInfo3.setBackground(Color.WHITE);
			pnInfo3.setLayout(new BorderLayout(0, 0));
			pnInfo3.add(getPnBts3(), BorderLayout.SOUTH);
		}
		return pnInfo3;
	}

	private void finish() {
		mcDonalds.saveOrder();
		initialize();
	}

	private JLabel getLblAdvise() {
		if (lblAdvise == null) {
			lblAdvise = new JLabel("Your order is being processed");
			lblAdvise.setFont(new Font("Tahoma", Font.BOLD, 28));
			lblAdvise.setBounds(135, 104, 478, 35);
		}
		return lblAdvise;
	}

	private JLabel getLbOk() {
		if (lbOk == null) {
			lbOk = new JLabel("");
			lbOk.setIcon(new ImageIcon(MainWindow.class
					.getResource("/uo/cpm/mcdonalds/ui/img/ok.png")));
			lbOk.setBounds(50, 91, 73, 52);
		}
		return lbOk;
	}

	private JLabel getLblCode() {
		if (lblCode == null) {
			lblCode = new JLabel("Your delivery code is:");
			lblCode.setFont(new Font("Tahoma", Font.PLAIN, 16));
			lblCode.setBounds(138, 172, 191, 26);
		}
		return lblCode;
	}

	private JTextField getTxtCode() {
		if (txtCode == null) {
			txtCode = new JTextField();
			txtCode.setFont(new Font("Tahoma", Font.PLAIN, 20));
			txtCode.setEditable(false);
			txtCode.setText(FileUtil.setFileName());
			txtCode.setBounds(341, 161, 191, 45);
			txtCode.setColumns(10);
		}
		return txtCode;
	}
	private JPanel getPnSouth() {
		if (pnSouth == null) {
			pnSouth = new JPanel();
			pnSouth.setBackground(Color.WHITE);
			pnSouth.setLayout(new BorderLayout(0, 0));
			pnSouth.add(getPnInfo(), BorderLayout.SOUTH);
			pnSouth.add(getTabbedPane(), BorderLayout.CENTER);
		}
		return pnSouth;
	}
	private JPanel getPnInfo() {
		if (pnInfo == null) {
			pnInfo = new JPanel();
			pnInfo.setBackground(Color.WHITE);
			pnInfo.setLayout(new GridLayout(1, 3, 0, 0));
			pnInfo.add(getTxtPrice());
			pnInfo.add(getPnBts());
		}
		return pnInfo;
	}
	private JTextField getTxtPrice() {
		if (txtPrice == null) {
			txtPrice = new JTextField();
			txtPrice.setText("Price: 0.00 €");
			txtPrice.setForeground(Color.WHITE);
			txtPrice.setFont(new Font("Arial Black", Font.BOLD, 16));
			txtPrice.setEditable(false);
			txtPrice.setColumns(10);
			txtPrice.setBackground(Color.ORANGE);
		}
		return txtPrice;
	}
	private JPanel getPnBts() {
		if (pnBts == null) {
			pnBts = new JPanel();
			pnBts.setLayout(new CardLayout(0, 0));
			pnBts.add(getPnMain(), "pnMain");
			pnBts.add(getPnRegistry(), "pnRegistry");
			pnBts.add(getPnConfirmation(), "pnConfirmation");
		}
		return pnBts;
	}
	private JPanel getPnMain() {
		if (pnMain == null) {
			pnMain = new JPanel();
			pnMain.setLayout(new GridLayout(1, 2, 0, 0));
			pnMain.add(getBtnCancel1());
			pnMain.add(getBtnNext1());
		}
		return pnMain;
	}
	private JButton getBtnCancel1() {
		if (btnCancel1 == null) {
			btnCancel1 = new JButton("Cancel");
			btnCancel1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			btnCancel1.setMnemonic('C');
			btnCancel1.setForeground(Color.WHITE);
			btnCancel1.setFont(new Font("Arial Black", Font.PLAIN, 16));
			btnCancel1.setBackground(Color.RED);
		}
		return btnCancel1;
	}
	private JButton getBtnNext1() {
		if (btnNext1 == null) {
			btnNext1 = new JButton("Next");
			btnNext1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showPn2();
				}
			});
			btnNext1.setMnemonic('S');
			btnNext1.setForeground(Color.WHITE);
			btnNext1.setFont(new Font("Arial Black", Font.PLAIN, 16));
			btnNext1.setEnabled(false);
			btnNext1.setBackground(new Color(0, 128, 0));
		}
		return btnNext1;
	}
	private JPanel getPnRegistry() {
		if (pnRegistry == null) {
			pnRegistry = new JPanel();
			pnRegistry.setLayout(new GridLayout(1, 2, 0, 0));
			pnRegistry.add(getBtnBack2());
			pnRegistry.add(getBtnNext2());
		}
		return pnRegistry;
	}
	private JButton getBtnBack2() {
		if (btnBack2 == null) {
			btnBack2 = new JButton("Back");
			btnBack2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showPn1();
				}
			});
			btnBack2.setMnemonic('B');
			btnBack2.setForeground(Color.WHITE);
			btnBack2.setFont(new Font("Arial Black", Font.PLAIN, 16));
			btnBack2.setBackground(Color.RED);
		}
		return btnBack2;
	}
	private JButton getBtnNext2() {
		if (btnNext2 == null) {
			btnNext2 = new JButton("Next");
			btnNext2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showPn3();
				}
			});
			btnNext2.setMnemonic('N');
			btnNext2.setForeground(Color.WHITE);
			btnNext2.setFont(new Font("Arial Black", Font.PLAIN, 16));
			btnNext2.setBackground(new Color(0, 128, 0));
		}
		return btnNext2;
	}
	private JPanel getPnConfirmation() {
		if (pnBtConfirmation == null) {
			pnBtConfirmation = new JPanel();
			pnBtConfirmation.setLayout(new GridLayout(0, 2, 0, 0));
			pnBtConfirmation.add(getBtnBack3());
			pnBtConfirmation.add(getBtnFinish());
		}
		return pnBtConfirmation;
	}
	private JButton getBtnBack3() {
		if (btnBack3 == null) {
			btnBack3 = new JButton("Back");
			btnBack3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					showPn2();
				}
			});
			btnBack3.setMnemonic('B');
			btnBack3.setForeground(Color.WHITE);
			btnBack3.setFont(new Font("Arial Black", Font.PLAIN, 16));
			btnBack3.setBackground(Color.RED);
		}
		return btnBack3;
	}
	private JButton getBtnFinish() {
		if (btnFinish == null) {
			btnFinish = new JButton("Finish");
			btnFinish.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					finish();
				}
			});
			btnFinish.setMnemonic('F');
			btnFinish.setForeground(Color.WHITE);
			btnFinish.setFont(new Font("Arial Black", Font.PLAIN, 16));
			btnFinish.setBackground(new Color(0, 128, 0));
		}
		return btnFinish;
	}
	private JTabbedPane getTabbedPane() {
		if (tabbedPane == null) {
			tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			tabbedPane.addTab("Food", null, getSPFood(), null);
			tabbedPane.addTab("Drinks", null, getSPDrinks(), null);
			tabbedPane.setMnemonicAt(0, KeyEvent.VK_F);
			tabbedPane.setMnemonicAt(1, KeyEvent.VK_D);
		}
		return tabbedPane;
	}
	private JScrollPane getSPDrinks() {
		if (sPDrinks == null) {
			sPDrinks = new JScrollPane();
			sPDrinks.setViewportView(getListDrinks());
		}
		return sPDrinks;
	}
	private JScrollPane getSPFood() {
		if (sPFood == null) {
			sPFood = new JScrollPane();
			sPFood.setViewportView(getListFood());
		}
		return sPFood;
	}
	private JList<Product> getListDrinks() {
		if (listDrinks == null) {
			modelDrinks = new DefaultListModel<Product>();
			listDrinks = new JList<Product>(modelDrinks);
			listDrinks.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					if (e.getKeyCode() == KeyEvent.VK_DELETE) {
						if (listDrinks.getSelectedIndex() != -1) {modelDrinks.remove(listDrinks.getSelectedIndex());}
					}
				}
			});
		}
		return listDrinks;
	}
	private JList<Product> getListFood() {
		if (listFood == null) {
			modelFood = new DefaultListModel<Product>();
			listFood = new JList<Product>(modelFood);
			listFood.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					if (e.getKeyCode() == KeyEvent.VK_DELETE || e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
						if (listFood.getSelectedIndex() != -1) {modelFood.remove(listFood.getSelectedIndex());}
					}
				}
			});
		}
		return listFood;
	}
	private ImageIcon loadResizedIcon(String resourcePath, int maxWidth, int maxHeight) { 
		 ImageIcon originalIcon = new ImageIcon(getClass().getResource(resourcePath)); 
		 int originalWidth = originalIcon.getIconWidth(); 
		 int originalHeight = originalIcon.getIconHeight(); 
		 
		 // Resize only if the original image exceeds max dimensions 
		 if (originalWidth > maxWidth || originalHeight > maxHeight) { 
		 // Calculate scaled dimensions while maintaining aspect ratio 
		 double widthRatio = (double) maxWidth / originalWidth; 
		 double heightRatio = (double) maxHeight / originalHeight; 
		 double scaleFactor = Math.min(widthRatio, heightRatio); 
		 
		 int newWidth = (int) (originalWidth * scaleFactor); 
		 int newHeight = (int) (originalHeight * scaleFactor); 

		 // Resize the image 
		 Image resizedImage = originalIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH); 
		 return new ImageIcon(resizedImage); 
		 } 
		 return originalIcon; // Return original icon if no resizing is needed 
		} 
	private JPanel getPanelFilter() {
		if (panelFilter == null) {
			panelFilter = new JPanel();
			panelFilter.setLayout(new GridLayout(0, 1, 0, 0));
			panelFilter.add(getBtnBurgers());
			panelFilter.add(getBtnDrinks());
			panelFilter.add(getBtnSides());
			panelFilter.add(getBtnDesserts());
			panelFilter.add(getBtnRemoveFilter());
		}
		return panelFilter;
	}
	private JButton getBtnBurgers() {
		if (btnBurgers == null) {
			btnBurgers = new JButton("Burgers");
			btnBurgers.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					applyFilter(TypeOfProduct.Burger);
				}
			});
			btnBurgers.setHorizontalTextPosition(SwingConstants.CENTER);
			btnBurgers.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnBurgers.setIcon(loadResizedIcon("/uo/cpm/mcdonalds/ui/img/HA03.png", 70, 70));
		}
		return btnBurgers;
	}
	private JButton getBtnDrinks() {
		if (btnDrinks == null) {
			btnDrinks = new JButton("Drinks");
			btnDrinks.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					applyFilter(TypeOfProduct.Drink);
				}
			});
			btnDrinks.setHorizontalTextPosition(SwingConstants.CENTER);
			btnDrinks.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnDrinks.setIcon(loadResizedIcon("/uo/cpm/mcdonalds/ui/img/BE03.png", 70, 70));
		}
		return btnDrinks;
	}
	private JButton getBtnSides() {
		if (btnSides == null) {
			btnSides = new JButton("Sides");
			btnSides.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					applyFilter(TypeOfProduct.Side);
				}
			});
			btnSides.setHorizontalTextPosition(SwingConstants.CENTER);
			btnSides.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnSides.setIcon(loadResizedIcon("/uo/cpm/mcdonalds/ui/img/CO05.png", 70, 70));
		}
		return btnSides;
	}
	private JButton getBtnDesserts() {
		if (btnDesserts == null) {
			btnDesserts = new JButton("Desserts");
			btnDesserts.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					applyFilter(TypeOfProduct.Dessert);
				}
			});
			btnDesserts.setHorizontalTextPosition(SwingConstants.CENTER);
			btnDesserts.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnDesserts.setIcon(loadResizedIcon("/uo/cpm/mcdonalds/ui/img/PO04.png", 70, 70));
		}
		return btnDesserts;
	}
	
	private void applyFilter(TypeOfProduct type) {
		disableProductsByType(type);
	}
	
	private void enableAllProducts() {
		for (Component c : getPnProducts().getComponents()) {
			if (c instanceof JButton) {
				JButton b = (JButton) c;
				b.setEnabled(true);
			}
		}
	}
	
	private void disableProductsByType(TypeOfProduct type) {
		for (int i = 0; i < pnProducts.getComponents().length; i++) {
			JButton boton = (JButton) (pnProducts.getComponents()[i]);
			boton.setEnabled(type.equals(TypeOfProduct.valueOf(mcDonalds.getMenuProducts()[i].getType())));
		}
	}
	private JButton getBtnRemoveFilter() {
		if (btnRemoveFilter == null) {
			btnRemoveFilter = new JButton("Remove Filter");
			btnRemoveFilter.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					enableAllProducts();
				}
			});
		}
		return btnRemoveFilter;
	}
}
