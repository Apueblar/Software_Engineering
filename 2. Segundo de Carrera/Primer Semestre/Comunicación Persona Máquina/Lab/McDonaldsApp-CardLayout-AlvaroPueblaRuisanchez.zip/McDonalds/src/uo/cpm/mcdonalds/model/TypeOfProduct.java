package uo.cpm.mcdonalds.model;

public enum TypeOfProduct {
	Burger, Drink, Side, Dessert; 
}
